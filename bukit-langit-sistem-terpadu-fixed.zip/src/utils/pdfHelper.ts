import type { FinancialDocument, BusinessSettings } from '../types';

export async function generateDocumentPdf(doc: FinancialDocument, settings?: BusinessSettings): Promise<void> {
  try {
    const { default: html2canvas } = await import('html2canvas-pro');
    const { jsPDF } = await import('jspdf');

    const element = document.getElementById('document-preview-container');
    if (!element) {
      throw new Error('Preview container not found. Please make sure the document preview is visible.');
    }

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
    });

    const imgWidth = 210;
    const pageHeight = 297;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    const pdf = new jsPDF('p', 'mm', 'a4');
    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position -= pageHeight;
      pdf.addPage();
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    const fileName = `${doc.documentType}_${doc.documentNumber || doc.id}.pdf`.replace(/\//g, '-');
    pdf.save(fileName);
  } catch (err) {
    console.error('PDF generation failed:', err);
    throw err;
  }
}
