import type { FinancialDocument, DocumentType } from '../types';
import * as XLSX from 'xlsx';

export interface ModuleTemplate {
  key: string;
  label: string;
  headers: string[];
  sampleRow: Record<string, string>;
  mapFn: (row: Record<string, any>) => Partial<FinancialDocument>;
}

export const MODULE_TEMPLATES: Record<string, ModuleTemplate> = {
  documents: {
    key: 'documents',
    label: 'Dokumen Keuangan',
    headers: [
      'documentType', 'documentNumber', 'documentTitle', 'clientName',
      'clientCompany', 'documentDate', 'totalAmount', 'notes',
    ],
    sampleRow: {
      documentType: 'invoice',
      documentNumber: 'INV/2024/001',
      documentTitle: 'Invoice Reservasi',
      clientName: 'John Doe',
      clientCompany: 'PT Contoh',
      documentDate: '2024-01-15',
      totalAmount: '1500000',
      notes: 'Catatan opsional',
    },
    mapFn: (row) => ({
      documentType: (row.documentType || 'invoice') as DocumentType,
      documentNumber: row.documentNumber || '',
      documentTitle: row.documentTitle || '',
      clientName: row.clientName || '',
      clientCompany: row.clientCompany || '',
      documentDate: row.documentDate || '',
      totalAmount: Number(row.totalAmount) || 0,
      grandTotal: Number(row.totalAmount) || 0,
      notes: row.notes || '',
      status: 'draft' as const,
    }),
  },
  bookings: {
    key: 'bookings',
    label: 'Booking Hotel',
    headers: [
      'guestName', 'phone', 'roomType', 'checkInDate', 'checkOutDate',
      'nights', 'totalPrice', 'source',
    ],
    sampleRow: {
      guestName: 'Jane Doe',
      phone: '081234567890',
      roomType: 'Deluxe',
      checkInDate: '2024-02-01',
      checkOutDate: '2024-02-03',
      nights: '2',
      totalPrice: '3000000',
      source: 'Direct',
    },
    mapFn: (row) => ({
      documentType: 'invoice' as DocumentType,
      clientName: row.guestName || '',
      documentTitle: `Booking ${row.guestName || ''}`,
      totalAmount: Number(row.totalPrice) || 0,
      grandTotal: Number(row.totalPrice) || 0,
      notes: `Room: ${row.roomType || '-'}, ${row.checkInDate} - ${row.checkOutDate}`,
    }),
  },
};

export function downloadExcelTemplate(moduleKey: string): void {
  const template = MODULE_TEMPLATES[moduleKey];
  if (!template) {
    alert(`Template untuk modul "${moduleKey}" tidak ditemukan.`);
    return;
  }

  const wb = XLSX.utils.book_new();
  const data = [template.headers, template.headers.map((h) => template.sampleRow[h] || '')];
  const ws = XLSX.utils.aoa_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, template.label);
  XLSX.writeFile(wb, `template_${moduleKey}.xlsx`);
}

export function mapExcelRowsToDocuments(
  moduleKey: string,
  rows: Record<string, any>[],
): Partial<FinancialDocument>[] {
  const template = MODULE_TEMPLATES[moduleKey];
  if (!template) return [];
  return rows.map((row) => template.mapFn(row));
}
