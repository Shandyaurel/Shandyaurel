import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  writeBatch,
  Timestamp,
  limit,
} from 'firebase/firestore';
import type {
  Booking,
  ATVBooking,
  BreakfastRecord,
  BreakfastBulkEditHistoryItem,
  ExtraIncomeItem,
  ExtraServiceCatalogItem,
  InventoryItem,
  InventoryLog,
  AgentFee,
  FinancialDocument,
  ClientContact,
  CombinedOrder,
  RundownEvent,
  Quotation,
  OfferPackage,
  BusinessSettings,
  MonthlyTarget,
  SystemLog,
} from '../types';
import type { Lead } from '../types/document';

const firebaseConfig = (window as any).__FIREBASE_CONFIG__ ||
  JSON.parse(document.getElementById('firebase-config')?.textContent || '{}');

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const db = getFirestore(app);

export interface BulkImportResult {
  success: number;
  failed: number;
  errors: string[];
}

const CALENDAR_TOKEN_KEY = 'bukit_langit_gcal_token';

export function getCalendarAccessToken(): string | null {
  try {
    return localStorage.getItem(CALENDAR_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setCalendarAccessToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(CALENDAR_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(CALENDAR_TOKEN_KEY);
    }
  } catch {}
}

export async function authorizeGoogleCalendar(): Promise<string | null> {
  return null;
}

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

function subscribe<T>(collectionName: string, callback: (items: T[]) => void, sortField = 'createdAt'): () => void {
  const q = query(collection(db, collectionName), orderBy(sortField, 'desc'));
  return onSnapshot(q, (snapshot) => {
    const items = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as T));
    callback(items);
  }, (err) => {
    console.error(`Error subscribing to ${collectionName}:`, err);
  });
}

async function saveItem(collectionName: string, data: any, userEmail?: string): Promise<string> {
  const id = data.id || generateId(collectionName);
  const now = new Date().toISOString();
  const payload = {
    ...data,
    id,
    updatedAt: now,
    ...(data.createdAt ? {} : { createdAt: now }),
    ...(userEmail && !data.createdBy ? { createdBy: userEmail } : {}),
  };
  await setDoc(doc(db, collectionName, id), payload);
  return id;
}

async function deleteItem(collectionName: string, id: string): Promise<void> {
  await deleteDoc(doc(db, collectionName, id));
}

// Business Settings
export async function getBusinessSettings(): Promise<BusinessSettings> {
  const ref = doc(db, 'settings', 'business');
  const snap = await getDoc(ref);
  if (snap.exists()) return snap.data() as BusinessSettings;
  return { businessName: 'Bukit Langit', tagline: 'Sistem Terpadu' };
}

export async function saveBusinessSettings(settings: BusinessSettings): Promise<void> {
  await setDoc(doc(db, 'settings', 'business'), { ...settings, updatedAt: new Date().toISOString() });
  window.dispatchEvent(new Event('business_settings_updated'));
}

// Bookings
export function subscribeBookings(callback: (items: Booking[]) => void): () => void {
  return subscribe<Booking>('bookings', callback);
}

export async function saveBooking(data: Partial<Booking>, userEmail: string): Promise<string> {
  return saveItem('bookings', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteBooking(bookingOrId: Booking | string, _userEmail?: string, _reason?: string): Promise<void> {
  const id = typeof bookingOrId === 'string' ? bookingOrId : bookingOrId.id;
  return deleteItem('bookings', id);
}

export async function deleteBookingsBatch(bookingsOrIds: Booking[] | string[], _userEmail?: string, _reason?: string): Promise<void> {
  const batch = writeBatch(db);
  (bookingsOrIds as any[]).forEach((item) => {
    const id = typeof item === 'string' ? item : item.id;
    batch.delete(doc(db, 'bookings', id));
  });
  await batch.commit();
}

// ATV Bookings
export function subscribeATVBookings(callback: (items: ATVBooking[]) => void): () => void {
  return subscribe<ATVBooking>('atvBookings', callback);
}

export async function saveATVBooking(data: Partial<ATVBooking>, userEmail: string): Promise<string> {
  return saveItem('atvBookings', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteATVBooking(bookingOrId: ATVBooking | string, _userEmail?: string, _reason?: string): Promise<void> {
  const id = typeof bookingOrId === 'string' ? bookingOrId : bookingOrId.id;
  return deleteItem('atvBookings', id);
}

export async function deleteATVBookingsBatch(bookingsOrIds: ATVBooking[] | string[], _userEmail?: string, _reason?: string): Promise<void> {
  const batch = writeBatch(db);
  (bookingsOrIds as any[]).forEach((item) => {
    const id = typeof item === 'string' ? item : item.id;
    batch.delete(doc(db, 'atvBookings', id));
  });
  await batch.commit();
}

// Breakfast Records
export function subscribeBreakfast(callback: (items: BreakfastRecord[]) => void): () => void {
  return subscribe<BreakfastRecord>('breakfast', callback);
}

export async function saveBreakfast(data: Partial<BreakfastRecord>, userEmail: string): Promise<string> {
  return saveItem('breakfast', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteBreakfast(id: string): Promise<void> {
  return deleteItem('breakfast', id);
}

export async function bulkUpdateBreakfastRecords(
  updates: Array<{ id: string; data: Partial<BreakfastRecord> }>,
  historyEntry: Omit<BreakfastBulkEditHistoryItem, 'id'>,
): Promise<void> {
  const batch = writeBatch(db);
  const now = new Date().toISOString();
  updates.forEach(({ id, data }) => {
    batch.update(doc(db, 'breakfast', id), { ...data, updatedAt: now });
  });
  const historyId = generateId('bfh');
  batch.set(doc(db, 'breakfastBulkHistory', historyId), { ...historyEntry, id: historyId });
  await batch.commit();
}

export function subscribeBreakfastBulkHistory(callback: (items: BreakfastBulkEditHistoryItem[]) => void): () => void {
  return subscribe<BreakfastBulkEditHistoryItem>('breakfastBulkHistory', callback, 'editedAt');
}

export function getBreakfastBulkHistoryLocal(): BreakfastBulkEditHistoryItem[] {
  try {
    const raw = localStorage.getItem('bukit_langit_bf_bulk_history');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function syncAllBookingsToBreakfast(bookings: Booking[], userEmail: string): Promise<number> {
  let count = 0;
  for (const booking of bookings) {
    if (booking.includeBreakfast && booking.status !== 'Cancelled') {
      await saveBreakfast(
        {
          bookingId: booking.id,
          guestName: booking.guestName,
          guestPhone: booking.guestPhone,
          roomType: booking.rooms?.[0]?.roomType || booking.roomType || '',
          paxCount: booking.breakfastPaxPerNight,
          date: booking.checkInDate,
          status: 'Pending',
        },
        userEmail,
      );
      count++;
    }
  }
  return count;
}

// Extra Income
export function subscribeExtraIncome(callback: (items: ExtraIncomeItem[]) => void): () => void {
  return subscribe<ExtraIncomeItem>('extraIncome', callback);
}

export async function saveExtraIncome(data: Partial<ExtraIncomeItem>, userEmail: string): Promise<string> {
  return saveItem('extraIncome', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteExtraIncome(id: string): Promise<void> {
  return deleteItem('extraIncome', id);
}

// Extra Service Catalog
export function subscribeExtraServiceCatalog(callback: (items: ExtraServiceCatalogItem[]) => void): () => void {
  return subscribe<ExtraServiceCatalogItem>('extraServiceCatalog', callback);
}

export async function saveExtraServiceCatalogItem(data: Partial<ExtraServiceCatalogItem>): Promise<string> {
  return saveItem('extraServiceCatalog', data);
}

export async function deleteExtraServiceCatalogItem(id: string): Promise<void> {
  return deleteItem('extraServiceCatalog', id);
}

// Inventory
export function subscribeInventoryItems(callback: (items: InventoryItem[]) => void): () => void {
  return subscribe<InventoryItem>('inventory', callback);
}

export async function saveInventoryItem(data: Partial<InventoryItem>): Promise<string> {
  return saveItem('inventory', data);
}

export async function deleteInventoryItem(id: string): Promise<void> {
  return deleteItem('inventory', id);
}

export function subscribeInventoryLogs(callback: (items: InventoryLog[]) => void): () => void {
  return subscribe<InventoryLog>('inventoryLogs', callback);
}

export async function recordInventoryMovement(log: Partial<InventoryLog>, itemId: string, newStock: number): Promise<void> {
  const logId = generateId('invlog');
  const now = new Date().toISOString();
  const batch = writeBatch(db);
  batch.set(doc(db, 'inventoryLogs', logId), { ...log, id: logId, createdAt: now });
  batch.update(doc(db, 'inventory', itemId), { currentStock: newStock, updatedAt: now });
  await batch.commit();
}

// Agent Fees
export function subscribeAgentFees(callback: (items: AgentFee[]) => void): () => void {
  return subscribe<AgentFee>('agentFees', callback);
}

export async function saveAgentFee(data: Partial<AgentFee>, userEmail: string): Promise<string> {
  return saveItem('agentFees', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteAgentFee(id: string): Promise<void> {
  return deleteItem('agentFees', id);
}

export async function approveAgentFee(id: string, approvedBy: string): Promise<void> {
  await updateDoc(doc(db, 'agentFees', id), {
    status: 'Approved',
    approvedBy,
    updatedAt: new Date().toISOString(),
  });
}

export async function rejectAgentFee(id: string, rejectedBy: string, reason: string): Promise<void> {
  await updateDoc(doc(db, 'agentFees', id), {
    status: 'Rejected',
    rejectedBy,
    rejectionReason: reason,
    updatedAt: new Date().toISOString(),
  });
}

export async function batchMarkAgentFeesAsPaid(
  ids: string[],
  paymentMethod: string,
  paidDate: string,
): Promise<void> {
  const batch = writeBatch(db);
  const now = new Date().toISOString();
  ids.forEach((id) => {
    batch.update(doc(db, 'agentFees', id), {
      status: 'Paid',
      paymentMethod,
      paidDate,
      updatedAt: now,
    });
  });
  await batch.commit();
}

// Financial Documents
export function subscribeDocuments(callback: (items: FinancialDocument[]) => void): () => void {
  return subscribe<FinancialDocument>('documents', callback);
}

export async function saveDocument(data: Partial<FinancialDocument>, userEmail?: string): Promise<string> {
  return saveItem('documents', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteDocument(id: string): Promise<void> {
  return deleteItem('documents', id);
}

export async function generateNextDocumentNumber(prefix: string): Promise<string> {
  const q = query(collection(db, 'documents'), orderBy('createdAt', 'desc'), limit(1));
  const snap = await getDocs(q);

  const now = new Date();
  const monthRoman = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'][now.getMonth()];
  const year = now.getFullYear();
  let nextNum = 1;

  if (!snap.empty) {
    const lastDoc = snap.docs[0].data() as FinancialDocument;
    const parts = lastDoc.documentNumber?.split('/');
    if (parts && parts.length > 0) {
      const num = parseInt(parts[0], 10);
      if (!isNaN(num)) nextNum = num + 1;
    }
  }

  return `${String(nextNum).padStart(4, '0')}/${prefix}/${monthRoman}/${year}`;
}

export async function bulkImportDocuments(documents: Partial<FinancialDocument>[]): Promise<BulkImportResult> {
  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const d of documents) {
    try {
      await saveDocument(d);
      success++;
    } catch (err) {
      failed++;
      errors.push(`Failed to import document: ${(err as Error).message}`);
    }
  }

  return { success, failed, errors };
}

// Partners
export function subscribePartners(callback: (items: ClientContact[]) => void): () => void {
  return subscribe<ClientContact>('partners', callback);
}

export async function savePartner(data: Partial<ClientContact>): Promise<string> {
  return saveItem('partners', data);
}

export async function deletePartner(id: string): Promise<void> {
  return deleteItem('partners', id);
}

export async function addPartnerFollowUpLog(partnerId: string, log: any): Promise<void> {
  const ref = doc(db, 'partners', partnerId);
  const snap = await getDoc(ref);
  if (snap.exists()) {
    const partner = snap.data() as ClientContact;
    const logs = partner.followUpLogs || [];
    logs.push(log);
    await updateDoc(ref, { followUpLogs: logs, updatedAt: new Date().toISOString() });
  }
}

export async function linkPartnerContract(partnerId: string, contractId: string): Promise<void> {
  await updateDoc(doc(db, 'partners', partnerId), {
    contractId,
    updatedAt: new Date().toISOString(),
  });
}

// Leads
export function subscribeLeads(callback: (items: Lead[]) => void): () => void {
  return subscribe<Lead>('leads', callback);
}

export async function saveLead(data: Partial<Lead>, userEmail: string): Promise<string> {
  return saveItem('leads', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteLead(id: string): Promise<void> {
  return deleteItem('leads', id);
}

export async function recordLeadFollowUp(leadId: string, logEntry: any): Promise<void> {
  const ref = doc(db, 'leads', leadId);
  const snap = await getDoc(ref);
  if (snap.exists()) {
    const lead = snap.data() as Lead;
    const logs = lead.activityLog || [];
    logs.push(logEntry);
    await updateDoc(ref, {
      activityLog: logs,
      lastContactedDate: logEntry.date,
      nextFollowUpDate: logEntry.nextFollowUpDate || null,
      updatedAt: new Date().toISOString(),
    });
  }
}

export async function updateLeadStatus(leadId: string, status: string, userEmail: string): Promise<void> {
  await updateDoc(doc(db, 'leads', leadId), {
    status,
    updatedAt: new Date().toISOString(),
  });
}

export async function updateLeadPromoStatus(leadId: string, promoStatus: string, userEmail: string): Promise<void> {
  const now = new Date().toISOString();
  await updateDoc(doc(db, 'leads', leadId), {
    promoStatus,
    promoSentAt: promoStatus === 'sent' ? now : undefined,
    promoSentBy: promoStatus === 'sent' ? userEmail : undefined,
    updatedAt: now,
  });
}

export async function updateLeadsPromoStatusBatch(leadIds: string[], promoStatus: string, userEmail: string): Promise<void> {
  const batch = writeBatch(db);
  const now = new Date().toISOString();
  leadIds.forEach((id) => {
    batch.update(doc(db, 'leads', id), {
      promoStatus,
      promoSentAt: promoStatus === 'sent' ? now : undefined,
      promoSentBy: promoStatus === 'sent' ? userEmail : undefined,
      updatedAt: now,
    });
  });
  await batch.commit();
}

// Influencers
export function subscribeInfluencers(callback: (items: any[]) => void): () => void {
  return subscribe('influencers', callback);
}

export async function saveInfluencer(data: any, userEmail: string): Promise<string> {
  return saveItem('influencers', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteInfluencer(id: string): Promise<void> {
  return deleteItem('influencers', id);
}

export async function updateInfluencerStatus(id: string, status: string): Promise<void> {
  await updateDoc(doc(db, 'influencers', id), { status, updatedAt: new Date().toISOString() });
}

export async function updateInfluencerRating(id: string, rating: number): Promise<void> {
  await updateDoc(doc(db, 'influencers', id), { rating, updatedAt: new Date().toISOString() });
}

// Combined Orders
export function subscribeCombinedOrders(callback: (items: CombinedOrder[]) => void): () => void {
  return subscribe<CombinedOrder>('combinedOrders', callback);
}

export async function saveCombinedOrder(data: Partial<CombinedOrder>, userEmail: string): Promise<string> {
  return saveItem('combinedOrders', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteCombinedOrder(id: string): Promise<void> {
  return deleteItem('combinedOrders', id);
}

export async function deleteCombinedOrdersBatch(ids: string[]): Promise<void> {
  const batch = writeBatch(db);
  ids.forEach((id) => batch.delete(doc(db, 'combinedOrders', id)));
  await batch.commit();
}

// Rundown Events
export function subscribeRundownEvents(callback: (items: RundownEvent[]) => void): () => void {
  return subscribe<RundownEvent>('rundownEvents', callback);
}

export async function saveRundownEvent(data: Partial<RundownEvent>, userEmail: string): Promise<string> {
  return saveItem('rundownEvents', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteRundownEvent(id: string): Promise<void> {
  return deleteItem('rundownEvents', id);
}

// Quotations
export function subscribeQuotations(callback: (items: Quotation[]) => void): () => void {
  return subscribe<Quotation>('quotations', callback);
}

export async function saveQuotation(data: Partial<Quotation>, userEmail: string): Promise<string> {
  return saveItem('quotations', { ...data, createdBy: data.createdBy || userEmail }, userEmail);
}

export async function deleteQuotation(id: string): Promise<void> {
  return deleteItem('quotations', id);
}

export async function convertQuotationToDeal(quotationId: string, userEmail: string): Promise<void> {
  await updateDoc(doc(db, 'quotations', quotationId), {
    status: 'Converted',
    updatedAt: new Date().toISOString(),
  });
}

// Offer Packages
export function subscribeOfferPackages(callback: (items: OfferPackage[]) => void): () => void {
  return subscribe<OfferPackage>('offerPackages', callback);
}

export async function saveOfferPackage(data: Partial<OfferPackage>): Promise<string> {
  return saveItem('offerPackages', data);
}

export async function deleteOfferPackage(id: string): Promise<void> {
  return deleteItem('offerPackages', id);
}

// Monthly Target
export function subscribeMonthlyTarget(monthPrefix: string, callback: (target: MonthlyTarget | null) => void): () => void {
  const ref = doc(db, 'monthlyTargets', monthPrefix);
  return onSnapshot(ref, (snap) => {
    if (snap.exists()) {
      callback({ id: snap.id, ...snap.data() } as MonthlyTarget);
    } else {
      callback(null);
    }
  });
}

// System Logs
export function subscribeSystemLogs(callback: (items: SystemLog[]) => void): () => void {
  return subscribe<SystemLog>('systemLogs', callback, 'timestamp');
}

// Rundown Helpers
export function parseTimeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTimeString(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function getRundownItemDays(items: RundownEvent['items']): number[] {
  const days = new Set<number>();
  items.forEach((item) => days.add(item.day || 1));
  return Array.from(days).sort((a, b) => a - b);
}
