import type { Booking, ATVBooking, BusinessSettings, OperationalCalendar } from '../types';

export function buildGoogleCalendarEmbedUrl(
  _calendarId: string,
  _timezone: string,
  _viewMode: string,
  _operationalCalendars?: OperationalCalendar[],
): string {
  return '';
}

export function getDirectGoogleCalendarWebUrl(_calendarId: string): string {
  return '';
}

export async function listGoogleCalendarEvents(_params: any): Promise<any[]> {
  return [];
}

export async function createGoogleCalendarEvent(_params: any): Promise<string> {
  return '';
}

export async function deleteGoogleCalendarEvent(_params: any): Promise<void> {}

export async function syncBookingToGoogleCalendar(_booking: Booking, _settings: BusinessSettings, _token: string): Promise<string | null> {
  return null;
}

export async function syncATVBookingToGoogleCalendar(_atv: ATVBooking, _settings: BusinessSettings, _token: string): Promise<string | null> {
  return null;
}
