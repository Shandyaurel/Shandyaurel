import type { FinancialDocument } from '../types';

export function executePrintDocument(doc: FinancialDocument): void {
  const previewEl = document.getElementById('document-preview-container');
  if (!previewEl) {
    alert('Preview dokumen tidak ditemukan. Pastikan preview terlihat di layar.');
    return;
  }

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Popup diblokir oleh browser. Izinkan popup untuk mencetak dokumen.');
    return;
  }

  const styles = Array.from(document.styleSheets)
    .map((sheet) => {
      try {
        return Array.from(sheet.cssRules).map((rule) => rule.cssText).join('\n');
      } catch {
        return '';
      }
    })
    .join('\n');

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>${doc.documentTitle || 'Dokumen'} - ${doc.documentNumber || ''}</title>
      <style>
        ${styles}
        @media print {
          body { margin: 0; padding: 0; }
          @page { margin: 10mm; }
        }
        body { font-family: 'Inter', system-ui, sans-serif; background: white; }
      </style>
    </head>
    <body>
      ${previewEl.outerHTML}
    </body>
    </html>
  `);

  printWindow.document.close();
  setTimeout(() => {
    printWindow.print();
    printWindow.close();
  }, 500);
}
