import type { BreakfastRecord, BusinessSettings } from '../types';

export function printBreakfastVouchers(records: BreakfastRecord[], settings?: BusinessSettings): void {
  const businessName = settings?.businessName || 'Bukit Langit Campventure';
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Popup diblokir oleh browser.');
    return;
  }

  const vouchersHtml = records.map((r, i) => `
    <div style="border: 2px dashed #334155; border-radius: 12px; padding: 24px; margin-bottom: 16px; page-break-inside: avoid; max-width: 400px;">
      <div style="text-align: center; margin-bottom: 12px;">
        <h2 style="margin: 0; font-size: 16px; color: #1e293b;">${businessName}</h2>
        <p style="margin: 4px 0 0; font-size: 11px; color: #64748b;">VOUCHER BREAKFAST</p>
      </div>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 12px 0;" />
      <table style="width: 100%; font-size: 13px; color: #334155;">
        <tr><td style="padding: 4px 0; color: #94a3b8;">Tamu:</td><td style="padding: 4px 0; font-weight: bold;">${r.guestName}</td></tr>
        <tr><td style="padding: 4px 0; color: #94a3b8;">Tanggal:</td><td style="padding: 4px 0;">${r.date}</td></tr>
        <tr><td style="padding: 4px 0; color: #94a3b8;">Kamar:</td><td style="padding: 4px 0;">${r.roomType || '-'}</td></tr>
        <tr><td style="padding: 4px 0; color: #94a3b8;">Jumlah Pax:</td><td style="padding: 4px 0; font-weight: bold;">${r.paxCount} orang</td></tr>
        ${r.menuNotes ? `<tr><td style="padding: 4px 0; color: #94a3b8;">Menu:</td><td style="padding: 4px 0;">${r.menuNotes}</td></tr>` : ''}
      </table>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 12px 0;" />
      <p style="text-align: center; font-size: 10px; color: #94a3b8; margin: 0;">Voucher #${i + 1} — Tunjukkan saat sarapan</p>
    </div>
  `).join('');

  printWindow.document.write(`
    <!DOCTYPE html><html><head><title>Voucher Breakfast</title>
    <style>
      body { font-family: 'Inter', system-ui, sans-serif; padding: 20px; background: white; }
      @media print { @page { margin: 10mm; } }
    </style>
    </head><body>${vouchersHtml}</body></html>
  `);

  printWindow.document.close();
  setTimeout(() => { printWindow.print(); printWindow.close(); }, 500);
}

export function printBreakfast(records: BreakfastRecord[], date: string, settings?: BusinessSettings): void {
  const businessName = settings?.businessName || 'Bukit Langit Campventure';
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const totalPax = records.reduce((s, r) => s + r.paxCount, 0);

  const rowsHtml = records.map((r, i) => `
    <tr>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${i + 1}</td>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; font-weight: 600;">${r.guestName}</td>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${r.roomType || '-'}</td>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: center; font-weight: bold;">${r.paxCount}</td>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${r.menuNotes || '-'}</td>
      <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${r.status}</td>
    </tr>
  `).join('');

  printWindow.document.write(`
    <!DOCTYPE html><html><head><title>Daftar Breakfast - ${date}</title>
    <style>
      body { font-family: 'Inter', system-ui, sans-serif; padding: 20px; background: white; }
      table { width: 100%; border-collapse: collapse; font-size: 13px; }
      th { background: #f1f5f9; padding: 10px 8px; text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; border-bottom: 2px solid #cbd5e1; }
      @media print { @page { margin: 10mm; } }
    </style>
    </head><body>
      <h2 style="margin: 0 0 4px; font-size: 18px;">${businessName}</h2>
      <p style="margin: 0 0 16px; color: #64748b; font-size: 13px;">Daftar Breakfast — ${date} — Total: ${totalPax} pax</p>
      <table>
        <thead><tr><th>No</th><th>Nama Tamu</th><th>Kamar</th><th>Pax</th><th>Menu</th><th>Status</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </body></html>
  `);

  printWindow.document.close();
  setTimeout(() => { printWindow.print(); printWindow.close(); }, 500);
}
