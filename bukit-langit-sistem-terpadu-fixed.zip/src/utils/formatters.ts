import type { Booking, ATVBooking, PaymentStatus, BookingRoomItem, ATVTrackItem, PaymentRecord } from '../types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
}

export function formatDateIndo(dateStr: string): string {
  if (!dateStr) return '-';
  try {
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
  } catch {
    return dateStr;
  }
}

export function getTodayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentTimeString(): string {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}

export function calculatePaymentStatus(grandTotal: number, paidAmount: number): PaymentStatus {
  if (paidAmount <= 0) return 'Unpaid';
  if (paidAmount >= grandTotal) return 'Paid';
  if (paidAmount >= grandTotal * 0.5) return 'Partially Paid';
  return 'DP Paid';
}

export function getPaymentStatusBadge(status: PaymentStatus | string): { color: string; bg: string; border: string } {
  switch (status) {
    case 'Paid':
      return { color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200' };
    case 'DP Paid':
    case 'Partially Paid':
      return { color: 'text-blue-700', bg: 'bg-blue-50', border: 'border-blue-200' };
    case 'Unpaid':
      return { color: 'text-rose-700', bg: 'bg-rose-50', border: 'border-rose-200' };
    case 'Overpaid':
      return { color: 'text-purple-700', bg: 'bg-purple-50', border: 'border-purple-200' };
    case 'Refunded':
      return { color: 'text-slate-700', bg: 'bg-slate-50', border: 'border-slate-200' };
    default:
      return { color: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-200' };
  }
}

export const DEFAULT_ROOM_TYPES = [
  { name: 'Standard Room', basePrice: 350000 },
  { name: 'Deluxe Room', basePrice: 500000 },
  { name: 'Family Room', basePrice: 650000 },
  { name: 'Camp Tent', basePrice: 200000 },
  { name: 'Glamping Tent', basePrice: 450000 },
  { name: 'Villa', basePrice: 1200000 },
];

export const DEFAULT_ATV_TRACKS = [
  { name: 'Short Track (30 min)', basePrice: 150000 },
  { name: 'Medium Track (45 min)', basePrice: 250000 },
  { name: 'Long Track (60 min)', basePrice: 350000 },
  { name: 'Extreme Track (90 min)', basePrice: 500000 },
];

export const DEFAULT_BOOKING_SOURCES = ['Walk in', 'WhatsApp', 'Instagram', 'Facebook', 'Website', 'OTA', 'Referral', 'Travel Agent', 'Corporate', 'Other'];

export const DEFAULT_PAYMENT_METHODS = ['Cash / Tunai', 'Transfer BCA', 'Transfer Mandiri', 'Transfer BRI', 'QRIS', 'Kartu Kredit', 'Lainnya'];

export function calculateBookingCalculations(
  rooms: BookingRoomItem[],
  discountType: string,
  discountValue: number,
  taxRate: number,
  paidAmount: number,
): {
  subtotal: number;
  discount: number;
  taxAmount: number;
  grandTotal: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
} {
  const subtotal = rooms.reduce((sum, r) => sum + r.roomPrice * r.roomQty * r.nights, 0);
  let discount = 0;
  if (discountType === 'percentage') discount = Math.round(subtotal * (discountValue / 100));
  else if (discountType === 'fixed') discount = discountValue;

  const afterDiscount = subtotal - discount;
  const taxAmount = Math.round(afterDiscount * (taxRate / 100));
  const grandTotal = afterDiscount + taxAmount;
  const remainingBalance = grandTotal - paidAmount;
  const paymentStatus = calculatePaymentStatus(grandTotal, paidAmount);

  return { subtotal, discount, taxAmount, grandTotal, remainingBalance, paymentStatus };
}

export function calculateATVCalculations(
  tracks: ATVTrackItem[],
  discountType: string,
  discountValue: number,
  taxRate: number,
  paidAmount: number,
): {
  subtotal: number;
  discount: number;
  taxAmount: number;
  grandTotal: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
} {
  const subtotal = tracks.reduce((sum, t) => sum + t.pricePerUnit * t.qty, 0);
  let discount = 0;
  if (discountType === 'percentage') discount = Math.round(subtotal * (discountValue / 100));
  else if (discountType === 'fixed') discount = discountValue;

  const afterDiscount = subtotal - discount;
  const taxAmount = Math.round(afterDiscount * (taxRate / 100));
  const grandTotal = afterDiscount + taxAmount;
  const remainingBalance = grandTotal - paidAmount;
  const paymentStatus = calculatePaymentStatus(grandTotal, paidAmount);

  return { subtotal, discount, taxAmount, grandTotal, remainingBalance, paymentStatus };
}
