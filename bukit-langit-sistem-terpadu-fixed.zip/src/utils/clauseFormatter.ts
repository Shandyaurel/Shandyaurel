import React from 'react';

interface FormatOptions {
  defaultAsBullet?: boolean;
}

export function renderFormattedClauseLines(
  text: string | string[],
  options?: FormatOptions,
): React.ReactNode[] {
  const lines = Array.isArray(text) ? text : text.split('\n').filter((l) => l.trim());

  return lines.map((line, i) => {
    const trimmed = line.trim();
    if (!trimmed) return null;

    const isNumbered = /^\d+[\.\)]/.test(trimmed);
    const isBullet = /^[-•●]/.test(trimmed);
    const isSubItem = /^\s{2,}/.test(line);

    let displayText = trimmed;
    if (isNumbered) {
      displayText = trimmed.replace(/^\d+[\.\)]\s*/, '');
    } else if (isBullet) {
      displayText = trimmed.replace(/^[-•●]\s*/, '');
    }

    const style: React.CSSProperties = {
      marginBottom: '4px',
      paddingLeft: isSubItem ? '24px' : isBullet || isNumbered ? '16px' : '0',
      lineHeight: '1.6',
    };

    if (isNumbered) {
      return React.createElement(
        'div',
        { key: i, style },
        React.createElement('span', { style: { fontWeight: 600, marginRight: '6px' } },
          trimmed.match(/^\d+[\.\)]/)?.[0] || ''),
        displayText,
      );
    }

    if (isBullet || (options?.defaultAsBullet && !isNumbered)) {
      return React.createElement(
        'div',
        { key: i, style },
        React.createElement('span', { style: { marginRight: '6px' } }, '•'),
        displayText,
      );
    }

    return React.createElement('div', { key: i, style }, trimmed);
  });
}

interface ClauseListProps {
  clauses: string | string[];
}

export const ClauseList: React.FC<ClauseListProps> = ({ clauses }) => {
  if (!clauses || (Array.isArray(clauses) && clauses.length === 0)) return null;

  const lines = Array.isArray(clauses) ? clauses : [clauses];

  return React.createElement(
    'div',
    { style: { fontSize: '11px', lineHeight: '1.6', color: '#334155' } },
    lines.map((line, i) => {
      const trimmed = line.trim();
      if (!trimmed) return null;

      const isNumbered = /^\d+[\.\)]/.test(trimmed);

      return React.createElement(
        'div',
        {
          key: i,
          style: {
            marginBottom: '3px',
            paddingLeft: isNumbered ? '0' : '8px',
          },
        },
        isNumbered ? trimmed : `• ${trimmed}`,
      );
    }),
  );
};
