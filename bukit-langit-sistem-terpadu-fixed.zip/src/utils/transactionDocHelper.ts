import type {
  Booking,
  ATVBooking,
  FinancialDocument,
  DocumentType,
  BusinessSettings,
} from '../types';
import { formatRupiah, formatDateIndo } from './formatters';
import { DEFAULT_SETTINGS, getDefaultTermsForDocType } from './storage';

export type SupportedTransaction = Booking | ATVBooking;
export type ModuleType = 'hotel' | 'atv' | 'combined_order' | 'extra_income';

export type WhatsAppTemplateKey =
  | 'booking_confirmation'
  | 'payment_reminder'
  | 'invoice_share'
  | 'receipt_share'
  | 'quotation_share';

export const WHATSAPP_TEMPLATE_KEYS: WhatsAppTemplateKey[] = [
  'booking_confirmation',
  'payment_reminder',
  'invoice_share',
  'receipt_share',
  'quotation_share',
];

export const WHATSAPP_TEMPLATE_LABELS: Record<WhatsAppTemplateKey, string> = {
  booking_confirmation: 'Konfirmasi Booking',
  payment_reminder: 'Pengingat Pembayaran',
  invoice_share: 'Kirim Invoice',
  receipt_share: 'Kirim Kwitansi',
  quotation_share: 'Kirim Penawaran',
};

export const AVAILABLE_DOC_TYPES: { value: DocumentType; label: string }[] = [
  { value: 'invoice', label: 'Invoice' },
  { value: 'receipt', label: 'Kwitansi' },
  { value: 'kwitansi_dp', label: 'Kwitansi DP' },
  { value: 'quotation', label: 'Penawaran Harga' },
  { value: 'proforma', label: 'Proforma Invoice' },
];

export const DEFAULT_WHATSAPP_TEMPLATES: Record<string, string> = {
  booking_confirmation: `Halo {guestName}! 👋\n\nTerima kasih atas reservasi Anda di {businessName}.\n\n📅 Check-in: {checkInDate}\n📅 Check-out: {checkOutDate}\n🏨 Kamar: {roomType}\n💰 Total: {grandTotal}\n\nSampai jumpa! 🌿`,
  payment_reminder: `Halo {guestName},\n\nIni adalah pengingat pembayaran untuk reservasi Anda:\n\n💰 Total: {grandTotal}\n💳 Sudah Dibayar: {paidAmount}\n⏳ Sisa: {remainingBalance}\n\nTerima kasih! 🙏`,
  invoice_share: `Halo {guestName},\n\nBerikut invoice untuk transaksi Anda:\n📄 No: {documentNumber}\n💰 Total: {totalAmount}\n\nTerima kasih! 🌿`,
  receipt_share: `Halo {guestName},\n\nBerikut kwitansi pembayaran Anda:\n📄 No: {documentNumber}\n💰 Dibayar: {totalAmount}\n\nTerima kasih! 🙏`,
  quotation_share: `Halo {guestName},\n\nBerikut penawaran harga dari kami:\n📄 No: {documentNumber}\n💰 Total: {totalAmount}\n\nBerlaku 14 hari. Hubungi kami untuk konfirmasi. 🌿`,
};

function isBooking(t: SupportedTransaction): t is Booking {
  return 'checkInDate' in t && 'roomType' in t;
}

export function extractTransactionData(
  transaction: SupportedTransaction,
  moduleType: ModuleType,
): Record<string, any> {
  if (moduleType === 'hotel' && isBooking(transaction)) {
    return {
      guestName: transaction.guestName || '',
      phone: transaction.phone || '',
      roomType: transaction.roomType || '',
      checkInDate: transaction.checkInDate || '',
      checkOutDate: transaction.checkOutDate || '',
      nights: transaction.nights || 1,
      totalPrice: transaction.totalPrice || 0,
      grandTotal: transaction.grandTotal || transaction.totalPrice || 0,
      paidAmount: transaction.paidAmount || 0,
      remainingBalance: (transaction.grandTotal || transaction.totalPrice || 0) - (transaction.paidAmount || 0),
      source: transaction.source || '',
      notes: transaction.notes || '',
    };
  }

  const atv = transaction as ATVBooking;
  return {
    guestName: atv.customerName || '',
    phone: atv.phone || '',
    totalPrice: atv.totalPrice || 0,
    grandTotal: atv.grandTotal || atv.totalPrice || 0,
    paidAmount: atv.paidAmount || 0,
    remainingBalance: (atv.grandTotal || atv.totalPrice || 0) - (atv.paidAmount || 0),
    date: atv.date || '',
    notes: atv.notes || '',
  };
}

export function interpolateWhatsAppText(
  template: string,
  data: Record<string, any>,
  settings?: BusinessSettings,
): string {
  const s = settings || DEFAULT_SETTINGS;
  const vars: Record<string, string> = {
    ...Object.fromEntries(
      Object.entries(data).map(([k, v]) => [
        k,
        typeof v === 'number' ? formatRupiah(v) : String(v ?? ''),
      ]),
    ),
    businessName: s.businessName || '',
    businessPhone: s.phone || '',
    businessEmail: s.email || '',
  };

  return template.replace(/\{(\w+)\}/g, (_, key) => vars[key] ?? `{${key}}`);
}

export function buildFinancialDocumentFromTransaction(
  transaction: SupportedTransaction,
  moduleType: ModuleType,
  docType: DocumentType,
  docNumber: string,
  settings?: BusinessSettings,
): Partial<FinancialDocument> {
  const data = extractTransactionData(transaction, moduleType);
  const s = settings || DEFAULT_SETTINGS;

  const items = [];
  if (moduleType === 'hotel' && isBooking(transaction)) {
    items.push({
      description: `${data.roomType} - ${data.nights} malam`,
      quantity: data.nights,
      unitPrice: Math.round((data.totalPrice || 0) / (data.nights || 1)),
      amount: data.totalPrice || 0,
    });
  } else {
    items.push({
      description: `ATV Booking - ${data.guestName}`,
      quantity: 1,
      unitPrice: data.totalPrice || 0,
      amount: data.totalPrice || 0,
    });
  }

  return {
    documentType: docType,
    documentNumber: docNumber,
    documentTitle: `${docType === 'invoice' ? 'Invoice' : docType === 'receipt' ? 'Kwitansi' : 'Dokumen'} - ${data.guestName}`,
    documentDate: new Date().toISOString().split('T')[0],
    clientName: data.guestName || '',
    clientPhone: data.phone || '',
    items,
    totalAmount: data.totalPrice || 0,
    grandTotal: data.grandTotal || data.totalPrice || 0,
    paidAmount: docType === 'receipt' ? data.grandTotal || data.totalPrice || 0 : data.paidAmount || 0,
    remainingBalance: docType === 'receipt' ? 0 : data.remainingBalance || 0,
    notes: data.notes || '',
    termsAndConditions: [getDefaultTermsForDocType(docType)],
    status: 'draft',
    businessName: s.businessName,
    businessAddress: s.address,
    businessPhone: s.phone,
    businessEmail: s.email,
  };
}
