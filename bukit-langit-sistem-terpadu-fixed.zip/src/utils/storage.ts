import type { BusinessSettings, KlausulKontrakItem, DocumentType, RoomRateItem, FinancialDocument } from '../types';

export const DEFAULT_SETTINGS: BusinessSettings = {
  businessName: 'Bukit Langit Campventure',
  tagline: 'Camping & Adventure Destination',
  address: 'Desa Kemiren, Kec. Glagah, Kab. Banyuwangi, Jawa Timur 68432',
  phone: '+62 812-3456-7890',
  email: 'info@bukitlangit.com',
  website: 'www.bukitlangit.com',
  npwp: '',
  bankAccounts: [
    { bankName: 'BCA', accountNumber: '1801289191', accountName: 'PT HOLISTIK NUSANTARA GROUP' },
  ],
  defaultTaxRate: 0,
  breakfastPricePerPax: 35000,
  defaultBreakfastIncluded: true,
  signatory: { name: '', title: 'General Manager' },
};

export const DEFAULT_ROOM_RATE_NOTES: string[] = [
  'Harga sudah termasuk sarapan untuk 2 orang per kamar per malam.',
  'Check-in pukul 14:00 WIB, check-out pukul 12:00 WIB.',
  'Early check-in dan late check-out dikenakan biaya tambahan.',
];

export const DEFAULT_PAKET_RATE_NOTES: string[] = [
  'Harga per orang sudah termasuk akomodasi, makan, dan aktivitas.',
  'Minimum booking 20 pax.',
];

export const DEFAULT_ATV_RATE_NOTES: string[] = [
  'Harga sudah termasuk helm, sarung tangan, dan guide.',
  'Durasi track sekitar 30-45 menit per sesi.',
];

export const DEFAULT_KLAUSUL_KONTRAK: KlausulKontrakItem[] = [
  { id: 'k1', title: 'Ruang Lingkup Kerjasama', content: 'Pihak Pertama menyediakan fasilitas akomodasi dan wisata alam sesuai dengan paket yang disepakati.', order: 1 },
  { id: 'k2', title: 'Jangka Waktu Kontrak', content: 'Kontrak ini berlaku selama 1 (satu) tahun sejak tanggal penandatanganan dan dapat diperpanjang berdasarkan kesepakatan kedua belah pihak.', order: 2 },
  { id: 'k3', title: 'Harga dan Pembayaran', content: 'Harga yang berlaku sesuai dengan rate card terlampir. Pembayaran dilakukan paling lambat 7 hari sebelum tanggal kedatangan tamu.', order: 3 },
  { id: 'k4', title: 'Pembatalan', content: 'Pembatalan yang dilakukan kurang dari 3 hari sebelum kedatangan dikenakan biaya pembatalan sebesar 50% dari total biaya.', order: 4 },
  { id: 'k5', title: 'Force Majeure', content: 'Kedua belah pihak dibebaskan dari kewajiban apabila terjadi keadaan kahar (bencana alam, pandemi, kebijakan pemerintah).', order: 5 },
];

export const DEFAULT_WHATSAPP_TEMPLATES: Record<string, string> = {
  booking_confirmation: `Halo {guestName}! 👋\n\nTerima kasih atas reservasi Anda di Bukit Langit Campventure.\n\n📅 Check-in: {checkInDate}\n📅 Check-out: {checkOutDate}\n🏨 Kamar: {roomType}\n💰 Total: {grandTotal}\n\nSampai jumpa di Bukit Langit! 🌿`,
  payment_reminder: `Halo {guestName},\n\nIni adalah pengingat pembayaran untuk reservasi Anda:\n\n💰 Total: {grandTotal}\n💳 Sudah Dibayar: {paidAmount}\n⏳ Sisa: {remainingBalance}\n\nSilakan lakukan pembayaran ke:\n🏦 {bankName} - {accountNumber} a.n. {accountName}\n\nTerima kasih! 🙏`,
  invoice_share: `Halo {guestName},\n\nBerikut invoice untuk transaksi Anda:\n📄 No: {documentNumber}\n💰 Total: {totalAmount}\n\nTerima kasih telah berkunjung ke Bukit Langit! 🌿`,
};

export const DEFAULT_ROOM_RATES: RoomRateItem[] = [
  { roomType: 'Deluxe Room', code: 'DLX', price: 750000, inclusions: 'Breakfast 2 pax, Welcome drink, Wi-Fi, Water Heater', maxGuest: 2 },
  { roomType: 'Superior Room', code: 'SPR', price: 550000, inclusions: 'Breakfast 2 pax, Wi-Fi, Water Heater', maxGuest: 2 },
  { roomType: 'Standard Room', code: 'STD', price: 400000, inclusions: 'Breakfast 2 pax, Wi-Fi', maxGuest: 2 },
  { roomType: 'Family Suite', code: 'FAM', price: 1200000, inclusions: 'Breakfast 4 pax, Welcome drink, Wi-Fi, Water Heater, Living Area', maxGuest: 4 },
  { roomType: 'Glamping Tent', code: 'GLP', price: 650000, inclusions: 'Breakfast 2 pax, BBQ Set, Wi-Fi', maxGuest: 2 },
];

export const DEFAULT_TERMS_PRESETS: Record<string, string[]> = {
  invoice: [
    'Pembayaran dilakukan paling lambat 3 hari setelah invoice diterbitkan.',
    'Pembayaran dapat dilakukan via transfer bank ke rekening yang tertera.',
    'Invoice ini sah sebagai tagihan resmi.',
  ],
  receipt: [
    'Bukti pembayaran ini sah sebagai tanda terima resmi.',
    'Simpan bukti ini sebagai referensi.',
  ],
  quotation: [
    'Penawaran ini berlaku selama 14 hari sejak tanggal diterbitkan.',
    'Harga dapat berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.',
    'Harga belum termasuk pajak kecuali disebutkan.',
  ],
  contract: [
    'Kontrak ini mengikat kedua belah pihak sejak tanggal penandatanganan.',
  ],
  proforma: [
    'Proforma invoice ini bukan merupakan tagihan resmi.',
    'Harga dan ketersediaan dapat berubah.',
  ],
};

export function getActiveContractKlausul(settings?: BusinessSettings): KlausulKontrakItem[] {
  return settings?.defaultKlausulKontrak?.length
    ? settings.defaultKlausulKontrak
    : DEFAULT_KLAUSUL_KONTRAK;
}

const STORAGE_KEY = 'bukit_langit_settings';

export function getStoredSettings(): BusinessSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULT_SETTINGS };
}

export function saveStoredSettings(settings: Partial<BusinessSettings>): void {
  try {
    const current = getStoredSettings();
    const merged = { ...current, ...settings };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    window.dispatchEvent(new Event('business_settings_updated'));
  } catch (err) {
    console.warn('Failed to save settings to localStorage:', err);
  }
}

export function computeContractTerms(klausul: KlausulKontrakItem[]): string {
  return klausul
    .sort((a, b) => a.order - b.order)
    .map((k, i) => `Pasal ${i + 1}: ${k.title}\n${k.content}`)
    .join('\n\n');
}

export function getDefaultTermsForDocType(docType: DocumentType): string {
  switch (docType) {
    case 'invoice':
      return 'Pembayaran dilakukan paling lambat 3 hari setelah invoice diterbitkan.';
    case 'receipt':
      return 'Bukti pembayaran ini sah sebagai tanda terima resmi.';
    case 'quotation':
      return 'Penawaran ini berlaku selama 14 hari sejak tanggal diterbitkan.';
    case 'contract':
      return computeContractTerms(DEFAULT_KLAUSUL_KONTRAK);
    case 'proforma':
      return 'Proforma invoice ini bukan merupakan tagihan resmi.';
    default:
      return '';
  }
}
