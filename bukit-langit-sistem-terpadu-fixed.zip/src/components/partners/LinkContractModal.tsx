import React, { useState, useEffect } from 'react';
import { ClientContact, FinancialDocument } from '../../types';
import { Modal } from '../common/Modal';
import { subscribeDocuments, linkPartnerContract } from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatDateToIndonesian } from '../../utils/formatter';
import { FileCheck, Plus, CheckCircle2, Search, Loader2 } from 'lucide-react';

interface LinkContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  partner: ClientContact;
  onCreateNewContractForPartner: (partner: ClientContact) => void;
  onLinked?: () => void;
}

export const LinkContractModal: React.FC<LinkContractModalProps> = ({
  isOpen,
  onClose,
  partner,
  onCreateNewContractForPartner,
  onLinked,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [contracts, setContracts] = useState<FinancialDocument[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedContractId, setSelectedContractId] = useState<string>(
    partner.contractDocumentId || '',
  );
  const [isLinking, setIsLinking] = useState<boolean>(false);

  useEffect(() => {
    const unsub = subscribeDocuments(
      (docs) => {
        const b2b = docs.filter((d) => d.documentType === 'corporate_contract');
        setContracts(b2b);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error fetching contracts:', err);
        setIsLoading(false);
      },
    );

    return () => unsub();
  }, []);

  const handleLink = async () => {
    if (!selectedContractId) {
      showError('Pilih salah satu dokumen kontrak.');
      return;
    }

    const selectedDoc = contracts.find((c) => c.id === selectedContractId);
    if (!selectedDoc) return;

    try {
      setIsLinking(true);
      await linkPartnerContract(
        partner.id,
        selectedDoc,
        currentUser?.email || 'admin',
      );
      showSuccess(`Kontrak #${selectedDoc.documentNumber} berhasil ditautkan ke ${partner.name}.`);
      if (onLinked) onLinked();
      onClose();
    } catch (err) {
      showError((err as Error).message || 'Gagal menautkan kontrak.');
    } finally {
      setIsLinking(false);
    }
  };

  const filteredContracts = contracts.filter((c) => {
    const q = searchQuery.toLowerCase();
    return (
      (c.documentNumber && c.documentNumber.toLowerCase().includes(q)) ||
      (c.guestName && c.guestName.toLowerCase().includes(q)) ||
      (c.contractPeriod && c.contractPeriod.toLowerCase().includes(q))
    );
  });

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Tautkan Kontrak B2B: ${partner.name}`}
      maxWidth="max-w-xl"
    >
      <div className="space-y-4 text-xs">
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-blue-800">
              Mitra Terpilih
            </span>
            <p className="font-bold text-slate-900">{partner.name}</p>
            <p className="text-[11px] text-slate-600">
              PIC: {partner.contactPerson || '-'} • {partner.homeBase}
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              onClose();
              onCreateNewContractForPartner(partner);
            }}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Buat Kontrak Baru</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nomor kontrak atau nama instansi..."
            className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
          />
        </div>

        {/* List of Contracts */}
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {isLoading ? (
            <div className="p-8 text-center text-slate-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-600 mb-1" />
              <p className="text-[11px]">Memuat daftar kontrak B2B...</p>
            </div>
          ) : filteredContracts.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-xl text-slate-400">
              <p className="text-xs">Tidak ada dokumen kontrak B2B ditemukan.</p>
            </div>
          ) : (
            filteredContracts.map((c) => (
              <label
                key={c.id}
                className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                  selectedContractId === c.id
                    ? 'bg-blue-50/70 border-blue-500 ring-1 ring-blue-500'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="selectedContract"
                    checked={selectedContractId === c.id}
                    onChange={() => setSelectedContractId(c.id)}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">
                        {c.documentNumber}
                      </span>
                      <span className="text-slate-500 font-medium">
                        — {c.guestName}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Periode: {c.contractPeriod || `${c.contractStartDate} s/d ${c.contractEndDate}`}
                    </p>
                  </div>
                </div>

                {c.id === partner.contractDocumentId && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    Saat Ini Terhubung
                  </span>
                )}
              </label>
            ))
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleLink}
            disabled={isLinking || !selectedContractId}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {isLinking && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>Tautkan Kontrak Terpilih</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
