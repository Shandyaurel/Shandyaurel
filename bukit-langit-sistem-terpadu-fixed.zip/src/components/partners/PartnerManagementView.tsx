import React, { useState, useEffect, useMemo } from 'react';
import { ClientContact, FollowUpStatus, BusinessSettings, Booking, ATVBooking, CombinedOrder, AgentFee } from '../../types';
import {
  subscribePartners,
  deletePartner,
  getBusinessSettings,
  savePartner,
  subscribeBookings,
  subscribeATVBookings,
  subscribeCombinedOrders,
  subscribeAgentFees,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatDateToIndonesian } from '../../utils/formatter';
import { formatRupiah } from '../../utils/formatters';
import { PartnerFormModal } from './PartnerFormModal';
import { PartnerFollowUpModal } from './PartnerFollowUpModal';
import { WhatsAppChatModal } from './WhatsAppChatModal';
import { LinkContractModal } from './LinkContractModal';
import { Modal } from '../common/Modal';
import { DataImportModal } from '../common/DataImportModal';
import {
  Handshake,
  Search,
  Plus,
  Edit3,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  MessageSquare,
  FileCheck,
  User,
  Building2,
  Filter,
  Layers,
  LayoutGrid,
  List,
  Loader2,
  CalendarClock,
  Sparkles,
  Upload,
} from 'lucide-react';

interface PartnerManagementViewProps {
  onNavigateToCreateContract?: (partner: ClientContact) => void;
}

export const PartnerManagementView: React.FC<PartnerManagementViewProps> = ({
  onNavigateToCreateContract,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const { showSuccess, showError } = useToast();

  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [hotelBookings, setHotelBookings] = useState<Booking[]>([]);
  const [atvBookings, setAtvBookings] = useState<ATVBooking[]>([]);
  const [combinedOrders, setCombinedOrders] = useState<CombinedOrder[]>([]);
  const [agentFees, setAgentFees] = useState<AgentFee[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | undefined>();
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Contribution & Active Status State
  const [activeDaysThreshold, setActiveDaysThreshold] = useState<number>(90);
  const [activeStatusFilter, setActiveStatusFilter] = useState<'all' | 'active' | 'inactive' | 'zero_contrib'>('all');
  const [sortBy, setSortBy] = useState<'omzet_desc' | 'bookings_desc' | 'name_asc'>('omzet_desc');

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [cityFilter, setCityFilter] = useState<string>('all');
  const [contractFilter, setContractFilter] = useState<'all' | 'has_contract' | 'no_contract'>('all');
  const [viewLayout, setViewLayout] = useState<'grid' | 'table'>('grid');

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [editingPartner, setEditingPartner] = useState<ClientContact | null>(null);

  const [followUpPartner, setFollowUpPartner] = useState<ClientContact | null>(null);
  const [whatsAppPartner, setWhatsAppPartner] = useState<ClientContact | null>(null);
  const [linkContractPartner, setLinkContractPartner] = useState<ClientContact | null>(null);

  // Deletion state
  const [deletingPartner, setDeletingPartner] = useState<ClientContact | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    getBusinessSettings()
      .then(setSettings)
      .catch(console.error);

    const unsubPartners = subscribePartners(
      (list) => {
        setPartners(list);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error loading partners:', err);
        showError('Gagal memuat data mitra dari Firestore.');
        setIsLoading(false);
      },
    );

    const unsubHotel = subscribeBookings((list) => setHotelBookings(list));
    const unsubATV = subscribeATVBookings((list) => setAtvBookings(list));
    const unsubOrders = subscribeCombinedOrders((list) => setCombinedOrders(list));
    const unsubFees = subscribeAgentFees((list) => setAgentFees(list));

    return () => {
      unsubPartners();
      unsubHotel();
      unsubATV();
      unsubOrders();
      unsubFees();
    };
  }, []);

  // Filter options extraction
  const allCategories = Array.from(new Set(partners.map((p) => p.detail).filter(Boolean)));
  const allCities = Array.from(new Set(partners.map((p) => p.homeBase).filter(Boolean)));

  // KPI Calculations
  const totalPartners = partners.length;
  const dealPartners = partners.filter((p) => p.status === 'deal' || p.hasContract).length;
  const scheduledMeetings = partners.filter(
    (p) => p.meetingAgreement === 'yes' || p.status === 'meeting_agreed',
  ).length;

  // Due follow-ups today or overdue
  const todayStr = new Date().toISOString().split('T')[0];
  const dueFollowUps = partners.filter(
    (p) => p.nextFollowUpDate && p.nextFollowUpDate <= todayStr,
  ).length;

  // Helper to compute partner metrics
  const getPartnerMetrics = useMemo(() => {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - activeDaysThreshold);
    const cutoffStr = cutoffDate.toISOString().split('T')[0];

    return (partner: ClientContact) => {
      const pNameLower = partner.name.toLowerCase();

      const matchedHotel = hotelBookings.filter((b) => {
        if (b.partnerId && b.partnerId === partner.id) return true;
        if (b.partnerName && b.partnerName.toLowerCase() === pNameLower) return true;
        if (b.bookingVia && b.bookingVia.toLowerCase().includes(pNameLower)) return true;
        return false;
      });

      const matchedAtv = atvBookings.filter((b) => {
        if (b.partnerId && b.partnerId === partner.id) return true;
        if (b.partnerName && b.partnerName.toLowerCase() === pNameLower) return true;
        if (b.bookingVia && b.bookingVia.toLowerCase().includes(pNameLower)) return true;
        return false;
      });

      const matchedOrders = combinedOrders.filter((o) => {
        if (o.partnerId && o.partnerId === partner.id) return true;
        if (o.partnerName && o.partnerName.toLowerCase() === pNameLower) return true;
        if (o.bookingVia && o.bookingVia.toLowerCase().includes(pNameLower)) return true;
        return false;
      });

      const matchedFees = agentFees.filter((f) => {
        if (f.partnerId && f.partnerId === partner.id) return true;
        if (f.name && f.name.toLowerCase().includes(pNameLower)) return true;
        return false;
      });

      const totalBookings = matchedHotel.length + matchedAtv.length + matchedOrders.length;
      const hotelRevenue = matchedHotel.reduce((sum, b) => sum + (Number(b.grandTotal) || 0), 0);
      const atvRevenue = matchedAtv.reduce(
        (sum, b) => sum + (Number(b.grandTotal) || Number(b.totalAmount) || 0),
        0,
      );
      const orderRevenue = matchedOrders.reduce((sum, o) => sum + (Number(o.grandTotal) || 0), 0);
      const totalRevenue = hotelRevenue + atvRevenue + orderRevenue;
      const totalCommissions = matchedFees.reduce((sum, f) => sum + (Number(f.amount) || 0), 0);

      const recentBooking = [...matchedHotel, ...matchedAtv, ...matchedOrders].some(
        (b) => (b.date || (b as any).checkInDate || b.createdAt) >= cutoffStr,
      );
      const isActive = recentBooking;

      return {
        totalBookings,
        hotelCount: matchedHotel.length,
        atvCount: matchedAtv.length,
        orderCount: matchedOrders.length,
        totalRevenue,
        totalCommissions,
        isActive,
      };
    };
  }, [hotelBookings, atvBookings, combinedOrders, agentFees, activeDaysThreshold]);

  // Poin 7: jumlah mitra yang belum berkontribusi (0 omzet) — actionable untuk didatangi lagi
  const zeroContribCount = useMemo(
    () => partners.filter((p) => getPartnerMetrics(p).totalRevenue === 0).length,
    [partners, getPartnerMetrics],
  );

  // Filtered & Sorted List
  const filteredPartners = useMemo(() => {
    return partners
      .filter((p) => {
        const q = searchQuery.toLowerCase();
        const matchesSearch =
          (p.name && p.name.toLowerCase().includes(q)) ||
          (p.contactPerson && p.contactPerson.toLowerCase().includes(q)) ||
          (p.homeBase && p.homeBase.toLowerCase().includes(q)) ||
          (p.phone && p.phone.includes(q)) ||
          (p.detail && p.detail.toLowerCase().includes(q));

        if (!matchesSearch) return false;

        if (statusFilter !== 'all' && p.status !== statusFilter) return false;
        if (categoryFilter !== 'all' && p.detail !== categoryFilter) return false;
        if (cityFilter !== 'all' && p.homeBase !== cityFilter) return false;

        if (contractFilter === 'has_contract' && !p.hasContract) return false;
        if (contractFilter === 'no_contract' && p.hasContract) return false;

        const metrics = getPartnerMetrics(p);
        if (activeStatusFilter === 'active' && !metrics.isActive) return false;
        if (activeStatusFilter === 'inactive' && metrics.isActive) return false;
        // Poin 7: mitra yang belum berkontribusi (0 omzet) untuk di-follow-up / didatangi lagi
        if (activeStatusFilter === 'zero_contrib' && metrics.totalRevenue > 0) return false;

        return true;
      })
      .sort((a, b) => {
        const mA = getPartnerMetrics(a);
        const mB = getPartnerMetrics(b);
        if (sortBy === 'omzet_desc') {
          return mB.totalRevenue - mA.totalRevenue;
        }
        if (sortBy === 'bookings_desc') {
          return mB.totalBookings - mA.totalBookings;
        }
        return a.name.localeCompare(b.name);
      });
  }, [
    partners,
    searchQuery,
    statusFilter,
    categoryFilter,
    cityFilter,
    contractFilter,
    activeStatusFilter,
    sortBy,
    getPartnerMetrics,
  ]);

  const getStatusBadge = (status: FollowUpStatus) => {
    switch (status) {
      case 'deal':
        return {
          label: 'Deal / Mitra Aktif',
          className: 'bg-emerald-100 text-emerald-800 border-emerald-300',
        };
      case 'wants_meeting':
        return {
          label: 'Mau Ketemu',
          className: 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-300',
        };
      case 'meeting_agreed':
        return {
          label: 'Janji Temu Terjadwal',
          className: 'bg-purple-100 text-purple-800 border-purple-300',
        };
      case 'negotiation':
        return {
          label: 'Negosiasi Rate',
          className: 'bg-blue-100 text-blue-800 border-blue-300',
        };
      case 'contacted':
        return {
          label: 'Menunggu Respon',
          className: 'bg-amber-100 text-amber-800 border-amber-300',
        };
      case 'followup_later':
        return {
          label: 'Follow Up Nanti',
          className: 'bg-indigo-100 text-indigo-800 border-indigo-300',
        };
      case 'declined':
        return {
          label: 'Menolak',
          className: 'bg-slate-100 text-slate-700 border-slate-300',
        };
      default:
        return {
          label: 'Belum Dihubungi',
          className: 'bg-rose-100 text-rose-800 border-rose-300',
        };
    }
  };

  const handleDeleteConfirm = () => {
    if (!deletingPartner) return;
    const target = deletingPartner;
    const reason = deleteReason.trim() || 'Dihapus dari modul Mitra Bisnis';
    const userEmail = currentUser?.email || 'admin';

    // (1) Tutup modal & tampilkan notifikasi segera (OPTIMISTIC <1 detik)
    setDeletingPartner(null);
    setDeleteReason('');
    showSuccess(`Mitra "${target.name}" berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deletePartner(target, userEmail, reason).catch((err) => {
      console.error('Error deleting partner:', err);
      showError('Gagal sinkron hapus mitra ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <Handshake className="w-5 h-5 text-blue-600" />
            <span>Manajemen Mitra Bisnis & B2B CRM</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Database biro perjalanan, agen wisata, instansi korporat, event organizer, dan pipeline follow-up sales marketing.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsImportModalOpen(true)}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all shrink-0"
          >
            <Upload className="w-4 h-4 text-blue-600" />
            <span>Import Excel/CSV</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setEditingPartner(null);
              setIsFormModalOpen(true);
            }}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition-all shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Mitra Baru</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Mitra</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">
              <Handshake className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalPartners}</p>
          <span className="text-[11px] text-slate-400">Database partner B2B</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700">Mitra Aktif (Deal)</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-950 mt-2">{dealPartners}</p>
          <span className="text-[11px] text-emerald-600 font-medium">Berkontrak / Aktif</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-purple-700">Janji Temu / Meeting</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-xs">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-purple-950 mt-2">{scheduledMeetings}</p>
          <span className="text-[11px] text-purple-600 font-medium">Pertemuan Terjadwal</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700">Perlu Follow-up</span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold text-xs">
              <CalendarClock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-950 mt-2">{dueFollowUps}</p>
          <span className="text-[11px] text-rose-600 font-medium">Jatuh tempo hari ini</span>
        </div>

        {/* Poin 7: mitra belum berkontribusi (0 omzet) — klik untuk filter */}
        <button
          type="button"
          onClick={() => setActiveStatusFilter(activeStatusFilter === 'zero_contrib' ? 'all' : 'zero_contrib')}
          title="Tampilkan mitra yang belum menghasilkan omzet untuk di-follow-up / didatangi lagi"
          className={`text-left bg-white p-4 rounded-2xl border shadow-sm cursor-pointer transition-all ${
            activeStatusFilter === 'zero_contrib' ? 'border-amber-400 ring-2 ring-amber-200' : 'border-slate-200 hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-700">Belum Berkontribusi</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-950 mt-2">{zeroContribCount}</p>
          <span className="text-[11px] text-amber-600 font-medium">0 omzet · perlu didatangi</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama mitra, PIC, kota, nomor WA..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto">
            {/* View Layout Toggle */}
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200 shrink-0">
              <button
                type="button"
                onClick={() => setViewLayout('grid')}
                className={`p-1.5 rounded-lg cursor-pointer transition-all ${
                  viewLayout === 'grid'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Tampilan Grid Kartu"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewLayout('table')}
                className={`p-1.5 rounded-lg cursor-pointer transition-all ${
                  viewLayout === 'table'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Tampilan Tabel Rinci"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Dropdown Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1 text-xs">
          <div>
            <select
              value={activeStatusFilter}
              onChange={(e) => setActiveStatusFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-blue-50 border border-blue-200 text-blue-900 rounded-xl font-bold cursor-pointer"
            >
              <option value="all">Semua Status Aktif</option>
              <option value="active">🟢 Hanya Mitra Aktif</option>
              <option value="inactive">🔴 Hanya Mitra Tidak Aktif</option>
              <option value="zero_contrib">⚠️ Belum Berkontribusi (0 omzet)</option>
            </select>
          </div>

          <div>
            <select
              value={activeDaysThreshold}
              onChange={(e) => setActiveDaysThreshold(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 text-slate-800 rounded-xl font-medium cursor-pointer"
            >
              <option value={30}>Acuan Aktif: 30 Hari</option>
              <option value={60}>Acuan Aktif: 60 Hari</option>
              <option value={90}>Acuan Aktif: 90 Hari (Default)</option>
              <option value={180}>Acuan Aktif: 180 Hari</option>
              <option value={365}>Acuan Aktif: 1 Tahun</option>
            </select>
          </div>

          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl font-bold cursor-pointer"
            >
              <option value="omzet_desc">Sort: Omzet Terbesar</option>
              <option value="bookings_desc">Sort: Tamu/Booking Terbanyak</option>
              <option value="name_asc">Sort: Nama A-Z</option>
            </select>
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-semibold cursor-pointer"
            >
              <option value="all">Semua Status CRM</option>
              <option value="uncontacted">Belum Dihubungi</option>
              <option value="contacted">Sudah Dihubungi</option>
              <option value="wants_meeting">Mau Ketemu</option>
              <option value="meeting_agreed">Janji Temu Terjadwal</option>
              <option value="negotiation">Negosiasi</option>
              <option value="deal">Deal / Mitra Aktif</option>
              <option value="followup_later">Follow Up Nanti</option>
              <option value="declined">Menolak</option>
            </select>
          </div>

          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-semibold cursor-pointer"
            >
              <option value="all">Semua Tipe Usaha</option>
              {allCategories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-semibold cursor-pointer"
            >
              <option value="all">Semua Kota Asal</option>
              {allCities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={contractFilter}
              onChange={(e) => setContractFilter(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 font-semibold cursor-pointer"
            >
              <option value="all">Semua Status Kontrak</option>
              <option value="has_contract">Sudah Berkontrak (B2B)</option>
              <option value="no_contract">Belum Ada Kontrak</option>
            </select>
          </div>
        </div>
      </div>

      {/* Content: Cards or Table */}
      {isLoading ? (
        <div className="bg-white rounded-2xl p-12 text-center text-slate-400 border border-slate-200">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600 mb-2" />
          <p className="text-xs">Memuat data mitra bisnis & status follow-up...</p>
        </div>
      ) : filteredPartners.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-sm">
          <Handshake className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-slate-800">
            Belum Ada Data Mitra Bisnis
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? 'Tidak ditemukan mitra yang sesuai dengan filter pencarian.'
              : 'Mulai bangun jaringan kemitraan dengan menambahkan biro travel, EO, atau instansi korporat.'}
          </p>
          {!searchQuery && (
            <button
              type="button"
              onClick={() => {
                setEditingPartner(null);
                setIsFormModalOpen(true);
              }}
              className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Mitra Sekarang</span>
            </button>
          )}
        </div>
      ) : viewLayout === 'grid' ? (
        /* GRID CARDS VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPartners.map((partner) => {
            const statusBadge = getStatusBadge(partner.status);
            const metrics = getPartnerMetrics(partner);
            const isFollowUpDue =
              partner.nextFollowUpDate && partner.nextFollowUpDate <= todayStr;

            return (
              <div
                key={partner.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  {/* Top Badges */}
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                      {partner.detail || 'Travel Agency'}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {metrics.isActive ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                          <span>Aktif ({activeDaysThreshold}H)</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 border border-slate-200">
                          Tidak Aktif
                        </span>
                      )}
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${statusBadge.className}`}
                      >
                        {statusBadge.label}
                      </span>
                      {metrics.totalRevenue === 0 && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Belum Berkontribusi</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Company Name & City */}
                  <div>
                    <h3 className="text-base font-black text-slate-900 leading-tight">
                      {partner.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{partner.homeBase || 'Banyuwangi'}</span>
                    </div>
                  </div>

                  {/* TOTAL KONTRIBUSI MITRA */}
                  <div className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-xl space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-900 border-b border-amber-200/60 pb-1">
                      <span>TOTAL KONTRIBUSI MITRA</span>
                      <span className="font-medium text-amber-700">Realtime</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Total Tamu / Booking:</span>
                      <span className="font-bold text-slate-900">
                        {metrics.totalBookings} <span className="text-[10px] text-slate-500 font-normal">({metrics.hotelCount} Hotel, {metrics.atvCount} ATV)</span>
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Total Omzet:</span>
                      <span className="font-black text-emerald-700">{formatRupiah(metrics.totalRevenue)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-600">Total Komisi:</span>
                      <span className="font-bold text-purple-700">{formatRupiah(metrics.totalCommissions)}</span>
                    </div>
                  </div>

                  {/* PIC Details */}
                  <div className="p-3 bg-slate-50/70 border border-slate-200/80 rounded-xl space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-medium">PIC:</span>
                      <span className="font-bold text-slate-900">
                        {partner.contactPerson || '-'}
                      </span>
                    </div>
                    {partner.contactPersonTitle && (
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">Jabatan:</span>
                        <span className="text-slate-600">
                          {partner.contactPersonTitle}
                        </span>
                      </div>
                    )}
                    <div className="flex items-center justify-between font-mono pt-0.5">
                      <span className="text-slate-500">Telp/WA:</span>
                      <span className="font-bold text-emerald-800">
                        {partner.phone}
                      </span>
                    </div>
                    {partner.email && (
                      <div className="flex items-center justify-between text-[11px] truncate">
                        <span className="text-slate-400">Email:</span>
                        <span className="text-slate-600 truncate max-w-[150px]">
                          {partner.email}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Meeting Schedule & Follow Up Indicator */}
                  <div className="space-y-1.5 text-xs">
                    {partner.meetingDate && (
                      <div className="p-2 bg-purple-50 border border-purple-200 rounded-lg text-purple-900 flex items-center justify-between text-[11px]">
                        <div className="flex items-center gap-1.5 font-semibold">
                          <Calendar className="w-3.5 h-3.5 text-purple-600" />
                          <span>Meeting: {partner.meetingDate}</span>
                        </div>
                        {partner.meetingTime && (
                          <span className="font-mono">{partner.meetingTime}</span>
                        )}
                      </div>
                    )}

                    {partner.nextFollowUpDate && (
                      <div
                        className={`p-2 rounded-lg flex items-center justify-between text-[11px] font-semibold ${
                          isFollowUpDue
                            ? 'bg-rose-50 text-rose-900 border border-rose-200 animate-pulse'
                            : 'bg-slate-50 text-slate-700 border border-slate-200'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span>Next Follow-up:</span>
                        </div>
                        <span>{formatDateToIndonesian(partner.nextFollowUpDate)}</span>
                      </div>
                    )}

                    {/* Contract status info */}
                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100">
                      <span className="text-slate-400">Status Kontrak:</span>
                      {partner.hasContract ? (
                        <span className="font-mono font-bold text-emerald-700 flex items-center gap-1">
                          <FileCheck className="w-3.5 h-3.5" />
                          <span>#{partner.contractNumber || 'Aktif'}</span>
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">Belum Berkontrak</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Bottom Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-1">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      title="Chat WhatsApp"
                      onClick={() => setWhatsAppPartner(partner)}
                      className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WA</span>
                    </button>

                    <button
                      type="button"
                      title="Log Follow-Up"
                      onClick={() => setFollowUpPartner(partner)}
                      className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>Log ({partner.logs?.length || 0})</span>
                    </button>

                    <button
                      type="button"
                      title="Buat / Buka Kontrak B2B"
                      onClick={() => {
                        if (onNavigateToCreateContract) {
                          onNavigateToCreateContract(partner);
                        } else {
                          setLinkContractPartner(partner);
                        }
                      }}
                      className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-900 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <FileCheck className="w-3.5 h-3.5 text-purple-600" />
                      <span>Kontrak</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      title="Edit Data Mitra"
                      onClick={() => {
                        setEditingPartner(partner);
                        setIsFormModalOpen(true);
                      }}
                      className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    {isAdmin && (
                      <button
                        type="button"
                        title="Hapus Mitra"
                        onClick={() => setDeletingPartner(partner)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* DETAILED TABLE VIEW */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[11px] tracking-wider">
                <th className="py-3 px-4">Nama Mitra & Kota</th>
                <th className="py-3 px-4">Keaktifan</th>
                <th className="py-3 px-4">Total Kontribusi</th>
                <th className="py-3 px-4">PIC & Kontak</th>
                <th className="py-3 px-4">Pipeline & Follow-up</th>
                <th className="py-3 px-4">Status Kontrak</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPartners.map((partner) => {
                const statusBadge = getStatusBadge(partner.status);
                const metrics = getPartnerMetrics(partner);
                const isFollowUpDue =
                  partner.nextFollowUpDate && partner.nextFollowUpDate <= todayStr;

                return (
                  <tr key={partner.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 text-xs">
                        {partner.name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {partner.detail} • {partner.homeBase}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      {metrics.isActive ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 inline-flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                          <span>Aktif ({activeDaysThreshold}H)</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 border border-slate-200">
                          Tidak Aktif
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-black text-emerald-700 text-xs">
                        {formatRupiah(metrics.totalRevenue)}
                      </div>
                      <div className="text-[10px] text-slate-600">
                        {metrics.totalBookings} Booking ({metrics.hotelCount} Hotel, {metrics.atvCount} ATV)
                      </div>
                      {metrics.totalCommissions > 0 && (
                        <div className="text-[10px] text-purple-700 font-medium">
                          Komisi: {formatRupiah(metrics.totalCommissions)}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">
                        {partner.contactPerson || '-'}
                      </div>
                      <div className="font-mono text-[11px] text-emerald-800 font-bold">
                        {partner.phone}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border ${statusBadge.className}`}
                      >
                        {statusBadge.label}
                      </span>
                      <div className="text-[10px] text-slate-400 mt-1">
                        Sales: {partner.followupBy || 'Staff'}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      {partner.meetingDate ? (
                        <div className="text-[11px] font-semibold text-purple-900">
                          Meeting: {partner.meetingDate} {partner.meetingTime ? `(${partner.meetingTime})` : ''}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">Tidak ada meeting</span>
                      )}
                      {partner.nextFollowUpDate && (
                        <div
                          className={`text-[10px] font-bold mt-0.5 ${
                            isFollowUpDue ? 'text-rose-700' : 'text-slate-500'
                          }`}
                        >
                          Next: {formatDateToIndonesian(partner.nextFollowUpDate)}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      {partner.hasContract ? (
                        <div>
                          <span className="font-mono font-bold text-emerald-800">
                            #{partner.contractNumber || 'Aktif'}
                          </span>
                          {partner.contractExpiryDate && (
                            <div className="text-[10px] text-slate-400">
                              Exp: {partner.contractExpiryDate}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Belum Ada Kontrak</span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          title="Chat WhatsApp"
                          onClick={() => setWhatsAppPartner(partner)}
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg cursor-pointer"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          title="Catat Follow-Up"
                          onClick={() => setFollowUpPartner(partner)}
                          className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer"
                        >
                          <Clock className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          title="Buat / Buka Kontrak B2B"
                          onClick={() => {
                            if (onNavigateToCreateContract) {
                              onNavigateToCreateContract(partner);
                            } else {
                              setLinkContractPartner(partner);
                            }
                          }}
                          className="p-1.5 text-purple-700 hover:text-purple-900 hover:bg-purple-100 rounded-lg cursor-pointer"
                        >
                          <FileCheck className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          title="Edit Mitra"
                          onClick={() => {
                            setEditingPartner(partner);
                            setIsFormModalOpen(true);
                          }}
                          className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        {isAdmin && (
                          <button
                            type="button"
                            title="Hapus Mitra"
                            onClick={() => setDeletingPartner(partner)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* MODAL: ADD / EDIT PARTNER */}
      {isFormModalOpen && (
        <PartnerFormModal
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          initialData={editingPartner}
        />
      )}

      {/* MODAL: FOLLOW-UP LOGS */}
      {followUpPartner && (
        <PartnerFollowUpModal
          isOpen={Boolean(followUpPartner)}
          onClose={() => setFollowUpPartner(null)}
          partner={followUpPartner}
        />
      )}

      {/* MODAL: WHATSAPP CHAT WITH TEMPLATES */}
      {whatsAppPartner && (
        <WhatsAppChatModal
          isOpen={Boolean(whatsAppPartner)}
          onClose={() => setWhatsAppPartner(null)}
          partner={whatsAppPartner}
          settings={settings}
        />
      )}

      {/* MODAL: LINK CONTRACT */}
      {linkContractPartner && (
        <LinkContractModal
          isOpen={Boolean(linkContractPartner)}
          onClose={() => setLinkContractPartner(null)}
          partner={linkContractPartner}
          onCreateNewContractForPartner={(p) => {
            if (onNavigateToCreateContract) {
              onNavigateToCreateContract(p);
            }
          }}
        />
      )}

      {/* MODAL: DELETE CONFIRMATION */}
      {deletingPartner && (
        <Modal
          isOpen={Boolean(deletingPartner)}
          onClose={() => setDeletingPartner(null)}
          title="Hapus Data Mitra Bisnis"
          maxWidth="max-w-md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Konfirmasi Penghapusan Mitra</p>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  Mitra <strong>{deletingPartner.name}</strong> akan dihapus dan dipindahkan ke riwayat audit <code>deletion_history</code>.
                </p>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Alasan Penghapusan (Wajib):
              </label>
              <textarea
                rows={3}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="Alasan penghapusan data mitra..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDeletingPartner(null)}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={isDeleting || !deleteReason.trim()}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeleting && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Hapus Mitra</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          moduleKey="partners"
          moduleTitle="Mitra Bisnis B2B"
        />
      )}
    </div>
  );
};
