import React, { useState } from 'react';
import { ClientContact, FollowUpStatus, MeetingAgreement } from '../../types';
import { Modal } from '../common/Modal';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { savePartner } from '../../utils/firebase';
import { Building2, User, Phone, Mail, MapPin, Calendar, Clock, Loader2 } from 'lucide-react';

interface PartnerFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: ClientContact | null;
  onSaved?: (partner: ClientContact) => void;
}

const BUSINESS_CATEGORIES = [
  'Travel Agency',
  'Tour Organizer / Biro Wisata',
  'Corporate / Perusahaan',
  'Event Organizer (EO) / WO',
  'Sekolah / Universitas',
  'Komunitas & Perkumpulan',
  'Instansi Pemerintah / BUMN',
  'Vendor Logistik & Catering',
  'Lainnya',
];

const CITIES = [
  'Banyuwangi',
  'Surabaya',
  'Malang',
  'Bali / Denpasar',
  'Jakarta',
  'Jember',
  'Sidoarjo',
  'Yogyakarta',
  'Bandung',
  'Lainnya',
];

export const PartnerFormModal: React.FC<PartnerFormModalProps> = ({
  isOpen,
  onClose,
  initialData,
  onSaved,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [name, setName] = useState<string>(initialData?.name || '');
  const [detail, setDetail] = useState<string>(
    initialData?.detail || 'Travel Agency',
  );
  const [customDetail, setCustomDetail] = useState<string>('');
  const [homeBase, setHomeBase] = useState<string>(
    initialData?.homeBase || 'Banyuwangi',
  );
  const [customHomeBase, setCustomHomeBase] = useState<string>('');
  const [phone, setPhone] = useState<string>(initialData?.phone || '');
  const [email, setEmail] = useState<string>(initialData?.email || '');
  const [contactPerson, setContactPerson] = useState<string>(
    initialData?.contactPerson || '',
  );
  const [contactPersonTitle, setContactPersonTitle] = useState<string>(
    initialData?.contactPersonTitle || 'Pimpinan / PIC Kerjasama',
  );
  const [followupBy, setFollowupBy] = useState<string>(
    initialData?.followupBy || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Staff Sales',
  );
  const [status, setStatus] = useState<FollowUpStatus>(
    initialData?.status || 'uncontacted',
  );
  const [meetingAgreement, setMeetingAgreement] = useState<MeetingAgreement>(
    initialData?.meetingAgreement || 'pending',
  );
  const [meetingDate, setMeetingDate] = useState<string>(
    initialData?.meetingDate || '',
  );
  const [meetingTime, setMeetingTime] = useState<string>(
    initialData?.meetingTime || '',
  );
  const [meetingLocation, setMeetingLocation] = useState<string>(
    initialData?.meetingLocation || '',
  );
  const [nextFollowUpDate, setNextFollowUpDate] = useState<string>(
    initialData?.nextFollowUpDate || '',
  );
  const [contractRateScheduleDate, setContractRateScheduleDate] = useState<string>(
    initialData?.contractRateScheduleDate || '',
  );
  const [notes, setNotes] = useState<string>(initialData?.notes || '');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showError('Nama Mitra / Perusahaan wajib diisi.');
      return;
    }
    if (!phone.trim()) {
      showError('Nomor Telepon / WhatsApp wajib diisi.');
      return;
    }

    const effectiveDetail = detail === 'Lainnya' ? customDetail.trim() || 'Mitra' : detail;
    const effectiveHomeBase = homeBase === 'Lainnya' ? customHomeBase.trim() || 'Banyuwangi' : homeBase;

    try {
      setIsSaving(true);
      const payload: Partial<ClientContact> & {
        name: string;
        detail: string;
        homeBase: string;
        phone: string;
      } = {
        id: initialData?.id,
        name: name.trim(),
        detail: effectiveDetail,
        homeBase: effectiveHomeBase,
        phone: phone.trim(),
        email: email.trim(),
        contactPerson: contactPerson.trim(),
        contactPersonTitle: contactPersonTitle.trim(),
        followupBy: followupBy.trim(),
        status,
        meetingAgreement,
        meetingDate,
        meetingTime,
        meetingLocation,
        nextFollowUpDate,
        contractRateScheduleDate,
        notes: notes.trim(),
        hasContract: initialData?.hasContract || false,
        contractNumber: initialData?.contractNumber || '',
        contractExpiryDate: initialData?.contractExpiryDate || '',
        contractDocumentId: initialData?.contractDocumentId || '',
        logs: initialData?.logs || [],
      };

      const saved = await savePartner(payload, currentUser?.email || 'admin');
      if (saved) {
        showSuccess(`Data mitra "${saved.name}" berhasil disimpan.`);
        if (onSaved) onSaved(saved);
        onClose();
      }
    } catch (err) {
      showError((err as Error).message || 'Gagal menyimpan data mitra.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Data Mitra Bisnis' : 'Tambah Mitra Bisnis Baru'}
      maxWidth="max-w-2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Company Name */}
          <div className="sm:col-span-2">
            <label className="block font-semibold text-slate-700 mb-1">
              Nama Instansi / Biro Travel / Perusahaan: *
            </label>
            <div className="relative">
              <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Contoh: PT. Jadi Liburan Tour & Travel"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Business Category */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Kategori / Tipe Usaha:
            </label>
            <select
              value={detail}
              onChange={(e) => setDetail(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white cursor-pointer"
            >
              {BUSINESS_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            {detail === 'Lainnya' && (
              <input
                type="text"
                value={customDetail}
                onChange={(e) => setCustomDetail(e.target.value)}
                placeholder="Ketik tipe usaha spesifik..."
                className="w-full mt-1.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
              />
            )}
          </div>

          {/* City / Home Base */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Kota Asal / Home Base:
            </label>
            <select
              value={homeBase}
              onChange={(e) => setHomeBase(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white cursor-pointer"
            >
              {CITIES.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
            {homeBase === 'Lainnya' && (
              <input
                type="text"
                value={customHomeBase}
                onChange={(e) => setCustomHomeBase(e.target.value)}
                placeholder="Ketik nama kota..."
                className="w-full mt-1.5 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
              />
            )}
          </div>

          {/* PIC Contact Person */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Nama PIC / Kontak Utama:
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="Bapak / Ibu PIC"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white"
              />
            </div>
          </div>

          {/* PIC Title */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Jabatan PIC:
            </label>
            <input
              type="text"
              value={contactPersonTitle}
              onChange={(e) => setContactPersonTitle(e.target.value)}
              placeholder="Contoh: Manager Operasional / Direktur"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white"
            />
          </div>

          {/* Phone / WhatsApp */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              No. Telepon / WhatsApp: *
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="081234567890"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-900 focus:bg-white"
              />
            </div>
          </div>

          {/* Email */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Email Resmi:
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="partner@domain.com"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white"
              />
            </div>
          </div>

          {/* Assigned Sales */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Staf Sales & Marketing PIC:
            </label>
            <input
              type="text"
              value={followupBy}
              onChange={(e) => setFollowupBy(e.target.value)}
              placeholder="Nama Staf Sales"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:bg-white"
            />
          </div>

          {/* Pipeline Status */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Status Pipeline CRM:
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as FollowUpStatus)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white cursor-pointer"
            >
              <option value="uncontacted">Belum Dihubungi (New)</option>
              <option value="contacted">Sudah Dihubungi / Menunggu Respon</option>
              <option value="wants_meeting">Mau Ketemu (jadwal belum fix)</option>
              <option value="meeting_agreed">Janji Temu Terjadwal</option>
              <option value="negotiation">Negosiasi / Penawaran Rate</option>
              <option value="deal">Deal (Mitra Aktif)</option>
              <option value="followup_later">Follow Up Nanti</option>
              <option value="declined">Menolak / Tidak Tertarik</option>
            </select>
          </div>
        </div>

        {/* Meeting & Follow Up Schedule Section */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
          <span className="font-bold text-slate-900 block border-b border-slate-200 pb-1.5">
            Jadwal Pertemuan & Rencana Follow-up
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Kesediaan Meeting:
              </label>
              <select
                value={meetingAgreement}
                onChange={(e) => setMeetingAgreement(e.target.value as MeetingAgreement)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              >
                <option value="pending">Menunggu Konfirmasi</option>
                <option value="yes">Bersedia Ketemu</option>
                <option value="done">Sudah Bertemu</option>
                <option value="no">Tidak Bersedia</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Tanggal Janji Temu:
              </label>
              <input
                type="date"
                value={meetingDate}
                onChange={(e) => setMeetingDate(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Jam Meeting:
              </label>
              <input
                type="text"
                value={meetingTime}
                onChange={(e) => setMeetingTime(e.target.value)}
                placeholder="10:00 WIB"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Lokasi Meeting:
              </label>
              <input
                type="text"
                value={meetingLocation}
                onChange={(e) => setMeetingLocation(e.target.value)}
                placeholder="Kantor Mitra / Bukit Langit / Coffee Shop"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Next Follow-Up Date:
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Jadwal Kontrak Rate:
              </label>
              <input
                type="date"
                value={contractRateScheduleDate}
                onChange={(e) => setContractRateScheduleDate(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            Catatan Tambahan & Kebutuhan Khusus Mitra:
          </label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Catatan profil, preferensi jenis grup, tanggal potensial outbound..."
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 leading-relaxed focus:bg-white"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSaving}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{initialData ? 'Simpan Perubahan' : 'Tambah Mitra'}</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
