import React, { useState } from 'react';
import { ClientContact, BusinessSettings } from '../../types';
import { Modal } from '../common/Modal';
import { DEFAULT_WHATSAPP_TEMPLATES, DEFAULT_SETTINGS } from '../../utils/storage';
import { addPartnerFollowUpLog } from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { MessageSquare, ExternalLink, Copy, Check, Sparkles, Send } from 'lucide-react';

interface WhatsAppChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  partner: ClientContact;
  settings?: BusinessSettings;
}

export const WhatsAppChatModal: React.FC<WhatsAppChatModalProps> = ({
  isOpen,
  onClose,
  partner,
  settings = DEFAULT_SETTINGS,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const partnerTemplates = DEFAULT_WHATSAPP_TEMPLATES.filter(
    (t) => t.category === 'Sales CRM' || t.category === 'Kirim Dokumen',
  );

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(
    partnerTemplates[0]?.id || 'tpl-sales-perkenalan',
  );
  const [customText, setCustomText] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [autoLogFollowUp, setAutoLogFollowUp] = useState<boolean>(true);

  // Compile placeholders into final text
  const getCompiledTemplate = (tplText: string) => {
    const bizName = settings.businessName || 'BUKIT LANGIT CAMPVENTURE';
    const bizPhone = settings.phone || '0812-5905-1120';
    const salesName =
      partner.followupBy ||
      currentUser?.displayName ||
      currentUser?.email?.split('@')[0] ||
      'Staff Sales';
    const picName = partner.contactPerson || partner.name;

    return tplText
      .replace(/{BUSINESS_NAME}/g, bizName)
      .replace(/{GUEST_NAME}/g, partner.name)
      .replace(/{PIC_NAME}/g, picName)
      .replace(/{SALES_NAME}/g, salesName)
      .replace(/{HOME_BASE}/g, partner.homeBase || 'Banyuwangi')
      .replace(/{PHONE}/g, bizPhone)
      .replace(/{DOC_NUMBER}/g, partner.contractNumber || 'CTR/01/1001')
      .replace(/{DOC_TITLE}/g, 'KONTRAK KERJASAMA B2B')
      .replace(/{CONTRACT_PERIOD}/g, '1 Tahun Kalender')
      .replace(/{CONTRACT_EXPIRY}/g, partner.contractExpiryDate || 'Akhir Tahun')
      .replace(/{MEETING_DATE}/g, partner.meetingDate || 'Besok')
      .replace(/{MEETING_TIME}/g, partner.meetingTime || '10:00 WIB')
      .replace(/{MEETING_LOCATION}/g, partner.meetingLocation || partner.homeBase || 'Kantor Klien')
      .replace(/{PAYMENT_STATUS}/g, 'AKTIF');
  };

  // Initialize custom text when template changes
  React.useEffect(() => {
    const activeTpl = partnerTemplates.find((t) => t.id === selectedTemplateId);
    if (activeTpl) {
      setCustomText(getCompiledTemplate(activeTpl.templateText));
    }
  }, [selectedTemplateId, partner, settings]);

  const handleCopyText = () => {
    navigator.clipboard.writeText(customText);
    setCopied(true);
    showSuccess('Teks pesan WhatsApp berhasil disalin ke clipboard.');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenWhatsApp = async () => {
    let cleanPhone = (partner.phone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '62' + cleanPhone.substring(1);
    }

    if (!cleanPhone) {
      showError('Nomor telepon mitra tidak valid.');
      return;
    }

    // Optionally auto-log this follow up
    if (autoLogFollowUp) {
      try {
        const activeTpl = partnerTemplates.find((t) => t.id === selectedTemplateId);
        await addPartnerFollowUpLog(
          partner.id,
          {
            date: new Date().toISOString(),
            author: currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Sales',
            actionType: 'wa_message',
            summary: `Mengirim pesan WA [${activeTpl?.name || 'Template'}]: "${customText.substring(0, 80)}..."`,
          },
          currentUser?.email || 'admin',
        );
      } catch (err) {
        console.warn('Gagal mencatat log follow-up otomatis:', err);
      }
    }

    const encoded = encodeURIComponent(customText);
    const waUrl = `https://wa.me/${cleanPhone}?text=${encoded}`;
    window.open(waUrl, '_blank');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Kirim Pesan WhatsApp: ${partner.name}`}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-4 text-xs">
        {/* Partner Info Summary */}
        <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div>
            <p className="font-bold text-slate-900 text-xs">{partner.name}</p>
            <p className="text-[11px] text-emerald-800 font-medium">
              PIC: {partner.contactPerson || '-'} ({partner.contactPersonTitle || partner.detail})
            </p>
          </div>
          <span className="font-mono text-xs font-bold text-emerald-950 bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
            {partner.phone}
          </span>
        </div>

        {/* Template Selector */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            Pilih Template Pesan Sales & Follow-up:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {partnerTemplates.map((tpl) => (
              <button
                key={tpl.id}
                type="button"
                onClick={() => setSelectedTemplateId(tpl.id)}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedTemplateId === tpl.id
                    ? 'bg-emerald-50 border-emerald-500 ring-1 ring-emerald-500'
                    : 'bg-slate-50 border-slate-200 hover:bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs line-clamp-1">
                    {tpl.name}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-white text-slate-500 border border-slate-200 uppercase font-semibold shrink-0">
                    {tpl.badge}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Message Editor Preview */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="font-semibold text-slate-700">
              Isi Pesan (Dapat Diedit Sebelum Dikirim):
            </label>
            <button
              type="button"
              onClick={handleCopyText}
              className="text-[11px] text-slate-600 hover:text-slate-900 font-semibold flex items-center gap-1 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-600">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Teks</span>
                </>
              )}
            </button>
          </div>
          <textarea
            rows={8}
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-mono leading-relaxed focus:bg-white"
          />
        </div>

        {/* Auto Log Option */}
        <label className="flex items-center gap-2 cursor-pointer pt-1">
          <input
            type="checkbox"
            checked={autoLogFollowUp}
            onChange={(e) => setAutoLogFollowUp(e.target.checked)}
            className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
          />
          <span className="text-slate-700 font-medium text-xs">
            Otomatis catat pengiriman pesan ini ke Riwayat Follow-Up mitra.
          </span>
        </label>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Kirim Pesan via WhatsApp</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
