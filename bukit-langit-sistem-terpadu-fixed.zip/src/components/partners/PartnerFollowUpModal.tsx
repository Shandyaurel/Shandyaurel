import React, { useState } from 'react';
import { ClientContact, FollowUpLog, FollowUpStatus, MeetingAgreement } from '../../types';
import { Modal } from '../common/Modal';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { addPartnerFollowUpLog, savePartner } from '../../utils/firebase';
import { formatDateToIndonesian } from '../../utils/formatter';
import {
  MessageSquare,
  Phone,
  Calendar,
  Mail,
  FileCheck,
  FileText,
  Plus,
  Clock,
  User,
  MapPin,
  CheckCircle2,
  Loader2,
  Send,
} from 'lucide-react';

interface PartnerFollowUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  partner: ClientContact;
  onUpdated?: () => void;
}

export const PartnerFollowUpModal: React.FC<PartnerFollowUpModalProps> = ({
  isOpen,
  onClose,
  partner,
  onUpdated,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [actionType, setActionType] = useState<FollowUpLog['actionType']>('wa_message');
  const [summary, setSummary] = useState<string>('');
  const [author, setAuthor] = useState<string>(
    currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Staff Sales',
  );

  // Status & Next follow up updates
  const [currentStatus, setCurrentStatus] = useState<FollowUpStatus>(partner.status);
  const [nextFollowUpDate, setNextFollowUpDate] = useState<string>(
    partner.nextFollowUpDate || '',
  );
  const [meetingAgreement, setMeetingAgreement] = useState<MeetingAgreement>(
    partner.meetingAgreement || 'pending',
  );
  const [meetingDate, setMeetingDate] = useState<string>(partner.meetingDate || '');
  const [meetingTime, setMeetingTime] = useState<string>(partner.meetingTime || '');
  const [meetingLocation, setMeetingLocation] = useState<string>(
    partner.meetingLocation || '',
  );

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleAddLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!summary.trim()) {
      showError('Ringkasan aktivitas follow-up wajib diisi.');
      return;
    }

    try {
      setIsSubmitting(true);

      // 1. Add log entry
      await addPartnerFollowUpLog(
        partner.id,
        {
          date: new Date().toISOString(),
          author: author.trim(),
          actionType,
          summary: summary.trim(),
        },
        currentUser?.email || 'admin',
      );

      // 2. Update partner status and next follow-up date
      const updatedPartner: ClientContact = {
        ...partner,
        status: currentStatus,
        nextFollowUpDate,
        meetingAgreement,
        meetingDate,
        meetingTime,
        meetingLocation,
      };

      await savePartner(updatedPartner, currentUser?.email || 'admin');

      showSuccess('Catatan follow-up berhasil ditambahkan.');
      setSummary('');
      if (onUpdated) onUpdated();
      onClose();
    } catch (err) {
      showError((err as Error).message || 'Gagal menambahkan log follow-up.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getActionIcon = (type: FollowUpLog['actionType']) => {
    switch (type) {
      case 'wa_message':
        return <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />;
      case 'phone_call':
        return <Phone className="w-3.5 h-3.5 text-blue-600" />;
      case 'meeting':
        return <Calendar className="w-3.5 h-3.5 text-purple-600" />;
      case 'email':
        return <Mail className="w-3.5 h-3.5 text-amber-600" />;
      case 'contract_sent':
        return <FileCheck className="w-3.5 h-3.5 text-indigo-600" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-slate-600" />;
    }
  };

  const getActionLabel = (type: FollowUpLog['actionType']) => {
    switch (type) {
      case 'wa_message':
        return 'Pesan WhatsApp';
      case 'phone_call':
        return 'Panggilan Telepon';
      case 'meeting':
        return 'Pertemuan / Meeting';
      case 'email':
        return 'Email Resmi';
      case 'contract_sent':
        return 'Pengiriman Kontrak';
      default:
        return 'Catatan Internal';
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Log Aktivitas Follow-Up: ${partner.name}`}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-5 text-xs">
        {/* Partner Header Summary */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400">
              Mitra Bisnis
            </span>
            <h3 className="text-sm font-black text-slate-900">{partner.name}</h3>
            <p className="text-[11px] text-slate-500">
              {partner.detail} • {partner.homeBase} • PIC: {partner.contactPerson || '-'}
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Status Terkini
            </span>
            <span className="px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase bg-blue-100 text-blue-800 border border-blue-200">
              {partner.status}
            </span>
          </div>
        </div>

        {/* Form Tambah Aktivitas */}
        <form onSubmit={handleAddLog} className="p-4 bg-white border border-slate-200 rounded-xl space-y-3 shadow-xs">
          <span className="font-bold text-slate-900 block border-b border-slate-100 pb-2 flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-blue-600" />
            <span>Tambah Catatan Interaksi Baru</span>
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Jenis Interaksi:
              </label>
              <select
                value={actionType}
                onChange={(e) => setActionType(e.target.value as FollowUpLog['actionType'])}
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 cursor-pointer"
              >
                <option value="wa_message">WhatsApp Chat / Penawaran</option>
                <option value="phone_call">Panggilan Telepon</option>
                <option value="meeting">Meeting Tatap Muka</option>
                <option value="email">Kirim Email Resmi</option>
                <option value="contract_sent">Kirim Draft / Kontrak B2B</option>
                <option value="note">Catatan Internal Sales</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Staf Sales / Pelapor:
              </label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Nama staf"
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">
                Rangkuman Hasil Komunikasi / Follow-up: *
              </label>
              <textarea
                required
                rows={3}
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="Contoh: Mengirimkan rate card B2B untuk grup 50 pax. Klien tertarik dengan paket Outbound 2D1N dan meminta follow-up tanggal 15..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 leading-relaxed focus:bg-white"
              />
            </div>

            {/* Quick Status and Next Follow up Update */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Perbarui Status Pipeline:
              </label>
              <select
                value={currentStatus}
                onChange={(e) => setCurrentStatus(e.target.value as FollowUpStatus)}
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 cursor-pointer"
              >
                <option value="uncontacted">Belum Dihubungi</option>
                <option value="contacted">Sudah Dihubungi</option>
                <option value="wants_meeting">Mau Ketemu</option>
                <option value="meeting_agreed">Janji Temu Terjadwal</option>
                <option value="negotiation">Negosiasi Rate</option>
                <option value="deal">Deal (Mitra Aktif)</option>
                <option value="followup_later">Follow Up Nanti</option>
                <option value="declined">Menolak</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Next Follow-Up Date:
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isSubmitting || !summary.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span>Simpan Aktivitas</span>
            </button>
          </div>
        </form>

        {/* Riwayat Interaksi (Logs) */}
        <div className="space-y-3">
          <span className="font-bold text-slate-900 block">
            Riwayat Interaksi & Catatan Sebelumnya ({partner.logs?.length || 0})
          </span>

          {!partner.logs || partner.logs.length === 0 ? (
            <div className="p-6 text-center bg-slate-50 border border-slate-200 rounded-xl text-slate-400">
              <Clock className="w-6 h-6 mx-auto mb-1 opacity-50" />
              <p className="text-xs">Belum ada catatan follow-up sebelumnya.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {partner.logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      {getActionIcon(log.actionType)}
                      <span>{getActionLabel(log.actionType)}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {formatDateToIndonesian(log.date)}
                    </span>
                  </div>
                  <p className="text-slate-700 leading-relaxed pl-5">
                    {log.summary}
                  </p>
                  <p className="text-[10px] text-slate-400 pl-5">
                    Oleh: {log.author || 'Sales'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};
