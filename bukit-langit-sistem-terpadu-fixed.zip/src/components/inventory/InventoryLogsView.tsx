import React, { useState, useMemo } from 'react';
import { InventoryLog } from '../../types';
import { formatDateIndo, getTodayDateString } from '../../utils/formatters';
import {
  Search,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
  Calendar,
  History,
  Printer,
  Home,
} from 'lucide-react';

interface InventoryLogsViewProps {
  logs: InventoryLog[];
  categories: string[];
  isLoading?: boolean;
  hasMore?: boolean;
  onLoadMore?: () => void;
  currentLimit?: number;
}

export const InventoryLogsView: React.FC<InventoryLogsViewProps> = ({
  logs,
  categories,
  isLoading = false,
  hasMore = false,
  onLoadMore,
  currentLimit = 50,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'IN' | 'OUT'>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [dateFilterPreset, setDateFilterPreset] = useState<'all' | 'today' | 'thisMonth' | 'custom'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const todayStr = getTodayDateString();
  const currentMonthStr = todayStr.substring(0, 7);

  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // Type filter
      if (filterType !== 'ALL' && log.type !== filterType) return false;

      // Category filter
      if (filterCategory !== 'ALL' && log.category !== filterCategory) return false;

      // Date filter
      const lDate = log.date || (log.createdAt ? log.createdAt.split('T')[0] : '');
      if (dateFilterPreset === 'today' && lDate !== todayStr) return false;
      if (dateFilterPreset === 'thisMonth' && !lDate.startsWith(currentMonthStr)) return false;
      if (dateFilterPreset === 'custom') {
        if (startDate && lDate < startDate) return false;
        if (endDate && lDate > endDate) return false;
      }

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = log.itemName.toLowerCase().includes(q);
        const matchNotes = log.notes?.toLowerCase().includes(q);
        const matchRoom = log.roomNumber?.toLowerCase().includes(q);
        const matchAtv = log.atvBookingId?.toLowerCase().includes(q);
        if (!matchName && !matchNotes && !matchRoom && !matchAtv) return false;
      }

      return true;
    });
  }, [logs, filterType, filterCategory, dateFilterPreset, startDate, endDate, searchQuery, todayStr, currentMonthStr]);

  const summary = useMemo(() => {
    let totalInQty = 0;
    let totalOutQty = 0;
    filteredLogs.forEach((l) => {
      if (l.type === 'IN') totalInQty += l.qty || 0;
      else if (l.type === 'OUT') totalOutQty += l.qty || 0;
    });
    return {
      count: filteredLogs.length,
      totalInQty,
      totalOutQty,
    };
  }, [filteredLogs]);

  return (
    <div className="space-y-4">
      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama barang, catatan, no kamar, ref booking..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-hidden"
            />
          </div>

          {/* Filter Tipe */}
          <div>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as 'ALL' | 'IN' | 'OUT')}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Jenis Mutasi</option>
              <option value="IN">Stok Masuk (IN)</option>
              <option value="OUT">Stok Keluar (OUT)</option>
            </select>
          </div>

          {/* Filter Kategori */}
          <div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Kategori</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Date Filter Presets */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal:</span>
            </span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setDateFilterPreset('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'all'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('today')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'today'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Hari Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('thisMonth')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'thisMonth'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Bulan Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('custom')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'custom'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Rentang
              </button>
            </div>

            {dateFilterPreset === 'custom' && (
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
                <span className="text-xs text-slate-400">s/d</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="text-xs text-slate-500 font-medium">
              Masuk: <strong className="text-emerald-600">+{summary.totalInQty}</strong> | Keluar:{' '}
              <strong className="text-amber-600">-{summary.totalOutQty}</strong>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Log</span>
            </button>
          </div>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading && logs.length === 0 ? (
          <div className="p-8 space-y-3">
            <div className="flex items-center justify-center py-6 gap-2 text-slate-500 text-xs">
              <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <span>Memuat data riwayat mutasi...</span>
            </div>
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-10 bg-slate-100 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredLogs.length > 0 ? (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="py-3 px-4">Tanggal</th>
                    <th className="py-3 px-4">Barang & Kategori</th>
                    <th className="py-3 px-4 text-center">Jenis Mutasi</th>
                    <th className="py-3 px-4 text-right">Jumlah (Qty)</th>
                    <th className="py-3 px-4">Kamar / Ref</th>
                    <th className="py-3 px-4">Keterangan</th>
                    <th className="py-3 px-4">Oleh</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredLogs.map((log) => {
                    const isIN = log.type === 'IN';
                    return (
                      <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-semibold text-slate-900">{formatDateIndo(log.date)}</div>
                          <div className="text-[10px] text-slate-400">
                            {log.createdAt ? log.createdAt.substring(11, 16) : ''}
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{log.itemName}</div>
                          {log.category && (
                            <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded">
                              {log.category}
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] border ${
                              isIN
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-amber-50 text-amber-700 border-amber-200'
                            }`}
                          >
                            {isIN ? (
                              <ArrowDownLeft className="w-3 h-3" />
                            ) : (
                              <ArrowUpRight className="w-3 h-3" />
                            )}
                            <span>{isIN ? 'MASUK' : 'KELUAR'}</span>
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right font-extrabold">
                          <span className={isIN ? 'text-emerald-600' : 'text-amber-600'}>
                            {isIN ? `+${log.qty}` : `-${log.qty}`}
                          </span>
                        </td>

                        <td className="py-3 px-4">
                          {log.roomNumber || log.roomType ? (
                            <div className="flex items-center gap-1 text-slate-700 font-medium">
                              <Home className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>
                                {log.roomNumber} {log.roomType ? `(${log.roomType})` : ''}
                              </span>
                            </div>
                          ) : log.atvBookingId ? (
                            <span className="text-[11px] font-mono text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded">
                              ATV #{log.atvBookingId.substring(log.atvBookingId.length - 6)}
                            </span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>

                        <td className="py-3 px-4 max-w-xs text-slate-600 font-medium">
                          {log.notes || '-'}
                        </td>

                        <td className="py-3 px-4 text-slate-500 whitespace-nowrap text-[11px]">
                          {log.createdBy ? log.createdBy.split('@')[0] : 'System'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Load More Button */}
            {onLoadMore && (hasMore || logs.length >= currentLimit) && (
              <div className="p-3 border-t border-slate-100 flex items-center justify-center bg-slate-50/50">
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={onLoadMore}
                  className="px-4 py-2 bg-white hover:bg-slate-100 text-blue-700 font-bold text-xs rounded-xl border border-slate-200 shadow-2xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isLoading && (
                    <div className="w-3.5 h-3.5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  )}
                  <span>Muat Lebih Banyak Riwayat (+50)</span>
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="py-16 text-center">
            <History className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">Belum Ada Riwayat Mutasi</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Tidak ada catatan stok masuk atau keluar yang sesuai dengan filter pencarian.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
