import React, { useState, useEffect } from 'react';
import { InventoryItem } from '../../types';
import { Modal } from '../common/Modal';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Package,
  Calendar,
  Home,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { getTodayDateString } from '../../utils/formatters';

interface InventoryStockModalProps {
  isOpen: boolean;
  onClose: () => void;
  movementType: 'IN' | 'OUT';
  items: InventoryItem[];
  preselectedItemId?: string;
  onConfirmMovement: (payload: {
    itemId: string;
    type: 'IN' | 'OUT';
    qty: number;
    date: string;
    roomNumber?: string;
    roomType?: string;
    notes?: string;
  }) => Promise<void>;
}

export const InventoryStockModal: React.FC<InventoryStockModalProps> = ({
  isOpen,
  onClose,
  movementType,
  items,
  preselectedItemId,
  onConfirmMovement,
}) => {
  const [itemId, setItemId] = useState<string>('');
  const [qty, setQty] = useState<number>(1);
  const [date, setDate] = useState<string>(getTodayDateString());
  const [roomNumber, setRoomNumber] = useState<string>('');
  const [roomType, setRoomType] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    if (preselectedItemId && items.some((i) => i.id === preselectedItemId)) {
      setItemId(preselectedItemId);
    } else if (items.length > 0) {
      setItemId(items[0].id);
    } else {
      setItemId('');
    }
    setQty(1);
    setDate(getTodayDateString());
    setRoomNumber('');
    setRoomType('');
    setNotes('');
    setErrorMsg('');
  }, [preselectedItemId, items, isOpen, movementType]);

  const selectedItem = items.find((i) => i.id === itemId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemId) {
      setErrorMsg('Silakan pilih barang inventaris terlebih dahulu.');
      return;
    }
    if (qty <= 0) {
      setErrorMsg('Jumlah (qty) harus lebih besar dari 0.');
      return;
    }

    if (movementType === 'OUT' && selectedItem && qty > selectedItem.stock) {
      setErrorMsg(
        `Stok saat ini (${selectedItem.stock} ${selectedItem.unit}) tidak mencukupi untuk pengeluaran ${qty} ${selectedItem.unit}.`,
      );
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onConfirmMovement({
        itemId,
        type: movementType,
        qty: Number(qty),
        date: date || getTodayDateString(),
        roomNumber: roomNumber.trim() || undefined,
        roomType: roomType.trim() || undefined,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err) {
      console.error('Error submitting inventory movement:', err);
      setErrorMsg('Gagal mencatat mutasi stok.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isIN = movementType === 'IN';

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isIN ? 'Catat Stok Masuk (IN)' : 'Catat Stok Keluar / Pemakaian (OUT)'}
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {/* Header Indicator */}
        <div
          className={`p-3 rounded-xl flex items-center gap-2.5 border ${
            isIN
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-amber-50 border-amber-200 text-amber-800'
          }`}
        >
          <div
            className={`w-7 h-7 rounded-lg flex items-center justify-center ${
              isIN ? 'bg-emerald-600 text-white' : 'bg-amber-600 text-white'
            }`}
          >
            {isIN ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
          </div>
          <div>
            <div className="font-bold">
              {isIN ? 'Penerimaan / Restock Barang' : 'Pengeluaran / Pemakaian Operasional'}
            </div>
            <div className="text-[11px] opacity-80">
              {isIN
                ? 'Menambah jumlah stok barang dan mencatat riwayat masuk.'
                : 'Mengurangi jumlah stok barang dan mencatat peruntukan pemakaian.'}
            </div>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Pilih Barang */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-slate-400" />
            <span>Pilih Barang *</span>
          </label>
          <select
            value={itemId}
            onChange={(e) => setItemId(e.target.value)}
            required
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:bg-white"
          >
            {items.length === 0 && <option value="">Belum ada barang terdaftar</option>}
            {items.map((i) => (
              <option key={i.id} value={i.id}>
                {i.name} [{i.category}] — Stok Saat Ini: {i.stock} {i.unit}
              </option>
            ))}
          </select>
        </div>

        {/* Info Sisa Stok & Qty */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal Mutasi *</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white font-medium"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-slate-400" />
              <span>
                Jumlah {isIN ? 'Masuk' : 'Keluar'} ({selectedItem?.unit || 'Unit'}) *
              </span>
            </label>
            <input
              type="number"
              min="1"
              required
              value={qty}
              onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
              className={`w-full px-3 py-2 border rounded-xl text-xs font-extrabold focus:bg-white ${
                isIN
                  ? 'border-emerald-300 text-emerald-700 bg-emerald-50/30'
                  : 'border-amber-300 text-amber-700 bg-amber-50/30'
              }`}
            />
            {selectedItem && (
              <div className="text-[11px] text-slate-500 mt-1 flex justify-between">
                <span>Stok Sekarang: {selectedItem.stock}</span>
                <span className="font-bold">
                  Stok Akhir:{' '}
                  {isIN ? selectedItem.stock + qty : Math.max(0, selectedItem.stock - qty)}{' '}
                  {selectedItem.unit}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Pengeluaran Spesifik: No Kamar & Tipe Kamar (Optional) */}
        {!isIN && (
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2.5">
            <div className="font-semibold text-slate-700 flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
              <Home className="w-3.5 h-3.5 text-slate-400" />
              <span>Peruntukan Kamar / Unit (Opsional)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <input
                  type="text"
                  placeholder="No Kamar / Tenda (mis: Tenda 03)"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Tipe Kamar (mis: Glamping Safari)"
                  value={roomType}
                  onChange={(e) => setRoomType(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
            </div>
          </div>
        )}

        {/* Catatan / Keterangan */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            <span>Keterangan / Keperluan</span>
          </label>
          <input
            type="text"
            placeholder={
              isIN
                ? 'Contoh: Restock dari Toko Logistik Bogor, PO-102...'
                : 'Contoh: Persiapan tamu rombongan, penggantian handuk rusak...'
            }
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting || items.length === 0}
            className={`px-5 py-2 text-white font-semibold rounded-xl shadow-xs transition-colors disabled:opacity-50 cursor-pointer ${
              isIN ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-600 hover:bg-amber-700'
            }`}
          >
            {isSubmitting
              ? 'Menyimpan...'
              : isIN
              ? 'Simpan Stok Masuk'
              : 'Simpan Stok Keluar'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
