import React, { useState, useEffect } from 'react';
import { InventoryItem } from '../../types';
import { Modal } from '../common/Modal';
import { Package, Hash, AlertTriangle, Tag, FileText } from 'lucide-react';

interface InventoryItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemToEdit?: InventoryItem | null;
  onSave: (payload: Partial<InventoryItem>) => Promise<void>;
  categories: string[];
}

const COMMON_UNITS = [
  'Pcs',
  'Botol',
  'Pasang',
  'Box',
  'Pack',
  'Unit',
  'Liter',
  'Kg',
  'Set',
  'Roll',
  'Lembar',
  'Kaleng',
];

export const InventoryItemModal: React.FC<InventoryItemModalProps> = ({
  isOpen,
  onClose,
  itemToEdit,
  onSave,
  categories,
}) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Hotel');
  const [unit, setUnit] = useState('Pcs');
  const [customUnit, setCustomUnit] = useState('');
  const [stock, setStock] = useState<number>(0);
  const [minStock, setMinStock] = useState<number>(5);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (itemToEdit) {
      setName(itemToEdit.name || '');
      setCategory(itemToEdit.category || (categories[0] || 'Hotel'));
      if (COMMON_UNITS.includes(itemToEdit.unit)) {
        setUnit(itemToEdit.unit);
        setCustomUnit('');
      } else {
        setUnit('custom');
        setCustomUnit(itemToEdit.unit || '');
      }
      setStock(itemToEdit.stock ?? 0);
      setMinStock(itemToEdit.minStock ?? 5);
      setNotes(itemToEdit.notes || '');
    } else {
      setName('');
      setCategory(categories[0] || 'Hotel');
      setUnit('Pcs');
      setCustomUnit('');
      setStock(0);
      setMinStock(5);
      setNotes('');
    }
    setErrorMsg('');
  }, [itemToEdit, categories, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Nama barang inventaris wajib diisi.');
      return;
    }

    const finalUnit = unit === 'custom' ? customUnit.trim() || 'Pcs' : unit;

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onSave({
        id: itemToEdit?.id,
        name: name.trim(),
        category,
        unit: finalUnit,
        stock: Number(stock) || 0,
        minStock: Number(minStock) || 0,
        notes: notes.trim(),
      });
      onClose();
    } catch (err) {
      console.error('Error saving inventory item:', err);
      setErrorMsg('Gagal menyimpan data barang inventaris.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={itemToEdit ? 'Edit Barang Inventaris' : 'Tambah Barang Inventaris Baru'}
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-medium">
            {errorMsg}
          </div>
        )}

        {/* Nama Barang */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-slate-400" />
            <span>Nama Barang / Perlengkapan *</span>
          </label>
          <input
            type="text"
            required
            placeholder="Contoh: Helm ATV Anak, Handuk Mandi, Air Mineral 600ml..."
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:border-blue-600 font-medium"
          />
        </div>

        {/* Kategori & Satuan */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              <span>Kategori</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-slate-400" />
              <span>Satuan Unit</span>
            </label>
            <div className="flex gap-2">
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
              >
                {COMMON_UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
                <option value="custom">Lainnya...</option>
              </select>

              {unit === 'custom' && (
                <input
                  type="text"
                  placeholder="Ketik..."
                  value={customUnit}
                  onChange={(e) => setCustomUnit(e.target.value)}
                  className="w-24 px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              )}
            </div>
          </div>
        </div>

        {/* Stok Awal & Stok Minimum */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-slate-400" />
              <span>{itemToEdit ? 'Jumlah Stok Saat Ini' : 'Stok Awal'}</span>
            </label>
            <input
              type="number"
              min="0"
              value={stock}
              onChange={(e) => setStock(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
              <span>Batas Minimum (Peringatan Menipis)</span>
            </label>
            <input
              type="number"
              min="0"
              value={minStock}
              onChange={(e) => setMinStock(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
            />
            <p className="text-[10px] text-slate-400 mt-1">
              Sistem akan memberi tanda peringatan jika stok ≤ nilai ini.
            </p>
          </div>
        </div>

        {/* Catatan / Spesifikasi */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            <span>Keterangan / Lokasi Penyimpanan (Opsional)</span>
          </label>
          <textarea
            rows={2}
            placeholder="Contoh: Disimpan di rak gudang logistik A2, batch pengadaan 2026..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white resize-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'Menyimpan...' : itemToEdit ? 'Simpan Perubahan' : 'Tambah Barang'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
