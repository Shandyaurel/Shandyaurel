import React, { useState, useEffect, useMemo } from 'react';
import { InventoryItem, InventoryLog, BusinessSettings } from '../../types';
import {
  subscribeInventoryItems,
  subscribeInventoryLogs,
  saveInventoryItem,
  deleteInventoryItem,
  recordInventoryMovement,
  getBusinessSettings,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { InventoryItemModal } from './InventoryItemModal';
import { InventoryStockModal } from './InventoryStockModal';
import { InventoryLogsView } from './InventoryLogsView';
import { Modal } from '../common/Modal';
import { DataImportModal } from '../common/DataImportModal';
import {
  Boxes,
  Package,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Plus,
  Search,
  History,
  Edit2,
  Trash2,
  Tag,
  CheckCircle2,
  AlertCircle,
  Upload,
} from 'lucide-react';

interface InventoryViewProps {
  businessSettings?: BusinessSettings | null;
}

export const InventoryView: React.FC<InventoryViewProps> = () => {
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [activeTab, setActiveTab] = useState<'items' | 'logs'>('items');
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [logs, setLogs] = useState<InventoryLog[]>([]);
  const [categories, setCategories] = useState<string[]>(['Hotel', 'ATV', 'Amenities', 'Dapur', 'Operasional']);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters for items
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterStockStatus, setFilterStockStatus] = useState<'ALL' | 'LOW' | 'OUT' | 'SAFE'>('ALL');

  // Modals
  const [isItemModalOpen, setIsItemModalOpen] = useState<boolean>(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [itemToEdit, setItemToEdit] = useState<InventoryItem | null>(null);

  const [isStockModalOpen, setIsStockModalOpen] = useState<boolean>(false);
  const [stockMovementType, setStockMovementType] = useState<'IN' | 'OUT'>('IN');
  const [preselectedItemId, setPreselectedItemId] = useState<string>('');

  const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Lazy loading state for logs
  const [logsLimit, setLogsLimit] = useState<number>(50);
  const [isLogsLoading, setIsLogsLoading] = useState<boolean>(false);

  // 1. Subscribe to items immediately (fast & non-blocking)
  useEffect(() => {
    setIsLoading(true);

    const unsubItems = subscribeInventoryItems(
      (data) => {
        setItems(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error loading inventory items:', error);
        showError('Gagal memuat daftar barang inventaris.');
        setIsLoading(false);
      },
    );

    // Fetch custom categories from settings
    getBusinessSettings().then((settings) => {
      if (settings?.inventoryCategories && settings.inventoryCategories.length > 0) {
        setCategories(settings.inventoryCategories);
      }
    }).catch(() => {});

    return () => {
      unsubItems();
    };
  }, [showError]);

  // 2. Lazy load logs ONLY when activeTab === 'logs'
  useEffect(() => {
    if (activeTab !== 'logs') return;

    setIsLogsLoading(true);
    const unsubLogs = subscribeInventoryLogs(
      (data) => {
        setLogs(data);
        setIsLogsLoading(false);
      },
      (error) => {
        console.error('Error loading inventory logs:', error);
        setIsLogsLoading(false);
      },
      logsLimit,
    );

    return () => {
      unsubLogs();
    };
  }, [activeTab, logsLimit]);

  const handleLoadMoreLogs = () => {
    setLogsLimit((prev) => prev + 50);
  };

  // Statistics calculation
  const stats = useMemo(() => {
    let lowStockCount = 0;
    let outOfStockCount = 0;
    let totalUnits = 0;

    items.forEach((item) => {
      totalUnits += item.stock || 0;
      if (item.stock === 0) {
        outOfStockCount++;
      } else if (item.stock <= (item.minStock || 0)) {
        lowStockCount++;
      }
    });

    return {
      totalItems: items.length,
      lowStockCount,
      outOfStockCount,
      totalWarning: lowStockCount + outOfStockCount,
      totalUnits,
      totalLogs: logs.length,
    };
  }, [items, logs]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Category
      if (filterCategory !== 'ALL' && item.category !== filterCategory) return false;

      // Stock status
      if (filterStockStatus === 'OUT' && item.stock !== 0) return false;
      if (filterStockStatus === 'LOW' && (item.stock === 0 || item.stock > item.minStock)) return false;
      if (filterStockStatus === 'SAFE' && item.stock <= item.minStock) return false;

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(q);
        const matchCat = item.category.toLowerCase().includes(q);
        const matchNotes = item.notes?.toLowerCase().includes(q);
        if (!matchName && !matchCat && !matchNotes) return false;
      }

      return true;
    });
  }, [items, filterCategory, filterStockStatus, searchQuery]);

  const handleOpenAdd = () => {
    setItemToEdit(null);
    setIsItemModalOpen(true);
  };

  const handleOpenEdit = (item: InventoryItem) => {
    setItemToEdit(item);
    setIsItemModalOpen(true);
  };

  const handleOpenMovement = (type: 'IN' | 'OUT', itemId?: string) => {
    setStockMovementType(type);
    setPreselectedItemId(itemId || '');
    setIsStockModalOpen(true);
  };

  const handleSaveItem = async (payload: Partial<InventoryItem>) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    await saveInventoryItem(payload, userEmail);
    showSuccess(payload.id ? 'Barang inventaris diperbarui' : 'Barang inventaris berhasil ditambahkan');
  };

  const handleConfirmMovement = async (payload: {
    itemId: string;
    type: 'IN' | 'OUT';
    qty: number;
    date: string;
    roomNumber?: string;
    roomType?: string;
    notes?: string;
  }) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    await recordInventoryMovement(payload, userEmail);
    showSuccess(`Stok ${payload.type === 'IN' ? 'masuk (+)' : 'keluar (-)'} berhasil dicatat`);
  };

  const handleDeleteClick = (item: InventoryItem) => {
    setItemToDelete(item);
    setDeleteReason('');
  };

  const handleConfirmDelete = () => {
    if (!itemToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const target = itemToDelete;
    const reason = deleteReason.trim();

    // (1) Tutup modal konfirmasi & notifikasi segera (OPTIMISTIC <1 detik)
    setItemToDelete(null);
    setDeleteReason('');
    showSuccess(`Barang ${target.name} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteInventoryItem(target, userEmail, reason).catch((err) => {
      console.error('Error deleting inventory item:', err);
      showError('Gagal sinkron hapus barang ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div id="inventory-module" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Boxes className="w-6 h-6 text-blue-600" />
            <span>Manajemen Inventaris & Logistik</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Stok perlengkapan hotel, konsumabel tamu, suku cadang/helm ATV, dan pencatatan mutasi barang.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="p-1 bg-slate-200/70 rounded-xl border border-slate-200 flex items-center">
            <button
              id="tab-inventory-items"
              type="button"
              onClick={() => setActiveTab('items')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'items' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Daftar Barang</span>
            </button>
            <button
              id="tab-inventory-logs"
              type="button"
              onClick={() => setActiveTab('logs')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'logs' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Riwayat Mutasi</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              id="btn-import-inventory"
              type="button"
              onClick={() => setIsImportModalOpen(true)}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-blue-600" />
              <span>Import Excel/CSV</span>
            </button>

            <button
              id="btn-stock-in"
              type="button"
              onClick={() => handleOpenMovement('IN')}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowDownLeft className="w-3.5 h-3.5" />
              <span>Stok Masuk</span>
            </button>

            <button
              id="btn-stock-out"
              type="button"
              onClick={() => handleOpenMovement('OUT')}
              className="px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Stok Keluar</span>
            </button>

            <button
              id="btn-add-inventory-item"
              type="button"
              onClick={handleOpenAdd}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Item</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Jenis Barang</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Package className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">{stats.totalItems} Item</div>
          <div className="text-[11px] text-slate-400 mt-0.5">{stats.totalUnits} Total unit fisik</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Perlu Restock / Menipis</span>
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                stats.totalWarning > 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-400'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div
            className={`text-xl font-extrabold mt-2 ${
              stats.totalWarning > 0 ? 'text-amber-600' : 'text-slate-900'
            }`}
          >
            {stats.totalWarning} Item
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {stats.outOfStockCount > 0
              ? `${stats.outOfStockCount} habis, ${stats.lowStockCount} menipis`
              : 'Semua stok dalam batas aman'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Status Stok Habis</span>
            <div
              className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                stats.outOfStockCount > 0 ? 'bg-rose-100 text-rose-700' : 'bg-emerald-50 text-emerald-600'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div
            className={`text-xl font-extrabold mt-2 ${
              stats.outOfStockCount > 0 ? 'text-rose-600' : 'text-emerald-600'
            }`}
          >
            {stats.outOfStockCount} Item
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Stok = 0 unit</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Riwayat Aktivitas</span>
            <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <History className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">{stats.totalLogs} Log</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Catatan mutasi IN / OUT</div>
        </div>
      </div>

      {activeTab === 'logs' ? (
        <InventoryLogsView
          logs={logs}
          categories={categories}
          isLoading={isLogsLoading}
          currentLimit={logsLimit}
          onLoadMore={handleLoadMoreLogs}
        />
      ) : (
        <>
          {/* Item Filters & Search */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="relative md:col-span-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="inventory-search-input"
                  type="text"
                  placeholder="Cari nama barang, kategori, catatan..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-blue-600"
                />
              </div>

              <div>
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white"
                >
                  <option value="ALL">Semua Kategori</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <select
                  value={filterStockStatus}
                  onChange={(e) => setFilterStockStatus(e.target.value as 'ALL' | 'LOW' | 'OUT' | 'SAFE')}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white"
                >
                  <option value="ALL">Semua Kondisi Stok</option>
                  <option value="LOW">Stok Menipis (≤ Min)</option>
                  <option value="OUT">Stok Habis (0)</option>
                  <option value="SAFE">Stok Aman</option>
                </select>
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {isLoading ? (
              <div className="py-16 text-center">
                <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs text-slate-400">Memuat data inventaris...</p>
              </div>
            ) : filteredItems.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                      <th className="py-3 px-4">Nama Barang & Kategori</th>
                      <th className="py-3 px-4 text-right">Stok Saat Ini</th>
                      <th className="py-3 px-4 text-right">Batas Min</th>
                      <th className="py-3 px-4">Satuan</th>
                      <th className="py-3 px-4 text-center">Status Stok</th>
                      <th className="py-3 px-4">Lokasi / Keterangan</th>
                      <th className="py-3 px-4 text-right">Aksi & Mutasi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {filteredItems.map((item) => {
                      const isOutOfStock = item.stock === 0;
                      const isLowStock = !isOutOfStock && item.stock <= (item.minStock || 0);

                      return (
                        <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{item.name}</div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 font-medium rounded-md">
                                {item.category}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">ID: {item.id}</span>
                            </div>
                          </td>

                          <td className="py-3 px-4 text-right">
                            <span
                              className={`text-sm font-extrabold ${
                                isOutOfStock
                                  ? 'text-rose-600'
                                  : isLowStock
                                  ? 'text-amber-600'
                                  : 'text-slate-900'
                              }`}
                            >
                              {item.stock}
                            </span>
                          </td>

                          <td className="py-3 px-4 text-right font-medium text-slate-500">
                            {item.minStock}
                          </td>

                          <td className="py-3 px-4 font-semibold text-slate-700">
                            {item.unit}
                          </td>

                          <td className="py-3 px-4 text-center">
                            {isOutOfStock ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                <AlertCircle className="w-3 h-3" />
                                <span>Habis</span>
                              </span>
                            ) : isLowStock ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                                <AlertTriangle className="w-3 h-3" />
                                <span>Menipis</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Aman</span>
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-4 max-w-xs text-slate-500 truncate" title={item.notes}>
                            {item.notes || '-'}
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                title="Catat Stok Masuk"
                                onClick={() => handleOpenMovement('IN', item.id)}
                                className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg cursor-pointer transition-colors"
                              >
                                <ArrowDownLeft className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                title="Catat Stok Keluar / Pakai"
                                onClick={() => handleOpenMovement('OUT', item.id)}
                                className="p-1.5 text-amber-600 hover:bg-amber-50 rounded-lg cursor-pointer transition-colors"
                              >
                                <ArrowUpRight className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                title="Edit Detail Barang"
                                onClick={() => handleOpenEdit(item)}
                                className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                title="Hapus Barang"
                                onClick={() => handleDeleteClick(item)}
                                className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-16 text-center">
                <Boxes className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-700">Belum Ada Barang Terdaftar</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Belum ada item inventaris yang sesuai. Klik tombol "Tambah Item" di atas untuk mendaftarkan barang baru.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {/* Item Modal */}
      {isItemModalOpen && (
        <InventoryItemModal
          isOpen={isItemModalOpen}
          onClose={() => setIsItemModalOpen(false)}
          itemToEdit={itemToEdit}
          onSave={handleSaveItem}
          categories={categories}
        />
      )}

      {/* Stock Movement Modal */}
      {isStockModalOpen && (
        <InventoryStockModal
          isOpen={isStockModalOpen}
          onClose={() => setIsStockModalOpen(false)}
          movementType={stockMovementType}
          items={items}
          preselectedItemId={preselectedItemId}
          onConfirmMovement={handleConfirmMovement}
        />
      )}

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        title="Konfirmasi Hapus Barang Inventaris"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus data barang <strong>{itemToDelete?.name}</strong> (Stok saat ini: {itemToDelete?.stock}{' '}
            {itemToDelete?.unit})?
            Tindakan ini akan dicatat dalam riwayat penghapusan dan log audit.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Barang sudah tidak dipakai / rusak total..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setItemToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Barang'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          moduleKey="inventory"
          moduleTitle="Master Barang Inventaris"
        />
      )}
    </div>
  );
};
