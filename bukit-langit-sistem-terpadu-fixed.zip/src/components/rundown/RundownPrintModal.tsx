import React, { useRef } from 'react';
import { Printer, X, Download, Calendar, Clock, MapPin, Building2, User } from 'lucide-react';
import { RundownEvent, BusinessSettings } from '../../types';
import { parseTimeToMinutes, minutesToTimeString, getRundownItemDays } from '../../utils/firebase';

interface RundownPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  rundown: RundownEvent | null;
  settings?: BusinessSettings;
}

export const RundownPrintModal: React.FC<RundownPrintModalProps> = ({
  isOpen,
  onClose,
  rundown,
  settings,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !rundown) return null;

  const handlePrint = () => {
    window.print();
  };

  const businessName = settings?.businessName || 'BUKIT LANGIT CAMPVENTURE';
  const tagline = settings?.tagline || 'Glamping, Resort & ATV Adventure';
  const address = settings?.address || 'Jl. Raya Puncak KM 84, Cisarua, Bogor, Jawa Barat';
  const phone = settings?.phone || '0812-3456-7890';
  const email = settings?.email || 'bolangcampventure@gmail.com';

  const formattedDate = new Date(rundown.date).toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  // 1c. Blok Tanda Tangan: Template dari Settings, Nama dari form rundown
  const templates = settings?.rundownSignatureTemplates || [
    { id: 'sig_1', roleGroup: 'Perwakilan Panitia / Klien', title: 'PIC / Ketua Panitia', defaultName: '' },
    { id: 'sig_2', roleGroup: 'Tim Bukit Langit', title: 'Operational Manager / LO', defaultName: 'Operational Manager' },
    { id: 'sig_3', roleGroup: 'Tim Bukit Langit', title: 'Koordinator Acara & Lapangan', defaultName: 'Koordinator Lapangan' },
  ];

  const renderedSignatories = templates.map((tmpl) => {
    const match = (rundown.signatories || []).find(
      (s) => s.id === tmpl.id || s.title.toLowerCase() === tmpl.title.toLowerCase()
    );
    const isPic = tmpl.title.toLowerCase().includes('pic') || tmpl.roleGroup?.toLowerCase().includes('klien');
    const nameFromRundown = match?.name?.trim() || (isPic ? rundown.picName?.trim() : '');
    const finalName = nameFromRundown || tmpl.defaultName || (isPic ? rundown.groupName : `Tim ${businessName}`);
    return {
      roleGroup: tmpl.roleGroup,
      title: tmpl.title,
      displayName: finalName,
    };
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Modal Controls (Hidden when printing) */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-600 rounded-xl">
              <Printer className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Pratinjau Cetak Rundown Acara</h3>
              <p className="text-xs text-slate-300">Format dokumen siap cetak A4 / PDF resmi</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10 bg-slate-100 print:bg-white print:p-0 print:overflow-visible">
          <div
            ref={printRef}
            id="printable-rundown-sheet"
            className="bg-white max-w-[210mm] mx-auto p-8 sm:p-12 shadow-md border border-slate-200 rounded-xl print:shadow-none print:border-none print:p-6 print:max-w-none"
          >
            {/* Kop Surat / Business Header */}
            <div className="border-b-2 border-slate-800 pb-5 mb-6 flex items-start justify-between">
              <div>
                <h1 className="text-2xl font-black text-slate-900 tracking-tight">{businessName}</h1>
                <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider mt-0.5">{tagline}</p>
                <p className="text-[11px] text-slate-500 mt-1 max-w-md">
                  {address} • Telp: {phone} • Email: {email}
                </p>
              </div>
              <div className="text-right">
                <div className="inline-block bg-slate-900 text-white text-[11px] font-bold tracking-wider uppercase px-3 py-1 rounded-sm">
                  Rundown Acara Resmi
                </div>
                <div className="text-[10px] text-slate-400 mt-1.5 font-mono">
                  Ref: {rundown.id}
                </div>
              </div>
            </div>

            {/* Event Summary Grid */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-6 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Nama Acara</span>
                <span className="font-bold text-slate-900">{rundown.eventName}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Rombongan / Klien</span>
                <span className="font-bold text-slate-900">{rundown.groupName}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Hari / Tanggal</span>
                <span className="font-semibold text-slate-800">{formattedDate}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Waktu Pelaksanaan</span>
                <span className="font-bold text-blue-700">
                  {rundown.startTime} - {rundown.endTime} WIB
                </span>
                <span className="text-[10px] text-slate-500 block">
                  ({Math.floor((rundown.totalDurationMin || 0) / 60)} Jam {(rundown.totalDurationMin || 0) % 60} Menit)
                </span>
              </div>
            </div>

            {/* Rundown Activities Table */}
            <div className="mb-6 overflow-hidden rounded-lg border border-slate-200">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-800 text-white font-semibold text-[11px]">
                    <th className="py-2.5 px-3 w-10 text-center">No</th>
                    <th className="py-2.5 px-3 w-28 text-center">Waktu (WIB)</th>
                    <th className="py-2.5 px-3 w-16 text-center">Durasi</th>
                    <th className="py-2.5 px-4">Nama Kegiatan / Sesi</th>
                    <th className="py-2.5 px-3 w-32">Lokasi</th>
                    <th className="py-2.5 px-3 w-28">PIC</th>
                    <th className="py-2.5 px-3 w-40">Catatan / Perlengkapan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {(() => {
                    const itemDays = getRundownItemDays(rundown.items || [], rundown.startTime || '08:00');
                    const isMultiDay = itemDays.some(d => d > 1);

                    return (rundown.items || []).map((item, index) => {
                    let gapMinutes = 0;
                    if (index > 0) {
                      const prevEnd = parseTimeToMinutes(rundown.items[index - 1].endTime);
                      const curStart = parseTimeToMinutes(item.startTime);
                      if (curStart > prevEnd) {
                        gapMinutes = curStart - prevEnd;
                      }
                    }

                    const currentDay = itemDays[index];
                    const prevDay = index > 0 ? itemDays[index - 1] : currentDay;
                    const showDaySeparator = currentDay > prevDay;

                    const isSantai = item.type === 'santai';

                    return (
                      <React.Fragment key={item.id || index}>
                        {/* HARI 1 header at start of multi-day rundown */}
                        {index === 0 && isMultiDay && (
                          <tr className="bg-indigo-900 text-white">
                            <td colSpan={7} className="py-2 px-4 text-center font-black text-sm tracking-wider">
                              📅 HARI 1
                            </td>
                          </tr>
                        )}

                        {/* Day separator when crossing to next day */}
                        {showDaySeparator && (
                          <tr className="bg-indigo-900 text-white">
                            <td colSpan={7} className="py-2 px-4 text-center font-black text-sm tracking-wider">
                              📅 HARI {currentDay}
                            </td>
                          </tr>
                        )}

                        {gapMinutes > 0 && (
                          <tr className="bg-amber-50/70 border-y border-dashed border-amber-300 text-[10px] text-amber-900 font-semibold italic">
                            <td colSpan={7} className="py-1 px-4 text-center">
                              ⏱ Jeda Kosong Antar Acara: {gapMinutes} Menit ({rundown.items[index - 1].endTime} – {item.startTime} WIB)
                            </td>
                          </tr>
                        )}
                        <tr
                          className={
                            isSantai
                              ? 'bg-slate-100/90 text-slate-800'
                              : index % 2 === 0
                              ? 'bg-white'
                              : 'bg-slate-50/70'
                          }
                        >
                          <td className="py-2 px-3 text-center font-bold text-slate-600">{index + 1}</td>
                          <td className="py-2 px-3 text-center font-mono font-bold text-blue-900 whitespace-nowrap">
                            {item.startTime} - {item.endTime}
                            {item.isManualTime && (
                              <span className="text-[9px] text-amber-700 ml-1 font-sans">*</span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-center text-slate-500 font-medium">
                            {item.durationMin} mnt
                          </td>
                          <td className="py-2 px-4 font-bold text-slate-800">
                            {item.title}
                            {isSantai && (
                              <span className="text-[10px] font-normal text-slate-500 ml-2 italic">
                                (Waktu Santai / Bebas)
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-slate-600">{item.location || '-'}</td>
                          <td className="py-2 px-3 text-slate-600 font-medium">{item.pic || '-'}</td>
                          <td className="py-2 px-3 text-[11px] text-slate-500 italic">
                            {item.note || '-'}
                          </td>
                        </tr>
                      </React.Fragment>
                    );
                  });
                  })()}
                </tbody>
              </table>
            </div>

            {/* Notes Section */}
            {rundown.notes && (
              <div className="p-3.5 bg-amber-50/60 border border-amber-200 rounded-lg text-xs mb-8">
                <span className="font-bold text-amber-900 block mb-1">Catatan Khusus & Ketentuan Lapangan:</span>
                <p className="text-amber-800 whitespace-pre-wrap leading-relaxed">{rundown.notes}</p>
              </div>
            )}

            {/* 1c. Blok Tanda Tangan Dinamis: label dari template Settings + nama dari rundown */}
            <div className={`grid grid-cols-${Math.min(3, Math.max(2, renderedSignatories.length))} gap-6 text-xs text-center mt-10 pt-4 border-t border-slate-200 break-inside-avoid`}>
              {renderedSignatories.map((sig, sIdx) => (
                <div key={sIdx} className="flex flex-col items-center">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">{sig.roleGroup}</p>
                  <p className="font-semibold text-slate-700 mb-16">{sig.title}</p>
                  <div className="border-t border-slate-400 w-44 mx-auto pt-1 font-bold text-slate-800">
                    ( {sig.displayName} )
                  </div>
                  <p className="text-[10px] text-slate-500 mt-0.5">{sig.title}</p>
                </div>
              ))}
            </div>

            {/* Footer timestamp */}
            <div className="mt-8 pt-3 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400">
              <span>Dicetak secara otomatis melalui {businessName} System</span>
              <span>Tanggal Cetak: {new Date().toLocaleDateString('id-ID')} {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
