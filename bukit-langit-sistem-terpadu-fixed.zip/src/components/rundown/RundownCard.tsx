import React from 'react';
import {
  Calendar,
  Clock,
  Users,
  Edit3,
  Trash2,
  Copy,
  Printer,
  Share2,
  Play,
  ListTodo,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { RundownEvent } from '../../types';

interface RundownCardProps {
  rundown: RundownEvent;
  onEdit: (rundown: RundownEvent) => void;
  onDelete: (rundown: RundownEvent) => void;
  onDuplicate: (rundown: RundownEvent) => void;
  onPrint: (rundown: RundownEvent) => void;
  onWhatsApp: (rundown: RundownEvent) => void;
  onLiveRunner: (rundown: RundownEvent) => void;
}

export const RundownCard: React.FC<RundownCardProps> = ({
  rundown,
  onEdit,
  onDelete,
  onDuplicate,
  onPrint,
  onWhatsApp,
  onLiveRunner,
}) => {
  const isToday = rundown.date === new Date().toISOString().split('T')[0];
  const formattedDate = new Date(rundown.date).toLocaleDateString('id-ID', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const durationHours = Math.floor((rundown.totalDurationMin || 0) / 60);
  const durationMins = (rundown.totalDurationMin || 0) % 60;
  const itemCount = rundown.items?.length || 0;

  return (
    <div className={`bg-white rounded-2xl border transition-all overflow-hidden flex flex-col justify-between ${
      isToday ? 'border-rose-300 ring-2 ring-rose-500/20 shadow-md' : 'border-slate-200 hover:border-slate-300 shadow-xs hover:shadow-md'
    }`}>
      {/* Top Banner & Header */}
      <div className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                rundown.status === 'Confirmed'
                  ? 'bg-emerald-100 text-emerald-800'
                  : rundown.status === 'In Progress'
                  ? 'bg-blue-100 text-blue-800'
                  : rundown.status === 'Completed'
                  ? 'bg-purple-100 text-purple-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {rundown.status || 'Draft'}
            </span>

            {isToday && (
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-600 text-white shadow-2xs animate-pulse">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                <span>LIVE HARI INI</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-100">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{formattedDate}</span>
            </div>
          </div>
        </div>

        {/* Title & Group */}
        <h3 className="font-bold text-base text-slate-900 line-clamp-1 group-hover:text-blue-600">
          {rundown.eventName}
        </h3>
        <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
          <Users className="w-3.5 h-3.5 text-slate-400" />
          <span className="truncate">{rundown.groupName}</span>
        </div>

        {/* Timing & Stats Metrics */}
        <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100 text-xs">
          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Waktu Acara</span>
            <div className="font-mono font-bold text-blue-900 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span>{rundown.startTime} - {rundown.endTime}</span>
            </div>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Sesi & Durasi</span>
            <div className="font-bold text-slate-800 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span>{itemCount} Sesi ({durationHours}j {durationMins}m)</span>
            </div>
          </div>
        </div>

        {/* Activity preview pills */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {(rundown.items || []).slice(0, 3).map((item, idx) => (
            <span
              key={item.id || idx}
              className="text-[10px] font-medium bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md truncate max-w-[150px]"
            >
              {idx + 1}. {item.title}
            </span>
          ))}
          {itemCount > 3 && (
            <span className="text-[10px] font-medium text-slate-400 px-1 py-0.5">
              +{itemCount - 3} lainnya
            </span>
          )}
        </div>
      </div>

      {/* Action Footer */}
      <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-1">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onLiveRunner(rundown)}
            className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
            title="Buka Mode Live Runner"
          >
            <Play className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onPrint(rundown)}
            className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            title="Cetak format resmi"
          >
            <Printer className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onWhatsApp(rundown)}
            className="p-1.5 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
            title="Salin format WhatsApp"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onDuplicate(rundown)}
            className="p-1.5 text-indigo-600 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
            title="Duplikat Rundown"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onDelete(rundown)}
            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
            title="Hapus Rundown"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          {isToday && (
            <button
              type="button"
              onClick={() => onEdit(rundown)}
              className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
              title="Edit Form Rundown"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          )}

          {isToday ? (
            <button
              type="button"
              onClick={() => onLiveRunner(rundown)}
              className="px-3.5 py-1.5 text-xs font-black text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Buka Mode Live Running Hari Ini"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Live Running</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onEdit(rundown)}
              className="px-3 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-100 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span>Edit Rundown</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
