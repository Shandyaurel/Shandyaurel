import React, { useState, useEffect } from 'react';
import { Copy, Calendar, Users, X, AlertCircle } from 'lucide-react';
import { RundownEvent } from '../../types';

interface RundownDuplicateModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceRundown: RundownEvent | null;
  onConfirm: (newDate: string, newGroupName: string) => Promise<void>;
  isLoading?: boolean;
}

export const RundownDuplicateModal: React.FC<RundownDuplicateModalProps> = ({
  isOpen,
  onClose,
  sourceRundown,
  onConfirm,
  isLoading = false,
}) => {
  const [newDate, setNewDate] = useState<string>('');
  const [newGroupName, setNewGroupName] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (sourceRundown) {
      // Default to tomorrow's date or current date
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setNewDate(tomorrow.toISOString().split('T')[0]);
      setNewGroupName(`${sourceRundown.groupName} (Salinan)`);
      setError(null);
    }
  }, [sourceRundown, isOpen]);

  if (!isOpen || !sourceRundown) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDate) {
      setError('Tanggal pelaksanaan acara wajib diisi.');
      return;
    }
    if (!newGroupName.trim()) {
      setError('Nama rombongan / instansi wajib diisi.');
      return;
    }

    try {
      await onConfirm(newDate, newGroupName.trim());
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal menduplikasi rundown acara.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl backdrop-blur-xs">
              <Copy className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Duplikat Rundown Acara</h3>
              <p className="text-xs text-blue-100">Buat salinan jadwal untuk rombongan / tanggal baru</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isLoading}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-100 text-xs text-blue-800 space-y-1">
            <div className="font-semibold text-blue-950">Rundown Sumber:</div>
            <div className="font-medium">{sourceRundown.eventName}</div>
            <div className="text-slate-600">
              {sourceRundown.groupName} • {sourceRundown.items?.length || 0} kegiatan ({sourceRundown.startTime} - {sourceRundown.endTime})
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Tanggal Acara Baru <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Nama Kelompok / Instansi Baru <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Users className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="Contoh: PT Bank Mandiri Batch 2"
                required
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5"
            >
              {isLoading ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Menduplikasi...</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Buat Duplikat</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
