import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import type { RundownEvent } from '../../types';
import {
  subscribeRundownEvents,
  saveRundownEvent,
  deleteRundownEvent,
} from '../../utils/firebase';
import { RundownCard } from './RundownCard';
import { RundownDuplicateModal } from './RundownDuplicateModal';
import { RundownPrintModal } from './RundownPrintModal';
import {
  Plus,
  Search,
  Calendar,
  Loader2,
  ListTodo,
  Filter,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const RundownView: React.FC = () => {
  const { currentUser, isAllowed } = useAuth();
  const { showSuccess, showError } = useToast();
  const [events, setEvents] = useState<RundownEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'upcoming' | 'past'>('all');

  const [editingEvent, setEditingEvent] = useState<RundownEvent | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [dupEvent, setDupEvent] = useState<RundownEvent | null>(null);
  const [printEvent, setPrintEvent] = useState<RundownEvent | null>(null);

  useEffect(() => {
    if (!isAllowed('rundown')) return;
    const unsub = subscribeRundownEvents((data) => {
      setEvents(data);
      setLoading(false);
    });
    return unsub;
  }, [isAllowed]);

  const today = new Date().toISOString().split('T')[0];

  const filtered = useMemo(() => {
    let list = [...events];
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (e) =>
          (e.eventName || '').toLowerCase().includes(q) ||
          (e.clientName || '').toLowerCase().includes(q),
      );
    }
    if (filterStatus === 'upcoming') {
      list = list.filter((e) => e.eventDate >= today);
    } else if (filterStatus === 'past') {
      list = list.filter((e) => e.eventDate < today);
    }
    return list.sort((a, b) => (b.eventDate || '').localeCompare(a.eventDate || ''));
  }, [events, search, filterStatus, today]);

  const handleDelete = async (ev: RundownEvent) => {
    if (!confirm(`Hapus rundown "${ev.eventName}"?`)) return;
    try {
      await deleteRundownEvent(ev.id);
      showSuccess('Rundown berhasil dihapus.');
    } catch {
      showError('Gagal menghapus rundown.');
    }
  };

  const handleDuplicate = async (ev: RundownEvent, newDate: string) => {
    try {
      const dup: Partial<RundownEvent> = {
        ...ev,
        id: undefined as any,
        eventDate: newDate,
        eventName: `${ev.eventName} (Copy)`,
        createdAt: new Date().toISOString(),
      };
      delete (dup as any).id;
      await saveRundownEvent(dup as RundownEvent);
      showSuccess('Rundown berhasil diduplikasi.');
      setDupEvent(null);
    } catch {
      showError('Gagal menduplikasi rundown.');
    }
  };

  const handleWhatsApp = (ev: RundownEvent) => {
    const text = `*RUNDOWN: ${ev.eventName}*\nTanggal: ${ev.eventDate}\nKlien: ${ev.clientName || '-'}\n\n${
      (ev.items || [])
        .map((item, i) => `${i + 1}. ${item.time || ''} — ${item.activity || ''}`)
        .join('\n')
    }`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-100 rounded-xl">
            <ListTodo className="w-5 h-5 text-orange-700" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Rundown Events</h2>
            <p className="text-xs text-slate-500">{events.length} total rundown</p>
          </div>
        </div>
        <button
          onClick={() => { setEditingEvent(null); setShowForm(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 text-sm font-medium"
        >
          <Plus className="w-4 h-4" /> Buat Rundown
        </button>
      </div>

      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            placeholder="Cari nama event atau klien..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm"
          />
        </div>
        <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
          {(['all', 'upcoming', 'past'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                filterStatus === s ? 'bg-white shadow-sm text-slate-800' : 'text-slate-500'
              }`}
            >
              {s === 'all' ? 'Semua' : s === 'upcoming' ? 'Mendatang' : 'Selesai'}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 text-slate-400">
          <Calendar className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">Belum ada rundown.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {filtered.map((ev) => (
              <motion.div
                key={ev.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
              >
                <RundownCard
                  rundown={ev}
                  onEdit={(e) => { setEditingEvent(e); setShowForm(true); }}
                  onDelete={handleDelete}
                  onDuplicate={(e) => setDupEvent(e)}
                  onPrint={(e) => setPrintEvent(e)}
                  onWhatsApp={handleWhatsApp}
                  onLiveRunner={() => {}}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {dupEvent && (
        <RundownDuplicateModal
          isOpen
          event={dupEvent}
          onClose={() => setDupEvent(null)}
          onDuplicate={handleDuplicate}
        />
      )}

      {printEvent && (
        <RundownPrintModal
          isOpen
          event={printEvent}
          onClose={() => setPrintEvent(null)}
        />
      )}
    </div>
  );
};
