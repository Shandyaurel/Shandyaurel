import React, { useState, useEffect } from 'react';
import {
  ATVBooking,
  ATVTrackItem,
  DiscountType,
  ATVBookingStatus,
  BusinessSettings,
  PaymentRecord,
  ClientContact,
} from '../../types';
import { subscribePartners } from '../../utils/firebase';
import {
  DEFAULT_BOOKING_SOURCES,
  DEFAULT_PAYMENT_METHODS,
  DEFAULT_ATV_TRACKS,
  formatRupiah,
  formatDateIndo,
  getTodayDateString,
  getCurrentTimeString,
  calculateATVCalculations,
  getPaymentStatusBadge,
} from '../../utils/formatters';
import {
  Plus,
  Trash2,
  Compass,
  Calendar,
  CreditCard,
  User,
  Clock,
  Percent,
  CheckCircle,
  Handshake,
  Building2,
  FileText,
} from 'lucide-react';

interface ATVBookingFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingToEdit?: ATVBooking | null;
  onSave: (data: Partial<ATVBooking>) => Promise<void>;
  businessSettings?: BusinessSettings | null;
  onOpenQuickDoc?: (booking: ATVBooking) => void;
}

export const ATVBookingFormModal: React.FC<ATVBookingFormModalProps> = ({
  isOpen,
  onClose,
  bookingToEdit,
  onSave,
  businessSettings,
  onOpenQuickDoc,
}) => {
  const isEditing = !!bookingToEdit;

  // Form State
  const [date, setDate] = useState<string>(getTodayDateString());
  const [bookingDate, setBookingDate] = useState<string>(getTodayDateString());
  const [bookingTime, setBookingTime] = useState<string>('09:00');
  const [guestName, setGuestName] = useState<string>('');
  const [guestPhone, setGuestPhone] = useState<string>('');
  const [sourceType, setSourceType] = useState<string>('Walk in');
  const [bookingVia, setBookingVia] = useState<string>('Walk in');
  const [partnerId, setPartnerId] = useState<string>('');
  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [status, setStatus] = useState<ATVBookingStatus>('Scheduled');
  const [notes, setNotes] = useState<string>('');

  // Tracks, Pricing, & Payment State
  const [tracks, setTracks] = useState<ATVTrackItem[]>([
    { trackType: DEFAULT_ATV_TRACKS[0].name, qty: 1, price: DEFAULT_ATV_TRACKS[0].defaultPrice },
  ]);
  const [discountType, setDiscountType] = useState<DiscountType>('Nominal');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [agentFee, setAgentFee] = useState<number>(0);

  // Payment State
  const [dp, setDp] = useState<number>(0);
  const [dpDate, setDpDate] = useState<string>(getTodayDateString());
  const [dpTime, setDpTime] = useState<string>(getCurrentTimeString());
  const [dpMethod, setDpMethod] = useState<string>('Transfer (PT)');

  const [pelunasan, setPelunasan] = useState<number>(0);
  const [pelunasanDate, setPelunasanDate] = useState<string>('');
  const [pelunasanTime, setPelunasanTime] = useState<string>('');
  const [pelunasanMethod, setPelunasanMethod] = useState<string>('Cash');

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Subscribe to partners
  useEffect(() => {
    if (!isOpen) return;
    const unsub = subscribePartners(
      (list) => setPartners(list),
      (err) => console.error('Error fetching partners in ATV form:', err),
    );
    return () => unsub();
  }, [isOpen]);

  // Combined sources & payment methods
  const bookingSources = Array.from(
    new Set([...DEFAULT_BOOKING_SOURCES, ...(businessSettings?.customBookingSources || [])]),
  );
  const paymentMethods = Array.from(
    new Set([...DEFAULT_PAYMENT_METHODS, ...(businessSettings?.customPaymentMethods || [])]),
  );

  // Populate form
  useEffect(() => {
    if (!isOpen) return;

    if (bookingToEdit) {
      setDate(bookingToEdit.date || getTodayDateString());
      setBookingDate(bookingToEdit.bookingDate || getTodayDateString());
      setBookingTime(bookingToEdit.bookingTime || '09:00');
      setGuestName(bookingToEdit.guestName || '');
      setGuestPhone(bookingToEdit.guestPhone || '');
      setBookingVia(bookingToEdit.bookingVia || 'Walk in');
      setPartnerId(bookingToEdit.partnerId || '');
      if (bookingToEdit.partnerId || (bookingToEdit.bookingVia && (bookingToEdit.bookingVia.toLowerCase().includes('mitra') || bookingToEdit.bookingVia.toLowerCase().includes('agent')))) {
        setSourceType('Tour Agent / Mitra');
      } else {
        setSourceType(bookingToEdit.bookingVia || 'Walk in');
      }
      setStatus(bookingToEdit.status || 'Scheduled');
      setNotes(bookingToEdit.notes || '');

      if (bookingToEdit.tracks && bookingToEdit.tracks.length > 0) {
        setTracks(bookingToEdit.tracks.map((t) => ({ ...t })));
      } else {
        setTracks([
          {
            trackType: DEFAULT_ATV_TRACKS[0].name,
            qty: 1,
            price: DEFAULT_ATV_TRACKS[0].defaultPrice,
          },
        ]);
      }

      setDiscountType(bookingToEdit.discountType || 'Nominal');
      setDiscountValue(bookingToEdit.discountValue || 0);
      setAgentFee(bookingToEdit.agentFee || 0);

      setDp(bookingToEdit.dp || 0);
      setDpDate(bookingToEdit.dpDate || bookingToEdit.date || getTodayDateString());
      setDpTime(bookingToEdit.dpTime || '12:00');
      setDpMethod(bookingToEdit.dpMethod || 'Cash');

      setPelunasan(bookingToEdit.pelunasan || 0);
      setPelunasanDate(bookingToEdit.pelunasanDate || '');
      setPelunasanTime(bookingToEdit.pelunasanTime || '');
      setPelunasanMethod(bookingToEdit.pelunasanMethod || 'Cash');
    } else {
      const today = getTodayDateString();
      setDate(today);
      setBookingDate(today);
      setBookingTime('09:00');
      setGuestName('');
      setGuestPhone('');
      setSourceType('Walk in');
      setBookingVia('Walk in');
      setPartnerId('');
      setStatus('Scheduled');
      setNotes('');

      setTracks([
        {
          trackType: DEFAULT_ATV_TRACKS[0].name,
          qty: 1,
          price: DEFAULT_ATV_TRACKS[0].defaultPrice,
        },
      ]);

      setDiscountType('Nominal');
      setDiscountValue(0);
      setAgentFee(0);

      setDp(0);
      setDpDate(today);
      setDpTime(getCurrentTimeString());
      setDpMethod('Transfer (PT)');

      setPelunasan(0);
      setPelunasanDate('');
      setPelunasanTime('');
      setPelunasanMethod('Cash');
    }
    setFormError('');
  }, [isOpen, bookingToEdit]);

  // Track Repeater Helpers
  const handleAddTrack = () => {
    setTracks((prev) => [
      ...prev,
      {
        trackType: DEFAULT_ATV_TRACKS[0].name,
        qty: 1,
        price: DEFAULT_ATV_TRACKS[0].defaultPrice,
      },
    ]);
  };

  const handleRemoveTrack = (index: number) => {
    if (tracks.length <= 1) return;
    setTracks((prev) => prev.filter((_, i) => i !== index));
  };

  const handleTrackFieldChange = (
    index: number,
    field: keyof ATVTrackItem,
    value: string | number,
  ) => {
    setTracks((prev) => {
      const copy = [...prev];
      const target = { ...copy[index] };

      if (field === 'trackType') {
        target.trackType = String(value);
        const found = DEFAULT_ATV_TRACKS.find((p) => p.name === value);
        if (found) target.price = found.defaultPrice;
      } else if (field === 'qty') {
        target.qty = Math.max(1, Number(value) || 1);
      } else if (field === 'price') {
        target.price = Math.max(0, Number(value) || 0);
      }

      copy[index] = target;
      return copy;
    });
  };

  // Calculations
  const calc = calculateATVCalculations({
    tracks,
    discountType,
    discountValue,
    agentFee,
    dp,
    pelunasan,
  });

  const paymentBadge = getPaymentStatusBadge(calc.paymentStatus);

  // Quick Pay Helper
  const handlePayFullRemaining = () => {
    const remaining = Math.max(0, calc.grandTotal - (Number(dp) || 0));
    setPelunasan(remaining);
    if (!pelunasanDate) setPelunasanDate(getTodayDateString());
    if (!pelunasanTime) setPelunasanTime(getCurrentTimeString());
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!guestName.trim()) {
      setFormError('Nama tamu/pengemudi wajib diisi.');
      return;
    }

    if (tracks.length === 0) {
      setFormError('Minimal harus memilih 1 jenis track ATV.');
      return;
    }

    // Build payment history
    const paymentHistory: PaymentRecord[] = [];
    if (dp > 0) {
      paymentHistory.push({
        id: `pay_dp_${Date.now()}`,
        date: dpDate || date || getTodayDateString(),
        time: dpTime || '12:00',
        amount: Number(dp),
        method: dpMethod,
        type: 'DP',
        notes: 'DP Sewa ATV',
      });
    }
    if (pelunasan > 0) {
      paymentHistory.push({
        id: `pay_lunas_${Date.now() + 1}`,
        date: pelunasanDate || date || getTodayDateString(),
        time: pelunasanTime || getCurrentTimeString(),
        amount: Number(pelunasan),
        method: pelunasanMethod,
        type: 'Pelunasan',
        notes: 'Pelunasan Sewa ATV',
      });
    }

    const selectedPartnerObj = partnerId ? partners.find((p) => p.id === partnerId) : undefined;
    const finalBookingVia = partnerId && selectedPartnerObj ? selectedPartnerObj.name : bookingVia;

    const payload: Partial<ATVBooking> = {
      ...(bookingToEdit ? { id: bookingToEdit.id } : {}),
      date,
      bookingDate,
      bookingTime,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
      bookingVia: finalBookingVia,
      partnerId: partnerId || undefined,
      partnerName: selectedPartnerObj ? selectedPartnerObj.name : undefined,
      tracks,
      discountType,
      discountValue: Number(discountValue) || 0,
      discountAmount: calc.discountAmount,
      agentFee: Number(agentFee) || 0,
      grandTotal: calc.grandTotal,
      dp: Number(dp) || 0,
      dpDate: dp > 0 ? dpDate : '',
      dpTime: dp > 0 ? dpTime : '',
      dpMethod: dp > 0 ? dpMethod : '',
      pelunasan: Number(pelunasan) || 0,
      pelunasanDate: pelunasan > 0 ? pelunasanDate : '',
      pelunasanTime: pelunasan > 0 ? pelunasanTime : '',
      pelunasanMethod: pelunasan > 0 ? pelunasanMethod : '',
      paymentHistory,
      pendapatan: calc.pendapatan,
      status,
      paymentMethod: dpMethod || pelunasanMethod || 'Cash',
      notes: notes.trim(),
    };

    try {
      setIsSaving(true);
      await onSave(payload);
      onClose();
    } catch (err) {
      console.error('Error saving ATV booking:', err);
      setFormError('Gagal menyimpan reservasi ATV. Silakan coba lagi.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  const selectedPartner = partnerId ? partners.find((p) => p.id === partnerId) : undefined;

  return (
    <div
      id="atv-booking-form-modal"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
    >
      <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-600 text-white flex items-center justify-center shadow-xs">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isEditing ? `Ubah Sewa ATV (${bookingToEdit.id})` : 'Pemesanan Sewa ATV Adventure Baru'}
              </h2>
              <p className="text-xs text-slate-500">
                Atur jadwal sesi main, pilihan trek, jumlah unit, dan rincian pembayaran.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isEditing && bookingToEdit && onOpenQuickDoc && (
              <button
                type="button"
                onClick={() => onOpenQuickDoc(bookingToEdit)}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Buka Dokumen & Salin WhatsApp"
              >
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                <span>Dokumen & WA</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {formError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700">
              {formError}
            </div>
          )}

          {/* Section 1: Informasi Tamu & Sesi Main */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-orange-600" />
              <span>Informasi Tamu & Jadwal Sesi</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Tamu / Grup <span className="text-rose-500">*</span>
                </label>
                <input
                  id="atv-guest-name"
                  type="text"
                  required
                  placeholder="Contoh: Rian & Rekan / Bpk. Aditya"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-orange-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sumber Pemesanan
                </label>
                <select
                  id="atv-booking-via"
                  value={sourceType}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSourceType(val);
                    if (val === 'Tour Agent / Mitra') {
                      if (!partnerId && partners.length > 0) {
                        setPartnerId(partners[0].id);
                        setBookingVia(partners[0].name);
                      }
                    } else {
                      setPartnerId('');
                      setBookingVia(val);
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-orange-600 font-medium"
                >
                  <option value="Walk in">Walk in (Langsung di Lokasi)</option>
                  <option value="Direct WA">Direct WhatsApp / Telepon</option>
                  <option value="Instagram">Instagram</option>
                  <option value="TikTok">TikTok</option>
                  <option value="Website">Website Resmi</option>
                  <option value="OTA">OTA (Agoda / Traveloka / Booking)</option>
                  <option value="Tour Agent / Mitra">Tour Agent / Mitra Bisnis</option>
                  {businessSettings?.customBookingSources?.filter((s) => !['Walk in', 'Direct WA', 'Instagram', 'TikTok', 'Website', 'OTA', 'Tour Agent / Mitra'].includes(s)).map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Sub-dropdown when Tour Agent / Mitra is selected */}
            {(sourceType === 'Tour Agent / Mitra' || partnerId) && (
              <div className="p-3 bg-orange-50/70 border border-orange-200 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-orange-900">
                  <Handshake className="w-4 h-4 text-orange-600" />
                  <span>Pilih Mitra Bisnis / Travel Agent Terdaftar</span>
                </div>
                {partners.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
                    <select
                      value={partnerId}
                      onChange={(e) => {
                        const pId = e.target.value;
                        setPartnerId(pId);
                        const pObj = partners.find((p) => p.id === pId);
                        if (pObj) {
                          setBookingVia(pObj.name);
                        }
                      }}
                      className="w-full px-3 py-2 bg-white border border-orange-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-orange-500"
                    >
                      <option value="">-- Pilih Mitra --</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} {p.detail ? `(${p.detail})` : ''} - {p.homeBase || 'Lokal'}
                        </option>
                      ))}
                    </select>
                    {selectedPartner && (
                      <div className="text-[11px] text-orange-800 bg-white px-2.5 py-1.5 rounded-lg border border-orange-100 flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                        <span className="truncate">
                          PIC: <strong>{selectedPartner.contactPerson || '-'}</strong> | Telp: {selectedPartner.phone || '-'}
                        </span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    Belum ada mitra bisnis tersimpan. Anda dapat mendaftarkan mitra di menu <strong>Mitra Bisnis</strong>.
                  </p>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  No. WhatsApp / HP
                </label>
                <input
                  id="atv-guest-phone"
                  type="text"
                  placeholder="08123456789"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-orange-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tgl Transaksi (`date`)
                </label>
                <input
                  id="atv-transaction-date"
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-orange-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tgl Main (`bookingDate`)
                </label>
                <input
                  id="atv-ride-date"
                  type="date"
                  required
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-orange-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Jam Sesi (`bookingTime`)
                </label>
                <input
                  id="atv-ride-time"
                  type="time"
                  required
                  value={bookingTime}
                  onChange={(e) => setBookingTime(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-orange-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200/60">
              <span className="text-xs font-semibold text-slate-600">Status Sesi ATV:</span>
              <select
                id="atv-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as ATVBookingStatus)}
                className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-orange-600"
              >
                <option value="Scheduled">Scheduled (Terjadwal)</option>
                <option value="Completed">Completed (Selesai Main)</option>
                <option value="Cancelled">Cancelled (Batal)</option>
              </select>
            </div>
          </div>

          {/* Section 2: Multi-Track Repeater */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <Compass className="w-4 h-4 text-orange-600" />
                <span>Pilihan Track ATV ({tracks.length})</span>
              </h3>
              <button
                type="button"
                onClick={handleAddTrack}
                className="px-3 py-1 bg-orange-50 hover:bg-orange-100 text-orange-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Jenis Track</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {tracks.map((track, idx) => {
                const itemSubtotal = (Number(track.price) || 0) * (Number(track.qty) || 1);

                return (
                  <div
                    key={idx}
                    className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center gap-3"
                  >
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {/* Track Type */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Jenis Track #{idx + 1}
                        </label>
                        <select
                          value={track.trackType}
                          onChange={(e) => handleTrackFieldChange(idx, 'trackType', e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white focus:border-orange-600"
                        >
                          {DEFAULT_ATV_TRACKS.map((p) => (
                            <option key={p.name} value={p.name}>
                              {p.name} ({formatRupiah(p.defaultPrice)})
                            </option>
                          ))}
                          <option value="Track Khusus">Kustom Lainnya...</option>
                        </select>
                      </div>

                      {/* Quantity */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Jumlah Unit / Orang
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={track.qty}
                          onChange={(e) => handleTrackFieldChange(idx, 'qty', e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 text-center focus:outline-hidden focus:bg-white focus:border-orange-600"
                        />
                      </div>

                      {/* Price */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Harga / Unit (Rp)
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="10000"
                          value={track.price}
                          onChange={(e) => handleTrackFieldChange(idx, 'price', e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 text-right focus:outline-hidden focus:bg-white focus:border-orange-600"
                        />
                      </div>
                    </div>

                    {/* Subtotal & Delete */}
                    <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 shrink-0">
                      <div className="text-right">
                        <div className="text-[10px] text-slate-400">Total</div>
                        <div className="text-xs font-bold text-slate-900">
                          {formatRupiah(itemSubtotal)}
                        </div>
                      </div>

                      {tracks.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveTrack(idx)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 3: Diskon & Agent Fee */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Percent className="w-4 h-4 text-orange-600" />
              <span>Potongan Harga & Komisi Agent</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tipe Diskon</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDiscountType('Nominal')}
                    className={`py-1.5 px-3 text-xs font-semibold rounded-lg border text-center cursor-pointer ${
                      discountType === 'Nominal'
                        ? 'bg-orange-600 text-white border-orange-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    Nominal
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiscountType('Persen')}
                    className={`py-1.5 px-3 text-xs font-semibold rounded-lg border text-center cursor-pointer ${
                      discountType === 'Persen'
                        ? 'bg-orange-600 text-white border-orange-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    Persen (%)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nilai Diskon ({discountType === 'Persen' ? '%' : 'Rp'})
                </label>
                <input
                  id="atv-discount-value"
                  type="number"
                  min="0"
                  max={discountType === 'Persen' ? 100 : undefined}
                  value={discountValue}
                  onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-orange-600 text-right"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Agent Fee / Komisi (Rp)</label>
                <input
                  id="atv-agent-fee"
                  type="number"
                  min="0"
                  step="10000"
                  value={agentFee}
                  onChange={(e) => setAgentFee(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-orange-600 text-right"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Live Summary */}
          <div className="bg-orange-50/60 p-4 rounded-xl border border-orange-100 flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-500 block">Subtotal</span>
              <span className="text-sm font-semibold text-slate-800">{formatRupiah(calc.subtotal)}</span>
            </div>
            {calc.discountAmount > 0 && (
              <div>
                <span className="text-xs text-rose-500 block">Diskon</span>
                <span className="text-sm font-semibold text-rose-600">−{formatRupiah(calc.discountAmount)}</span>
              </div>
            )}
            <div>
              <span className="text-xs text-orange-600 block font-bold uppercase tracking-wider">Grand Total</span>
              <span className="text-lg font-extrabold text-orange-950">{formatRupiah(calc.grandTotal)}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block">Pendapatan Bersih</span>
              <span className="text-sm font-bold text-emerald-700">{formatRupiah(calc.pendapatan)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Status Bayar:</span>
              <span
                className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${paymentBadge.bg} ${paymentBadge.text} ${paymentBadge.border}`}
              >
                {paymentBadge.label}
              </span>
            </div>
          </div>

          {/* Section 5: DP & Pelunasan */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-orange-600" />
                <span>Pencatatan Pembayaran ATV</span>
              </h3>
              {calc.sisa > 0 && (
                <button
                  type="button"
                  onClick={handlePayFullRemaining}
                  className="text-xs text-orange-600 hover:text-orange-800 font-semibold cursor-pointer"
                >
                  Lunaskan Sisa ({formatRupiah(calc.sisa)})
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* DP */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
                <span className="text-xs font-bold text-slate-900 block">Uang Muka (DP)</span>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Jumlah DP (Rp)</label>
                  <input
                    id="atv-dp-amount"
                    type="number"
                    min="0"
                    step="10000"
                    placeholder="0"
                    value={dp}
                    onChange={(e) => setDp(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:bg-white text-right font-semibold"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    value={dpDate}
                    onChange={(e) => setDpDate(e.target.value)}
                    className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                  <select
                    value={dpMethod}
                    onChange={(e) => setDpMethod(e.target.value)}
                    className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    {paymentMethods.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pelunasan */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
                <span className="text-xs font-bold text-slate-900 block">Pelunasan</span>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Jumlah Pelunasan (Rp)</label>
                  <input
                    id="atv-pelunasan-amount"
                    type="number"
                    min="0"
                    step="10000"
                    placeholder="0"
                    value={pelunasan}
                    onChange={(e) => setPelunasan(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:bg-white text-right font-semibold"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    value={pelunasanDate}
                    onChange={(e) => setPelunasanDate(e.target.value)}
                    className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                  <select
                    value={pelunasanMethod}
                    onChange={(e) => setPelunasanMethod(e.target.value)}
                    className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    {paymentMethods.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Section 6: Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Catatan Tambahan</label>
            <textarea
              id="atv-notes"
              rows={2}
              placeholder="Contoh: Termasuk peminjaman perlengkapan helm & sepatu boots..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-orange-600"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs rounded-lg transition-colors shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Menyimpan...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'Simpan Perubahan' : 'Simpan Sewa ATV'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
