import React, { useState, useMemo } from 'react';
import { ATVBooking, BusinessSettings } from '../../types';
import {
  formatRupiah,
  formatDateIndo,
  calculatePaymentStatus,
  getPaymentStatusBadge,
} from '../../utils/formatters';
import {
  Compass,
  CreditCard,
  DollarSign,
  TrendingUp,
  Printer,
  Users,
} from 'lucide-react';

interface ATVReportViewProps {
  bookings: ATVBooking[];
  businessSettings?: BusinessSettings | null;
}

export const ATVReportView: React.FC<ATVReportViewProps> = ({ bookings }) => {
  const [reportMode, setReportMode] = useState<'TRANSAKSI' | 'MAIN'>('MAIN');
  const [periodPreset, setPeriodPreset] = useState<'thisMonth' | 'lastMonth' | 'thisYear' | 'custom'>('thisMonth');

  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth();

  const firstDayThisMonth = new Date(currentYear, currentMonth, 1).toISOString().split('T')[0];
  const lastDayThisMonth = new Date(currentYear, currentMonth + 1, 0).toISOString().split('T')[0];

  const [startDate, setStartDate] = useState<string>(firstDayThisMonth);
  const [endDate, setEndDate] = useState<string>(lastDayThisMonth);

  const handlePeriodPresetChange = (preset: 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom') => {
    setPeriodPreset(preset);
    if (preset === 'thisMonth') {
      setStartDate(new Date(currentYear, currentMonth, 1).toISOString().split('T')[0]);
      setEndDate(new Date(currentYear, currentMonth + 1, 0).toISOString().split('T')[0]);
    } else if (preset === 'lastMonth') {
      setStartDate(new Date(currentYear, currentMonth - 1, 1).toISOString().split('T')[0]);
      setEndDate(new Date(currentYear, currentMonth, 0).toISOString().split('T')[0]);
    } else if (preset === 'thisYear') {
      setStartDate(`${currentYear}-01-01`);
      setEndDate(`${currentYear}-12-31`);
    }
  };

  const filteredBookings = useMemo(() => {
    return bookings.filter((b) => {
      if (b.status === 'Cancelled') return false;
      const targetDate = reportMode === 'TRANSAKSI' ? b.date : (b.bookingDate || b.date);
      if (!targetDate) return false;
      if (startDate && targetDate < startDate) return false;
      if (endDate && targetDate > endDate) return false;
      return true;
    });
  }, [bookings, reportMode, startDate, endDate]);

  const metrics = useMemo(() => {
    let totalPendapatan = 0;
    let totalGrandTotal = 0;
    let totalDiscount = 0;
    let totalAgentFee = 0;
    let totalUnitsSold = 0;
    let totalDibayar = 0;

    const paymentMethodMap: Record<string, { amount: number; count: number }> = {};
    const trackMap: Record<string, { count: number; revenue: number }> = {};

    filteredBookings.forEach((b) => {
      totalPendapatan += b.pendapatan || (b.grandTotal - (b.agentFee || 0)) || 0;
      totalGrandTotal += b.grandTotal || 0;
      totalDiscount += b.discountAmount || 0;
      totalAgentFee += b.agentFee || 0;

      const paid = (b.dp || 0) + (b.pelunasan || 0);
      totalDibayar += paid;

      // Track items aggregation
      if (b.tracks && b.tracks.length > 0) {
        b.tracks.forEach((t) => {
          const qty = Number(t.qty) || 1;
          const price = Number(t.price) || 0;
          totalUnitsSold += qty;
          const trackName = t.trackType || 'Standard Track';
          if (!trackMap[trackName]) {
            trackMap[trackName] = { count: 0, revenue: 0 };
          }
          trackMap[trackName].count += qty;
          trackMap[trackName].revenue += qty * price;
        });
      }

      // Payment Breakdown
      if (b.paymentHistory && b.paymentHistory.length > 0) {
        b.paymentHistory.forEach((p) => {
          const m = p.method || 'Lainnya';
          if (!paymentMethodMap[m]) paymentMethodMap[m] = { amount: 0, count: 0 };
          paymentMethodMap[m].amount += p.amount || 0;
          paymentMethodMap[m].count += 1;
        });
      } else {
        if (b.dp && b.dp > 0) {
          const m = b.dpMethod || 'Cash';
          if (!paymentMethodMap[m]) paymentMethodMap[m] = { amount: 0, count: 0 };
          paymentMethodMap[m].amount += b.dp;
          paymentMethodMap[m].count += 1;
        }
        if (b.pelunasan && b.pelunasan > 0) {
          const m = b.pelunasanMethod || 'Cash';
          if (!paymentMethodMap[m]) paymentMethodMap[m] = { amount: 0, count: 0 };
          paymentMethodMap[m].amount += b.pelunasan;
          paymentMethodMap[m].count += 1;
        }
      }
    });

    const avgValue = filteredBookings.length > 0 ? Math.round(totalGrandTotal / filteredBookings.length) : 0;

    return {
      totalBookings: filteredBookings.length,
      totalPendapatan,
      totalGrandTotal,
      totalDiscount,
      totalAgentFee,
      totalUnitsSold,
      totalDibayar,
      avgValue,
      paymentMethodBreakdown: Object.entries(paymentMethodMap).sort((a, b) => b[1].amount - a[1].amount),
      trackBreakdown: Object.entries(trackMap).sort((a, b) => b[1].revenue - a[1].revenue),
    };
  }, [filteredBookings]);

  return (
    <div id="atv-report-view" className="space-y-6">
      {/* Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Mode Laporan:</span>
          <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setReportMode('MAIN')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                reportMode === 'MAIN' ? 'bg-white text-orange-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Mode Tgl Main (`bookingDate`)
            </button>
            <button
              type="button"
              onClick={() => setReportMode('TRANSAKSI')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                reportMode === 'TRANSAKSI' ? 'bg-white text-orange-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Mode Transaksi (`date`)
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('thisMonth')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                periodPreset === 'thisMonth' ? 'bg-orange-600 text-white font-semibold' : 'text-slate-600'
              }`}
            >
              Bulan Ini
            </button>
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('lastMonth')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                periodPreset === 'lastMonth' ? 'bg-orange-600 text-white font-semibold' : 'text-slate-600'
              }`}
            >
              Bulan Lalu
            </button>
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('thisYear')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                periodPreset === 'thisYear' ? 'bg-orange-600 text-white font-semibold' : 'text-slate-600'
              }`}
            >
              Tahun Ini
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800"
            />
            <span className="text-xs text-slate-400">s/d</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800"
            />
          </div>

          <button
            type="button"
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg inline-flex items-center gap-1.5 cursor-pointer ml-auto"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Pendapatan Bersih ATV
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.totalPendapatan)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Grand Total: {formatRupiah(metrics.totalGrandTotal)}
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Unit ATV Disewa
            </span>
            <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
              <Compass className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {metrics.totalUnitsSold} Unit
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Dari {metrics.totalBookings} transaksi pemesanan
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Rata-rata / Transaksi
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.avgValue)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Agent Fee: {formatRupiah(metrics.totalAgentFee)}
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Realisasi Terbayar
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.totalDibayar)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Diskon: {formatRupiah(metrics.totalDiscount)}
          </div>
        </div>
      </div>

      {/* Breakdown per Metode & Track */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-orange-600" />
            <span>Breakdown Metode Pembayaran</span>
          </h3>

          {metrics.paymentMethodBreakdown.length > 0 ? (
            <div className="space-y-3">
              {metrics.paymentMethodBreakdown.map(([method, data]) => {
                const percentage = metrics.totalDibayar > 0 ? Math.round((data.amount / metrics.totalDibayar) * 100) : 0;
                return (
                  <div key={method} className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="font-semibold text-slate-800">{method}</span>
                      <span className="font-bold text-slate-900">{formatRupiah(data.amount)} ({percentage}%)</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-orange-600 rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400">Belum ada data pembayaran.</div>
          )}
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Compass className="w-4 h-4 text-orange-600" />
            <span>Breakdown Jenis Track ATV</span>
          </h3>

          {metrics.trackBreakdown.length > 0 ? (
            <div className="space-y-3">
              {metrics.trackBreakdown.map(([trackName, data]) => {
                const percentage = metrics.totalGrandTotal > 0 ? Math.round((data.revenue / metrics.totalGrandTotal) * 100) : 0;
                return (
                  <div key={trackName} className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="font-semibold text-slate-800">{trackName} ({data.count} unit)</span>
                      <span className="font-bold text-slate-900">{formatRupiah(data.revenue)} ({percentage}%)</span>
                    </div>
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-6 text-center text-xs text-slate-400">Belum ada data track.</div>
          )}
        </div>
      </div>
    </div>
  );
};
