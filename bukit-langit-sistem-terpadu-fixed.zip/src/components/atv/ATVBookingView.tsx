import React, { useState, useEffect, useMemo } from 'react';
import { ATVBooking, BusinessSettings } from '../../types';
import {
  subscribeATVBookings,
  saveATVBooking,
  deleteATVBooking,
  deleteATVBookingsBatch,
  getBusinessSettings,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  formatRupiah,
  formatDateIndo,
  getTodayDateString,
  calculatePaymentStatus,
  getPaymentStatusBadge,
} from '../../utils/formatters';
import { ATVBookingFormModal } from './ATVBookingFormModal';
import { ATVReportView } from './ATVReportView';
import { Modal } from '../common/Modal';
import { TransactionQuickDocWAModal } from '../documents/TransactionQuickDocWAModal';
import {
  Compass,
  Plus,
  Search,
  BarChart3,
  Edit2,
  Trash2,
  Phone,
  Clock,
  CheckSquare,
  FileText,
} from 'lucide-react';

interface ATVBookingViewProps {
  businessSettings?: BusinessSettings | null;
}

export const ATVBookingView: React.FC<ATVBookingViewProps> = ({ businessSettings }) => {
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [activeTab, setActiveTab] = useState<'manage' | 'reports'>('manage');
  const [bookings, setBookings] = useState<ATVBooking[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Selection for bulk actions
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState<boolean>(false);
  const [bulkDeleteReason, setBulkDeleteReason] = useState<string>('');

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateFilterType, setDateFilterType] = useState<'all' | 'today' | 'thisMonth' | 'custom'>('all');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState<string>('all');
  const [filterOpStatus, setFilterOpStatus] = useState<string>('all');

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [bookingToEdit, setBookingToEdit] = useState<ATVBooking | null>(null);
  const [quickDocBooking, setQuickDocBooking] = useState<ATVBooking | null>(null);

  const [bookingToDelete, setBookingToDelete] = useState<ATVBooking | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeATVBookings(
      (data) => {
        setBookings(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error fetching ATV bookings:', error);
        showError('Gagal memuat data sewa ATV.');
        setIsLoading(false);
      },
    );
    return () => unsubscribe();
  }, [showError]);

  const stats = useMemo(() => {
    let totalPendapatan = 0;
    let totalUnits = 0;
    let lunasCount = 0;
    let dpCount = 0;
    let belumBayarCount = 0;

    bookings.forEach((b) => {
      if (b.status !== 'Cancelled') {
        totalPendapatan += b.pendapatan || (b.grandTotal - (b.agentFee || 0)) || 0;
      }
      if (b.tracks) {
        b.tracks.forEach((t) => {
          totalUnits += Number(t.qty) || 1;
        });
      }
      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
      const st = calculatePaymentStatus(totalPaid, b.grandTotal);
      if (st === 'Lunas') lunasCount++;
      else if (st === 'DP') dpCount++;
      else belumBayarCount++;
    });

    return {
      total: bookings.length,
      totalUnits,
      totalPendapatan,
      lunasCount,
      dpCount,
      belumBayarCount,
    };
  }, [bookings]);

  const filteredBookings = useMemo(() => {
    const todayStr = getTodayDateString();
    const currentMonth = todayStr.substring(0, 7);

    return bookings.filter((b) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = b.guestName.toLowerCase().includes(q);
        const matchPhone = b.guestPhone?.toLowerCase().includes(q);
        const matchId = b.id.toLowerCase().includes(q);
        const matchTrack = b.tracks?.some((t) => t.trackType.toLowerCase().includes(q));
        if (!matchName && !matchPhone && !matchId && !matchTrack) return false;
      }

      const bDate = b.bookingDate || b.date || '';
      if (dateFilterType === 'today') {
        if (b.bookingDate !== todayStr && b.date !== todayStr) return false;
      } else if (dateFilterType === 'thisMonth') {
        if (!bDate.startsWith(currentMonth)) return false;
      } else if (dateFilterType === 'custom') {
        if (customStartDate && bDate < customStartDate) return false;
        if (customEndDate && bDate > customEndDate) return false;
      }

      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
      const payStatus = calculatePaymentStatus(totalPaid, b.grandTotal);
      if (filterPaymentStatus !== 'all' && payStatus !== filterPaymentStatus) {
        return false;
      }

      if (filterOpStatus !== 'all' && b.status !== filterOpStatus) {
        return false;
      }

      return true;
    });
  }, [bookings, searchQuery, dateFilterType, customStartDate, customEndDate, filterPaymentStatus, filterOpStatus]);

  const handleOpenAdd = () => {
    setBookingToEdit(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEdit = (booking: ATVBooking) => {
    setBookingToEdit(booking);
    setIsFormModalOpen(true);
  };

  const handleSave = async (payload: Partial<ATVBooking>): Promise<void> => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const isNew = !payload.id;

    // (1) Tampilkan toast "Reservasi tersimpan" segera (OPTIMISTIC)
    showSuccess(isNew ? 'Reservasi tersimpan' : 'Pemesanan ATV diperbarui');

    // (2) Panggil saveATVBooking TANPA await agar modal langsung menutup < 1 detik
    saveATVBooking(payload, userEmail)
      .then(async (savedId) => {
        const targetId = savedId || payload.id;
        // Booking saved successfully
      })
      .catch((err) => {
        console.error('Error saving ATV booking to Firestore:', err);
        showError('Gagal sinkron ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  const handleDeleteClick = (booking: ATVBooking) => {
    setBookingToDelete(booking);
    setDeleteReason('');
  };

  const handleConfirmDelete = () => {
    if (!bookingToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const targetBooking = bookingToDelete;
    const reason = deleteReason.trim();

    // (1) Langsung tutup modal konfirmasi dan tampilkan toast segera (OPTIMISTIC <1 detik)
    setBookingToDelete(null);
    setDeleteReason('');
    showSuccess(`Pemesanan ATV ${targetBooking.guestName} berhasil dihapus.`);

    // (2) Panggil deleteATVBooking TANPA await di latar belakang
    deleteATVBooking(targetBooking, userEmail, reason)
      .catch((err) => {
        console.error('Error deleting ATV:', err);
        showError('Gagal sinkron hapus ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  // Selection Helpers
  const isAllSelected = filteredBookings.length > 0 && selectedIds.length === filteredBookings.length;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredBookings.map((b) => b.id));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleOpenBulkDeleteModal = () => {
    if (selectedIds.length === 0) return;
    setBulkDeleteReason('');
    setIsBulkDeleteModalOpen(true);
  };

  const handleConfirmBulkDelete = () => {
    if (selectedIds.length === 0) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const targetBookings = bookings.filter((b) => selectedIds.includes(b.id));
    const targetIds = [...selectedIds];
    const count = targetIds.length;
    const reason = bulkDeleteReason.trim();

    // (1) Tutup modal dan bersihkan pilihan segera (OPTIMISTIC <1 detik)
    setIsBulkDeleteModalOpen(false);
    setSelectedIds([]);
    setBulkDeleteReason('');
    showSuccess(`${count} sesi ATV berhasil dihapus.`);

    // (2) Jalankan batch delete di latar belakang TANPA await di jalur UI
    deleteATVBookingsBatch(targetBookings, userEmail, reason)
      .catch((err) => {
        console.error('Error in batch delete ATV:', err);
        showError('Gagal sinkron hapus massal ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  return (
    <div id="atv-booking-module" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Compass className="w-6 h-6 text-orange-600" />
            <span>Sewa & Petualangan ATV</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Jadwal sesi main, pilihan trek medan, pencatatan DP/Lunas, dan laporan revenue ATV.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-slate-200/70 rounded-xl border border-slate-200 flex items-center">
            <button
              id="tab-manage-atv"
              type="button"
              onClick={() => setActiveTab('manage')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'manage' ? 'bg-white text-orange-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              Kelola Sesi ATV
            </button>
            <button
              id="tab-report-atv"
              type="button"
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'reports' ? 'bg-white text-orange-700 shadow-xs' : 'text-slate-600'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Laporan & Analitik</span>
            </button>
          </div>

          {activeTab === 'manage' && (
            <button
              id="btn-add-atv-booking"
              type="button"
              onClick={handleOpenAdd}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Sewa ATV</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'reports' ? (
        <ATVReportView bookings={bookings} businessSettings={businessSettings} />
      ) : (
        <>
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Total Transaksi</span>
              <span className="text-lg font-bold text-slate-900">{stats.total}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Unit ATV Disewa</span>
              <span className="text-lg font-bold text-orange-600">{stats.totalUnits} Unit</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Total Pendapatan</span>
              <span className="text-lg font-bold text-emerald-600">{formatRupiah(stats.totalPendapatan)}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Status Lunas</span>
              <span className="text-lg font-bold text-emerald-600">{stats.lunasCount}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Belum Bayar / DP</span>
              <span className="text-lg font-bold text-amber-600">{stats.dpCount + stats.belumBayarCount}</span>
            </div>
          </div>

          {/* Filter & Search */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="relative md:col-span-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="atv-search-input"
                  type="text"
                  placeholder="Cari nama pemesan, kontak, track..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-orange-600"
                />
              </div>

              <div>
                <select
                  value={filterPaymentStatus}
                  onChange={(e) => setFilterPaymentStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white"
                >
                  <option value="all">Semua Status Bayar</option>
                  <option value="Lunas">Lunas</option>
                  <option value="DP">DP</option>
                  <option value="Belum Bayar">Belum Bayar</option>
                </select>
              </div>

              <div>
                <select
                  value={filterOpStatus}
                  onChange={(e) => setFilterOpStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white"
                >
                  <option value="all">Semua Status Sesi</option>
                  <option value="Scheduled">Scheduled</option>
                  <option value="Completed">Completed</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">Filter Tanggal Main:</span>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setDateFilterType('all')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                      dateFilterType === 'all' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Semua
                  </button>
                  <button
                    type="button"
                    onClick={() => setDateFilterType('today')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                      dateFilterType === 'today' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Hari Ini
                  </button>
                  <button
                    type="button"
                    onClick={() => setDateFilterType('thisMonth')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                      dateFilterType === 'thisMonth' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Bulan Ini
                  </button>
                  <button
                    type="button"
                    onClick={() => setDateFilterType('custom')}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                      dateFilterType === 'custom' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                    }`}
                  >
                    Kustom
                  </button>
                </div>

                {dateFilterType === 'custom' && (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="date"
                      value={customStartDate}
                      onChange={(e) => setCustomStartDate(e.target.value)}
                      className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                    <span className="text-xs text-slate-400">s/d</span>
                    <input
                      type="date"
                      value={customEndDate}
                      onChange={(e) => setCustomEndDate(e.target.value)}
                      className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                )}
              </div>

              {/* Bulk Delete Button when items selected */}
              {selectedIds.length > 0 && (
                <button
                  type="button"
                  onClick={handleOpenBulkDeleteModal}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus Terpilih ({selectedIds.length})</span>
                </button>
              )}
            </div>
          </div>

          {/* ATV Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {isLoading ? (
              <div className="py-16 text-center">
                <div className="w-8 h-8 border-3 border-orange-600/30 border-t-orange-600 rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs text-slate-400">Memuat data sesi ATV...</p>
              </div>
            ) : filteredBookings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                      <th className="py-3 px-3 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={isAllSelected}
                          onChange={toggleSelectAll}
                          aria-label="Pilih semua sesi ATV"
                          className="w-4 h-4 rounded text-orange-600 border-slate-300 focus:ring-orange-500 cursor-pointer"
                        />
                      </th>
                      <th className="py-3 px-4">Jadwal Sesi</th>
                      <th className="py-3 px-4">Tamu & Kontak</th>
                      <th className="py-3 px-4">Rincian Track</th>
                      <th className="py-3 px-4">Sumber</th>
                      <th className="py-3 px-4 text-right">Grand Total</th>
                      <th className="py-3 px-4 text-center">Status Bayar</th>
                      <th className="py-3 px-4 text-center">Status Sesi</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {filteredBookings.map((b) => {
                      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
                      const paymentStatus = calculatePaymentStatus(totalPaid, b.grandTotal);
                      const badge = getPaymentStatusBadge(paymentStatus);
                      const isRowSelected = selectedIds.includes(b.id);

                      const trackSummary = b.tracks && b.tracks.length > 0
                        ? b.tracks.map((t) => `${t.trackType} ×${t.qty}`).join(', ')
                        : 'ATV Ride';

                      return (
                        <tr
                          key={b.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            isRowSelected ? 'bg-orange-50/40' : ''
                          }`}
                        >
                          <td className="py-3 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={isRowSelected}
                              onChange={() => toggleSelectRow(b.id)}
                              aria-label={`Pilih sesi ${b.guestName}`}
                              className="w-4 h-4 rounded text-orange-600 border-slate-300 focus:ring-orange-500 cursor-pointer"
                            />
                          </td>

                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">{formatDateIndo(b.bookingDate)}</div>
                            <div className="text-[11px] text-orange-600 font-medium flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3" />
                              <span>{b.bookingTime || '09:00'} WIB</span>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{b.guestName}</div>
                            {b.guestPhone && (
                              <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span>{b.guestPhone}</span>
                              </div>
                            )}
                          </td>

                          <td className="py-3 px-4 max-w-xs font-medium text-slate-800 truncate" title={trackSummary}>
                            {trackSummary}
                          </td>

                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-medium rounded text-[11px]">
                              {b.bookingVia}
                            </span>
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="font-bold text-slate-900">{formatRupiah(b.grandTotal)}</div>
                            <div className="text-[10px] text-slate-400">Dibayar: {formatRupiah(totalPaid)}</div>
                          </td>

                          <td className="py-3 px-4 text-center">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg} ${badge.text} ${badge.border}`}
                            >
                              {badge.label}
                            </span>
                          </td>

                          <td className="py-3 px-4 text-center">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-semibold ${
                                b.status === 'Scheduled'
                                  ? 'bg-blue-50 text-blue-700'
                                  : b.status === 'Completed'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-rose-50 text-rose-600'
                              }`}
                            >
                              {b.status}
                            </span>
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setQuickDocBooking(b)}
                                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                                title="Buat Dokumen & Salin WhatsApp"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Dokumen / WA</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEdit(b)}
                                className="p-1.5 text-slate-500 hover:text-orange-600 hover:bg-orange-50 rounded-lg cursor-pointer"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteClick(b)}
                                className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-16 text-center">
                <Compass className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-700">Belum Ada Sesi ATV</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Belum ada transaksi pemesanan ATV. Klik tombol Tambah Sewa ATV di atas untuk mulai mencatat.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {/* Form Modal */}
      {isFormModalOpen && (
        <ATVBookingFormModal
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          bookingToEdit={bookingToEdit}
          onSave={handleSave}
          businessSettings={businessSettings}
          onOpenQuickDoc={(b) => setQuickDocBooking(b)}
        />
      )}

      {/* Quick Action Modal: Dokumen & Salin WhatsApp */}
      {quickDocBooking && (
        <TransactionQuickDocWAModal
          isOpen={!!quickDocBooking}
          onClose={() => setQuickDocBooking(null)}
          transaction={quickDocBooking}
          moduleType="atv"
          businessSettings={businessSettings}
        />
      )}

      {/* Single Delete Confirmation Modal */}
      <Modal
        isOpen={!!bookingToDelete}
        onClose={() => setBookingToDelete(null)}
        title="Konfirmasi Hapus Sesi ATV"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus pemesanan ATV tamu <strong>{bookingToDelete?.guestName}</strong> (ID: {bookingToDelete?.id})?
            Tindakan ini akan dicatat di log audit dan riwayat penghapusan.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Tamu membatalkan sewa..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setBookingToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Sesi ATV'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Bulk Delete Confirmation Modal */}
      <Modal
        isOpen={isBulkDeleteModalOpen}
        onClose={() => setIsBulkDeleteModalOpen(false)}
        title="Konfirmasi Hapus Massal Sesi ATV"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Apakah Anda yakin ingin menghapus <strong>{selectedIds.length}</strong> sesi ATV terpilih sekaligus?
            Tindakan ini akan dicatat di log audit dan riwayat penghapusan.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan Massal (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Pembersihan data pembatalan massal..."
              value={bulkDeleteReason}
              onChange={(e) => setBulkDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsBulkDeleteModalOpen(false)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleConfirmBulkDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg cursor-pointer"
            >
              Hapus {selectedIds.length} Sesi ATV
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
