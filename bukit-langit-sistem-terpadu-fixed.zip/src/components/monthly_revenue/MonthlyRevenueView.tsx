import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  TrendingUp,
  BarChart3,
  Users,
  Compass,
  BedDouble,
  Utensils,
  ShoppingBag,
  DollarSign,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  ChevronDown,
  Award,
  Sparkles,
  Percent,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Booking,
  ATVBooking,
  BreakfastRecord,
  ExtraIncomeItem,
  Lead,
  BusinessSettings,
} from '../../types';
import {
  subscribeBookings,
  subscribeATVBookings,
  subscribeBreakfast,
  subscribeExtraIncome,
  subscribeLeads,
  getBusinessSettings,
} from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatters';

const MONTH_NAMES = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

export const MonthlyRevenueView: React.FC = () => {
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [atvBookings, setAtvBookings] = useState<ATVBooking[]>([]);
  const [breakfastRecords, setBreakfastRecords] = useState<BreakfastRecord[]>([]);
  const [extraIncomeItems, setExtraIncomeItems] = useState<ExtraIncomeItem[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Available year choices
  const availableYears = useMemo(() => {
    const currentYear = new Date().getFullYear();
    return [currentYear - 2, currentYear - 1, currentYear, currentYear + 1];
  }, []);

  // Real-time Subscriptions
  useEffect(() => {
    let isMounted = true;

    const unsubBookings = subscribeBookings((data) => {
      if (isMounted) setBookings(data);
    });

    const unsubATV = subscribeATVBookings((data) => {
      if (isMounted) setAtvBookings(data);
    });

    const unsubBreakfast = subscribeBreakfast((data) => {
      if (isMounted) setBreakfastRecords(data);
    });

    const unsubExtra = subscribeExtraIncome((data) => {
      if (isMounted) setExtraIncomeItems(data);
    });

    const unsubLeads = subscribeLeads((data) => {
      if (isMounted) {
        setLeads(data);
        setIsLoading(false);
      }
    });

    return () => {
      isMounted = false;
      unsubBookings();
      unsubATV();
      unsubBreakfast();
      unsubExtra();
      unsubLeads();
    };
  }, []);

  // Calculate 12 Months Data for Selected Year
  const monthlyData = useMemo(() => {
    return MONTH_NAMES.map((name, index) => {
      const monthNumber = index + 1;
      const monthPrefix = `${selectedYear}-${String(monthNumber).padStart(2, '0')}`;

      // Kamar
      const monthBookings = bookings.filter((b) => {
        const d = b.date || b.checkInDate || b.createdAt;
        return d && d.startsWith(monthPrefix) && b.status !== 'Cancelled';
      });
      const kamarRevenue = monthBookings.reduce((sum, b) => sum + (b.pendapatan || 0), 0);
      const kamarBookingCount = monthBookings.length;

      // ATV
      const monthATV = atvBookings.filter((a) => {
        const d = a.date || a.bookingDate || a.createdAt;
        return d && d.startsWith(monthPrefix) && a.status !== 'Cancelled';
      });
      const atvRevenue = monthATV.reduce((sum, a) => sum + (a.pendapatan || 0), 0);
      const atvSessionCount = monthATV.length;

      // Breakfast
      const monthBreakfast = breakfastRecords.filter((br) => {
        const d = br.date || br.createdAt;
        return d && d.startsWith(monthPrefix) && br.status !== 'Dibatalkan';
      });
      const breakfastRevenue = monthBreakfast.reduce(
        (sum, br) => sum + ((br.qty || 0) * (br.price || 0)),
        0,
      );
      const breakfastPortions = monthBreakfast.reduce((sum, br) => sum + (br.qty || 0), 0);

      // Extra Income
      const monthExtra = extraIncomeItems.filter((ex) => {
        const d = ex.date || ex.createdAt;
        return d && d.startsWith(monthPrefix);
      });
      const extraRevenue = monthExtra.reduce((sum, ex) => {
        const paid = ex.totalPaid !== undefined ? ex.totalPaid : (ex.status === 'Lunas' ? ex.total : 0);
        return sum + (paid || 0);
      }, 0);
      const extraLaba = monthExtra.reduce((sum, ex) => {
        const cost = Number(ex.cost) || 0;
        const total = Number(ex.total) || 0;
        return sum + (ex.laba !== undefined ? Number(ex.laba) : (total - cost));
      }, 0);

      // Leads
      const monthLeads = leads.filter((l) => {
        const d = l.chatDate || l.createdAt;
        return d && d.startsWith(monthPrefix);
      });
      const totalLeads = monthLeads.length;
      const wonLeads = monthLeads.filter((l) => l.leadStatus === 'Booking Confirmed').length;
      const closingRate = totalLeads > 0 ? Math.round((wonLeads / totalLeads) * 100) : 0;

      const totalRevenue = kamarRevenue + atvRevenue + breakfastRevenue + extraRevenue;

      return {
        monthNumber,
        monthName: name,
        shortName: name.slice(0, 3),
        kamarRevenue,
        kamarBookingCount,
        atvRevenue,
        atvSessionCount,
        breakfastRevenue,
        breakfastPortions,
        extraRevenue,
        extraLaba,
        totalLeads,
        wonLeads,
        closingRate,
        totalRevenue,
      };
    });
  }, [bookings, atvBookings, breakfastRecords, extraIncomeItems, leads, selectedYear]);

  // Annual Totals
  const annualSummary = useMemo(() => {
    return monthlyData.reduce(
      (acc, item) => ({
        totalRevenue: acc.totalRevenue + item.totalRevenue,
        kamarRevenue: acc.kamarRevenue + item.kamarRevenue,
        kamarBookingCount: acc.kamarBookingCount + item.kamarBookingCount,
        atvRevenue: acc.atvRevenue + item.atvRevenue,
        atvSessionCount: acc.atvSessionCount + item.atvSessionCount,
        breakfastRevenue: acc.breakfastRevenue + item.breakfastRevenue,
        extraRevenue: acc.extraRevenue + item.extraRevenue,
        extraLaba: acc.extraLaba + item.extraLaba,
        totalLeads: acc.totalLeads + item.totalLeads,
        wonLeads: acc.wonLeads + item.wonLeads,
      }),
      {
        totalRevenue: 0,
        kamarRevenue: 0,
        kamarBookingCount: 0,
        atvRevenue: 0,
        atvSessionCount: 0,
        breakfastRevenue: 0,
        extraRevenue: 0,
        extraLaba: 0,
        totalLeads: 0,
        wonLeads: 0,
      },
    );
  }, [monthlyData]);

  // Per-PIC Performance Breakdown
  const picPerformance = useMemo(() => {
    const yearPrefix = `${selectedYear}-`;
    const yearLeads = leads.filter((l) => (l.chatDate || l.createdAt || '').startsWith(yearPrefix));

    const map: Record<
      string,
      {
        pic: string;
        totalLeads: number;
        wonLeads: number;
        lostLeads: number;
        inProgressLeads: number;
        estimatedGuests: number;
      }
    > = {};

    yearLeads.forEach((lead) => {
      const pic = lead.picClosing?.trim() || lead.picFollowUp?.trim() || lead.picPerolehan?.trim() || 'Tanpa PIC';
      if (!map[pic]) {
        map[pic] = {
          pic,
          totalLeads: 0,
          wonLeads: 0,
          lostLeads: 0,
          inProgressLeads: 0,
          estimatedGuests: 0,
        };
      }

      map[pic].totalLeads += 1;
      if (lead.leadStatus === 'Booking Confirmed') {
        map[pic].wonLeads += 1;
        map[pic].estimatedGuests += Number(lead.estimatedGuestCount) || 0;
      } else if (lead.leadStatus === 'Cancelled-Lost') {
        map[pic].lostLeads += 1;
      } else {
        map[pic].inProgressLeads += 1;
      }
    });

    return Object.values(map).sort((a, b) => b.wonLeads - a.wonLeads);
  }, [leads, selectedYear]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Filter Year */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-white/10 text-blue-200 border border-white/10 mb-3 backdrop-blur-xs">
              <TrendingUp className="w-3.5 h-3.5 text-blue-300" />
              <span>Rekapitulasi Finansial & Perolehan Tahunan</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Perolehan Bulanan & Kinerja PIC
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Tabel komparasi 12 bulan pendapatan seluruh unit bisnis (Kamar, ATV, Resto, Extra POS) dan rasio konversi per PIC.
            </p>
          </div>

          {/* Year Selector Dropdown */}
          <div className="flex items-center gap-2 bg-slate-800/90 p-2 rounded-xl border border-slate-700">
            <span className="text-xs font-bold text-slate-300 pl-2">Tahun:</span>
            <div className="flex items-center gap-1">
              {availableYears.map((year) => (
                <button
                  key={year}
                  type="button"
                  onClick={() => setSelectedYear(year)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    selectedYear === year
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  {year}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Annual KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Omzet Tahun {selectedYear}
          </span>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {formatRupiah(annualSummary.totalRevenue)}
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            Rata-rata {formatRupiah(annualSummary.totalRevenue / 12)} / bulan
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Booking Kamar
          </span>
          <div className="text-2xl font-black text-blue-900 mt-2">
            {annualSummary.kamarBookingCount} <span className="text-xs text-slate-400 font-normal">Kamar</span>
          </div>
          <span className="text-xs text-blue-600 font-medium mt-1 block">
            {formatRupiah(annualSummary.kamarRevenue)}
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Sesi Wahana ATV
          </span>
          <div className="text-2xl font-black text-amber-900 mt-2">
            {annualSummary.atvSessionCount} <span className="text-xs text-slate-400 font-normal">Sesi</span>
          </div>
          <span className="text-xs text-amber-600 font-medium mt-1 block">
            {formatRupiah(annualSummary.atvRevenue)}
          </span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Closing Leads Tahunan
          </span>
          <div className="text-2xl font-black text-emerald-900 mt-2">
            {annualSummary.wonLeads} <span className="text-xs text-slate-400 font-normal">/ {annualSummary.totalLeads} Confirmed</span>
          </div>
          <span className="text-xs text-emerald-600 font-bold mt-1 block">
            Rasio Konversi {annualSummary.totalLeads > 0 ? Math.round((annualSummary.wonLeads / annualSummary.totalLeads) * 100) : 0}%
          </span>
        </div>
      </div>

      {/* Monthly Bar Chart Comparison */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Grafik Komparasi Pendapatan Bulanan ({selectedYear})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Breakdown kontribusi Kamar, ATV, Breakfast, dan Pendapatan Tambahan per bulan
            </p>
          </div>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
              <XAxis dataKey="shortName" stroke="#94A3B8" fontSize={11} tickLine={false} />
              <YAxis
                stroke="#94A3B8"
                fontSize={10}
                tickLine={false}
                tickFormatter={(val) => `Rp ${(val / 1000000).toFixed(0)}M`}
              />
              <Tooltip
                formatter={(val: unknown, name: unknown) => [formatRupiah(Number(val) || 0), String(name)]}
                contentStyle={{ backgroundColor: '#0F172A', borderRadius: '0.75rem', border: 'none', color: '#fff', fontSize: '12px' }}
              />
              <Legend
                verticalAlign="top"
                align="right"
                iconType="circle"
                wrapperStyle={{ paddingBottom: '10px' }}
                formatter={(val) => <span className="text-xs text-slate-700 font-semibold">{val}</span>}
              />
              <Bar dataKey="kamarRevenue" name="Kamar" fill="#2563EB" stackId="a" radius={[0, 0, 0, 0]} />
              <Bar dataKey="atvRevenue" name="ATV" fill="#D97706" stackId="a" radius={[0, 0, 0, 0]} />
              <Bar dataKey="breakfastRevenue" name="Sarapan" fill="#059669" stackId="a" radius={[0, 0, 0, 0]} />
              <Bar dataKey="extraRevenue" name="Pendapatan Tambahan" fill="#7C3AED" stackId="a" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 12-Month Table Breakdown */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Tabel Rekapitulasi Perolehan Bulanan ({selectedYear})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Rincian pendapatan per lini produk, jumlah reservasi, dan performa konversi leads
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <th className="py-3 px-4">Bulan</th>
                <th className="py-3 px-4 text-right">Pendapatan Total</th>
                <th className="py-3 px-4 text-right">Kamar Glamping</th>
                <th className="py-3 px-4 text-right">Wahana ATV</th>
                <th className="py-3 px-4 text-right">Sarapan Resto</th>
                <th className="py-3 px-4 text-right">Pendapatan Tambahan (Laba)</th>
                <th className="py-3 px-4 text-center">Bkg Kamar</th>
                <th className="py-3 px-4 text-center">Leads Masuk</th>
                <th className="py-3 px-4 text-center">Closing Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {monthlyData.map((row) => (
                <tr key={row.monthNumber} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900">{row.monthName}</td>
                  <td className="py-3 px-4 text-right font-black font-mono text-slate-900">
                    {formatRupiah(row.totalRevenue)}
                  </td>
                  <td className="py-3 px-4 text-right font-medium text-blue-900">
                    {formatRupiah(row.kamarRevenue)}
                  </td>
                  <td className="py-3 px-4 text-right font-medium text-amber-900">
                    {formatRupiah(row.atvRevenue)}
                  </td>
                  <td className="py-3 px-4 text-right font-medium text-emerald-900">
                    {formatRupiah(row.breakfastRevenue)}
                  </td>
                  <td className="py-3 px-4 text-right font-medium text-purple-900">
                    {formatRupiah(row.extraRevenue)}{' '}
                    <span className="text-[10px] text-slate-400">({formatRupiah(row.extraLaba)})</span>
                  </td>
                  <td className="py-3 px-4 text-center font-bold text-slate-700">
                    {row.kamarBookingCount}
                  </td>
                  <td className="py-3 px-4 text-center text-slate-600">
                    {row.wonLeads} <span className="text-slate-400">/ {row.totalLeads}</span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        row.closingRate >= 50
                          ? 'bg-emerald-100 text-emerald-800'
                          : row.closingRate > 0
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {row.closingRate}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-900 text-white font-bold border-t-2 border-slate-900">
                <td className="py-3.5 px-4 font-black">TOTAL {selectedYear}</td>
                <td className="py-3.5 px-4 text-right font-black font-mono text-emerald-400 text-sm">
                  {formatRupiah(annualSummary.totalRevenue)}
                </td>
                <td className="py-3.5 px-4 text-right text-blue-300">
                  {formatRupiah(annualSummary.kamarRevenue)}
                </td>
                <td className="py-3.5 px-4 text-right text-amber-300">
                  {formatRupiah(annualSummary.atvRevenue)}
                </td>
                <td className="py-3.5 px-4 text-right text-emerald-300">
                  {formatRupiah(annualSummary.breakfastRevenue)}
                </td>
                <td className="py-3.5 px-4 text-right text-purple-300">
                  {formatRupiah(annualSummary.extraRevenue)}
                </td>
                <td className="py-3.5 px-4 text-center">{annualSummary.kamarBookingCount}</td>
                <td className="py-3.5 px-4 text-center">
                  {annualSummary.wonLeads} / {annualSummary.totalLeads}
                </td>
                <td className="py-3.5 px-4 text-center text-emerald-300 font-black">
                  {annualSummary.totalLeads > 0
                    ? Math.round((annualSummary.wonLeads / annualSummary.totalLeads) * 100)
                    : 0}
                  %
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Per-PIC Performance Breakdown */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-500" />
              <span>Performa Konversi Per-PIC ({selectedYear})</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Distribusi penanganan prospek klien dan total tamu booking terkonfirmasi per staf
            </p>
          </div>
        </div>

        {picPerformance.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-500">
            Belum ada data leads tercatat pada tahun {selectedYear}.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {picPerformance.map((item, idx) => {
              const conversion =
                item.totalLeads > 0 ? Math.round((item.wonLeads / item.totalLeads) * 100) : 0;
              return (
                <div
                  key={item.pic || idx}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="font-bold text-xs text-slate-900 truncate">{item.pic}</span>
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full text-[10px] font-bold">
                        {conversion}% Win Rate
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-200/60 text-center text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Total</span>
                        <span className="font-bold text-slate-800">{item.totalLeads}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-emerald-600 block font-semibold">Confirmed</span>
                        <span className="font-bold text-emerald-700">{item.wonLeads}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">Proses</span>
                        <span className="font-bold text-slate-700">{item.inProgressLeads}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium text-[11px]">Total Tamu Closing:</span>
                    <span className="font-black font-mono text-emerald-700">
                      {item.estimatedGuests} Pax
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
