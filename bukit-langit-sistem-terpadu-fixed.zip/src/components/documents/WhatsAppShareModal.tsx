import React, { useState } from 'react';
import { FinancialDocument, BusinessSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatRupiah } from '../../utils/formatter';
import { MessageSquare, Copy, Check, ExternalLink } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface WhatsAppShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: FinancialDocument | null;
  settings?: BusinessSettings;
}

export const WhatsAppShareModal: React.FC<WhatsAppShareModalProps> = ({
  isOpen,
  onClose,
  document: doc,
  settings,
}) => {
  const { showSuccess } = useToast();
  const [copied, setCopied] = useState<boolean>(false);

  if (!doc) return null;

  const buildWhatsAppMessage = (): string => {
    const businessName = settings?.businessName || 'BUKIT LANGIT CAMPVENTURE';
    const guestName = doc.guestName || 'Tamu Terhormat';
    const docNumber = doc.documentNumber || '-';
    const total = formatRupiah(doc.totalAmount || 0);
    const dp = formatRupiah(doc.downPaymentAmount || 0);
    const sisa = formatRupiah(doc.remainingAmount || 0);
    const status = doc.paymentStatus || 'BELUM LUNAS';
    const stay = doc.stayDate || doc.arrivalDate || '-';
    const room = doc.roomType || '-';
    const bank = doc.bankAccount || settings?.bankAccounts?.[0] || {
      bankName: 'BRI',
      accountNumber: '000701002452566',
      accountHolder: settings?.businessName || 'PT. HOLISTIK NUSANTARA GROUP',
    };

    const docTypeLabels: Record<string, string> = {
      invoice: 'Invoice Tagihan',
      kwitansi_dp: 'Kwitansi Pembayaran DP',
      booking_confirmation: 'Konfirmasi Reservasi',
      registration_card: 'Registration Card',
      hotel_voucher: 'Hotel Stay Voucher',
      proforma: 'Proforma Invoice',
      corporate_contract: 'Kontrak Kerjasama',
    };

    const docTitle = docTypeLabels[doc.documentType] || doc.documentTitle || 'Dokumen Keuangan';

    if (doc.documentType === 'kwitansi_dp') {
      return `*BUKTI TANDA TERIMA PEMBAYARAN (KWITANSI)*
*${businessName}*
===============================
Halo Yth. *${guestName}*,

Terima kasih! Pembayaran uang muka (DP) untuk reservasi Anda telah kami terima dengan rincian: 💳✅

• No. Tanda Terima: *${docNumber}*
• Tanggal: *${doc.documentDate}*
• Atas Nama: *${guestName}*
• Periode Menginap: *${stay}*
• Jumlah DP Diterima: *${dp}*
• Sisa Pelunasan: *${sisa}*
• Status: *${status}*

Rekening Resmi:
Bank *${bank.bankName}* No. Rek: *${bank.accountNumber}* a.n. *${bank.accountHolder}*

Salam hangat,
*${businessName}*`;
    }

    if (doc.documentType === 'booking_confirmation') {
      return `*KONFIRMASI RESERVASI RESMI*
*${businessName}*
===============================
Halo Yth. *${guestName}*,

Terima kasih atas pemesanan Anda di *${businessName}*! Reservasi Anda telah terkonfirmasi dengan rincian: 🏕️✨

• No. Konfirmasi: *${doc.confirmationNumber || docNumber}*
• Tipe Kamar / Unit: *${room}*
• Periode Menginap: *${stay}*
• Check-in: *${doc.arrivalDate || '-'} (${doc.checkInTime || '14.00 WIB'})*
• Check-out: *${doc.departureDate || '-'} (${doc.checkOutTime || '12.00 WIB'})*
• Total Biaya: *${total}*
• Status: *${status}*

Salam hangat,
*${businessName}*`;
    }

    return `*${businessName}*
*INFORMASI & RINCIAN ${docTitle.toUpperCase()}*
===============================
Halo Yth. *${guestName}*,
Berikut kami sampaikan rincian resmi *${docTitle}* Anda di *${businessName}*:

• Jenis Dokumen: *${docTitle}*
• Nomor: *${docNumber}*
• Tanggal: *${doc.documentDate}*
• Periode / Menginap: *${stay}*
===============================
*TOTAL TAGIHAN:* *${total}*
*Status Pembayaran:* *${status}*

*Pembayaran Transfer Ke:*
Bank *${bank.bankName}*
No. Rek: *${bank.accountNumber}*
A.N: *${bank.accountHolder}*

Salam hangat,
*${businessName}*`;
  };

  const messageText = buildWhatsAppMessage();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(messageText);
      setCopied(true);
      showSuccess('Teks pesan WhatsApp berhasil disalin ke clipboard!');
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
    }
  };

  const cleanPhone = (doc.guestPhone || '').replace(/[^0-9]/g, '');
  const formattedPhone = cleanPhone.startsWith('0')
    ? '62' + cleanPhone.slice(1)
    : cleanPhone;

  const waLink = formattedPhone
    ? `https://wa.me/${formattedPhone}?text=${encodeURIComponent(messageText)}`
    : `https://wa.me/?text=${encodeURIComponent(messageText)}`;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Bagikan via Pesan WhatsApp"
      maxWidth="max-w-xl"
    >
      <div className="space-y-4 text-xs">
        <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <div>
              <p className="font-semibold text-emerald-950">
                Pesan untuk: {doc.guestName || 'Tamu'}
              </p>
              <p className="text-[11px] text-emerald-700">
                {doc.guestPhone || 'Nomor telepon belum diisi'}
              </p>
            </div>
          </div>
          <span className="px-2 py-0.5 bg-emerald-200/60 font-mono font-bold text-[10px] rounded-md">
            #{doc.documentNumber}
          </span>
        </div>

        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            Draf Pesan WhatsApp:
          </label>
          <textarea
            readOnly
            value={messageText}
            rows={10}
            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs text-slate-800 leading-relaxed focus:outline-hidden"
          />
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={handleCopy}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Salin Teks Pesan</span>
              </>
            )}
          </button>

          <a
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Buka di WhatsApp Web</span>
          </a>
        </div>
      </div>
    </Modal>
  );
};
