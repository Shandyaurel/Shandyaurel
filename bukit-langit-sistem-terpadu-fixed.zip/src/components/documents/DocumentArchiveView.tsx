import React, { useState, useEffect, useMemo } from 'react';
import { FinancialDocument, BusinessSettings, DocumentType } from '../../types';
import {
  subscribeDocuments,
  deleteDocument,
  saveDocument,
  getBusinessSettings,
} from '../../utils/firebase';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import { DEFAULT_SETTINGS } from '../../utils/storage';
import { formatRupiah, formatDateToIndonesian } from '../../utils/formatter';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';
import { DocumentPreview } from '../DocumentPreview';
import { DocumentPreviewModal } from './DocumentPreviewModal';
import { WhatsAppShareModal } from './WhatsAppShareModal';
import {
  FileText,
  Search,
  Download,
  Eye,
  Trash2,
  Copy,
  Edit,
  MessageSquare,
  Plus,
  RefreshCw,
  Loader2,
  DollarSign,
  CheckCircle2,
  Clock,
} from 'lucide-react';

interface DocumentArchiveViewProps {
  onEditDocument?: (doc: FinancialDocument) => void;
  onCreateNew?: () => void;
}

const DOCUMENT_TYPE_LABELS: Record<string, string> = {
  invoice: 'Invoice',
  kwitansi_dp: 'Kwitansi DP',
  booking_confirmation: 'Konfirmasi Booking',
  registration_card: 'Reg Card',
  hotel_voucher: 'Hotel Voucher',
  proforma: 'Proforma Invoice',
  corporate_contract: 'Kontrak Kerjasama',
  pengajuan_dana: 'Pengajuan Dana / Komisi',
};

export const DocumentArchiveView: React.FC<DocumentArchiveViewProps> = ({
  onEditDocument,
  onCreateNew,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [documents, setDocuments] = useState<FinancialDocument[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Modals & Actions
  const [previewDoc, setPreviewDoc] = useState<FinancialDocument | null>(null);
  const [printingDoc, setPrintingDoc] = useState<FinancialDocument | null>(null);
  const [shareDoc, setShareDoc] = useState<FinancialDocument | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FinancialDocument | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  useEffect(() => {
    getBusinessSettings().then((s) => setSettings(s));

    const unsubscribe = subscribeDocuments(
      (list) => {
        setDocuments(list);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error fetching documents:', err);
        setIsLoading(false);
      },
    );

    return () => unsubscribe();
  }, []);

  // Filtered Documents
  const filteredDocuments = useMemo(() => {
    return documents.filter((doc) => {
      // Search
      const search = searchTerm.toLowerCase();
      const matchSearch =
        !searchTerm ||
        (doc.documentNumber && doc.documentNumber.toLowerCase().includes(search)) ||
        (doc.guestName && doc.guestName.toLowerCase().includes(search)) ||
        (doc.guestOrganization && doc.guestOrganization.toLowerCase().includes(search)) ||
        (doc.guestPhone && doc.guestPhone.includes(search));

      // Type
      const matchType = selectedType === 'all' || doc.documentType === selectedType;

      // Status
      const matchStatus =
        selectedStatus === 'all' ||
        doc.paymentStatus?.toUpperCase() === selectedStatus.toUpperCase();

      // Date range
      const docDate = doc.documentDate || (doc.createdAt ? doc.createdAt.split('T')[0] : '');
      const matchStartDate = !startDate || docDate >= startDate;
      const matchEndDate = !endDate || docDate <= endDate;

      return matchSearch && matchType && matchStatus && matchStartDate && matchEndDate;
    });
  }, [documents, searchTerm, selectedType, selectedStatus, startDate, endDate]);

  // Financial KPI Summaries
  const kpiStats = useMemo(() => {
    const totalCount = filteredDocuments.length;
    const totalValue = filteredDocuments.reduce(
      (sum, d) => sum + (Number(d.totalAmount) || 0),
      0,
    );
    const totalPaid = filteredDocuments.reduce((sum, d) => {
      if (d.paymentStatus?.toUpperCase() === 'LUNAS') return sum + (Number(d.totalAmount) || 0);
      if (d.paymentStatus?.toUpperCase() === 'DP') return sum + (Number(d.downPaymentAmount || d.dpAmount) || 0);
      return sum;
    }, 0);
    const totalRemaining = Math.max(0, totalValue - totalPaid);

    return { totalCount, totalValue, totalPaid, totalRemaining };
  }, [filteredDocuments]);

  // Single Click Instant PDF Download
  const handleDownloadPdf = async (docItem: FinancialDocument) => {
    setDownloadingId(docItem.id);
    try {
      const effectiveSettings = settings || DEFAULT_SETTINGS;
      setPrintingDoc(docItem);
      await new Promise((r) => setTimeout(r, 150));
      await generateDocumentPdf(docItem, effectiveSettings);
      showSuccess(`PDF #${docItem.documentNumber} berhasil diunduh.`);
    } catch (err) {
      console.error('Error downloading PDF:', err);
      showError(
        'Gagal mengunduh PDF: ' +
          (err instanceof Error ? err.message : 'Kesalahan rendering'),
      );
    } finally {
      setDownloadingId(null);
      setPrintingDoc(null);
    }
  };

  // Duplicate Document
  const handleDuplicate = async (docItem: FinancialDocument) => {
    try {
      const duplicateData: Partial<FinancialDocument> & {
        guestName?: string;
        documentType: DocumentType;
      } = {
        ...docItem,
        id: undefined, // Create as new record
        documentNumber: undefined, // Let saveDocument auto-assign next number
        documentDate: new Date().toISOString().split('T')[0],
        paymentStatus: 'BELUM LUNAS',
        createdAt: undefined,
        updatedAt: undefined,
      };

      const newDoc = await saveDocument(duplicateData, currentUser?.email || 'Admin');
      showSuccess(`Dokumen berhasil diduplikasi menjadi #${newDoc.documentNumber}!`);
      if (onEditDocument) {
        onEditDocument(newDoc);
      }
    } catch (err) {
      console.error('Error duplicating document:', err);
      showError('Gagal menduplikasi dokumen.');
    }
  };

  // Confirm Delete (Optimistic)
  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    const target = deleteTarget;
    const reason = deleteReason.trim() || undefined;
    const userEmail = currentUser?.email || 'Admin';

    // (1) Tutup modal & tampilkan notifikasi segera (OPTIMISTIC <1 detik)
    setDeleteTarget(null);
    setDeleteReason('');
    showSuccess(`Dokumen #${target.documentNumber} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteDocument(target, userEmail, reason).catch((err) => {
      console.error('Error deleting document:', err);
      showError('Gagal sinkron hapus dokumen ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div className="space-y-6">
      {/* Header & New Document Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-lg uppercase tracking-wider">
              Arsip Digital
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Total {documents.length} Dokumen Tersimpan
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">
            Arsip Dokumen & Riwayat PDF
          </h1>
          <p className="text-xs text-slate-500">
            Daftar lengkap invoice, kwitansi, voucher, dan surat konfirmasi resmi Bukit Langit.
          </p>
        </div>

        {onCreateNew && (
          <button
            type="button"
            onClick={onCreateNew}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Buat Dokumen Baru</span>
          </button>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase">
              Dokumen Terfilter
            </p>
            <p className="text-xl font-black text-slate-900">
              {kpiStats.totalCount} <span className="text-xs font-normal text-slate-500">berkas</span>
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase">
              Akumulasi Tagihan
            </p>
            <p className="text-xl font-black text-emerald-900">
              {formatRupiah(kpiStats.totalValue)}
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase">
              Total Terbayar
            </p>
            <p className="text-xl font-black text-teal-800">
              {formatRupiah(kpiStats.totalPaid)}
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-400 uppercase">
              Sisa Piutang / Belum Lunas
            </p>
            <p className="text-xl font-black text-amber-800">
              {formatRupiah(kpiStats.totalRemaining)}
            </p>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          {/* Search Box */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari nomor dokumen, nama tamu, instansi, telp..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
            />
          </div>

          {/* Type Filter */}
          <div>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">Semua Jenis Dokumen</option>
              <option value="invoice">Invoice Tagihan</option>
              <option value="kwitansi_dp">Kwitansi DP</option>
              <option value="booking_confirmation">Konfirmasi Reservasi</option>
              <option value="registration_card">Registration Card</option>
              <option value="hotel_voucher">Hotel Voucher</option>
              <option value="proforma">Proforma Invoice</option>
              <option value="pengajuan_dana">Pengajuan Dana / Komisi Agen</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">Semua Status</option>
              <option value="LUNAS">Lunas</option>
              <option value="DP">DP</option>
              <option value="BELUM LUNAS">Belum Lunas</option>
              <option value="SEBAGIAN">Sebagian</option>
            </select>
          </div>

          {/* Reset Filters */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setSelectedType('all');
                setSelectedStatus('all');
                setStartDate('');
                setEndDate('');
              }}
              className="w-full px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Filter</span>
            </button>
          </div>
        </div>
      </div>

      {/* Table of Documents */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-emerald-600" />
            Memuat arsip dokumen...
          </div>
        ) : filteredDocuments.length === 0 ? (
          <div className="py-16 text-center space-y-2">
            <FileText className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="font-semibold text-slate-700 text-sm">
              Tidak ada dokumen ditemukan.
            </p>
            <p className="text-xs text-slate-400">
              Coba sesuaikan kata kunci pencarian atau buat dokumen baru.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600 uppercase text-[10px] tracking-wider">
                  <th className="py-3 px-4">No. Dokumen</th>
                  <th className="py-3 px-4">Jenis</th>
                  <th className="py-3 px-4">Tamu & Instansi</th>
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4 text-right">Grand Total</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center w-48">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDocuments.map((doc) => {
                  const isDownloadingThis = downloadingId === doc.id;
                  const isLunas = doc.paymentStatus?.toUpperCase() === 'LUNAS';
                  const isDp = doc.paymentStatus?.toUpperCase() === 'DP';

                  return (
                    <tr
                      key={doc.id}
                      className="hover:bg-slate-50/70 transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {doc.documentNumber}
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-800 text-[10px] font-bold rounded-md uppercase">
                          {DOCUMENT_TYPE_LABELS[doc.documentType] || doc.documentType}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-900">
                          {doc.guestName || '-'}
                        </p>
                        {doc.guestOrganization && (
                          <p className="text-[11px] text-emerald-800 font-medium">
                            {doc.guestOrganization}
                          </p>
                        )}
                        {doc.guestPhone && (
                          <p className="text-[10px] text-slate-400 font-mono">
                            {doc.guestPhone}
                          </p>
                        )}
                      </td>

                      <td className="py-3 px-4 text-slate-600">
                        {doc.documentDate ? formatDateToIndonesian(doc.documentDate) : '-'}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                        {formatRupiah(doc.totalAmount || 0)}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase ${
                            isLunas
                              ? 'bg-emerald-100 text-emerald-800'
                              : isDp
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {doc.paymentStatus || 'BELUM LUNAS'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {/* Preview Live */}
                          <button
                            type="button"
                            onClick={() => setPreviewDoc(doc)}
                            title="Preview Dokumen"
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* Quick Download PDF */}
                          <button
                            type="button"
                            onClick={() => handleDownloadPdf(doc)}
                            disabled={isDownloadingThis}
                            title="Download PDF"
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                          >
                            {isDownloadingThis ? (
                              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                            ) : (
                              <Download className="w-4 h-4" />
                            )}
                          </button>

                          {/* WhatsApp Share */}
                          <button
                            type="button"
                            onClick={() => setShareDoc(doc)}
                            title="Salin Pesan WA"
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <MessageSquare className="w-4 h-4 text-emerald-600" />
                          </button>

                          {/* Edit */}
                          {onEditDocument && (
                            <button
                              type="button"
                              onClick={() => onEditDocument(doc)}
                              title="Edit Dokumen"
                              className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}

                          {/* Duplicate */}
                          <button
                            type="button"
                            onClick={() => handleDuplicate(doc)}
                            title="Duplikasi Dokumen"
                            className="p-1.5 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Copy className="w-4 h-4" />
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            onClick={() => {
                              setDeleteTarget(doc);
                              setDeleteReason('');
                            }}
                            title="Hapus Dokumen"
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      {previewDoc && (
        <DocumentPreviewModal
          isOpen={!!previewDoc}
          onClose={() => setPreviewDoc(null)}
          document={previewDoc}
          settings={settings || undefined}
        />
      )}

      {/* WhatsApp Share Modal */}
      {shareDoc && (
        <WhatsAppShareModal
          isOpen={!!shareDoc}
          onClose={() => setShareDoc(null)}
          document={shareDoc}
          settings={settings || undefined}
        />
      )}

      {/* Delete Confirmation Modal (NO window.confirm) */}
      <Modal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title="Hapus Dokumen Keuangan"
        confirmLabel="Hapus Permanen"
        confirmVariant="danger"
        isLoading={isDeleting}
        onConfirm={handleConfirmDelete}
      >
        <div className="space-y-4 text-xs">
          <p className="text-slate-600 leading-relaxed">
            Apakah Anda yakin ingin menghapus berkas dokumen{' '}
            <strong className="text-slate-900 font-mono">
              #{deleteTarget?.documentNumber}
            </strong>{' '}
            atas nama <strong>{deleteTarget?.guestName}</strong> senilai{' '}
            <strong>{formatRupiah(deleteTarget?.totalAmount || 0)}</strong>?
          </p>

          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Data yang dihapus akan dicatat ke riwayat audit penghapusan sistem
            (<em>deletion history</em>).
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Alasan Penghapusan (Opsional):
            </label>
            <input
              type="text"
              placeholder="Contoh: Pembatalan transaksi / revisi nomor"
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:bg-white"
            />
          </div>
        </div>
      </Modal>

      {/* Offscreen unclipped container for instant high-res PDF generation */}
      {printingDoc && (
        <div
          style={{
            position: 'fixed',
            left: -9999,
            top: 0,
            width: '800px',
            opacity: 0.01,
            pointerEvents: 'none',
            zIndex: -999,
          }}
          aria-hidden="true"
        >
          <DocumentPreview document={printingDoc} settings={settings || DEFAULT_SETTINGS} />
        </div>
      )}
    </div>
  );
};
