import React, { useState, useEffect, useMemo } from 'react';
import { BusinessSettings, DocumentType, FinancialDocument } from '../../types';
import { Modal } from '../common/Modal';
import { DocumentPreview } from '../DocumentPreview';
import { executePrintDocument } from '../../utils/printHelper';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import { saveDocument, generateNextDocumentNumber } from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { DEFAULT_SETTINGS } from '../../utils/storage';
import {
  SupportedTransaction,
  ModuleType,
  WhatsAppTemplateKey,
  WHATSAPP_TEMPLATE_KEYS,
  WHATSAPP_TEMPLATE_LABELS,
  AVAILABLE_DOC_TYPES,
  DEFAULT_WHATSAPP_TEMPLATES,
  extractTransactionData,
  interpolateWhatsAppText,
  buildFinancialDocumentFromTransaction,
} from '../../utils/transactionDocHelper';
import {
  FileText,
  MessageSquare,
  Printer,
  Download,
  Copy,
  Check,
  ExternalLink,
  Loader2,
  BookmarkCheck,
  Sparkles,
  RefreshCw,
  Eye,
} from 'lucide-react';

interface TransactionQuickDocWAModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: SupportedTransaction | null;
  moduleType: ModuleType;
  businessSettings?: BusinessSettings | null;
  onSavedToArchive?: (doc: FinancialDocument) => void;
}

export const TransactionQuickDocWAModal: React.FC<TransactionQuickDocWAModalProps> = ({
  isOpen,
  onClose,
  transaction,
  moduleType,
  businessSettings,
  onSavedToArchive,
}) => {
  const { currentUser, userProfile } = useAuth();
  const { showSuccess, showError } = useToast();
  const settings = businessSettings || DEFAULT_SETTINGS;

  const [activeTab, setActiveTab] = useState<'doc' | 'wa'>('doc');
  const [selectedDocType, setSelectedDocType] = useState<DocumentType>('invoice');
  const [selectedTemplateKey, setSelectedTemplateKey] = useState<WhatsAppTemplateKey>(
    moduleType as WhatsAppTemplateKey,
  );
  const [docNumber, setDocNumber] = useState<string>('');
  const [isGeneratingNum, setIsGeneratingNum] = useState<boolean>(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);
  const [isSavingToArchive, setIsSavingToArchive] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [editedWaText, setEditedWaText] = useState<string>('');
  const [isManualEditWa, setIsManualEditWa] = useState<boolean>(false);

  // Auto-initialize doc type and template key based on transaction payment
  useEffect(() => {
    if (!transaction) return;
    setIsManualEditWa(false);

    let defaultDocType: DocumentType = 'invoice';
    let defaultTplKey: WhatsAppTemplateKey = moduleType;

    // Check if it's already DP or Lunas
    const anyTx = transaction as any;
    const dp = Number(anyTx.dp || anyTx.downPaymentAmount || 0);
    const grandTotal = Number(anyTx.grandTotal || anyTx.total || anyTx.totalAmount || 0);
    const pelunasan = Number(anyTx.pelunasan || 0);
    const paid = dp + pelunasan;

    if (paid >= grandTotal && grandTotal > 0) {
      defaultDocType = 'invoice';
      defaultTplKey = 'kwitansi_pelunasan';
    } else if (dp > 0 && paid < grandTotal) {
      defaultDocType = 'kwitansi_dp';
      defaultTplKey = 'kwitansi_dp';
    } else {
      defaultDocType = 'invoice';
      defaultTplKey = moduleType;
    }

    setSelectedDocType(defaultDocType);
    setSelectedTemplateKey(defaultTplKey);

    // Fetch next official document number
    setIsGeneratingNum(true);
    generateNextDocumentNumber(settings.documentPrefix)
      .then(({ docNumber: num }) => {
        setDocNumber(num);
      })
      .catch(() => {
        const rand = Math.floor(1000 + Math.random() * 9000);
        setDocNumber(`BL/${rand}`);
      })
      .finally(() => {
        setIsGeneratingNum(false);
      });
  }, [transaction, moduleType, settings.documentPrefix]);

  // Extract structured transaction data
  const data = useMemo(() => {
    if (!transaction) return null;
    return extractTransactionData(
      transaction,
      moduleType,
      selectedDocType,
      settings,
      docNumber || 'BL/1001',
    );
  }, [transaction, moduleType, selectedDocType, settings, docNumber]);

  // Construct FinancialDocument for DocumentPreview & PDF
  const financialDoc = useMemo(() => {
    if (!data || !transaction) return null;
    return buildFinancialDocumentFromTransaction(
      data,
      selectedDocType,
      docNumber || 'BL/1001',
      moduleType,
      transaction.id,
      settings,
    );
  }, [data, selectedDocType, docNumber, moduleType, transaction, settings]);

  // Compute interpolated WhatsApp message
  const computedWaText = useMemo(() => {
    if (!data) return '';
    const storedTemplates = settings.whatsappTemplates || {};
    const templateString =
      storedTemplates[selectedTemplateKey] ||
      DEFAULT_WHATSAPP_TEMPLATES[selectedTemplateKey] ||
      DEFAULT_WHATSAPP_TEMPLATES.invoice;

    return interpolateWhatsAppText(templateString, data);
  }, [data, settings.whatsappTemplates, selectedTemplateKey]);

  // Sync wa text into editor if not manually overriding
  useEffect(() => {
    if (!isManualEditWa) {
      setEditedWaText(computedWaText);
    }
  }, [computedWaText, isManualEditWa]);

  if (!transaction || !data || !financialDoc) return null;

  // Print Document (purely on demand)
  const handlePrint = () => {
    executePrintDocument('printable-invoice-quick');
    showSuccess('Perintah cetak dokumen dikirim.');
  };

  // Download PDF (strictly on demand when user clicks button)
  const handleDownloadPdf = async () => {
    setIsDownloadingPdf(true);
    try {
      await generateDocumentPdf(financialDoc, settings);
      showSuccess(`PDF #${financialDoc.documentNumber} berhasil diunduh.`);
    } catch (err) {
      console.error('Error generating PDF:', err);
      showError(
        'Gagal mengunduh PDF: ' +
          (err instanceof Error ? err.message : 'Kesalahan render kanvas'),
      );
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  // Save to Central Documents Collection
  const handleSaveToArchive = async () => {
    setIsSavingToArchive(true);
    try {
      const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
      const saved = await saveDocument(financialDoc, userEmail);
      showSuccess(
        `Dokumen #${saved.documentNumber} tersimpan di Dokumen & CRM!`,
      );
      if (onSavedToArchive) {
        onSavedToArchive(saved);
      }
    } catch (err) {
      console.error('Gagal menyimpan dokumen ke arsip:', err);
      showError('Gagal menyimpan ke arsip dokumen.');
    } finally {
      setIsSavingToArchive(false);
    }
  };

  // Copy WhatsApp Text to Clipboard
  const handleCopyWaText = async () => {
    const textToCopy = isManualEditWa ? editedWaText : computedWaText;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setIsCopied(true);
      showSuccess('Teks WhatsApp berhasil disalin ke clipboard!');
      setTimeout(() => setIsCopied(false), 2500);
    } catch {
      showError('Gagal menyalin teks ke clipboard.');
    }
  };

  // Direct WhatsApp Link
  const cleanPhone = (data.phone || '').replace(/[^0-9]/g, '');
  const formattedPhone = cleanPhone.startsWith('0')
    ? '62' + cleanPhone.slice(1)
    : cleanPhone;
  const currentWaMessage = isManualEditWa ? editedWaText : computedWaText;
  const waUrl = formattedPhone
    ? `https://wa.me/${formattedPhone}?text=${encodeURIComponent(currentWaMessage)}`
    : `https://wa.me/?text=${encodeURIComponent(currentWaMessage)}`;

  const moduleTitleMap: Record<ModuleType, string> = {
    hotel: 'Hotel Booking',
    atv: 'ATV Booking',
    combined_order: 'Order Gabungan',
    extra_income: 'Pendapatan Tambahan',
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Aksi Cepat Transaksi — ${moduleTitleMap[moduleType]}`}
      maxWidth="max-w-5xl"
    >
      <div className="space-y-4">
        {/* Top Summary Banner */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              {data.namaPelanggan.charAt(0).toUpperCase() || 'T'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 text-sm">
                  {data.namaPelanggan}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  {moduleTitleMap[moduleType]}
                </span>
              </div>
              <p className="text-slate-500 text-[11px] mt-0.5">
                {data.periode !== '-' ? data.periode : data.tanggal} • Tagihan:{' '}
                <span className="font-bold text-slate-800">{data.total}</span> (
                <span className="text-emerald-700 font-bold">{data.status}</span>)
              </p>
            </div>
          </div>

          {/* Mode Switch Tabs */}
          <div className="flex items-center bg-white border border-slate-200 p-1 rounded-xl shadow-2xs">
            <button
              type="button"
              onClick={() => setActiveTab('doc')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'doc'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Dokumen Resmi</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('wa')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'wa'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Salin WhatsApp</span>
            </button>
          </div>
        </div>

        {/* ================= TAB 1: DOKUMEN RESMI ================= */}
        {activeTab === 'doc' && (
          <div className="space-y-4">
            {/* Control Bar: Select Document Type & Actions */}
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-3">
                {/* Doc Type Selector */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Pilih Jenis Dokumen:
                  </label>
                  <select
                    value={selectedDocType}
                    onChange={(e) => setSelectedDocType(e.target.value as DocumentType)}
                    className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 cursor-pointer"
                  >
                    {AVAILABLE_DOC_TYPES.map((dt) => (
                      <option key={dt.type} value={dt.type}>
                        {dt.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Doc Number Input */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Nomor Dokumen:
                  </label>
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={docNumber}
                      onChange={(e) => setDocNumber(e.target.value)}
                      placeholder="BL/1001"
                      className="w-36 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-hidden focus:border-emerald-500"
                    />
                    {isGeneratingNum && (
                      <Loader2 className="w-3.5 h-3.5 text-slate-400 animate-spin" />
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Simpan ke Arsip, Cetak, Unduh PDF */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveToArchive}
                  disabled={isSavingToArchive}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                  title="Simpan salinan ke Arsip Dokumen & CRM"
                >
                  {isSavingToArchive ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <BookmarkCheck className="w-3.5 h-3.5 text-blue-600" />
                  )}
                  <span>Simpan ke Dokumen</span>
                </button>

                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  title="Cetak langsung dokumen ke printer"
                >
                  <Printer className="w-3.5 h-3.5 text-slate-600" />
                  <span>Cetak</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadPdf}
                  disabled={isDownloadingPdf}
                  className="px-3.5 py-1.5 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                  title="Buat dan unduh file PDF A4 resmi"
                >
                  {isDownloadingPdf ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Membuat PDF...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5 text-slate-200" />
                      <span>Unduh PDF</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Document Preview Container */}
            <div className="bg-slate-100 p-2 sm:p-4 rounded-2xl border border-slate-200 max-h-[60vh] overflow-y-auto shadow-inner flex justify-center">
              <DocumentPreview
                document={financialDoc}
                settings={settings}
                domId="printable-invoice-quick"
              />
            </div>
          </div>
        )}

        {/* ================= TAB 2: SALIN WHATSAPP ================= */}
        {activeTab === 'wa' && (
          <div className="space-y-4">
            {/* Template Selection Bar */}
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Template WhatsApp Aktif:
                </label>
                <select
                  value={selectedTemplateKey}
                  onChange={(e) => {
                    setSelectedTemplateKey(e.target.value as WhatsAppTemplateKey);
                    setIsManualEditWa(false);
                  }}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:border-emerald-500 cursor-pointer"
                >
                  {WHATSAPP_TEMPLATE_KEYS.map((k) => (
                    <option key={k} value={k}>
                      {WHATSAPP_TEMPLATE_LABELS[k]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsManualEditWa(!isManualEditWa);
                    if (!isManualEditWa) {
                      setEditedWaText(computedWaText);
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                    isManualEditWa
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {isManualEditWa ? 'Mode Edit Manual' : 'Ketik / Ubah Teks'}
                </button>

                {isManualEditWa && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsManualEditWa(false);
                      setEditedWaText(computedWaText);
                      showSuccess('Teks dikembalikan ke template dinamis.');
                    }}
                    className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg"
                    title="Reset kembali ke hasil template"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Live Message Preview / Editor Box */}
            <div className="bg-[#ECE5DD] p-4 sm:p-5 rounded-2xl border border-slate-300 shadow-inner">
              <div className="max-w-xl mx-auto bg-[#DCF8C6] text-slate-900 rounded-2xl rounded-tr-xs p-4 shadow-sm space-y-2 border border-emerald-200/50">
                <div className="flex items-center justify-between pb-2 border-b border-emerald-300/40 text-[10px] text-emerald-800 font-bold">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    Pratinjau Pesan WhatsApp ({WHATSAPP_TEMPLATE_LABELS[selectedTemplateKey]})
                  </span>
                  <span className="font-mono text-slate-500">
                    Penerima: {data.namaPelanggan}
                  </span>
                </div>

                {isManualEditWa ? (
                  <textarea
                    rows={12}
                    value={editedWaText}
                    onChange={(e) => setEditedWaText(e.target.value)}
                    className="w-full bg-white/90 p-3 rounded-xl border border-emerald-300 font-mono text-xs leading-relaxed text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                ) : (
                  <div className="whitespace-pre-line text-xs font-mono leading-relaxed text-slate-800 select-all p-1">
                    {computedWaText}
                  </div>
                )}

                <div className="text-[10px] text-slate-400 text-right pt-1 flex items-center justify-end gap-1">
                  <span>Hari ini</span>
                  <span className="text-blue-500 font-bold">✓✓</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions for WhatsApp */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
              <p className="text-[11px] text-slate-500">
                Template otomatis disinkronkan dari{' '}
                <span className="font-bold text-slate-700">
                  Pengaturan Bisnis → Template WhatsApp
                </span>
                .
              </p>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyWaText}
                  className="px-4 py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-xs"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-300">Tersalin ke Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-slate-300" />
                      <span>Salin Teks WhatsApp</span>
                    </>
                  )}
                </button>

                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                  title="Buka langsung pesan ke WhatsApp"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Buka WhatsApp Web</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
