import React, { useState } from 'react';
import { FinancialDocument, BusinessSettings } from '../../types';
import { Modal } from '../common/Modal';
import { DocumentPreview } from '../DocumentPreview';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import { DEFAULT_SETTINGS } from '../../utils/storage';
import { useToast } from '../../context/ToastContext';
import { Download, MessageSquare, Loader2 } from 'lucide-react';
import { WhatsAppShareModal } from './WhatsAppShareModal';

interface DocumentPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: FinancialDocument | null;
  settings?: BusinessSettings;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  isOpen,
  onClose,
  document: doc,
  settings,
}) => {
  const { showSuccess, showError } = useToast();
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState<boolean>(false);

  if (!doc) return null;

  const handleDownloadPdf = async () => {
    setIsDownloading(true);
    try {
      const effectiveSettings = settings || DEFAULT_SETTINGS;
      await generateDocumentPdf(doc, effectiveSettings);
      showSuccess(`PDF #${doc.documentNumber} berhasil diunduh.`);
    } catch (err) {
      console.error('Error downloading PDF:', err);
      showError('Gagal mengunduh PDF: ' + (err instanceof Error ? err.message : 'Kesalahan render'));
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={`Preview Dokumen #${doc.documentNumber}`}
        maxWidth="max-w-4xl"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <p className="text-xs text-slate-500 font-medium">
                Tipe: <span className="font-bold text-slate-800 uppercase">{doc.documentType}</span> • 
                Penerima: <span className="font-bold text-slate-800">{doc.guestName || doc.guestInfo?.name}</span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowWhatsAppModal(true)}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-emerald-200"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Salin WA</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isDownloading}
                className="px-3.5 py-1.5 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                {isDownloading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Mengunduh...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-3.5 h-3.5" />
                    <span>Unduh PDF</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="bg-slate-100 p-2 sm:p-4 rounded-xl max-h-[70vh] overflow-y-auto border border-slate-200 shadow-inner">
            <DocumentPreview document={doc} settings={settings || DEFAULT_SETTINGS} />
          </div>
        </div>
      </Modal>

      {/* WhatsApp Share Modal */}
      {showWhatsAppModal && (
        <WhatsAppShareModal
          isOpen={showWhatsAppModal}
          onClose={() => setShowWhatsAppModal(false)}
          document={doc}
          settings={settings || DEFAULT_SETTINGS}
        />
      )}
    </>
  );
};
