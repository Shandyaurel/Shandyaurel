import React, { useState, useEffect } from 'react';
import {
  FinancialDocument,
  DocumentType,
  DocumentItem,
  BusinessSettings,
  Booking,
  ATVBooking,
  CombinedOrder,
  PaymentStatus,
} from '../../types';
import {
  getBusinessSettings,
  generateNextDocumentNumber,
  saveDocument,
  subscribeBookings,
  subscribeATVBookings,
  subscribeCombinedOrders,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { angkaKeTerbilang } from '../../utils/terbilang';
import { formatRupiah, formatDateToIndonesian, formatDateForInput } from '../../utils/formatter';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import { DEFAULT_SETTINGS, getDefaultTermsForDocType } from '../../utils/storage';
import { DocumentPreview } from '../DocumentPreview';
import { WhatsAppShareModal } from './WhatsAppShareModal';
import {
  FileText,
  Save,
  Download,
  MessageSquare,
  Plus,
  Trash2,
  RefreshCw,
  Eye,
  Edit3,
  Building2,
  CreditCard,
  FileCheck,
  RotateCcw,
  Sparkles,
  Loader2,
  Calendar,
  User,
  ShieldAlert,
} from 'lucide-react';

interface DocumentEditorViewProps {
  initialDocument?: FinancialDocument | null;
  onSaved?: (doc: FinancialDocument) => void;
  onNavigateToArchive?: () => void;
}

const DOCUMENT_TYPES: { type: DocumentType; label: string; desc: string }[] = [
  {
    type: 'invoice',
    label: 'Invoice Tagihan',
    desc: 'Tagihan resmi pembayaran menginap, paket & layanan',
  },
  {
    type: 'kwitansi_dp',
    label: 'Kwitansi DP',
    desc: 'Bukti sah penerimaan uang muka / deposit reservasi',
  },
  {
    type: 'booking_confirmation',
    label: 'Konfirmasi Reservasi',
    desc: 'Surat konfirmasi kamar/tenda siap pakai untuk tamu',
  },
  {
    type: 'registration_card',
    label: 'Registration Card',
    desc: 'Formulir check-in fisik & data identitas tamu',
  },
  {
    type: 'hotel_voucher',
    label: 'Stay Voucher',
    desc: 'Voucher menginap dengan nomor kode booking',
  },
  {
    type: 'proforma',
    label: 'Proforma Invoice',
    desc: 'Estimasi penawaran harga sebelum transaksi final',
  },
  {
    type: 'pengajuan_dana',
    label: 'Pengajuan Dana / Komisi Agen',
    desc: 'Dokumen resmi pencairan dana & komisi agen untuk accounting',
  },
];

export const DocumentEditorView: React.FC<DocumentEditorViewProps> = ({
  initialDocument,
  onSaved,
  onNavigateToArchive,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError, showWarning } = useToast();

  const [settings, setSettings] = useState<BusinessSettings>(DEFAULT_SETTINGS);
  const [hotelBookings, setHotelBookings] = useState<Booking[]>([]);
  const [atvBookings, setATVBookings] = useState<ATVBooking[]>([]);
  const [combinedOrders, setCombinedOrders] = useState<CombinedOrder[]>([]);
  const [selectedBookingSource, setSelectedBookingSource] = useState<string>('');

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'form' | 'preview'>('form');

  // Document State
  const [docId, setDocId] = useState<string>(initialDocument?.id || '');
  const [documentType, setDocumentType] = useState<DocumentType>(
    initialDocument?.documentType || 'invoice',
  );
  const [documentTitle, setDocumentTitle] = useState<string>(
    initialDocument?.documentTitle || '',
  );
  const [documentNumber, setDocumentNumber] = useState<string>(
    initialDocument?.documentNumber || '',
  );
  const [documentDate, setDocumentDate] = useState<string>(
    initialDocument?.documentDate || formatDateForInput(),
  );
  const [dueDate, setDueDate] = useState<string>(
    initialDocument?.dueDate || '',
  );

  // Guest Info
  const [guestName, setGuestName] = useState<string>(
    initialDocument?.guestName || '',
  );
  const [guestOrganization, setGuestOrganization] = useState<string>(
    initialDocument?.guestOrganization || '',
  );
  const [guestPhone, setGuestPhone] = useState<string>(
    initialDocument?.guestPhone || '',
  );
  const [guestEmail, setGuestEmail] = useState<string>(
    initialDocument?.guestEmail || '',
  );
  const [guestAddress, setGuestAddress] = useState<string>(
    initialDocument?.guestAddress || '',
  );
  const [guestIdCard, setGuestIdCard] = useState<string>(
    initialDocument?.guestIdCard || '',
  );
  const [guestNationality, setGuestNationality] = useState<string>(
    initialDocument?.guestNationality || 'Indonesia',
  );
  const [vehiclePlate, setVehiclePlate] = useState<string>(
    initialDocument?.vehiclePlate || '',
  );

  // Stay Details
  const [stayDate, setStayDate] = useState<string>(
    initialDocument?.stayDate || '',
  );
  const [arrivalDate, setArrivalDate] = useState<string>(
    initialDocument?.arrivalDate || formatDateForInput(),
  );
  const [departureDate, setDepartureDate] = useState<string>(
    initialDocument?.departureDate || formatDateForInput(),
  );
  const [totalNights, setTotalNights] = useState<number>(
    initialDocument?.totalNights || 1,
  );
  const [checkInTime, setCheckInTime] = useState<string>(
    initialDocument?.checkInTime || '14.00 WIB',
  );
  const [checkOutTime, setCheckOutTime] = useState<string>(
    initialDocument?.checkOutTime || '12.00 WIB',
  );
  const [roomNumber, setRoomNumber] = useState<string>(
    initialDocument?.roomNumber || 'Glamping 01',
  );
  const [roomType, setRoomType] = useState<string>(
    initialDocument?.roomType || 'Deluxe Glamping Tent',
  );
  const [adultsCount, setAdultsCount] = useState<number>(
    initialDocument?.adultsCount || 2,
  );
  const [childrenCount, setChildrenCount] = useState<number>(
    initialDocument?.childrenCount || 0,
  );
  const [confirmationNumber, setConfirmationNumber] = useState<string>(
    initialDocument?.confirmationNumber || `BL-${Math.floor(100000 + Math.random() * 900000)}`,
  );
  const [voucherCode, setVoucherCode] = useState<string>(
    initialDocument?.voucherCode || `VCR-BL-${Math.floor(1000 + Math.random() * 9000)}`,
  );
  const [inclusions, setInclusions] = useState<string>(
    initialDocument?.inclusions || 'Breakfast 2 pax, Welcome drink, Wi-Fi',
  );
  const [receiptIntroText, setReceiptIntroText] = useState<string>(
    initialDocument?.receiptIntroText || '',
  );

  // Items
  const [items, setItems] = useState<DocumentItem[]>(
    initialDocument?.items && initialDocument.items.length > 0
      ? initialDocument.items
      : [
          {
            id: 'item-1',
            description: 'Sewa Tenda Deluxe Glamping (1 Malam)',
            quantity: 1,
            unit: 'Malam',
            unitPrice: 850000,
            total: 850000,
          },
        ],
  );

  // Pricing & Calculations
  const [useTax, setUseTax] = useState<boolean>(
    initialDocument?.useTax || false,
  );
  const [taxRate, setTaxRate] = useState<number>(
    initialDocument?.taxRate || 10,
  );
  const [downPaymentAmount, setDownPaymentAmount] = useState<number>(
    initialDocument?.downPaymentAmount || initialDocument?.dpAmount || 0,
  );
  const [dpDate, setDpDate] = useState<string>(initialDocument?.dpDate || '');
  const [importSearch, setImportSearch] = useState<string>(''); // cari di Impor Cepat Reservasi
  const [terbilangManual, setTerbilangManual] = useState<string>(
    initialDocument?.terbilangManual || '',
  );
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>(
    initialDocument?.paymentStatus || 'BELUM LUNAS',
  );
  const [paymentMethod, setPaymentMethod] = useState<string>(
    initialDocument?.paymentMethod || 'BANK TRANSFER',
  );

  // Bank & Signatories
  const [selectedBankIndex, setSelectedBankIndex] = useState<number>(0);
  const [signatoryName, setSignatoryName] = useState<string>(
    initialDocument?.signatoryName || '',
  );
  const [signatoryRole, setSignatoryRole] = useState<string>(
    initialDocument?.signatoryRole || '',
  );
  const [recipientSignatoryName, setRecipientSignatoryName] = useState<string>(
    initialDocument?.recipientSignatoryName || '',
  );

  // Terms & Notes
  const [showTerms, setShowTerms] = useState<boolean>(
    initialDocument?.showTermsAndConditions !== false,
  );
  const [termsTitle, setTermsTitle] = useState<string>(
    initialDocument?.termsTitle || 'Syarat & Ketentuan:',
  );
  const [termsText, setTermsText] = useState<string>(
    initialDocument?.termsAndConditions?.join('\n') || '',
  );
  const [notes, setNotes] = useState<string>(initialDocument?.notes || '');

  // Fetch Business Settings & Next Document Number on Mount
  useEffect(() => {
    let isMounted = true;
    getBusinessSettings().then((s) => {
      if (!isMounted) return;
      const combined = { ...DEFAULT_SETTINGS, ...s };
      setSettings(combined);
      if (combined.taxRate) setTaxRate(combined.taxRate);
      if (!signatoryName && combined.signatoryName) setSignatoryName(combined.signatoryName);
      if (!signatoryRole && combined.signatoryRole) setSignatoryRole(combined.signatoryRole);

      // If new document and no documentNumber yet, generate one
      if (!initialDocument && !documentNumber) {
        generateNextDocumentNumber(combined.documentPrefix || 'BL').then((res) => {
          if (isMounted) setDocumentNumber(res.docNumber);
        });
      }

      // Default terms
      if (!initialDocument && !termsText) {
        const defaultTerms = getDefaultTermsForDocType(documentType, combined, documentDate);
        setTermsText(defaultTerms.join('\n'));
      }
    });

    const unsubHotel = subscribeBookings((list) => setHotelBookings(list));
    const unsubATV = subscribeATVBookings((list) => setATVBookings(list));
    const unsubOrders = subscribeCombinedOrders((list) => setCombinedOrders(list));

    return () => {
      isMounted = false;
      unsubHotel();
      unsubATV();
      unsubOrders();
    };
  }, [initialDocument]);

  // Sync document title and default terms when documentType changes (only if creating fresh)
  const handleDocumentTypeChange = (newType: DocumentType) => {
    setDocumentType(newType);

    const defaultTitles: Record<DocumentType, string> = {
      invoice: 'INVOICE PELUNASAN',
      kwitansi_dp: 'OFFICIAL RECEIPT / KWITANSI DP',
      kwitansi_pelunasan: 'KWITANSI PELUNASAN RESMI',
      booking_confirmation: 'SURAT KONFIRMASI RESERVASI',
      registration_card: 'GUEST REGISTRATION CARD',
      hotel_voucher: 'HOTEL RESERVATION VOUCHER',
      proforma: 'PROFORMA INVOICE',
      corporate_contract: 'CONTRACT RATE TRAVEL AGENT & CORPORATE AGREEMENT',
      pengajuan_dana: 'PENGAJUAN DANA / KOMISI AGEN',
    };
    setDocumentTitle(defaultTitles[newType] || 'DOKUMEN KEUANGAN');

    const defaultTerms = getDefaultTermsForDocType(newType, settings, documentDate);
    setTermsText(defaultTerms.join('\n'));

    if (newType === 'kwitansi_dp') {
      setPaymentStatus('DP');
    } else if (newType === 'invoice') {
      setPaymentStatus('LUNAS');
    } else if (newType === 'proforma') {
      setPaymentStatus('BELUM LUNAS');
    }
  };

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + (Number(item.total) || 0), 0);
  const taxAmount = useTax ? Math.round((subtotal * (Number(taxRate) || 0)) / 100) : 0;
  const totalAmount = subtotal + taxAmount;
  const remainingAmount = Math.max(0, totalAmount - (Number(downPaymentAmount) || 0));

  // Auto Terbilang
  const computedTerbilang = terbilangManual.trim()
    ? terbilangManual
    : angkaKeTerbilang(
        documentType === 'kwitansi_dp' && downPaymentAmount > 0 ? downPaymentAmount : totalAmount,
      );

  // Add Item Row
  const handleAddItem = () => {
    const newItem: DocumentItem = {
      id: `item-${Date.now()}`,
      description: 'Layanan Tambahan / F&B',
      quantity: 1,
      unit: 'Pcs',
      unitPrice: 100000,
      total: 100000,
    };
    setItems([...items, newItem]);
  };

  // Remove Item Row
  const handleRemoveItem = (id: string) => {
    if (items.length <= 1) {
      showWarning('Dokumen harus memiliki setidaknya 1 item.');
      return;
    }
    setItems(items.filter((it) => it.id !== id));
  };

  // Update Item Row
  const handleUpdateItem = (id: string, field: keyof DocumentItem, value: any) => {
    setItems(
      items.map((it) => {
        if (it.id !== id) return it;
        const updated = { ...it, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          const qty = field === 'quantity' ? Number(value) : Number(it.quantity);
          const price = field === 'unitPrice' ? Number(value) : Number(it.unitPrice);
          updated.total = (isNaN(qty) ? 0 : qty) * (isNaN(price) ? 0 : price);
        }
        return updated;
      }),
    );
  };

  // Import Data from Hotel or ATV Booking
  const handleImportBooking = (bookingId: string) => {
    if (!bookingId) return;

    if (bookingId.startsWith('hotel_')) {
      const bId = bookingId.replace('hotel_', '');
      const b = hotelBookings.find((x) => x.id === bId);
      if (b) {
        setGuestName(b.guestName || '');
        setGuestPhone(b.guestPhone || '');
        setGuestEmail(b.guestEmail || '');
        setArrivalDate(b.checkInDate || '');
        setDepartureDate(b.checkOutDate || '');
        setStayDate(`${formatDateToIndonesian(b.checkInDate)} s/d ${formatDateToIndonesian(b.checkOutDate)}`);
        setDownPaymentAmount(b.dp || 0);

        if (b.status === 'Confirmed' || b.status === 'Check-out') {
          setPaymentStatus(b.pelunasan > 0 ? 'LUNAS' : b.dp > 0 ? 'DP' : 'BELUM LUNAS');
        }

        // Map rooms to items
        if (b.rooms && b.rooms.length > 0) {
          const mapped: DocumentItem[] = b.rooms.map((r, idx) => ({
            id: `imported-${idx}`,
            description: `Sewa Kamar ${r.roomType} (${r.nights || 1} Malam)`,
            quantity: r.roomQty || 1,
            unit: 'Unit',
            unitPrice: r.roomPrice || 0,
            total: (r.roomQty || 1) * (r.roomPrice || 0) * (r.nights || 1),
          }));
          setItems(mapped);
          setRoomType(b.rooms[0].roomType || 'Deluxe Glamping');
          setTotalNights(b.rooms[0].nights || 1);
        } else if (b.roomType) {
          setItems([
            {
              id: 'imported-0',
              description: `Sewa Kamar ${b.roomType} (${b.nights || 1} Malam)`,
              quantity: b.roomQty || 1,
              unit: 'Unit',
              unitPrice: b.roomPrice || 0,
              total: (b.roomQty || 1) * (b.roomPrice || 0) * (b.nights || 1),
            },
          ]);
          setRoomType(b.roomType);
          setTotalNights(b.nights || 1);
        }

        showSuccess(`Data reservasi hotel "${b.guestName}" berhasil diimpor!`);
      }
    } else if (bookingId.startsWith('atv_')) {
      const aId = bookingId.replace('atv_', '');
      const a = atvBookings.find((x) => x.id === aId);
      if (a) {
        setGuestName(a.guestName || '');
        setGuestPhone(a.guestPhone || '');
        setArrivalDate(a.bookingDate || '');
        setStayDate(`Aktivitas ATV: ${formatDateToIndonesian(a.bookingDate)} (${a.bookingTime || 'Pagi'})`);
        setDownPaymentAmount(a.dp || 0);
        setPaymentStatus(a.pelunasan > 0 ? 'LUNAS' : a.dp > 0 ? 'DP' : 'BELUM LUNAS');

        if (a.tracks && a.tracks.length > 0) {
          const mapped: DocumentItem[] = a.tracks.map((t, idx) => ({
            id: `atv-${idx}`,
            description: `Paket ATV ${t.trackType}`,
            quantity: t.qty || 1,
            unit: 'Unit',
            unitPrice: t.price || 0,
            total: (t.qty || 1) * (t.price || 0),
          }));
          setItems(mapped);
        }
        showSuccess(`Data booking ATV "${a.guestName}" berhasil diimpor!`);
      }
    } else if (bookingId.startsWith('order_')) {
      const oId = bookingId.replace('order_', '');
      const o = combinedOrders.find((x) => x.id === oId);
      if (o) {
        setGuestName(o.guestName || '');
        setGuestPhone(o.guestPhone || '');
        setGuestEmail(o.guestEmail || '');
        setGuestOrganization(o.partnerName ? `Partner: ${o.partnerName}` : '');
        setArrivalDate(o.date || '');
        setStayDate(`Order Gabungan #${o.orderNumber} (${o.date || ''})`);
        setDownPaymentAmount(o.dp || 0);

        const totalPaid = (o.dp || 0) + (o.pelunasan || 0);
        setPaymentStatus(totalPaid >= o.grandTotal ? 'LUNAS' : o.dp > 0 ? 'DP' : 'BELUM LUNAS');

        const combinedItems: DocumentItem[] = [];

        if (o.rooms && o.rooms.length > 0) {
          o.rooms.forEach((r, idx) => {
            combinedItems.push({
              id: `ord-room-${idx}`,
              description: `Sewa Kamar ${r.roomType} (${r.nights || 1} Malam)`,
              quantity: r.roomQty || 1,
              unit: 'Unit',
              unitPrice: r.roomPrice || 0,
              total: (r.roomQty || 1) * (r.roomPrice || 0) * (r.nights || 1),
            });
          });
        }

        if (o.tracks && o.tracks.length > 0) {
          o.tracks.forEach((t, idx) => {
            combinedItems.push({
              id: `ord-atv-${idx}`,
              description: `Aktivitas ATV ${t.trackType}`,
              quantity: t.qty || 1,
              unit: 'Unit',
              unitPrice: t.price || 0,
              total: (t.qty || 1) * (t.price || 0),
            });
          });
        }

        if (o.extraItems && o.extraItems.length > 0) {
          o.extraItems.forEach((e, idx) => {
            combinedItems.push({
              id: `ord-extra-${idx}`,
              description: `${e.category ? `[${e.category}] ` : ''}${e.description}`,
              quantity: e.qty || 1,
              unit: 'Pcs/Pax',
              unitPrice: e.unitPrice || 0,
              total: (e.qty || 1) * (e.unitPrice || 0),
            });
          });
        }

        if (combinedItems.length > 0) {
          setItems(combinedItems);
        }

        showSuccess(`Data Order Gabungan #${o.orderNumber} ("${o.guestName}") berhasil diimpor!`);
      }
    }
  };

  // Build active FinancialDocument object
  // Build active FinancialDocument object
  const currentDocument: FinancialDocument = {
    id: docId || 'draft-doc',
    documentType,
    documentTitle: documentTitle || (documentType === 'kwitansi_dp' ? 'OFFICIAL RECEIPT / KWITANSI DP' : documentType === 'booking_confirmation' ? 'SURAT KONFIRMASI RESERVASI' : documentType === 'registration_card' ? 'GUEST REGISTRATION CARD' : documentType === 'hotel_voucher' ? 'HOTEL RESERVATION VOUCHER' : documentType === 'proforma' ? 'PROFORMA INVOICE' : documentType === 'pengajuan_dana' ? 'PENGAJUAN DANA / KOMISI AGEN' : 'INVOICE PELUNASAN'),
    documentNumber: documentNumber || '01/BL/1001',
    documentDate,
    date: documentDate,
    dueDate: dueDate || undefined,
    headerCompactness: settings.headerCompactness || 'compact',
    headerLogoSize: settings.headerLogoSize || 52,
    guestName: guestName || 'Tamu Terhormat',
    guestOrganization: guestOrganization || undefined,
    guestPhone: guestPhone || undefined,
    guestEmail: guestEmail || undefined,
    guestAddress: guestAddress || undefined,
    guestIdCard: guestIdCard || undefined,
    guestNationality: guestNationality || 'Indonesia',
    vehiclePlate: vehiclePlate || undefined,
    stayDate: stayDate || (arrivalDate && departureDate ? `${formatDateToIndonesian(arrivalDate)} s/d ${formatDateToIndonesian(departureDate)} (${totalNights} Malam)` : '-'),
    arrivalDate,
    departureDate,
    totalNights,
    checkInTime,
    checkOutTime,
    roomNumber: roomNumber || undefined,
    roomType,
    adultsCount,
    childrenCount,
    confirmationNumber: confirmationNumber || undefined,
    voucherCode: voucherCode || undefined,
    inclusions,
    receiptIntroText: receiptIntroText || undefined,
    items,
    subtotal,
    useTax,
    applyTax: useTax,
    taxRate,
    taxAmount,
    totalAmount,
    grandTotal: totalAmount,
    downPaymentAmount,
    dpAmount: downPaymentAmount,
    dp: downPaymentAmount,
    dpDate: dpDate || undefined,
    remainingAmount,
    remainingBalance: remainingAmount,
    terbilang: terbilangManual || angkaKeTerbilang(totalAmount),
    terbilangManual: terbilangManual || undefined,
    paymentStatus,
    paymentMethod,
    bankAccount: settings.bankAccounts?.[selectedBankIndex] || {
      bankName: 'BRI',
      accountNumber: '000701002452566',
      accountHolder: settings.businessName || 'PT. HOLISTIK NUSANTARA GROUP',
      swiftCode: 'BRINIDJA',
    },
    showTermsAndConditions: showTerms,
    termsTitle,
    termsAndConditions: termsText ? termsText.split('\n').filter((t) => t.trim().length > 0) : [],
    terms: termsText ? termsText.split('\n').filter((t) => t.trim().length > 0) : [],
    hotelRules: [],
    notes: notes || undefined,
    signatoryName: signatoryName || settings.signatoryName || 'Bukit Langit Campventure',
    signatoryRole: signatoryRole || settings.signatoryRole || 'Management',
    recipientSignatoryName: recipientSignatoryName || guestName || 'Pihak Tamu',
    guestInfo: {
      name: guestName || 'Tamu Terhormat',
      organization: guestOrganization || '',
      phone: guestPhone || '',
      email: guestEmail || '',
      address: guestAddress || '',
      idNumber: guestIdCard || '',
      vehiclePlate: vehiclePlate || '',
    },
    stayDetails: {
      checkInDate: arrivalDate,
      checkInTime: checkInTime || '14:00',
      checkOutDate: departureDate,
      checkOutTime: checkOutTime || '12:00',
      nights: totalNights || 1,
      roomType: roomType || 'Standard',
      roomNumber: roomNumber || '',
      adults: adultsCount || 2,
      children: childrenCount || 0,
      confirmationCode: confirmationNumber || '',
      voucherCode: voucherCode || '',
    },
    signatory: {
      name: signatoryName || settings.signatoryName || 'Bukit Langit Campventure',
      position: signatoryRole || settings.signatoryRole || 'Management',
    },
    recipientSignatory: {
      name: recipientSignatoryName || guestName || 'Pihak Tamu',
    },
    manualPageBreaks: initialDocument?.manualPageBreaks || [],
    createdAt: initialDocument?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const handleSave = async () => {
    if (!guestName.trim()) {
      showError('Nama Tamu / Klien wajib diisi.');
      return;
    }
    if (items.length === 0) {
      showError('Rincian item tidak boleh kosong.');
      return;
    }

    setIsSaving(true);
    try {
      const saved = await saveDocument(currentDocument, currentUser?.email || 'Admin');
      setDocId(saved.id);
      setDocumentNumber(saved.documentNumber);
      showSuccess(`Dokumen #${saved.documentNumber} (${saved.documentType}) berhasil disimpan!`);
      if (onSaved) onSaved(saved);
    } catch (err) {
      console.error('Error saving document:', err);
      showError('Gagal menyimpan dokumen: ' + (err instanceof Error ? err.message : 'Kesalahan jaringan'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownloadPdf = async () => {
    setIsDownloading(true);
    try {
      const effectiveSettings = settings || DEFAULT_SETTINGS;
      await generateDocumentPdf(currentDocument, effectiveSettings);
      showSuccess(`PDF #${currentDocument.documentNumber} berhasil diunduh.`);
    } catch (err) {
      console.error('Error generating PDF:', err);
      showError('Gagal membuat PDF: ' + (err instanceof Error ? err.message : 'Render error'));
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-lg uppercase tracking-wider">
              {docId ? 'Edit Dokumen' : 'Generator Dokumen Baru'}
            </span>
            <span className="text-xs text-slate-500 font-mono font-bold">
              #{documentNumber || 'Auto-Number'}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
            {DOCUMENT_TYPES.find((d) => d.type === documentType)?.label || 'Pembuat Dokumen'}
          </h1>
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Tab switch for mobile / small screen */}
          <div className="lg:hidden flex bg-slate-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveTab('form')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'form'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Formulir</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'preview'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Live Preview</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setShowWhatsAppModal(true)}
            className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Salin WA</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={isDownloading}
            className="px-3.5 py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Membuat PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Unduh PDF A4</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menyimpan...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Simpan Dokumen</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Split Screen: Left = Form, Right = Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: FORM */}
        <div className={`lg:col-span-6 space-y-6 ${activeTab === 'preview' ? 'hidden lg:block' : 'block'}`}>
          {/* 1. Document Type & Auto-fill */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                1. Jenis Dokumen & Sumber Data
              </h2>
            </div>

            {/* Document Type Selector */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {DOCUMENT_TYPES.map((dt) => {
                const isSelected = documentType === dt.type;
                return (
                  <button
                    key={dt.type}
                    type="button"
                    onClick={() => handleDocumentTypeChange(dt.type)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-xs ring-1 ring-emerald-600'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <p className={`font-bold text-xs ${isSelected ? 'text-emerald-900' : 'text-slate-800'}`}>
                      {dt.label}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-tight line-clamp-2">
                      {dt.desc}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Quick Import From Booking */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <label className="block text-[11px] font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Impor Cepat Dari Reservasi Aktif:
              </label>
              <input
                type="text"
                value={importSearch}
                onChange={(e) => setImportSearch(e.target.value)}
                placeholder="Cari nama tamu / no. order / tanggal…"
                className="w-full px-3 py-2 mb-2 bg-white border border-slate-200 rounded-lg text-xs focus:outline-hidden"
              />
              <select
                value={selectedBookingSource}
                onChange={(e) => {
                  setSelectedBookingSource(e.target.value);
                  handleImportBooking(e.target.value);
                }}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-medium focus:outline-hidden cursor-pointer"
              >
                <option value="">-- Pilih Tamu / Reservasi Hotel & ATV --</option>
                {(() => {
                  const q = importSearch.trim().toLowerCase();
                  const match = (s: string) => !q || s.toLowerCase().includes(q);
                  const orders = combinedOrders.filter((o) =>
                    match(`${o.orderNumber} ${o.guestName} ${o.date}`),
                  );
                  const hotels = hotelBookings.filter((b) =>
                    match(`${b.guestName} ${b.roomType || ''} ${b.checkInDate}`),
                  );
                  const atvs = atvBookings.filter((a) =>
                    match(`${a.guestName} ${a.bookingDate}`),
                  );
                  return (
                    <>
                      {orders.length > 0 && (
                        <optgroup label="Order Gabungan Transaksi">
                          {orders.map((o) => (
                            <option key={o.id} value={`order_${o.id}`}>
                              Order #{o.orderNumber} - {o.guestName} ({o.date}) - Rp{' '}
                              {o.grandTotal.toLocaleString('id-ID')}
                            </option>
                          ))}
                        </optgroup>
                      )}
                      {hotels.length > 0 && (
                        <optgroup label="Reservasi Hotel / Glamping">
                          {hotels.map((b) => (
                            <option key={b.id} value={`hotel_${b.id}`}>
                              {b.guestName} - {b.roomType || 'Kamar'} ({b.checkInDate}) - Rp{' '}
                              {b.grandTotal.toLocaleString('id-ID')}
                            </option>
                          ))}
                        </optgroup>
                      )}
                      {atvs.length > 0 && (
                        <optgroup label="Reservasi ATV Adventure">
                          {atvs.map((a) => (
                            <option key={a.id} value={`atv_${a.id}`}>
                              {a.guestName} - ATV ({a.bookingDate}) - Rp{' '}
                              {a.grandTotal.toLocaleString('id-ID')}
                            </option>
                          ))}
                        </optgroup>
                      )}
                    </>
                  );
                })()}
              </select>
            </div>

            {/* Number & Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor Dokumen:
                </label>
                <input
                  type="text"
                  value={documentNumber}
                  onChange={(e) => setDocumentNumber(e.target.value)}
                  placeholder="Contoh: 09/BL/1842"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tanggal Terbit Dokumen:
                </label>
                <input
                  type="date"
                  value={documentDate}
                  onChange={(e) => setDocumentDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* 2. Guest & Stay Information */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <User className="w-4 h-4 text-emerald-600" />
              2. Informasi Tamu & Detail Menginap
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Tamu / Pemesan (Bill To) <span className="text-rose-500">*</span>:
                </label>
                <input
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="Contoh: Bpk. Ahmad Hidayat"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Instansi / Perusahaan:
                </label>
                <input
                  type="text"
                  value={guestOrganization}
                  onChange={(e) => setGuestOrganization(e.target.value)}
                  placeholder="Contoh: PT. Nusantara Abadi"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor HP / WhatsApp:
                </label>
                <input
                  type="text"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  placeholder="Contoh: 081234567890"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email:
                </label>
                <input
                  type="email"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                  placeholder="Contoh: tamu@gmail.com"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  No. Identitas (KTP / Paspor):
                </label>
                <input
                  type="text"
                  value={guestIdCard}
                  onChange={(e) => setGuestIdCard(e.target.value)}
                  placeholder="Contoh: 3510xxxxxxxxxxxx"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Plat Nomor Kendaraan:
                </label>
                <input
                  type="text"
                  value={vehiclePlate}
                  onChange={(e) => setVehiclePlate(e.target.value)}
                  placeholder="Contoh: P 1234 XY"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono uppercase focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Alamat Asal:
                </label>
                <input
                  type="text"
                  value={guestAddress}
                  onChange={(e) => setGuestAddress(e.target.value)}
                  placeholder="Contoh: Surabaya, Jawa Timur"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>

            {/* Stay specifics */}
            <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tanggal Check-in:
                </label>
                <input
                  type="date"
                  value={arrivalDate}
                  onChange={(e) => setArrivalDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tanggal Check-out:
                </label>
                <input
                  type="date"
                  value={departureDate}
                  onChange={(e) => setDepartureDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tipe Kamar / Glamping:
                </label>
                <input
                  type="text"
                  value={roomType}
                  onChange={(e) => setRoomType(e.target.value)}
                  placeholder="Deluxe Glamping Tent"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor Kamar:
                </label>
                <input
                  type="text"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  placeholder="Glamping 01"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div className="sm:col-span-2 lg:col-span-4">
                <label className="block font-semibold text-slate-700 mb-1">
                  Fasilitas Termasuk (Inclusions):
                </label>
                <input
                  type="text"
                  value={inclusions}
                  onChange={(e) => setInclusions(e.target.value)}
                  placeholder="Contoh: Breakfast for 2 persons, Welcome drink, Wi-Fi, Water Heater"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* 3. Items & Financial Table */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                3. Rincian Item Layanan & Biaya
              </h2>
              <button
                type="button"
                onClick={handleAddItem}
                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Baris</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {items.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-slate-600 text-[11px]">
                      Baris #{idx + 1}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(item.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-12 gap-2">
                    <div className="col-span-12 sm:col-span-6">
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => handleUpdateItem(item.id, 'description', e.target.value)}
                        placeholder="Deskripsi layanan / kamar"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:outline-hidden"
                      />
                    </div>
                    <div className="col-span-4 sm:col-span-2">
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => handleUpdateItem(item.id, 'quantity', e.target.value)}
                        placeholder="Qty"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-center focus:outline-hidden"
                      />
                    </div>
                    <div className="col-span-4 sm:col-span-2">
                      <input
                        type="text"
                        value={item.unit || 'Paket'}
                        onChange={(e) => handleUpdateItem(item.id, 'unit', e.target.value)}
                        placeholder="Satuan"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-center focus:outline-hidden"
                      />
                    </div>
                    <div className="col-span-4 sm:col-span-2">
                      <input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) => handleUpdateItem(item.id, 'unitPrice', e.target.value)}
                        placeholder="Harga"
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-right font-mono focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <div className="text-right font-mono font-bold text-slate-900 text-xs">
                    Subtotal: {formatRupiah(item.total)}
                  </div>
                </div>
              ))}
            </div>

            {/* Calculations & Tax */}
            <div className="pt-3 border-t border-slate-100 space-y-3 bg-slate-50/50 p-3.5 rounded-xl text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600 font-medium">Subtotal Item:</span>
                <span className="font-mono font-bold text-slate-900">{formatRupiah(subtotal)}</span>
              </div>

              <div className="flex items-center justify-between gap-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useTax}
                    onChange={(e) => setUseTax(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-slate-700 font-semibold">Aktifkan Pajak (PPN):</span>
                </label>
                {useTax && (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={taxRate}
                      onChange={(e) => setTaxRate(Number(e.target.value))}
                      className="w-16 px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs text-center font-mono"
                    />
                    <span className="text-slate-600">% = {formatRupiah(taxAmount)}</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center text-sm font-black pt-2 border-t border-slate-200">
                <span className="text-slate-900">Grand Total:</span>
                <span className="font-mono text-emerald-900 text-base">{formatRupiah(totalAmount)}</span>
              </div>

              {/* DP & Sisa */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Uang Muka / DP Diterima (Rp):
                  </label>
                  <input
                    type="number"
                    value={downPaymentAmount}
                    onChange={(e) => setDownPaymentAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold"
                  />
                  <label className="block font-semibold text-slate-700 mb-1 mt-2">
                    Tanggal DP Diterima (opsional):
                  </label>
                  <input
                    type="date"
                    value={dpDate}
                    onChange={(e) => setDpDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Sisa Tagihan (Auto):
                  </label>
                  <div className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-mono font-bold text-rose-700">
                    {formatRupiah(remainingAmount)}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Terbilang Otomatis:
                </label>
                <div className="p-2.5 bg-amber-50/80 border border-amber-200 rounded-xl text-[11px] font-semibold text-amber-950 italic">
                  {computedTerbilang}
                </div>
              </div>
            </div>
          </div>

          {/* 4. Bank, Status, Terms & Signatories */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-600" />
              4. Rekening, Status & Syarat Ketentuan
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Status Pembayaran:
                </label>
                <select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value as PaymentStatus)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold uppercase focus:bg-white focus:outline-hidden cursor-pointer"
                >
                  <option value="LUNAS">LUNAS</option>
                  <option value="DP">DP (Uang Muka)</option>
                  <option value="BELUM LUNAS">BELUM LUNAS</option>
                  <option value="SEBAGIAN">SEBAGIAN</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Metode Pembayaran:
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-hidden cursor-pointer"
                >
                  <option value="BANK TRANSFER">Bank Transfer (PT)</option>
                  <option value="TUNAI / CASH">Tunai / Cash di Lokasi</option>
                  <option value="EDC / KARTU KREDIT">EDC / Kartu Kredit</option>
                  <option value="QRIS">QRIS</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Rekening Tujuan Transfer:
                </label>
                <select
                  value={selectedBankIndex}
                  onChange={(e) => setSelectedBankIndex(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-hidden cursor-pointer"
                >
                  {settings.bankAccounts?.map((b, idx) => (
                    <option key={b.id || idx} value={idx}>
                      {b.bankName} - {b.accountNumber} a.n. {b.accountHolder}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Terms and Conditions Editor */}
            <div className="pt-3 border-t border-slate-100 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-800">
                  <input
                    type="checkbox"
                    checked={showTerms}
                    onChange={(e) => setShowTerms(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600"
                  />
                  <span>Tampilkan Syarat & Ketentuan pada Dokumen</span>
                </label>
              </div>

              {showTerms && (
                <div>
                  <textarea
                    rows={6}
                    value={termsText}
                    onChange={(e) => setTermsText(e.target.value)}
                    placeholder="Satu baris per klausul aturan..."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:outline-hidden font-mono"
                  />
                </div>
              )}
            </div>

            {/* Signatory */}
            <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nama Penandatangan (Hormat Kami):
                </label>
                <input
                  type="text"
                  value={signatoryName}
                  onChange={(e) => setSignatoryName(e.target.value)}
                  placeholder="Contoh: Bukit Langit Campventure"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Jabatan / Posisi:
                </label>
                <input
                  type="text"
                  value={signatoryRole}
                  onChange={(e) => setSignatoryRole(e.target.value)}
                  placeholder="Contoh: Reservation & Sales Management"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: LIVE A4 PREVIEW (TERKUNCI) */}
        <div className={`lg:col-span-6 sticky top-4 ${activeTab === 'form' ? 'hidden lg:block' : 'block'}`}>
          <div className="bg-slate-900 text-white px-4 py-3 rounded-t-2xl flex items-center justify-between text-xs font-bold shadow-lg">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>Live Preview Standar A4</span>
            </div>
            <span className="text-[11px] font-mono text-slate-300">
              #{documentNumber || 'Draft'}
            </span>
          </div>

          <div className="bg-slate-100 border-x border-b border-slate-300 rounded-b-2xl p-2 sm:p-4 max-h-[85vh] overflow-x-hidden overflow-y-auto shadow-inner">
            <div className="flex justify-center">
              <div className="scale-[0.5] sm:scale-[0.62] md:scale-[0.7] lg:scale-[0.6] xl:scale-[0.68] origin-top">
                <DocumentPreview document={currentDocument} settings={settings} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Offscreen fallback container for instant PDF capture when on mobile form view */}
      {activeTab === 'form' && (
        <div
          className="lg:hidden"
          style={{
            position: 'fixed',
            left: -9999,
            top: 0,
            width: '800px',
            opacity: 0.01,
            pointerEvents: 'none',
            zIndex: -999,
          }}
          aria-hidden="true"
        >
          <DocumentPreview document={currentDocument} settings={settings} />
        </div>
      )}

      {/* WhatsApp Modal */}
      {showWhatsAppModal && (
        <WhatsAppShareModal
          isOpen={showWhatsAppModal}
          onClose={() => setShowWhatsAppModal(false)}
          document={currentDocument}
          settings={settings}
        />
      )}
    </div>
  );
};
