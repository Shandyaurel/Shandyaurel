import React, { useState, useEffect, useMemo } from 'react';
import {
  CombinedOrder,
  CombinedOrderExtraItem,
  CostBreakdownItem,
  DiscountType,
  BusinessSettings,
  ClientContact,
  BookingRoomItem,
  ATVTrackItem,
  ExtraIncomeItem,
  ExtraServiceCatalogItem,
  InventoryItem,
  PaymentRecord,
} from '../../types';
import {
  subscribePartners,
  subscribeExtraServiceCatalog,
  subscribeInventoryItems,
} from '../../utils/firebase';
import {
  DEFAULT_BOOKING_SOURCES,
  DEFAULT_PAYMENT_METHODS,
  DEFAULT_ROOM_TYPES,
  DEFAULT_ATV_TRACKS,
  formatRupiah,
  getTodayDateString,
  getCurrentTimeString,
  formatDateIndo,
} from '../../utils/formatters';
import {
  ShoppingBag,
  Plus,
  Trash2,
  Hotel,
  Compass,
  Coins,
  User,
  Calendar,
  CreditCard,
  Percent,
  CheckCircle2,
  X,
  Utensils,
  Handshake,
  Building2,
  Phone,
  FileText,
  Search,
  Package,
  ChevronDown,
  ChevronUp,
  TrendingDown,
} from 'lucide-react';

interface CombinedOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderToEdit?: CombinedOrder | null;
  onSave: (data: Partial<CombinedOrder>) => Promise<void>;
  businessSettings?: BusinessSettings | null;
  onOpenQuickDoc?: (ord: CombinedOrder) => void;
}

export const CombinedOrderModal: React.FC<CombinedOrderModalProps> = ({
  isOpen,
  onClose,
  orderToEdit,
  onSave,
  businessSettings,
  onOpenQuickDoc,
}) => {
  const isEditing = !!orderToEdit;

  // Guest & Order Info
  const [date, setDate] = useState<string>(getTodayDateString());
  const [guestName, setGuestName] = useState<string>('');
  const [guestPhone, setGuestPhone] = useState<string>('');
  const [guestEmail, setGuestEmail] = useState<string>('');
  const [sourceType, setSourceType] = useState<string>('Walk in');
  const [bookingVia, setBookingVia] = useState<string>('Walk in');
  const [partnerId, setPartnerId] = useState<string>('');
  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [includeBreakfast, setIncludeBreakfast] = useState<boolean>(true);
  const [breakfastPaxPerNight, setBreakfastPaxPerNight] = useState<number>(2);
  const [status, setStatus] = useState<
    'Active' | 'Scheduled' | 'Confirmed' | 'Check-in' | 'Check-out' | 'Completed' | 'Cancelled'
  >('Scheduled');
  const [notes, setNotes] = useState<string>('');

  // 1. Hotel Rooms Repeater
  const [rooms, setRooms] = useState<BookingRoomItem[]>([]);

  // 2. ATV Tracks Repeater
  const [tracks, setTracks] = useState<ATVTrackItem[]>([]);

  // 3. Extra Items Repeater (dengan katalog + HPP + rincian modal)
  type ExtraRow = {
    id: string;
    catalogId?: string;
    category: string;
    description: string;
    qty: number;
    unitPrice: number;
    hpp: number; // HPP per unit (ringkasan)
    totalHpp: number; // qty * hpp (atau sum costBreakdown.amount)
    labaBersih: number; // total - totalHpp
    total: number;
    inventoryItemId?: string;
    costBreakdown: CostBreakdownItem[];
    _showBreakdown?: boolean; // UI only
    _catalogSearch?: string; // UI only — filter katalog per baris
    _catalogOpen?: boolean; // UI only — buka dropdown katalog
  };
  const [extraItems, setExtraItems] = useState<ExtraRow[]>([]);

  // Katalog Layanan Extra + Inventory
  const [catalogList, setCatalogList] = useState<ExtraServiceCatalogItem[]>([]);
  const [inventoryList, setInventoryList] = useState<InventoryItem[]>([]);

  // Grid katalog untuk Section 4
  const [showCatalogGrid, setShowCatalogGrid] = useState<boolean>(false);
  const [catalogGridSearch, setCatalogGridSearch] = useState<string>('');

  // Pricing & Discounts
  const [discountType, setDiscountType] = useState<DiscountType>('Nominal');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [agentFee, setAgentFee] = useState<number>(0);

  // Payments
  const [dp, setDp] = useState<number>(0);
  const [dpDate, setDpDate] = useState<string>(getTodayDateString());
  const [dpTime, setDpTime] = useState<string>('12:00');
  const [dpMethod, setDpMethod] = useState<string>('Cash');

  const [pelunasan, setPelunasan] = useState<number>(0);
  const [pelunasanDate, setPelunasanDate] = useState<string>('');
  const [pelunasanTime, setPelunasanTime] = useState<string>('');
  const [pelunasanMethod, setPelunasanMethod] = useState<string>('Cash');

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Subscribe partners + katalog + inventory
  useEffect(() => {
    if (!isOpen) return;
    const unsub = subscribePartners(
      (list) => setPartners(list),
      (err) => console.error('Error fetching partners in combined order modal:', err),
    );
    const unsubCatalog = subscribeExtraServiceCatalog((items) => setCatalogList(items));
    const unsubInv = subscribeInventoryItems((items) => setInventoryList(items));
    return () => {
      unsub();
      unsubCatalog();
      unsubInv();
    };
  }, [isOpen]);

  // Combined sources & payment methods
  const bookingSources = Array.from(
    new Set([...DEFAULT_BOOKING_SOURCES, ...(businessSettings?.customBookingSources || [])]),
  );
  const paymentMethods = Array.from(
    new Set([...DEFAULT_PAYMENT_METHODS, ...(businessSettings?.customPaymentMethods || [])]),
  );

  // ATV track options — ambil dari Business Settings (defaultAtvPackages).
  // Fallback ke DEFAULT_ATV_TRACKS kalau belum di-set operator.
  const atvOptions = useMemo(() => {
    const fromSettings = (businessSettings?.defaultAtvPackages || [])
      .filter((p) => p && p.name)
      .map((p) => ({
        name: p.name,
        defaultPrice: Number(p.specialRate) || Number(p.publishedRate) || 0,
      }));
    return fromSettings.length > 0 ? fromSettings : DEFAULT_ATV_TRACKS;
  }, [businessSettings]);

  // Populate form
  useEffect(() => {
    if (!isOpen) return;

    if (orderToEdit) {
      setDate(orderToEdit.date || getTodayDateString());
      setGuestName(orderToEdit.guestName || '');
      setGuestPhone(orderToEdit.guestPhone || '');
      setGuestEmail(orderToEdit.guestEmail || '');
      setBookingVia(orderToEdit.bookingVia || 'Walk in');
      setPartnerId(orderToEdit.partnerId || '');
      if (orderToEdit.partnerId || (orderToEdit.bookingVia && (orderToEdit.bookingVia.toLowerCase().includes('mitra') || orderToEdit.bookingVia.toLowerCase().includes('agent')))) {
        setSourceType('Tour Agent / Mitra');
      } else {
        setSourceType(orderToEdit.bookingVia || 'Walk in');
      }
      setIncludeBreakfast(orderToEdit.includeBreakfast ?? true);
      setBreakfastPaxPerNight(orderToEdit.breakfastPaxPerNight ?? 2);
      setStatus(orderToEdit.status as any || 'Scheduled');
      setNotes(orderToEdit.notes || '');

      setRooms(orderToEdit.rooms ? orderToEdit.rooms.map((r) => ({ ...r })) : []);
      setTracks(orderToEdit.tracks ? orderToEdit.tracks.map((t) => ({ ...t })) : []);
      setExtraItems(
        orderToEdit.extraItems
          ? orderToEdit.extraItems.map((e) => ({
              id: e.id,
              catalogId: e.catalogId,
              category: e.category || 'Lainnya',
              description: e.description,
              qty: Number(e.qty) || 1,
              unitPrice: Number(e.unitPrice) || 0,
              hpp: Number(e.hpp) || 0,
              totalHpp: Number(e.totalHpp) || 0,
              labaBersih: Number(e.labaBersih) || 0,
              total: Number(e.total) || 0,
              inventoryItemId: e.inventoryItemId,
              costBreakdown: e.costBreakdown || [],
              _showBreakdown: false,
              _catalogSearch: '',
              _catalogOpen: false,
            }))
          : [],
      );

      setDiscountType(orderToEdit.discountType || 'Nominal');
      setDiscountValue(orderToEdit.discountValue || 0);
      setAgentFee(orderToEdit.agentFee || 0);

      setDp(orderToEdit.dp || 0);
      setDpDate(orderToEdit.dpDate || orderToEdit.date || getTodayDateString());
      setDpTime(orderToEdit.dpTime || '12:00');
      setDpMethod(orderToEdit.dpMethod || 'Cash');

      setPelunasan(orderToEdit.pelunasan || 0);
      setPelunasanDate(orderToEdit.pelunasanDate || '');
      setPelunasanTime(orderToEdit.pelunasanTime || '');
      setPelunasanMethod(orderToEdit.pelunasanMethod || 'Cash');
    } else {
      const today = getTodayDateString();
      setDate(today);
      setGuestName('');
      setGuestPhone('');
      setGuestEmail('');
      setSourceType('Walk in');
      setBookingVia('Walk in');
      setPartnerId('');
      setIncludeBreakfast(true);
      setBreakfastPaxPerNight(businessSettings?.breakfastDefaultPaxPerNight || 2);
      setStatus('Scheduled');
      setNotes('');

      // Defaults: 1 room, 1 ATV track
      setRooms([
        {
          roomType: DEFAULT_ROOM_TYPES[0].name,
          checkInDate: today,
          checkOutDate: today,
          nights: 1,
          roomQty: 1,
          roomPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
          totalPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
        },
      ]);
      setTracks([
        {
          trackType: atvOptions[0].name,
          qty: 1,
          price: atvOptions[0].defaultPrice,
        },
      ]);
      setExtraItems([]);

      setDiscountType('Nominal');
      setDiscountValue(0);
      setAgentFee(0);

      setDp(0);
      setDpDate(today);
      setDpTime(getCurrentTimeString());
      setDpMethod('Cash');

      setPelunasan(0);
      setPelunasanDate('');
      setPelunasanTime('');
      setPelunasanMethod('Cash');
    }
    setFormError('');
  }, [isOpen, orderToEdit, businessSettings]);

  // Calculations
  const hotelSubtotal = rooms.reduce(
    (sum, r) => sum + (Number(r.roomQty || 1) * Number(r.roomPrice || 0) * Number(r.nights || 1)),
    0,
  );
  const atvSubtotal = tracks.reduce((sum, t) => sum + (Number(t.qty || 1) * Number(t.price || 0)), 0);
  const extraSubtotal = extraItems.reduce((sum, e) => sum + (Number(e.qty || 1) * Number(e.unitPrice || 0)), 0);

  const subtotal = hotelSubtotal + atvSubtotal + extraSubtotal;

  let discountAmount = 0;
  if (discountType === 'Persen') {
    discountAmount = Math.round((subtotal * Math.min(100, Math.max(0, discountValue))) / 100);
  } else {
    discountAmount = Math.min(subtotal, Math.max(0, discountValue));
  }

  const grandTotal = Math.max(0, subtotal - discountAmount);
  const totalPaid = (Number(dp) || 0) + (Number(pelunasan) || 0);
  const remaining = Math.max(0, grandTotal - totalPaid);

  // Room Repeaters
  const handleAddRoom = () => {
    const today = getTodayDateString();
    setRooms((prev) => [
      ...prev,
      {
        roomType: DEFAULT_ROOM_TYPES[0].name,
        checkInDate: today,
        checkOutDate: today,
        nights: 1,
        roomQty: 1,
        roomPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
        totalPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
      },
    ]);
  };

  const handleRemoveRoom = (idx: number) => {
    setRooms((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleRoomChange = (idx: number, field: string, value: any) => {
    setRooms((prev) => {
      const copy = [...prev];
      const target = { ...copy[idx] };
      if (field === 'roomType') {
        target.roomType = String(value);
        const found = DEFAULT_ROOM_TYPES.find((rt) => rt.name === value);
        if (found) target.roomPrice = found.defaultPrice;
      } else if (field === 'nights' || field === 'roomQty' || field === 'roomPrice') {
        (target as any)[field] = Math.max(0, Number(value) || 0);
      } else {
        (target as any)[field] = value;
        // Hitung ulang jumlah malam dari check-in/check-out agar total kamar = harga × qty × malam
        if (field === 'checkInDate' || field === 'checkOutDate') {
          const ci = field === 'checkInDate' ? value : (target as any).checkInDate;
          const co = field === 'checkOutDate' ? value : (target as any).checkOutDate;
          if (ci && co) {
            const diff = Math.round(
              (new Date(co).getTime() - new Date(ci).getTime()) / 86400000,
            );
            if (diff > 0) target.nights = diff;
          }
        }
      }
      copy[idx] = target;
      return copy;
    });
  };

  // ATV Repeaters
  const handleAddTrack = () => {
    setTracks((prev) => [
      ...prev,
      {
        trackType: atvOptions[0].name,
        qty: 1,
        price: atvOptions[0].defaultPrice,
        bookingDate: date, // default: tgl order
      },
    ]);
  };

  const handleRemoveTrack = (idx: number) => {
    setTracks((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleTrackChange = (idx: number, field: keyof ATVTrackItem, value: any) => {
    setTracks((prev) => {
      const copy = [...prev];
      const target = { ...copy[idx] };
      if (field === 'trackType') {
        target.trackType = String(value);
        const found = atvOptions.find((p) => p.name === value);
        if (found) target.price = found.defaultPrice;
      } else if (field === 'qty' || field === 'price') {
        (target as any)[field] = Math.max(0, Number(value) || 0);
      } else if (field === 'bookingDate') {
        target.bookingDate = String(value || '') || undefined;
      }
      copy[idx] = target;
      return copy;
    });
  };

  // --- Extra Item Repeaters (dengan katalog + HPP + rincian modal) ---

  // Hitung ulang total, totalHpp, labaBersih sebuah baris
  const recomputeRow = (row: ExtraRow): ExtraRow => {
    const qty = Math.max(1, Number(row.qty) || 1);
    const unitPrice = Math.max(0, Number(row.unitPrice) || 0);
    const total = qty * unitPrice;

    // HPP: kalau ada costBreakdown → sum amount; selain itu dari hpp per unit × qty
    const sumBreakdown = (row.costBreakdown || []).reduce(
      (s, c) => s + (Number(c.amount) || (Number(c.qty) || 0) * (Number(c.unitPrice) || 0)),
      0,
    );
    const totalHpp = sumBreakdown > 0 ? sumBreakdown : Math.max(0, Number(row.hpp) || 0) * qty;
    const hppPerUnit = qty > 0 ? Math.round(totalHpp / qty) : Number(row.hpp) || 0;
    const labaBersih = total - totalHpp;

    return {
      ...row,
      qty,
      unitPrice,
      total,
      hpp: hppPerUnit,
      totalHpp,
      labaBersih,
    };
  };

  const handleAddExtraItem = () => {
    setExtraItems((prev) => [
      ...prev,
      recomputeRow({
        id: `ext_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        category: 'Lainnya',
        description: '',
        qty: 1,
        unitPrice: 0,
        hpp: 0,
        totalHpp: 0,
        labaBersih: 0,
        total: 0,
        costBreakdown: [],
        _showBreakdown: false,
        _catalogSearch: '',
        _catalogOpen: true, // langsung buka dropdown katalog saat baris baru dibuat
      }),
    ]);
  };

  const handleRemoveExtraItem = (idx: number) => {
    setExtraItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleExtraItemChange = (idx: number, field: string, value: any) => {
    setExtraItems((prev) => {
      const copy = [...prev];
      let target: ExtraRow = { ...copy[idx] };
      if (field === 'category') target.category = String(value);
      else if (field === 'description') target.description = String(value);
      else if (field === 'qty') target.qty = Math.max(1, Number(value) || 1);
      else if (field === 'unitPrice') target.unitPrice = Math.max(0, Number(value) || 0);
      else if (field === 'hpp') target.hpp = Math.max(0, Number(value) || 0);
      else if (field === '_showBreakdown') target._showBreakdown = Boolean(value);
      else if (field === '_catalogSearch') target._catalogSearch = String(value);
      else if (field === '_catalogOpen') target._catalogOpen = Boolean(value);
      copy[idx] = recomputeRow(target);
      return copy;
    });
  };

  // Quick-add dari katalog langsung (dari grid di Section 4) — buat baris baru terisi penuh
  const handleQuickAddFromCatalog = (cat: ExtraServiceCatalogItem) => {
    const newId = `ext_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    const costBreakdown = (cat.defaultCostBreakdown || []).map((c, i) => ({
      id: `cost_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 5)}`,
      label: c.label || '',
      qty: Number(c.qty) || 1,
      unitPrice: Number(c.unitPrice) || 0,
      amount: (Number(c.qty) || 1) * (Number(c.unitPrice) || 0),
      inventoryItemId: c.inventoryItemId || undefined,
    }));
    const newRow: ExtraRow = recomputeRow({
      id: newId,
      catalogId: cat.id,
      category: cat.category || 'Lainnya',
      description: cat.name || '',
      qty: 1,
      unitPrice: cat.defaultSellingPrice || 0,
      hpp: 0,
      totalHpp: 0,
      labaBersih: 0,
      total: 0,
      costBreakdown,
      _showBreakdown: false,
      _catalogSearch: '',
      _catalogOpen: false,
    });
    setExtraItems((prev) => [...prev, newRow]);
  };

  // Pilih item dari katalog → autofill nama, kategori, harga jual, HPP, costBreakdown
  const handleSelectCatalogForRow = (idx: number, catalogId: string) => {
    const cat = catalogList.find((c) => c.id === catalogId);
    if (!cat) return;
    setExtraItems((prev) => {
      const copy = [...prev];
      const row: ExtraRow = { ...copy[idx] };
      row.catalogId = cat.id;
      row.description = cat.name || row.description;
      row.category = cat.category || row.category || 'Lainnya';
      if (cat.defaultSellingPrice && cat.defaultSellingPrice > 0) {
        row.unitPrice = cat.defaultSellingPrice;
      }
      // Clone defaultCostBreakdown jadi costBreakdown baris ini
      row.costBreakdown = (cat.defaultCostBreakdown || []).map((c, i) => ({
        id: `cost_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 5)}`,
        label: c.label || '',
        qty: Number(c.qty) || 1,
        unitPrice: Number(c.unitPrice) || 0,
        amount: (Number(c.qty) || 1) * (Number(c.unitPrice) || 0),
        inventoryItemId: c.inventoryItemId || undefined,
      }));
      row._catalogOpen = false;
      row._catalogSearch = '';
      row._showBreakdown = row.costBreakdown.length > 0;
      copy[idx] = recomputeRow(row);
      return copy;
    });
  };

  // Rincian modal (costBreakdown) handlers — per baris extra
  const handleAddCostRow = (extraIdx: number) => {
    setExtraItems((prev) => {
      const copy = [...prev];
      const row: ExtraRow = { ...copy[extraIdx], costBreakdown: [...copy[extraIdx].costBreakdown] };
      row.costBreakdown.push({
        id: `cost_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        label: '',
        qty: 1,
        unitPrice: 0,
        amount: 0,
      });
      row._showBreakdown = true;
      copy[extraIdx] = recomputeRow(row);
      return copy;
    });
  };

  const handleRemoveCostRow = (extraIdx: number, costIdx: number) => {
    setExtraItems((prev) => {
      const copy = [...prev];
      const row: ExtraRow = { ...copy[extraIdx], costBreakdown: [...copy[extraIdx].costBreakdown] };
      row.costBreakdown.splice(costIdx, 1);
      copy[extraIdx] = recomputeRow(row);
      return copy;
    });
  };

  const handleCostRowChange = (
    extraIdx: number,
    costIdx: number,
    field: keyof CostBreakdownItem,
    value: any,
  ) => {
    setExtraItems((prev) => {
      const copy = [...prev];
      const row: ExtraRow = { ...copy[extraIdx], costBreakdown: [...copy[extraIdx].costBreakdown] };
      const cost = { ...row.costBreakdown[costIdx] } as CostBreakdownItem;
      if (field === 'label') cost.label = String(value);
      else if (field === 'qty') cost.qty = Math.max(0, Number(value) || 0);
      else if (field === 'unitPrice') cost.unitPrice = Math.max(0, Number(value) || 0);
      else if (field === 'inventoryItemId') {
        cost.inventoryItemId = value ? String(value) : undefined;
        // Autofill label + HPP dari inventory
        if (value) {
          const inv = inventoryList.find((i) => i.id === value);
          if (inv) {
            if (!cost.label) cost.label = inv.name;
            cost.unitPrice = Number(inv.hpp) || cost.unitPrice;
          }
        }
      }
      cost.amount = (Number(cost.qty) || 0) * (Number(cost.unitPrice) || 0);
      row.costBreakdown[costIdx] = cost;
      copy[extraIdx] = recomputeRow(row);
      return copy;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!guestName.trim()) {
      setFormError('Nama tamu wajib diisi.');
      return;
    }

    if (rooms.length === 0 && tracks.length === 0 && extraItems.length === 0) {
      setFormError('Pilih minimal 1 item (Kamar Hotel, Track ATV, atau Layanan Tambahan).');
      return;
    }

    const paymentHistory: PaymentRecord[] = [];
    if (dp > 0) {
      paymentHistory.push({
        id: `pay_dp_${Date.now()}`,
        date: dpDate || date || getTodayDateString(),
        time: dpTime || '12:00',
        amount: Number(dp),
        method: dpMethod,
        type: 'DP',
        notes: 'DP Order Gabungan',
      });
    }
    if (pelunasan > 0) {
      paymentHistory.push({
        id: `pay_lunas_${Date.now() + 1}`,
        date: pelunasanDate || date || getTodayDateString(),
        time: pelunasanTime || getCurrentTimeString(),
        amount: Number(pelunasan),
        method: pelunasanMethod,
        type: 'Pelunasan',
        notes: 'Pelunasan Order Gabungan',
      });
    }

    const selectedPartnerObj = partnerId ? partners.find((p) => p.id === partnerId) : undefined;
    const finalBookingVia = partnerId && selectedPartnerObj ? selectedPartnerObj.name : bookingVia;

    const payload: Partial<CombinedOrder> = {
      ...(orderToEdit ? { id: orderToEdit.id, orderNumber: orderToEdit.orderNumber } : {}),
      date,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
      guestEmail: guestEmail.trim(),
      bookingVia: finalBookingVia,
      partnerId: partnerId || undefined,
      partnerName: selectedPartnerObj ? selectedPartnerObj.name : undefined,
      rooms: rooms.map((r) => ({ ...r, totalPrice: (r.roomQty || 1) * (r.roomPrice || 0) * (r.nights || 1) })),
      tracks: tracks.map((t) => ({ ...t, bookingDate: t.bookingDate || undefined })),
      extraItems: extraItems.map<CombinedOrderExtraItem>((e) => {
        const qty = Math.max(1, Number(e.qty) || 1);
        const unitPrice = Math.max(0, Number(e.unitPrice) || 0);
        const total = qty * unitPrice;
        const sumBreakdown = (e.costBreakdown || []).reduce(
          (s, c) => s + (Number(c.amount) || (Number(c.qty) || 0) * (Number(c.unitPrice) || 0)),
          0,
        );
        const totalHpp = sumBreakdown > 0 ? sumBreakdown : Math.max(0, Number(e.hpp) || 0) * qty;
        const hppPerUnit = qty > 0 ? Math.round(totalHpp / qty) : Number(e.hpp) || 0;
        const labaBersih = total - totalHpp;
        return {
          id: e.id,
          catalogId: e.catalogId,
          category: e.category || 'Lainnya',
          description: e.description,
          qty,
          unitPrice,
          total,
          hpp: hppPerUnit,
          totalHpp,
          labaBersih,
          inventoryItemId: e.inventoryItemId,
          costBreakdown: (e.costBreakdown || []).filter((c) => c.label || c.inventoryItemId || c.amount > 0),
        };
      }),
      subtotal,
      discountType,
      discountValue: Number(discountValue) || 0,
      discountAmount,
      agentFee: Number(agentFee) || 0,
      grandTotal,
      dp: Number(dp) || 0,
      dpDate: dp > 0 ? dpDate : '',
      dpTime: dp > 0 ? dpTime : '',
      dpMethod: dp > 0 ? dpMethod : '',
      pelunasan: Number(pelunasan) || 0,
      pelunasanDate: pelunasan > 0 ? pelunasanDate : '',
      pelunasanTime: pelunasan > 0 ? pelunasanTime : '',
      pelunasanMethod: pelunasan > 0 ? pelunasanMethod : '',
      paymentHistory,
      status,
      paymentMethod: dpMethod || pelunasanMethod || 'Cash',
      includeBreakfast: Boolean(includeBreakfast),
      breakfastPaxPerNight: Number(breakfastPaxPerNight) || 2,
      notes: notes.trim(),
    };

    try {
      setIsSaving(true);
      await onSave(payload);
      onClose();
    } catch (err) {
      console.error('Error saving combined order:', err);
      setFormError('Gagal menyimpan order gabungan. Silakan coba lagi.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  const selectedPartner = partnerId ? partners.find((p) => p.id === partnerId) : undefined;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-600/30 text-blue-400 rounded-xl">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">
                {isEditing ? `Ubah Order Gabungan #${orderToEdit?.orderNumber}` : 'Buat Order Gabungan Baru'}
              </h3>
              <p className="text-xs text-slate-400">
                Satu paket transaksi gabungan: Kamar Hotel + Track ATV + Pendapatan Extra
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isEditing && orderToEdit && onOpenQuickDoc && (
              <button
                type="button"
                onClick={() => onOpenQuickDoc(orderToEdit)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                title="Buka Dokumen & Salin WhatsApp"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Dokumen & WA</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold">
              {formError}
            </div>
          )}

          {/* Section 1: Guest & General */}
          <div className="p-4 bg-slate-50/80 border border-slate-200/80 rounded-xl space-y-4">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-600" />
              1. Informasi Tamu & Transaksi
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Tamu / Pemesan <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Bpk. Hendra Gunawan"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">No. WhatsApp / HP</label>
                <input
                  type="text"
                  placeholder="08123456789"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email (Opsional)</label>
                <input
                  type="email"
                  placeholder="hendra@gmail.com"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Tgl Order</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sumber Pemesanan
                </label>
                <select
                  value={sourceType}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSourceType(val);
                    if (val === 'Tour Agent / Mitra') {
                      if (!partnerId && partners.length > 0) {
                        setPartnerId(partners[0].id);
                        setBookingVia(partners[0].name);
                      }
                    } else {
                      setPartnerId('');
                      setBookingVia(val);
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-blue-600 font-medium"
                >
                  <option value="Walk in">Walk in (Langsung di Lokasi)</option>
                  <option value="Direct WA">Direct WhatsApp / Telepon</option>
                  <option value="Instagram">Instagram</option>
                  <option value="TikTok">TikTok</option>
                  <option value="Website">Website Resmi</option>
                  <option value="OTA">OTA (Agoda / Traveloka / Booking)</option>
                  <option value="Tour Agent / Mitra">Tour Agent / Mitra Bisnis</option>
                  {businessSettings?.customBookingSources?.filter((s) => !['Walk in', 'Direct WA', 'Instagram', 'TikTok', 'Website', 'OTA', 'Tour Agent / Mitra'].includes(s)).map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Status Transaksi</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-slate-800 focus:outline-hidden focus:border-blue-600"
                >
                  <option value="Scheduled">Scheduled (Terjadwal)</option>
                  <option value="Confirmed">Confirmed (Terkonfirmasi)</option>
                  <option value="Check-in">Check-in</option>
                  <option value="Check-out">Check-out</option>
                  <option value="Cancelled">Cancelled (Batal)</option>
                </select>
              </div>
            </div>

            {/* Sub-dropdown when Tour Agent / Mitra is selected */}
            {(sourceType === 'Tour Agent / Mitra' || partnerId) && (
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900">
                  <Handshake className="w-4 h-4 text-blue-600" />
                  <span>Pilih Mitra Bisnis / Travel Agent Terdaftar</span>
                </div>
                {partners.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
                    <select
                      value={partnerId}
                      onChange={(e) => {
                        const pId = e.target.value;
                        setPartnerId(pId);
                        const pObj = partners.find((p) => p.id === pId);
                        if (pObj) {
                          setBookingVia(pObj.name);
                        }
                      }}
                      className="w-full px-3 py-2 bg-white border border-blue-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                      <option value="">-- Pilih Mitra --</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} {p.detail ? `(${p.detail})` : ''} - {p.homeBase || 'Lokal'}
                        </option>
                      ))}
                    </select>
                    {selectedPartner && (
                      <div className="text-[11px] text-blue-800 bg-white px-2.5 py-1.5 rounded-lg border border-blue-100 flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span className="truncate">
                          PIC: <strong>{selectedPartner.contactPerson || '-'}</strong> | Telp: {selectedPartner.phone || '-'}
                        </span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    Belum ada mitra bisnis tersimpan. Anda dapat mendaftarkan mitra di menu <strong>Mitra Bisnis</strong>.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Hotel Rooms Repeater */}
          <div className="p-4 border border-blue-200 bg-blue-50/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                <Hotel className="w-4 h-4 text-blue-600" />
                2. Item Kamar Hotel (Glamping / Tenda)
              </h4>
              <button
                type="button"
                onClick={handleAddRoom}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                Tambah Kamar
              </button>
            </div>

            {rooms.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">Belum ada kamar hotel ditambahkan ke order ini.</p>
            ) : (
              <div className="space-y-2.5">
                {rooms.map((room, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-white border border-blue-100 rounded-xl grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end text-xs"
                  >
                    <div className="sm:col-span-3">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Tipe Kamar</label>
                      <select
                        value={room.roomType}
                        onChange={(e) => handleRoomChange(idx, 'roomType', e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800"
                      >
                        {DEFAULT_ROOM_TYPES.map((rt) => (
                          <option key={rt.name} value={rt.name}>
                            {rt.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Check-In</label>
                      <input
                        type="date"
                        value={room.checkInDate || date}
                        onChange={(e) => handleRoomChange(idx, 'checkInDate', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Check-Out</label>
                      <input
                        type="date"
                        value={room.checkOutDate || date}
                        onChange={(e) => handleRoomChange(idx, 'checkOutDate', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>

                    <div className="sm:col-span-1">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Jumlah</label>
                      <input
                        type="number"
                        min="1"
                        value={room.roomQty || 1}
                        onChange={(e) => handleRoomChange(idx, 'roomQty', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-center font-bold"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Harga / Malam</label>
                      <input
                        type="number"
                        step="1000"
                        value={room.roomPrice || 0}
                        onChange={(e) => handleRoomChange(idx, 'roomPrice', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-right font-bold text-slate-900"
                      />
                    </div>

                    <div className="sm:col-span-2 flex items-center justify-between gap-1">
                      <div>
                        <div className="text-[10px] text-slate-400">Total</div>
                        <div className="font-extrabold text-blue-700">
                          {formatRupiah((room.roomQty || 1) * (room.roomPrice || 0) * (room.nights || 1))}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveRoom(idx)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}

                {/* Include Breakfast Option */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 mt-2 border-t border-blue-200/70">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={includeBreakfast}
                      onChange={(e) => setIncludeBreakfast(e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded-sm border-slate-300 focus:ring-blue-500 cursor-pointer"
                    />
                    <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                      <Utensils className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Termasuk Sarapan (Include Breakfast)</span>
                    </span>
                  </label>

                  {includeBreakfast && (
                    <div className="flex items-center gap-2 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 text-xs">
                      <span className="font-semibold text-emerald-800">Porsi / Malam:</span>
                      <input
                        type="number"
                        min={1}
                        max={99}
                        value={breakfastPaxPerNight}
                        onChange={(e) => setBreakfastPaxPerNight(Math.max(1, parseInt(e.target.value, 10) || 1))}
                        className="w-14 px-2 py-0.5 bg-white border border-emerald-300 rounded text-center font-bold text-emerald-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      />
                      <span className="text-[11px] text-emerald-700 font-medium">Pax</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Section 3: ATV Tracks Repeater */}
          <div className="p-4 border border-orange-200 bg-orange-50/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-orange-900 uppercase tracking-wider flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-orange-600" />
                3. Item Wahana ATV
              </h4>
              <button
                type="button"
                onClick={handleAddTrack}
                className="px-2.5 py-1 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                Tambah Track ATV
              </button>
            </div>

            {tracks.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">Belum ada wahana ATV ditambahkan ke order ini.</p>
            ) : (
              <div className="space-y-2.5">
                {tracks.map((track, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-white border border-orange-100 rounded-xl grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end text-xs"
                  >
                    <div className="sm:col-span-3">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Jenis Track ATV</label>
                      <select
                        value={track.trackType}
                        onChange={(e) => handleTrackChange(idx, 'trackType', e.target.value)}
                        className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800"
                      >
                        {atvOptions.map((t) => (
                          <option key={t.name} value={t.name}>
                            {t.name} — {formatRupiah(t.defaultPrice)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-orange-500" />
                        Tgl Main
                      </label>
                      <input
                        type="date"
                        value={track.bookingDate || date}
                        onChange={(e) => handleTrackChange(idx, 'bookingDate' as any, e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Jumlah Unit</label>
                      <input
                        type="number"
                        min="1"
                        value={track.qty || 1}
                        onChange={(e) => handleTrackChange(idx, 'qty', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-center font-bold"
                      />
                    </div>

                    <div className="sm:col-span-3">
                      <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Harga Unit</label>
                      <input
                        type="number"
                        step="1000"
                        value={track.price || 0}
                        onChange={(e) => handleTrackChange(idx, 'price', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-right font-bold text-slate-900"
                      />
                    </div>

                    <div className="sm:col-span-2 flex items-center justify-between gap-1">
                      <div>
                        <div className="text-[10px] text-slate-400">Total</div>
                        <div className="font-extrabold text-orange-700">
                          {formatRupiah((track.qty || 1) * (track.price || 0))}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveTrack(idx)}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 4: Extra Income Items Repeater */}
          <div className="p-4 border border-amber-200 bg-amber-50/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                <Coins className="w-4 h-4 text-amber-600" />
                4. Pendapatan Tambahan / Layanan Extra
              </h4>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setShowCatalogGrid((v) => !v)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-xs ${
                    showCatalogGrid
                      ? 'bg-amber-700 text-white'
                      : 'bg-amber-600 hover:bg-amber-700 text-white'
                  }`}
                >
                  <Package className="w-3.5 h-3.5" />
                  {showCatalogGrid ? 'Tutup Katalog' : 'Pilih dari Katalog'}
                </button>
                <button
                  type="button"
                  onClick={handleAddExtraItem}
                  className="px-2.5 py-1 bg-slate-700 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Manual (Ad-hoc)
                </button>
              </div>
            </div>

            <p className="text-[11px] text-amber-800/70 -mt-1">
              Klik <strong>Pilih dari Katalog</strong> untuk tambah layanan dengan harga &amp; HPP
              otomatis. Pakai <strong>Manual</strong> untuk item ad-hoc &mdash; wajib isi rincian
              modal.
            </p>

            {/* Grid Katalog — expandable */}
            {showCatalogGrid && (
              <div className="bg-white border border-amber-200 rounded-xl p-3 space-y-2.5">
                <div className="flex items-center gap-2">
                  <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <input
                    type="text"
                    placeholder="Cari di katalog…"
                    value={catalogGridSearch}
                    onChange={(e) => setCatalogGridSearch(e.target.value)}
                    className="flex-1 px-2 py-1 border border-slate-200 rounded text-xs focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[11px] text-slate-500">
                    {catalogList.length} item
                  </span>
                </div>

                {catalogList.length === 0 ? (
                  <p className="text-[11px] text-slate-500 italic text-center py-3">
                    Katalog kosong. Buat item katalog dulu di menu{' '}
                    <strong>Pendapatan Tambahan → Katalog</strong>.
                  </p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 max-h-56 overflow-y-auto">
                    {catalogList
                      .filter((c) => {
                        const q = catalogGridSearch.trim().toLowerCase();
                        return (
                          !q ||
                          c.name.toLowerCase().includes(q) ||
                          (c.category || '').toLowerCase().includes(q)
                        );
                      })
                      .map((c) => {
                        const hpp = (c.defaultCostBreakdown || []).reduce(
                          (s, b) =>
                            s + (Number(b.amount) || (Number(b.qty) || 0) * (Number(b.unitPrice) || 0)),
                          0,
                        );
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => handleQuickAddFromCatalog(c)}
                            className="group text-left bg-slate-50 hover:bg-amber-100 border border-slate-200 hover:border-amber-400 rounded-lg p-2 transition-all"
                          >
                            <div className="text-[11px] font-bold text-slate-800 line-clamp-1 group-hover:text-amber-900">
                              {c.name}
                            </div>
                            <div className="text-[10px] text-slate-500 mb-1">
                              {c.category || 'Lainnya'}
                            </div>
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-[11px] font-bold text-amber-700">
                                {c.defaultSellingPrice
                                  ? formatRupiah(c.defaultSellingPrice)
                                  : '—'}
                              </span>
                              {hpp > 0 && (
                                <span className="text-[9px] text-rose-600">
                                  hpp {formatRupiah(hpp)}
                                </span>
                              )}
                            </div>
                          </button>
                        );
                      })}
                  </div>
                )}
                <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                  Klik item untuk tambah ke order (bisa klik beberapa kali). Qty default 1 &mdash; edit di baris di bawah.
                </p>
              </div>
            )}

            {extraItems.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">Belum ada pendapatan extra/makanan ditambahkan.</p>
            ) : (
              <div className="space-y-2.5">
                {extraItems.map((item, idx) => {
                  const filteredCatalog = (item._catalogSearch || '').trim()
                    ? catalogList.filter((c) =>
                        (c.name + ' ' + (c.category || ''))
                          .toLowerCase()
                          .includes((item._catalogSearch || '').toLowerCase()),
                      )
                    : catalogList;
                  const selectedCat = item.catalogId ? catalogList.find((c) => c.id === item.catalogId) : null;
                  return (
                    <div
                      key={item.id}
                      className="p-3 bg-white border border-amber-100 rounded-xl space-y-2.5 text-xs"
                    >
                      {/* Baris 1: Katalog picker */}
                      <div className="flex items-start gap-2 pb-2 border-b border-amber-50">
                        <div className="flex-1 relative">
                          <label className="block text-[11px] font-semibold text-amber-800 mb-0.5 flex items-center gap-1">
                            <Package className="w-3 h-3" />
                            Pilih dari Katalog Layanan Extra
                            {selectedCat && (
                              <span className="ml-1 px-1.5 py-0.5 bg-emerald-100 text-emerald-700 rounded text-[9px] font-bold">
                                KATALOG
                              </span>
                            )}
                          </label>
                          <div className="flex gap-1.5">
                            <div className="relative flex-1">
                              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400 pointer-events-none" />
                              <input
                                type="text"
                                placeholder={selectedCat ? selectedCat.name : 'Cari layanan di katalog…'}
                                value={item._catalogSearch || ''}
                                onFocus={() => handleExtraItemChange(idx, '_catalogOpen', true)}
                                onChange={(e) => {
                                  handleExtraItemChange(idx, '_catalogSearch', e.target.value);
                                  handleExtraItemChange(idx, '_catalogOpen', true);
                                }}
                                className="w-full pl-7 pr-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                              />
                              {item._catalogOpen && (
                                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-amber-200 rounded-lg shadow-lg max-h-56 overflow-y-auto">
                                  {filteredCatalog.length === 0 ? (
                                    <div className="p-2 text-[11px] text-slate-500 italic">
                                      Katalog kosong. Tambahkan di modul <strong>Pendapatan Tambahan &rarr; Katalog</strong>.
                                    </div>
                                  ) : (
                                    filteredCatalog.slice(0, 50).map((c) => (
                                      <button
                                        key={c.id}
                                        type="button"
                                        onClick={() => handleSelectCatalogForRow(idx, c.id)}
                                        className="w-full px-2.5 py-1.5 text-left hover:bg-amber-50 border-b border-slate-50 flex items-center justify-between gap-2"
                                      >
                                        <span className="flex-1 min-w-0">
                                          <span className="block font-semibold text-slate-800 truncate">{c.name}</span>
                                          <span className="block text-[10px] text-slate-500">
                                            {c.category || 'Lainnya'}
                                            {c.defaultCostBreakdown?.length ? ` · ${c.defaultCostBreakdown.length} komponen modal` : ''}
                                          </span>
                                        </span>
                                        {c.defaultSellingPrice ? (
                                          <span className="text-[11px] font-bold text-amber-700 whitespace-nowrap">
                                            {formatRupiah(c.defaultSellingPrice)}
                                          </span>
                                        ) : null}
                                      </button>
                                    ))
                                  )}
                                </div>
                              )}
                            </div>
                            {item._catalogOpen && (
                              <button
                                type="button"
                                onClick={() => handleExtraItemChange(idx, '_catalogOpen', false)}
                                className="px-2 py-1.5 text-[11px] text-slate-500 hover:bg-slate-50 rounded-lg border border-slate-200"
                              >
                                Tutup
                              </button>
                            )}
                            {item.catalogId && (
                              <button
                                type="button"
                                title="Lepas dari katalog (jadi manual)"
                                onClick={() => {
                                  handleExtraItemChange(idx, '_catalogSearch', '');
                                  setExtraItems((prev) => {
                                    const copy = [...prev];
                                    copy[idx] = { ...copy[idx], catalogId: undefined };
                                    return copy;
                                  });
                                }}
                                className="px-2 py-1.5 text-[11px] text-rose-600 hover:bg-rose-50 rounded-lg border border-rose-200"
                              >
                                Lepas
                              </button>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Baris 2: Data item */}
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
                        <div className="sm:col-span-3">
                          <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Kategori</label>
                          <input
                            type="text"
                            placeholder="F&B / API Unggun / BBQ"
                            value={item.category}
                            onChange={(e) => handleExtraItemChange(idx, 'category', e.target.value)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>

                        <div className="sm:col-span-4">
                          <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Deskripsi Item</label>
                          <input
                            type="text"
                            placeholder="Contoh: Paket BBQ 4 Pax"
                            value={item.description}
                            onChange={(e) => handleExtraItemChange(idx, 'description', e.target.value)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>

                        <div className="sm:col-span-1">
                          <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Qty</label>
                          <input
                            type="number"
                            min="1"
                            value={item.qty || 1}
                            onChange={(e) => handleExtraItemChange(idx, 'qty', e.target.value)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-center font-bold"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Harga Jual / unit</label>
                          <input
                            type="number"
                            step="1000"
                            value={item.unitPrice || 0}
                            onChange={(e) => handleExtraItemChange(idx, 'unitPrice', e.target.value)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-xs text-right font-bold text-slate-900"
                          />
                        </div>

                        <div className="sm:col-span-2 flex items-center justify-between gap-1">
                          <div>
                            <div className="text-[10px] text-slate-400">Total Jual</div>
                            <div className="font-extrabold text-amber-700">
                              {formatRupiah(item.total)}
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveExtraItem(idx)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Baris 3: HPP ringkas + toggle breakdown */}
                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-50">
                        <div className="flex items-center gap-1.5">
                          <TrendingDown className="w-3.5 h-3.5 text-rose-500" />
                          <span className="text-[11px] font-semibold text-slate-600">HPP / unit:</span>
                          <input
                            type="number"
                            step="1000"
                            value={item.hpp || 0}
                            onChange={(e) => handleExtraItemChange(idx, 'hpp', e.target.value)}
                            disabled={item.costBreakdown.length > 0}
                            title={item.costBreakdown.length > 0 ? 'HPP dihitung dari rincian modal' : ''}
                            className="w-24 px-2 py-1 border border-slate-200 rounded text-[11px] text-right font-bold text-slate-900 disabled:bg-slate-50 disabled:text-slate-500"
                          />
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Total HPP: <span className="font-bold text-rose-700">{formatRupiah(item.totalHpp)}</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Laba:{' '}
                          <span className={`font-bold ${item.labaBersih >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                            {formatRupiah(item.labaBersih)}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleExtraItemChange(idx, '_showBreakdown', !item._showBreakdown)}
                          className="ml-auto text-[11px] text-slate-600 hover:text-amber-700 flex items-center gap-1 font-semibold"
                        >
                          {item._showBreakdown ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          Rincian Modal{item.costBreakdown.length > 0 ? ` (${item.costBreakdown.length})` : ''}
                        </button>
                      </div>

                      {/* Baris 4: Rincian Modal (collapsible) */}
                      {item._showBreakdown && (
                        <div className="bg-slate-50/70 border border-slate-200 rounded-lg p-2.5 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                              Rincian Biaya Modal &amp; Pengurangan Stok
                            </div>
                            <button
                              type="button"
                              onClick={() => handleAddCostRow(idx)}
                              className="px-2 py-0.5 text-[10px] font-bold bg-slate-800 text-white rounded hover:bg-slate-900 flex items-center gap-1"
                            >
                              <Plus className="w-3 h-3" /> Komponen
                            </button>
                          </div>
                          {item.costBreakdown.length === 0 ? (
                            <p className="text-[11px] text-slate-400 italic">
                              Belum ada rincian. Kalau ambil dari stok, pilih item inventory. Kalau beli di luar, isi label &amp; harga modal saja.
                            </p>
                          ) : (
                            <div className="space-y-1.5">
                              {item.costBreakdown.map((cost, cIdx) => (
                                <div key={cost.id} className="grid grid-cols-12 gap-1.5 items-center">
                                  <select
                                    value={cost.inventoryItemId || ''}
                                    onChange={(e) =>
                                      handleCostRowChange(idx, cIdx, 'inventoryItemId', e.target.value)
                                    }
                                    className="col-span-3 px-1.5 py-1 border border-slate-200 rounded text-[11px] bg-white"
                                  >
                                    <option value="">— Beli di luar —</option>
                                    {inventoryList.map((inv) => (
                                      <option key={inv.id} value={inv.id}>
                                        {inv.name} (stok: {inv.stock})
                                      </option>
                                    ))}
                                  </select>
                                  <input
                                    type="text"
                                    placeholder="Label"
                                    value={cost.label}
                                    onChange={(e) => handleCostRowChange(idx, cIdx, 'label', e.target.value)}
                                    className="col-span-4 px-1.5 py-1 border border-slate-200 rounded text-[11px]"
                                  />
                                  <input
                                    type="number"
                                    min="0"
                                    placeholder="Qty"
                                    value={cost.qty || 0}
                                    onChange={(e) => handleCostRowChange(idx, cIdx, 'qty', e.target.value)}
                                    className="col-span-1 px-1 py-1 border border-slate-200 rounded text-[11px] text-center"
                                  />
                                  <input
                                    type="number"
                                    step="500"
                                    placeholder="Modal/unit"
                                    value={cost.unitPrice || 0}
                                    onChange={(e) => handleCostRowChange(idx, cIdx, 'unitPrice', e.target.value)}
                                    className="col-span-2 px-1.5 py-1 border border-slate-200 rounded text-[11px] text-right"
                                  />
                                  <div className="col-span-1 text-[10px] text-right text-slate-700 font-bold">
                                    {formatRupiah(cost.amount)}
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveCostRow(idx, cIdx)}
                                    className="col-span-1 p-1 text-slate-400 hover:text-rose-600"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                          <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-200">
                            Komponen dengan <strong>item inventory</strong> akan otomatis mengurangi stok saat order disimpan. Komponen tanpa inventory (beli di luar) hanya dicatat sebagai modal.
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Section 5: Discounts & Financial Summary */}
          <div className="p-4 bg-slate-900 text-white rounded-xl space-y-4">
            <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Percent className="w-4 h-4 text-emerald-400" />
              5. Ringkasan Keuangan, Diskon & Pembayaran
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Tipe Diskon</label>
                <div className="grid grid-cols-2 gap-1 p-1 bg-slate-800 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setDiscountType('Nominal')}
                    className={`py-1 rounded-md font-bold text-xs ${
                      discountType === 'Nominal' ? 'bg-blue-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    Rp (Nominal)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiscountType('Persen')}
                    className={`py-1 rounded-md font-bold text-xs ${
                      discountType === 'Persen' ? 'bg-blue-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    % (Persen)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Nilai Diskon</label>
                <input
                  type="number"
                  value={discountValue}
                  onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg font-bold text-white text-right"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">Fee Agen / Komisi (Rp)</label>
                <input
                  type="number"
                  step="1000"
                  value={agentFee}
                  onChange={(e) => setAgentFee(Number(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg font-bold text-white text-right"
                />
              </div>
            </div>

            {/* Payment Fields */}
            <div className="pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* DP */}
              <div className="p-3 bg-slate-800/80 rounded-xl space-y-2">
                <div className="font-bold text-emerald-400 text-xs">Pembayaran DP (Uang Muka)</div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-400">Nominal DP (Rp)</label>
                    <input
                      type="number"
                      value={dp}
                      onChange={(e) => setDp(Number(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg font-bold text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Metode Bayar</label>
                    <select
                      value={dpMethod}
                      onChange={(e) => setDpMethod(e.target.value)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                    >
                      {paymentMethods.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Pelunasan */}
              <div className="p-3 bg-slate-800/80 rounded-xl space-y-2">
                <div className="font-bold text-blue-400 text-xs flex items-center justify-between">
                  <span>Pelunasan</span>
                  {remaining > 0 && (
                    <button
                      type="button"
                      onClick={() => setPelunasan(remaining)}
                      className="text-[10px] underline text-blue-300 hover:text-white cursor-pointer"
                    >
                      Lunasi Sisa ({formatRupiah(remaining)})
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-400">Nominal Pelunasan (Rp)</label>
                    <input
                      type="number"
                      value={pelunasan}
                      onChange={(e) => setPelunasan(Number(e.target.value) || 0)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg font-bold text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400">Metode Bayar</label>
                    <select
                      value={pelunasanMethod}
                      onChange={(e) => setPelunasanMethod(e.target.value)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                    >
                      {paymentMethods.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Subtotal Calculations Bar */}
            <div className="p-3 bg-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
              <div>
                <span className="text-slate-400">Subtotal:</span>{' '}
                <span className="font-bold text-white">{formatRupiah(subtotal)}</span>
              </div>
              <div>
                <span className="text-slate-400">Diskon:</span>{' '}
                <span className="font-bold text-rose-400">-{formatRupiah(discountAmount)}</span>
              </div>
              <div>
                <span className="text-slate-400">Grand Total:</span>{' '}
                <span className="font-extrabold text-blue-400 text-sm">{formatRupiah(grandTotal)}</span>
              </div>
              <div>
                <span className="text-slate-400">Total Dibayar:</span>{' '}
                <span className="font-bold text-emerald-400">{formatRupiah(totalPaid)}</span>
              </div>
              <div>
                <span className="text-slate-400">Sisa Tagihan:</span>{' '}
                <span className={`font-bold ${remaining > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {formatRupiah(remaining)}
                </span>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Catatan Tambahan (Opsional)</label>
            <textarea
              rows={2}
              placeholder="Catatan permintaan khusus tamu, instruksi penjemputan, dll."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer transition-colors shadow-md disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Menyimpan...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEditing ? 'Simpan Perubahan' : 'Simpan Order Gabungan'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
