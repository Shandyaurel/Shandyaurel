import React, { useState, useEffect, useMemo } from 'react';
import { CombinedOrder, BusinessSettings, FinancialDocument } from '../../types';
import {
  subscribeCombinedOrders,
  saveCombinedOrder,
  deleteCombinedOrder,
  deleteCombinedOrdersBatch,
  saveDocument,
  generateNextDocumentNumber,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateIndo } from '../../utils/formatters';
import { CombinedOrderModal } from './CombinedOrderModal';
import { Modal } from '../common/Modal';
import { TransactionQuickDocWAModal } from '../documents/TransactionQuickDocWAModal';
import {
  ShoppingBag,
  Plus,
  Search,
  Filter,
  FileText,
  Edit2,
  Trash2,
  Hotel,
  Compass,
  Coins,
  CheckCircle2,
  Clock,
  XCircle,
  Building,
  User,
  Calendar,
  AlertCircle,
  Sparkles,
} from 'lucide-react';

interface CombinedOrderViewProps {
  businessSettings?: BusinessSettings | null;
  onNavigateToDocumentEditor?: (initialDoc?: FinancialDocument) => void;
}

export const CombinedOrderView: React.FC<CombinedOrderViewProps> = ({
  businessSettings,
  onNavigateToDocumentEditor,
}) => {
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();
  const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';

  const [orders, setOrders] = useState<CombinedOrder[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Selection for bulk delete
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState<boolean>(false);
  const [bulkDeleteReason, setBulkDeleteReason] = useState<string>('');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [orderToEdit, setOrderToEdit] = useState<CombinedOrder | null>(null);
  const [quickDocOrder, setQuickDocOrder] = useState<CombinedOrder | null>(null);
  const [orderToDelete, setOrderToDelete] = useState<CombinedOrder | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState<boolean>(false);

  useEffect(() => {
    setIsLoading(true);
    const unsub = subscribeCombinedOrders(
      (list) => {
        setOrders(list);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error fetching combined orders:', err);
        showError('Gagal memuat data order gabungan.');
        setIsLoading(false);
      },
    );
    return () => unsub();
  }, []);

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return orders.filter((ord) => {
      if (statusFilter !== 'ALL' && ord.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = ord.guestName.toLowerCase().includes(q);
        const matchNum = ord.orderNumber.toLowerCase().includes(q);
        const matchVia = (ord.bookingVia || '').toLowerCase().includes(q);
        const matchPhone = (ord.guestPhone || '').toLowerCase().includes(q);
        return matchName || matchNum || matchVia || matchPhone;
      }
      return true;
    });
  }, [orders, searchQuery, statusFilter]);

  // Summaries
  const totalOmzet = useMemo(
    () => orders.reduce((sum, o) => sum + (Number(o.grandTotal) || 0), 0),
    [orders],
  );

  const totalPaid = useMemo(
    () => orders.reduce((sum, o) => sum + (Number(o.dp || 0) + Number(o.pelunasan || 0)), 0),
    [orders],
  );

  const totalRemaining = Math.max(0, totalOmzet - totalPaid);

  const handleSaveOrder = async (data: Partial<CombinedOrder>): Promise<void> => {
    showSuccess('Order gabungan berhasil disimpan.');
    saveCombinedOrder(data, userEmail).catch((err) => {
      console.error('Error saving order:', err);
      showError('Gagal sinkron ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  const handleConfirmDelete = () => {
    if (!orderToDelete) return;
    const target = orderToDelete;
    const reason = deleteReason.trim();

    // Optimistic: langsung hilangkan barisnya, tutup modal & beri notif (terasa INSTAN)
    setOrders((prev) => prev.filter((o) => o.id !== target.id));
    setSelectedIds((prev) => prev.filter((id) => id !== target.id));
    setOrderToDelete(null);
    setDeleteReason('');
    showSuccess(`Order #${target.orderNumber} berhasil dihapus.`);

    // Hapus di server di latar belakang. Kalau GAGAL, kembalikan barisnya + tampilkan error.
    deleteCombinedOrder(target.id, reason, userEmail).catch((err) => {
      console.error('Error deleting order:', err);
      setOrders((prev) => (prev.some((o) => o.id === target.id) ? prev : [target, ...prev]));
      showError(
        'Gagal menghapus order: ' +
          (err instanceof Error ? err.message : 'Terjadi kesalahan koneksi ke server.'),
      );
    });
  };

  // Selection Helpers
  const isAllSelected = filteredOrders.length > 0 && selectedIds.length === filteredOrders.length;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredOrders.map((o) => o.id));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleOpenBulkDeleteModal = () => {
    if (selectedIds.length === 0) return;
    setBulkDeleteReason('');
    setIsBulkDeleteModalOpen(true);
  };

  const handleConfirmBulkDelete = () => {
    if (selectedIds.length === 0) return;
    const targetOrders = orders.filter((o) => selectedIds.includes(o.id));
    const targetIds = [...selectedIds];
    const count = targetIds.length;
    const reason = bulkDeleteReason.trim();

    // Optimistic: langsung hilangkan baris-barisnya, tutup modal & beri notif
    setOrders((prev) => prev.filter((o) => !targetIds.includes(o.id)));
    setSelectedIds([]);
    setIsBulkDeleteModalOpen(false);
    setBulkDeleteReason('');
    showSuccess(`${count} order gabungan berhasil dihapus.`);

    // Hapus massal di server di latar belakang. Kalau GAGAL, kembalikan baris + error.
    deleteCombinedOrdersBatch(targetOrders, userEmail, reason).catch((err) => {
      console.error('Error in batch delete combined orders:', err);
      setOrders((prev) => {
        const existing = new Set(prev.map((o) => o.id));
        const restored = targetOrders.filter((o) => !existing.has(o.id));
        return restored.length ? [...restored, ...prev] : prev;
      });
      showError(
        'Gagal menghapus massal order: ' +
          (err instanceof Error ? err.message : 'Terjadi kesalahan koneksi ke server.'),
      );
    });
  };

  // Buka shortcut Dokumen & Salin WhatsApp
  const handleCreateDocument = (order: CombinedOrder) => {
    setQuickDocOrder(order);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-600 text-white rounded-2xl shadow-md">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">Order Gabungan Transaksi</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Input 1 transaksi terpadu (Kamar Hotel + Wahana ATV + Pendapatan Extra) & buat dokumen gabungan
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setOrderToEdit(null);
            setIsModalOpen(true);
          }}
          className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Buat Order Gabungan</span>
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">Total Transaksi Gabungan</div>
            <div className="text-2xl font-extrabold text-slate-900 mt-1">{orders.length} Order</div>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <ShoppingBag className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">Total Omzet Order Gabungan</div>
            <div className="text-2xl font-extrabold text-blue-700 mt-1">{formatRupiah(totalOmzet)}</div>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <Coins className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">Sisa Tagihan Belum Lunas</div>
            <div className="text-2xl font-extrabold text-amber-600 mt-1">{formatRupiah(totalRemaining)}</div>
          </div>
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama tamu, no order, mitra..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-hidden focus:border-blue-600"
          />
        </div>

        <div className="flex items-center justify-between gap-2 overflow-x-auto w-full sm:w-auto">
          <div className="flex items-center gap-2">
            {['ALL', 'Scheduled', 'Confirmed', 'Check-in', 'Check-out', 'Cancelled'].map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs whitespace-nowrap cursor-pointer transition-colors ${
                  statusFilter === st
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st === 'ALL' ? 'Semua Status' : st}
              </button>
            ))}
          </div>

          {/* Bulk Delete button */}
          {selectedIds.length > 0 && (
            <button
              type="button"
              onClick={handleOpenBulkDeleteModal}
              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ml-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Terpilih ({selectedIds.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center">
            <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Memuat data order gabungan...</p>
          </div>
        ) : filteredOrders.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={toggleSelectAll}
                      aria-label="Pilih semua order gabungan"
                      className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer"
                    />
                  </th>
                  <th className="py-3 px-4">No & Tgl Order</th>
                  <th className="py-3 px-4">Nama Tamu & Sumber</th>
                  <th className="py-3 px-4">Rincian Paket & Item</th>
                  <th className="py-3 px-4 text-right">Grand Total</th>
                  <th className="py-3 px-4 text-center">Status Bayar</th>
                  <th className="py-3 px-4 text-center">Status Order</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredOrders.map((ord) => {
                  const totalPaid = (ord.dp || 0) + (ord.pelunasan || 0);
                  const isLunas = totalPaid >= ord.grandTotal;
                  const roomCount = ord.rooms?.length || 0;
                  const trackCount = ord.tracks?.length || 0;
                  const extraCount = ord.extraItems?.length || 0;
                  const isRowSelected = selectedIds.includes(ord.id);

                  return (
                    <tr
                      key={ord.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isRowSelected ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={isRowSelected}
                          onChange={() => toggleSelectRow(ord.id)}
                          aria-label={`Pilih order ${ord.orderNumber}`}
                          className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer"
                        />
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-extrabold text-blue-600">#{ord.orderNumber}</div>
                        <div className="text-[11px] text-slate-500">{formatDateIndo(ord.date)}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{ord.guestName}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Building className="w-3 h-3 text-slate-400" />
                          <span>{ord.bookingVia || 'Walk in'}</span>
                        </div>
                        {ord.guestPhone && (
                          <div className="text-[10px] text-slate-400 font-mono">{ord.guestPhone}</div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {roomCount > 0 && (
                            <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-bold rounded-md text-[10px] flex items-center gap-1 border border-blue-200">
                              <Hotel className="w-3 h-3" />
                              {roomCount} Kamar
                            </span>
                          )}
                          {trackCount > 0 && (
                            <span className="px-2 py-0.5 bg-orange-50 text-orange-700 font-bold rounded-md text-[10px] flex items-center gap-1 border border-orange-200">
                              <Compass className="w-3 h-3" />
                              {trackCount} ATV
                            </span>
                          )}
                          {extraCount > 0 && (
                            <span className="px-2 py-0.5 bg-amber-50 text-amber-700 font-bold rounded-md text-[10px] flex items-center gap-1 border border-amber-200">
                              <Coins className="w-3 h-3" />
                              {extraCount} Extra
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="text-sm font-extrabold text-slate-900">
                          {formatRupiah(ord.grandTotal)}
                        </div>
                        {ord.discountAmount > 0 && (
                          <div className="text-[10px] text-rose-500 font-medium">
                            Disc: -{formatRupiah(ord.discountAmount)}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-extrabold text-[10px] border ${
                            isLunas
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                              : ord.dp > 0
                              ? 'bg-amber-50 text-amber-700 border-amber-300'
                              : 'bg-rose-50 text-rose-700 border-rose-300'
                          }`}
                        >
                          {isLunas ? 'LUNAS' : ord.dp > 0 ? 'DP' : 'BELUM BAYAR'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <span className="px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-lg font-bold text-[11px]">
                          {ord.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Dokumen & WA Shortcut Button */}
                          <button
                            type="button"
                            title="Dokumen & Salin WhatsApp"
                            onClick={() => setQuickDocOrder(ord)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg font-bold text-[11px] flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Dokumen / WA</span>
                          </button>

                          <button
                            type="button"
                            title="Edit Order"
                            onClick={() => {
                              setOrderToEdit(ord);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            title="Hapus Order"
                            onClick={() => {
                              setOrderToDelete(ord);
                              setDeleteReason('');
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center">
            <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">Belum Ada Order Gabungan</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Klik "Buat Order Gabungan" untuk menginput transaksi kombinasi kamar hotel, wahana ATV, dan layanan tambahan sekaligus.
            </p>
          </div>
        )}
      </div>

      {/* Modal Add/Edit */}
      {isModalOpen && (
        <CombinedOrderModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          orderToEdit={orderToEdit}
          onSave={handleSaveOrder}
          businessSettings={businessSettings}
          onOpenQuickDoc={(ord) => setQuickDocOrder(ord)}
        />
      )}

      {/* Quick Action Modal: Dokumen & Salin WhatsApp */}
      {quickDocOrder && (
        <TransactionQuickDocWAModal
          isOpen={!!quickDocOrder}
          onClose={() => setQuickDocOrder(null)}
          transaction={quickDocOrder}
          moduleType="combined_order"
          businessSettings={businessSettings}
          onSavedToArchive={(savedDoc) => {
            if (onNavigateToDocumentEditor) {
              onNavigateToDocumentEditor(savedDoc);
            }
          }}
        />
      )}

      {/* Modal Single Delete */}
      <Modal
        isOpen={!!orderToDelete}
        onClose={() => setOrderToDelete(null)}
        title="Konfirmasi Hapus Order Gabungan"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus order gabungan <strong>#{orderToDelete?.orderNumber}</strong> ({orderToDelete?.guestName})?
            Tindakan ini juga akan menghapus/membatalkan entri kamar hotel dan ATV yang tertaut pada order ini.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Tamu membatalkan seluruh reservasi..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setOrderToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Order'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Modal Bulk Delete */}
      <Modal
        isOpen={isBulkDeleteModalOpen}
        onClose={() => setIsBulkDeleteModalOpen(false)}
        title="Konfirmasi Hapus Massal Order Gabungan"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Apakah Anda yakin ingin menghapus <strong>{selectedIds.length}</strong> order gabungan terpilih sekaligus?
            Tindakan ini juga akan membersihkan entri kamar dan wahana yang tertaut pada order-order ini.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan Massal (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Pembersihan data order massal..."
              value={bulkDeleteReason}
              onChange={(e) => setBulkDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsBulkDeleteModalOpen(false)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isBulkDeleting}
              onClick={handleConfirmBulkDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isBulkDeleting ? 'Menghapus...' : `Hapus ${selectedIds.length} Order Gabungan`}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
