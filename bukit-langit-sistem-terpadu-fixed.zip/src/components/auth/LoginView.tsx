import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Mail, Lock, Eye, EyeOff, LogIn, Compass, ShieldCheck, UserPlus } from 'lucide-react';
import { motion } from 'motion/react';
import { getStoredSettings } from '../../utils/storage';

export const LoginView: React.FC = () => {
  const { loginWithGoogle, loginWithEmail, registerWithEmail } = useAuth();
  const { showError, showSuccess } = useToast();

  const brand = getStoredSettings();

  const [isRegisterMode, setIsRegisterMode] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleGoogleSignIn = async () => {
    try {
      setIsSubmitting(true);
      await loginWithGoogle();
      showSuccess('Berhasil masuk ke sistem.');
    } catch (err: unknown) {
      const error = err as Error;
      console.error('Google Sign In Error:', error);
      if (error.message?.includes('popup-closed-by-user')) {
        showError('Jendela masuk Google ditutup sebelum selesai.');
      } else {
        showError('Gagal masuk dengan Google. Pastikan popup tidak diblokir browser.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      showError('Harap isi email dan kata sandi.');
      return;
    }

    if (password.length < 6) {
      showError('Kata sandi minimal 6 karakter.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (isRegisterMode) {
        await registerWithEmail(email.trim(), password);
        showSuccess('Akun berhasil didaftarkan.');
      } else {
        await loginWithEmail(email.trim(), password);
        showSuccess('Berhasil masuk.');
      }
    } catch (err: unknown) {
      const error = err as { code?: string; message?: string };
      console.error('Email Auth Error:', error);
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        showError('Email atau kata sandi tidak cocok.');
      } else if (error.code === 'auth/email-already-in-use') {
        showError('Email ini sudah terdaftar. Silakan pilih mode Masuk.');
      } else if (error.code === 'auth/weak-password') {
        showError('Kata sandi terlalu lemah. Gunakan minimal 6 karakter.');
      } else if (error.code === 'auth/operation-not-allowed') {
        showError('Autentikasi email belum diaktifkan di Firebase Console. Gunakan Google Sign In.');
      } else {
        showError('Terjadi kesalahan saat memproses login. Coba lagi.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="login-view-container"
      className="min-h-screen w-full bg-[#F8FAFC] flex flex-col justify-center items-center p-4 sm:p-6"
    >
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        id="login-card"
        className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8"
      >
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 shadow-xs border border-blue-100 overflow-hidden">
            {brand?.logoUrl ? (
              <img
                src={brand.logoUrl}
                alt={brand.businessName || 'Logo'}
                className="w-full h-full object-contain p-1 rounded-2xl"
              />
            ) : (
              <Compass className="w-7 h-7" />
            )}
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">{brand?.businessName || 'Bukit Langit'}</h1>
          <p className="text-sm text-slate-500 mt-1">
            Sistem Manajemen Terpadu & Layanan Operasional
          </p>
        </div>

        {/* Google Sign In Button */}
        <button
          id="google-signin-button"
          type="button"
          onClick={handleGoogleSignIn}
          disabled={isSubmitting}
          className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl border border-slate-200 bg-white text-slate-700 font-medium text-sm hover:bg-slate-50 hover:border-slate-300 transition-all shadow-xs disabled:opacity-50"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span>Masuk dengan Google</span>
        </button>

        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200" />
          </div>
          <span className="relative bg-white px-3 text-xs text-slate-400 uppercase tracking-wider font-medium">
            atau gunakan email
          </span>
        </div>

        {/* Email / Password Form */}
        <form onSubmit={handleEmailSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="login-email">
              Alamat Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@bukitlangit.id"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:border-blue-600 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5" htmlFor="login-password">
              Kata Sandi
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:border-blue-600 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 rounded-md"
                aria-label={showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            id="login-submit-button"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm rounded-lg transition-colors shadow-xs flex items-center justify-center gap-2 mt-2 disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : isRegisterMode ? (
              <>
                <UserPlus className="w-4 h-4" />
                <span>Daftar Akun Baru</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Masuk ke Dashboard</span>
              </>
            )}
          </button>
        </form>

        {/* Toggle Mode */}
        <div className="mt-6 pt-4 border-t border-slate-100 text-center">
          <button
            type="button"
            onClick={() => setIsRegisterMode(!isRegisterMode)}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium transition-colors"
          >
            {isRegisterMode
              ? 'Sudah memiliki akun? Masuk di sini'
              : 'Belum memiliki akun? Daftar akun baru'}
          </button>
        </div>

        {/* Security & Access Info */}
        <div className="mt-6 p-3.5 bg-slate-50 rounded-xl border border-slate-100 flex items-start gap-2.5 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <span>
            Hanya email yang telah terdaftar dalam daftar izin sistem (Allowlist) atau Administrator Utama yang dapat mengakses modul data.
          </span>
        </div>
      </motion.div>
    </div>
  );
};
