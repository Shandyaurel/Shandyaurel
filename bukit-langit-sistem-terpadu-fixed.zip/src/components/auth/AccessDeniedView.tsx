import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { ShieldAlert, LogOut, Mail, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

export const AccessDeniedView: React.FC = () => {
  const { currentUser, logout } = useAuth();

  return (
    <div
      id="access-denied-container"
      className="min-h-screen w-full bg-[#F8FAFC] flex flex-col justify-center items-center p-4 sm:p-6"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.25 }}
        id="access-denied-card"
        className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 text-center"
      >
        <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-4 border border-amber-100">
          <ShieldAlert className="w-7 h-7" />
        </div>

        <h2 className="text-xl font-bold text-slate-900 mb-2">Akses Belum Diizinkan</h2>
        <p className="text-sm text-slate-600 leading-relaxed mb-6">
          Akun Anda telah berhasil diautentikasi, namun alamat email ini belum terdaftar di dalam daftar pengguna yang diizinkan (Allowlist) sistem Bukit Langit.
        </p>

        {currentUser?.email && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 mb-6 text-left flex items-center gap-3">
            <Mail className="w-4 h-4 text-slate-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-xs text-slate-400 block font-medium">Email login saat ini</span>
              <span className="text-sm font-semibold text-slate-800 truncate block">
                {currentUser.email}
              </span>
            </div>
          </div>
        )}

        <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-4 text-left mb-6 text-xs text-slate-600 flex items-start gap-2.5">
          <HelpCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p>
            Untuk mendapatkan hak akses, silakan hubungi Administrator Sistem Bukit Langit agar email Anda dapat ditambahkan ke daftar izin operasional.
          </p>
        </div>

        <button
          id="access-denied-logout-button"
          type="button"
          onClick={() => logout()}
          className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm rounded-lg transition-colors shadow-xs flex items-center justify-center gap-2 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Keluar & Ganti Akun</span>
        </button>
      </motion.div>
    </div>
  );
};
