import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { getBusinessSettings, saveBusinessSettings } from '../../utils/firebase';
import { DEFAULT_SETTINGS } from '../../utils/storage';
import type { BusinessSettings, BankAccount, KlausulKontrakItem, RoomRateItem } from '../../types';
import {
  Settings,
  Save,
  Building2,
  CreditCard,
  FileText,
  Plus,
  Trash2,
  Loader2,
  Hotel,
  PenLine,
} from 'lucide-react';
import { motion } from 'motion/react';

type SettingsTab = 'business' | 'bank' | 'rooms' | 'documents';

export const BusinessSettingsView: React.FC = () => {
  const { isAdmin } = useAuth();
  const { showSuccess, showError } = useToast();
  const [settings, setSettings] = useState<BusinessSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<SettingsTab>('business');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const s = await getBusinessSettings();
      if (s) setSettings({ ...DEFAULT_SETTINGS, ...s });
    } catch (err) {
      showError('Gagal memuat pengaturan.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveBusinessSettings(settings);
      showSuccess('Pengaturan berhasil disimpan!');
    } catch (err) {
      showError('Gagal menyimpan pengaturan.');
    } finally {
      setSaving(false);
    }
  };

  const updateField = <K extends keyof BusinessSettings>(key: K, value: BusinessSettings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const updateBankAccount = (index: number, field: keyof BankAccount, value: string) => {
    const banks = [...(settings.bankAccounts || [])];
    banks[index] = { ...banks[index], [field]: value };
    updateField('bankAccounts', banks);
  };

  const addBankAccount = () => {
    updateField('bankAccounts', [
      ...(settings.bankAccounts || []),
      { bankName: '', accountNumber: '', accountName: '' },
    ]);
  };

  const removeBankAccount = (index: number) => {
    const banks = [...(settings.bankAccounts || [])];
    banks.splice(index, 1);
    updateField('bankAccounts', banks);
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-500">
        <Settings className="w-6 h-6 mr-2" />
        Hanya admin yang dapat mengakses pengaturan.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  const tabs: { key: SettingsTab; label: string; icon: React.ReactNode }[] = [
    { key: 'business', label: 'Bisnis', icon: <Building2 className="w-4 h-4" /> },
    { key: 'bank', label: 'Rekening Bank', icon: <CreditCard className="w-4 h-4" /> },
    { key: 'rooms', label: 'Kamar & Tarif', icon: <Hotel className="w-4 h-4" /> },
    { key: 'documents', label: 'Dokumen', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-100 rounded-xl">
            <Settings className="w-5 h-5 text-emerald-700" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Pengaturan Bisnis</h2>
            <p className="text-xs text-slate-500">Kelola informasi dan konfigurasi bisnis Anda</p>
          </div>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50 text-sm font-medium"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Simpan
        </button>
      </div>

      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all flex-1 justify-center ${
              activeTab === tab.key
                ? 'bg-white text-emerald-700 shadow-sm'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl border border-slate-200 p-6"
      >
        {activeTab === 'business' && (
          <div className="space-y-4">
            <InputField label="Nama Bisnis" value={settings.businessName || ''} onChange={(v) => updateField('businessName', v)} />
            <InputField label="Tagline" value={settings.tagline || ''} onChange={(v) => updateField('tagline', v)} />
            <InputField label="Alamat" value={settings.address || ''} onChange={(v) => updateField('address', v)} multiline />
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Telepon / WA" value={settings.phone || ''} onChange={(v) => updateField('phone', v)} />
              <InputField label="Email" value={settings.email || ''} onChange={(v) => updateField('email', v)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Website" value={settings.website || ''} onChange={(v) => updateField('website', v)} />
              <InputField label="NPWP" value={settings.npwp || ''} onChange={(v) => updateField('npwp', v)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <InputField label="Nama Penandatangan" value={settings.signatory?.name || ''} onChange={(v) => updateField('signatory', { ...settings.signatory, name: v, title: settings.signatory?.title || '' })} />
              <InputField label="Jabatan" value={settings.signatory?.title || ''} onChange={(v) => updateField('signatory', { ...settings.signatory, title: v, name: settings.signatory?.name || '' })} />
            </div>
            <InputField label="URL Logo" value={settings.logoUrl || ''} onChange={(v) => updateField('logoUrl', v)} placeholder="https://..." />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Tarif Pajak Default (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={settings.defaultTaxRate || 0}
                  onChange={(e) => updateField('defaultTaxRate', Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Harga Breakfast / Pax (Rp)</label>
                <input
                  type="number"
                  min={0}
                  value={settings.breakfastPricePerPax || 0}
                  onChange={(e) => updateField('breakfastPricePerPax', Number(e.target.value))}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'bank' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-slate-700">Rekening Bank</h3>
              <button onClick={addBankAccount} className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
                <Plus className="w-4 h-4" /> Tambah Rekening
              </button>
            </div>
            {(settings.bankAccounts || []).map((bank, i) => (
              <div key={i} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-slate-600">Rekening #{i + 1}</span>
                  <button onClick={() => removeBankAccount(i)} className="text-red-400 hover:text-red-600">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <input
                    placeholder="Nama Bank"
                    value={bank.bankName}
                    onChange={(e) => updateBankAccount(i, 'bankName', e.target.value)}
                    className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                  <input
                    placeholder="No. Rekening"
                    value={bank.accountNumber}
                    onChange={(e) => updateBankAccount(i, 'accountNumber', e.target.value)}
                    className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                  <input
                    placeholder="Atas Nama"
                    value={bank.accountName}
                    onChange={(e) => updateBankAccount(i, 'accountName', e.target.value)}
                    className="px-3 py-2 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>
            ))}
            {(!settings.bankAccounts || settings.bankAccounts.length === 0) && (
              <p className="text-center text-slate-400 text-sm py-8">Belum ada rekening bank. Klik "Tambah Rekening" untuk menambahkan.</p>
            )}
          </div>
        )}

        {activeTab === 'rooms' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-slate-700">Tipe Kamar & Tarif Default</h3>
              <button
                onClick={() => {
                  const rates = [...(settings.defaultRoomRates || [])];
                  rates.push({ roomType: '', code: '', price: 0, inclusions: '', maxGuest: 2 });
                  updateField('defaultRoomRates', rates);
                }}
                className="flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium"
              >
                <Plus className="w-4 h-4" /> Tambah Kamar
              </button>
            </div>
            {(settings.defaultRoomRates || []).map((room: RoomRateItem, i: number) => (
              <div key={i} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-slate-600">{room.roomType || `Kamar #${i + 1}`}</span>
                  <button
                    onClick={() => {
                      const rates = [...(settings.defaultRoomRates || [])];
                      rates.splice(i, 1);
                      updateField('defaultRoomRates', rates);
                    }}
                    className="text-red-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  <input placeholder="Tipe Kamar" value={room.roomType || ''} onChange={(e) => { const r = [...(settings.defaultRoomRates || [])]; r[i] = { ...r[i], roomType: e.target.value }; updateField('defaultRoomRates', r); }} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  <input placeholder="Kode" value={room.code || ''} onChange={(e) => { const r = [...(settings.defaultRoomRates || [])]; r[i] = { ...r[i], code: e.target.value }; updateField('defaultRoomRates', r); }} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  <input placeholder="Harga" type="number" value={room.price || 0} onChange={(e) => { const r = [...(settings.defaultRoomRates || [])]; r[i] = { ...r[i], price: Number(e.target.value) }; updateField('defaultRoomRates', r); }} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                  <input placeholder="Max Tamu" type="number" value={room.maxGuest || 2} onChange={(e) => { const r = [...(settings.defaultRoomRates || [])]; r[i] = { ...r[i], maxGuest: Number(e.target.value) }; updateField('defaultRoomRates', r); }} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
                </div>
                <input placeholder="Inklusif (contoh: Breakfast 2 pax, Wi-Fi)" value={room.inclusions || ''} onChange={(e) => { const r = [...(settings.defaultRoomRates || [])]; r[i] = { ...r[i], inclusions: e.target.value }; updateField('defaultRoomRates', r); }} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm" />
              </div>
            ))}
          </div>
        )}

        {activeTab === 'documents' && (
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-700 mb-2">Pengaturan Dokumen</h3>
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
              <input
                type="checkbox"
                checked={settings.defaultBreakfastIncluded ?? true}
                onChange={(e) => updateField('defaultBreakfastIncluded', e.target.checked)}
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <label className="text-sm text-slate-700">Default: Sarapan termasuk dalam harga kamar</label>
            </div>
            <InputField label="Prefix Nomor Invoice" value={settings.invoicePrefix || 'INV'} onChange={(v) => updateField('invoicePrefix', v)} />
            <InputField label="Prefix Nomor Kwitansi" value={settings.receiptPrefix || 'KWT'} onChange={(v) => updateField('receiptPrefix', v)} />
          </div>
        )}
      </motion.div>
    </div>
  );
};

const InputField: React.FC<{
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  multiline?: boolean;
}> = ({ label, value, onChange, placeholder, multiline }) => (
  <div>
    <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
    {multiline ? (
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={3}
        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 resize-none"
      />
    ) : (
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
      />
    )}
  </div>
);
