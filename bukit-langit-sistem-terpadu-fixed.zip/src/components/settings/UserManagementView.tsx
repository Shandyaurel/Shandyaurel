import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import type { UserProfile, NavigationModuleKey } from '../../types';
import {
  collection,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
} from 'firebase/firestore';
import { db } from '../../utils/firebase';
import {
  Users,
  Shield,
  ShieldCheck,
  UserCog,
  Trash2,
  Loader2,
  Search,
  Check,
  X,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const ALL_MODULE_KEYS: { key: NavigationModuleKey; label: string; group: string }[] = [
  { key: 'hotel', label: 'Hotel Booking', group: 'Operasional' },
  { key: 'atv', label: 'ATV Booking', group: 'Operasional' },
  { key: 'breakfast', label: 'Breakfast', group: 'Operasional' },
  { key: 'extra_income', label: 'Extra Income', group: 'Operasional' },
  { key: 'calendar', label: 'Kalender', group: 'Operasional' },
  { key: 'combined_orders', label: 'Combined Orders', group: 'Operasional' },
  { key: 'rundown', label: 'Rundown', group: 'Operasional' },
  { key: 'documents', label: 'Dokumen', group: 'Dokumen & CRM' },
  { key: 'partners', label: 'Partner / CRM', group: 'Dokumen & CRM' },
  { key: 'leads', label: 'Leads', group: 'Dokumen & CRM' },
  { key: 'quotations', label: 'Quotation', group: 'Dokumen & CRM' },
  { key: 'dashboard', label: 'Dashboard', group: 'Analitik' },
  { key: 'agent_fees', label: 'Agent Fees', group: 'Tambahan' },
  { key: 'inventory', label: 'Inventory', group: 'Tambahan' },
  { key: 'influencers', label: 'Influencer', group: 'Tambahan' },
  { key: 'offer_packages', label: 'Offer Packages', group: 'Tambahan' },
  { key: 'system_logs', label: 'System Logs', group: 'Pengaturan' },
  { key: 'settings', label: 'Pengaturan', group: 'Pengaturan' },
  { key: 'user_management', label: 'User Management', group: 'Pengaturan' },
];

export const UserManagementView: React.FC = () => {
  const { isAdmin, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [expandedUser, setExpandedUser] = useState<string | null>(null);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const q = query(collection(db, 'users'), orderBy('displayName'));
      const snap = await getDocs(q);
      const list = snap.docs.map((d) => ({ uid: d.id, ...d.data() })) as UserProfile[];
      setUsers(list);
    } catch (err) {
      showError('Gagal memuat daftar pengguna.');
    } finally {
      setLoading(false);
    }
  };

  const toggleRole = async (user: UserProfile) => {
    if (user.uid === currentUser?.uid) {
      showError('Tidak dapat mengubah role sendiri.');
      return;
    }
    try {
      const newRole = user.role === 'admin' ? 'staff' : 'admin';
      await updateDoc(doc(db, 'users', user.uid), { role: newRole });
      setUsers((prev) => prev.map((u) => (u.uid === user.uid ? { ...u, role: newRole } : u)));
      showSuccess(`Role ${user.displayName} diubah ke ${newRole}.`);
    } catch {
      showError('Gagal mengubah role.');
    }
  };

  const togglePermission = async (user: UserProfile, key: NavigationModuleKey) => {
    const current = user.allowedModules || [];
    const updated = current.includes(key)
      ? current.filter((k) => k !== key)
      : [...current, key];
    try {
      await updateDoc(doc(db, 'users', user.uid), { allowedModules: updated });
      setUsers((prev) =>
        prev.map((u) => (u.uid === user.uid ? { ...u, allowedModules: updated } : u)),
      );
    } catch {
      showError('Gagal mengubah permission.');
    }
  };

  const deleteUser = async (user: UserProfile) => {
    if (user.uid === currentUser?.uid) {
      showError('Tidak dapat menghapus akun sendiri.');
      return;
    }
    if (!confirm(`Hapus pengguna ${user.displayName}?`)) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid));
      setUsers((prev) => prev.filter((u) => u.uid !== user.uid));
      showSuccess(`${user.displayName} telah dihapus.`);
    } catch {
      showError('Gagal menghapus pengguna.');
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-500">
        <Shield className="w-6 h-6 mr-2" />
        Hanya admin yang dapat mengelola pengguna.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  const filtered = users.filter(
    (u) =>
      (u.displayName || '').toLowerCase().includes(search.toLowerCase()) ||
      (u.email || '').toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-violet-100 rounded-xl">
            <Users className="w-5 h-5 text-violet-700" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Manajemen Pengguna</h2>
            <p className="text-xs text-slate-500">{users.length} pengguna terdaftar</p>
          </div>
        </div>
      </div>

      <div className="relative mb-4">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          placeholder="Cari pengguna..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-violet-500"
        />
      </div>

      <div className="space-y-3">
        {filtered.map((user) => {
          const isExpanded = expandedUser === user.uid;
          return (
            <div key={user.uid} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div
                className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-slate-50"
                onClick={() => setExpandedUser(isExpanded ? null : user.uid)}
              >
                <div className="flex items-center gap-3">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="" className="w-9 h-9 rounded-full" />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-slate-200 flex items-center justify-center text-sm font-medium text-slate-600">
                      {(user.displayName || '?')[0]}
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{user.displayName}</p>
                    <p className="text-xs text-slate-500">{user.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                    user.role === 'admin'
                      ? 'bg-amber-100 text-amber-700'
                      : 'bg-slate-100 text-slate-600'
                  }`}>
                    {user.role === 'admin' ? (
                      <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Admin</span>
                    ) : (
                      <span className="flex items-center gap-1"><UserCog className="w-3 h-3" /> Staff</span>
                    )}
                  </span>
                  {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                </div>
              </div>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="border-t border-slate-100 overflow-hidden"
                  >
                    <div className="p-4 space-y-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => toggleRole(user)}
                          disabled={user.uid === currentUser?.uid}
                          className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 hover:bg-slate-50 disabled:opacity-40"
                        >
                          {user.role === 'admin' ? 'Jadikan Staff' : 'Jadikan Admin'}
                        </button>
                        <button
                          onClick={() => deleteUser(user)}
                          disabled={user.uid === currentUser?.uid}
                          className="px-3 py-1.5 text-xs font-medium rounded-lg border border-red-200 text-red-600 hover:bg-red-50 disabled:opacity-40"
                        >
                          <Trash2 className="w-3 h-3 inline mr-1" /> Hapus
                        </button>
                      </div>

                      {user.role !== 'admin' && (
                        <div>
                          <p className="text-xs font-semibold text-slate-600 mb-2">Akses Modul:</p>
                          <div className="grid grid-cols-3 gap-2">
                            {ALL_MODULE_KEYS.map((mod) => {
                              const hasAccess = user.allowedModules?.includes(mod.key);
                              return (
                                <button
                                  key={mod.key}
                                  onClick={() => togglePermission(user, mod.key)}
                                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs border transition-all ${
                                    hasAccess
                                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                                      : 'bg-slate-50 border-slate-200 text-slate-400'
                                  }`}
                                >
                                  {hasAccess ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                                  {mod.label}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                      {user.role === 'admin' && (
                        <p className="text-xs text-amber-600 bg-amber-50 px-3 py-2 rounded-lg">Admin memiliki akses ke semua modul.</p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};
