import React, { useRef } from 'react';
import { FinancialDocument, BusinessSettings } from '../types';
import { formatRupiah, formatDateIndo } from '../utils/formatters';
import { angkaKeTerbilang } from '../utils/terbilang';
import { BukitLangitLogo } from './common/BukitLangitLogo';
import {
  DEFAULT_SETTINGS,
  DEFAULT_TERMS_PRESETS,
  DEFAULT_ROOM_RATES,
  getDefaultTermsForDocType,
  computeContractTerms,
  getActiveContractKlausul,
  DEFAULT_ROOM_RATE_NOTES,
  DEFAULT_PAKET_RATE_NOTES,
  DEFAULT_ATV_RATE_NOTES,
} from '../utils/storage';
import { renderFormattedClauseLines, ClauseList } from '../utils/clauseFormatter';

interface DocumentPreviewProps {
  document: FinancialDocument;
  settings?: BusinessSettings;
  showWatermark?: boolean;
  scale?: number;
  domId?: string;
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({
  document: doc,
  settings: propSettings,
  showWatermark = false,
  domId = 'printable-invoice',
}) => {
  const settings = propSettings || DEFAULT_SETTINGS;
  const printableRef = useRef<HTMLDivElement | null>(null);

  const getMatchedRoomInclusion = (name?: string): string | undefined => {
    if (!name) return undefined;
    const rates =
      settings.defaultRoomRates && settings.defaultRoomRates.length > 0
        ? settings.defaultRoomRates
        : DEFAULT_ROOM_RATES;
    const lower = name.toLowerCase().trim();
    const matched = rates.find(
      (r) =>
        r.roomType.toLowerCase().trim() === lower ||
        lower.includes(r.roomType.toLowerCase().trim()) ||
        r.roomType.toLowerCase().trim().includes(lower) ||
        (r.code && lower === r.code.toLowerCase().trim())
    );
    return matched?.inclusions;
  };

  const defaultMasterInclusion =
    getMatchedRoomInclusion(doc.roomType) ||
    getMatchedRoomInclusion(doc.items?.[0]?.description) ||
    (settings.defaultRoomRates?.[0]?.inclusions || 'Breakfast 2 pax, Welcome drink, Wi-Fi, Water Heater');

  const terbilangText = doc.terbilangManual?.trim()
    ? doc.terbilangManual
    : doc.terbilang ||
      angkaKeTerbilang(
        doc.documentType === 'kwitansi_dp'
          ? (doc.downPaymentAmount ?? doc.dp ?? doc.grandTotal ?? doc.totalAmount ?? 0)
          : (doc.grandTotal ?? doc.totalAmount ?? 0)
      );

  const getTermsList = () => {
    if (doc.showTermsAndConditions === false) {
      return [];
    }
    if (doc.documentType === 'corporate_contract') {
      return computeContractTerms(doc, settings);
    }
    if (doc.termsAndConditions !== undefined && doc.termsAndConditions.length > 0) {
      return doc.termsAndConditions;
    }
    if (doc.terms && doc.terms.length > 0) {
      return doc.terms;
    }
    return getDefaultTermsForDocType(doc.documentType, settings, doc.documentDate || doc.date);
  };

  // Dynamic Header with Logo, Business Details, and Gold Divider Line
  const renderHeader = () => {
    // Hanya nama bisnis yang punya fallback. Field lain mengikuti Settings apa adanya:
    // kalau kosong, baris/label-nya disembunyikan (tidak menampilkan default atau "(kosong)").
    const bizName = settings.businessName || 'BUKIT LANGIT CAMPVENTURE';
    const bizTagline = settings.tagline?.trim() || '';
    const bizAddress = settings.address?.trim() || '';
    const bizPhone = settings.phone?.trim() || '';
    const bizEmail = settings.email?.trim() || '';
    const websiteVal = settings.website?.trim() || '';

    const contactParts: string[] = [];
    if (bizPhone) contactParts.push(`Telp/WA: ${bizPhone}`);
    if (bizEmail) contactParts.push(`Email: ${bizEmail}`);
    if (websiteVal) contactParts.push(`Web: ${websiteVal}`);
    const contactLine = contactParts.join(' | ');

    return (
      <div className="relative pb-1 mb-3">
        <div className="flex items-center justify-between">
          <div className="shrink-0 w-24 flex justify-start items-center">
            {settings.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt={bizName}
                className="h-16 w-auto max-w-[110px] object-contain"
              />
            ) : (
              <BukitLangitLogo size="lg" iconOnly showText={false} variant="icon" />
            )}
          </div>

          <div className="text-center flex-1 px-2">
            <h1 className="text-lg sm:text-xl font-black tracking-wider text-[#1a2b25] uppercase leading-tight">
              {bizName}
            </h1>
            {bizTagline && (
              <p className="text-[10px] font-bold text-[#96742e] uppercase tracking-wider mt-0.5">
                {bizTagline}
              </p>
            )}
            {bizAddress && (
              <p className="text-[10px] text-slate-600 mt-0.5 max-w-lg mx-auto leading-tight">
                {bizAddress}
              </p>
            )}
            {contactLine && (
              <p className="text-[9.5px] text-slate-500 mt-0.5 leading-tight">
                {contactLine}
              </p>
            )}
          </div>

          <div className="shrink-0 w-20 invisible">
            <div className="w-20" />
          </div>
        </div>

        {/* Elegant Gold Accent Divider */}
        <div className="w-full h-[1.5px] bg-gradient-to-r from-[#d8c28b] via-[#9e7c38] to-[#d8c28b] mt-1.5 mb-1.5 rounded-full opacity-85" />
      </div>
    );
  };

  // ==========================================
  // TEMPLATE: CORPORATE CONTRACT & RATE AGREEMENT (Exact B2B layout)
  // ==========================================
  const renderCorporateContractTemplate = () => {
    const roomRates =
      doc.roomRates !== undefined && doc.roomRates.length > 0
        ? doc.roomRates
        : settings.defaultRoomRates && settings.defaultRoomRates.length > 0
        ? settings.defaultRoomRates
        : [];

    const activePackageTables = (doc.packageTables || []).filter(
      (pt) => pt.items && pt.items.length > 0
    );

    const isKamarFootnoteEnabled =
      doc.roomRateNotesEnabled !== undefined
        ? doc.roomRateNotesEnabled
        : doc.footnoteKamarEnabled !== undefined
        ? doc.footnoteKamarEnabled
        : settings.defaultRoomRateNotesEnabled !== undefined
        ? settings.defaultRoomRateNotesEnabled
        : true;

    const kamarFootnoteText =
      doc.roomRateNotes !== undefined
        ? doc.roomRateNotes
        : settings.defaultRoomRateNotes || DEFAULT_ROOM_RATE_NOTES;

    return (
      <div className="space-y-3.5 text-xs text-slate-900 leading-normal">
        {/* 1. Document Contract Header */}
        <div className="text-center my-1 space-y-0.5 print-break-inside-avoid">
          <div className="font-mono text-xs font-bold text-slate-600">
            {doc.documentNumber || '024/CR-TA/SM/BLC/IX/2026'}
          </div>
          <h2 className="text-base sm:text-lg font-black tracking-wider text-slate-900 uppercase">
            {doc.documentTitle || 'CONTRACT RATE TRAVEL AGENT & CORPORATE AGREEMENT'}
          </h2>
          <div className="text-xs font-bold text-emerald-800">
            {doc.contractPeriod || '28 SEPTEMBER – 31 DESEMBER 2026'}
          </div>
        </div>

        {/* 2. Partner / Company Box */}
        <div className="border border-slate-300 rounded-lg p-2.5 bg-slate-50/80 text-xs space-y-1 print-break-inside-avoid">
          <div className="grid grid-cols-12 gap-1">
            <span className="col-span-3 text-slate-600 font-semibold">Nama Mitra / Perusahaan</span>
            <span className="col-span-9 font-bold uppercase">: {doc.guestName || doc.guestInfo?.name || '—'}</span>

            <span className="col-span-3 text-slate-600 font-semibold">Nama PIC / Kontak</span>
            <span className="col-span-9 font-medium">: {doc.companyContactPerson || doc.recipientSignatory?.name || '—'}</span>

            <span className="col-span-3 text-slate-600 font-semibold">Jabatan</span>
            <span className="col-span-9 font-medium">: {doc.companyContactTitle || doc.recipientSignatory?.position || '—'}</span>

            <span className="col-span-3 text-slate-600 font-semibold">Telepon / WhatsApp</span>
            <span className="col-span-9 font-medium">: {doc.guestPhone || doc.guestInfo?.phone || '—'}</span>

            <span className="col-span-3 text-slate-600 font-semibold">Email Resmi</span>
            <span className="col-span-9 font-medium">: {doc.guestEmail || doc.guestInfo?.email || '—'}</span>

            {doc.guestAddress && (
              <>
                <span className="col-span-3 text-slate-600 font-semibold">Alamat Kantor</span>
                <span className="col-span-9 font-medium">: {doc.guestAddress}</span>
              </>
            )}
          </div>
        </div>

        {/* 3. Intro Greeting */}
        <p className="text-[11px] text-slate-800 italic print-break-inside-avoid">
          {doc.contractIntroText || (
            <>
              Salam hangat dari <strong>{settings.businessName || 'BUKIT LANGIT CAMPVENTURE'}</strong>. Bersama ini kami sampaikan penawaran daftar harga kontrak resmi untuk perusahaan Anda sebagai berikut:
            </>
          )}
        </p>

        {/* 4. ROOM RATE MATRIX */}
        {roomRates && roomRates.length > 0 && (
          <div className="border border-slate-300 text-xs overflow-hidden rounded-md">
            <div className="bg-slate-800 text-white text-[11px] font-bold px-3 py-1.5 uppercase text-center tracking-wider">
              {doc.roomRateTableTitle || 'DAFTAR HARGA KAMAR (WEEKDAY & WEEKEND / HARI BESAR / HIGH SEASON)'}
            </div>
            <table className="w-full text-left border-collapse text-xs table-fixed">
              <colgroup>
                <col style={{ width: '24%' }} />
                <col style={{ width: '18%' }} />
                <col style={{ width: '18%' }} />
                <col style={{ width: '40%' }} />
              </colgroup>
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 font-bold text-[10px] text-slate-800">
                  <th className="py-1.5 px-2 border-r border-slate-300 text-center">TIPE KAMAR / GLAMPING</th>
                  <th className="py-1.5 px-2 border-r border-slate-300 text-center">HARGA WEEKDAY</th>
                  <th className="py-1.5 px-2 border-r border-slate-300 text-center">
                    {doc.roomRateWeekendHeader || 'HARGA WEEKEND'}
                  </th>
                  <th className="py-1.5 px-2 text-center">FASILITAS (INCLUSIONS)</th>
                </tr>
              </thead>
              <tbody>
                {roomRates.map((rr, i) => {
                  const wdPub = rr.weekdayPublishedRate ?? rr.publishedRate ?? 0;
                  const wdSpec = rr.weekdaySpecialRate ?? rr.specialRate ?? 0;
                  const wePub = rr.weekendPublishedRate ?? rr.publishedRate ?? 0;
                  const weSpec = rr.weekendSpecialRate ?? rr.specialRate ?? 0;
                  return (
                    <tr
                      key={rr.id || i}
                      className={`border-b border-slate-200 print-break-inside-avoid ${
                        i % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                      }`}
                    >
                      <td className="py-1.5 px-2 font-bold border-r border-slate-200 uppercase align-middle text-slate-900">
                        {rr.roomType}
                      </td>
                      <td className="py-1.5 px-2 text-center font-mono border-r border-slate-200 align-middle bg-blue-50/20">
                        <div className="font-bold text-emerald-800">{formatRupiah(wdSpec)}</div>
                        {wdPub > 0 && (
                          <div className="text-[10px] text-slate-400 line-through">{formatRupiah(wdPub)}</div>
                        )}
                      </td>
                      <td className="py-1.5 px-2 text-center font-mono border-r border-slate-200 align-middle bg-amber-50/20">
                        <div className="font-bold text-emerald-800">{formatRupiah(weSpec)}</div>
                        {wePub > 0 && (
                          <div className="text-[10px] text-slate-400 line-through">{formatRupiah(wePub)}</div>
                        )}
                      </td>
                      <td className="py-1.5 px-2 text-slate-700 align-top text-[11px] leading-relaxed">
                        {rr.inclusions || 'Breakfast 2 pax, Amenities Glamping'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {isKamarFootnoteEnabled && kamarFootnoteText && kamarFootnoteText.trim() !== '' && (
              <div className="bg-slate-50 px-2.5 py-1.5 text-[10px] text-slate-600 border-t border-slate-200 space-y-0.5 whitespace-pre-line print-break-inside-avoid">
                {kamarFootnoteText}
              </div>
            )}
          </div>
        )}

        {/* 5. PACKAGE & ACTIVITY TABLES (ATV, Full Board, Meeting, etc) */}
        {activePackageTables.map((pt, pIdx) => {
          const isAtv =
            pt.code?.toUpperCase() === 'ATV' ||
            (pt.title && pt.title.toLowerCase().includes('atv')) ||
            pt.id === 'pt-2';

          const hasItemDuration = (pt.items || []).some(
            (it) => Boolean((it.duration && it.duration.trim() !== '') || (it.durasi && it.durasi.trim() !== ''))
          );
          const showDurasi = pt.showDurasiColumn !== undefined ? pt.showDurasiColumn : hasItemDuration;
          const showFasilitas = pt.showFasilitasColumn !== undefined ? pt.showFasilitasColumn : true;

          const isFootnoteEnabled = pt.footnoteEnabled !== undefined ? pt.footnoteEnabled : true;
          const defaultFootnoteText = isAtv ? DEFAULT_ATV_RATE_NOTES : DEFAULT_PAKET_RATE_NOTES;
          const footnoteText =
            pt.footnoteText !== undefined && pt.footnoteText !== null && pt.footnoteText.trim() !== ''
              ? pt.footnoteText
              : pt.footnote !== undefined && pt.footnote !== null && pt.footnote.trim() !== ''
              ? pt.footnote
              : defaultFootnoteText;

          return (
            <div
              key={pt.id || pIdx}
              className="border border-slate-300 text-xs overflow-hidden rounded-md mt-2"
            >
              <div className="bg-slate-800 text-white text-[11px] font-bold px-3 py-1.5 uppercase text-center tracking-wider">
                {pt.title}
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 font-bold text-[10.5px] text-slate-800">
                    <th className="py-1.5 px-2 border-r border-slate-300">NAMA PAKET / AKTIVITAS</th>
                    {showDurasi && (
                      <th className="py-1.5 px-2 text-center w-28 border-r border-slate-300">DURASI</th>
                    )}
                    {showFasilitas && (
                      <th className="py-1.5 px-2 border-r border-slate-300">FASILITAS (INCLUSIONS)</th>
                    )}
                    <th className="py-1.5 px-2 text-right w-36">HARGA KHUSUS (NETT)</th>
                  </tr>
                </thead>
                <tbody>
                  {pt.items.map((item, i) => (
                    <tr
                      key={item.id || i}
                      className={`border-b border-slate-200 print-break-inside-avoid ${
                        i % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'
                      }`}
                    >
                      <td className="py-2 px-2 font-bold uppercase border-r border-slate-200 text-slate-900">
                        {item.name}
                      </td>
                      {showDurasi && (
                        <td className="py-2 px-2 text-center text-slate-700 border-r border-slate-200 text-[11px] font-medium whitespace-nowrap">
                          {item.duration || item.durasi || '-'}
                        </td>
                      )}
                      {showFasilitas && (
                        <td className="py-2 px-2 text-slate-700 border-r border-slate-200 text-[11px] leading-relaxed">
                          {item.inclusions || '-'}
                        </td>
                      )}
                      <td className="py-2 px-2 text-right font-mono">
                        <div className="font-bold text-emerald-800">{formatRupiah(item.specialRate)}</div>
                        {item.publishedRate > 0 && (
                          <div className="text-[10px] text-slate-400 line-through">{formatRupiah(item.publishedRate)}</div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {isFootnoteEnabled && footnoteText && footnoteText.trim() !== '' && (
                <div className="bg-slate-50 px-2.5 py-1.5 text-[10px] text-slate-600 border-t border-slate-200 space-y-0.5 whitespace-pre-line print-break-inside-avoid">
                  {footnoteText}
                </div>
              )}
              {pt.klausul && pt.klausul.trim() !== '' && (
                <div className="bg-amber-50/60 px-2.5 py-2 text-[10px] text-slate-700 border-t border-amber-200 whitespace-pre-line print-break-inside-avoid">
                  <p className="font-bold text-[10px] text-amber-900 uppercase tracking-wide mb-0.5">
                    Klausul &amp; Ketentuan Paket
                  </p>
                  {pt.klausul}
                </div>
              )}
            </div>
          );
        })}

        {/* 6. CONTRACT CHAPTERS WITH NUMBERED SECTIONS */}
        {(() => {
          const allPresets =
            settings.termsPresets && settings.termsPresets.length > 0
              ? settings.termsPresets
              : DEFAULT_TERMS_PRESETS;

          const chapters: {
            id: string;
            title: string;
            terms?: string[];
            isi?: string;
            defaultAsBullet: boolean;
          }[] = [];

          // Bab 1: Surcharge & General B2B Terms
          if (doc.showTermsAndConditions !== false) {
            const standardB2bPreset = allPresets.find((p) => p.id === 'tc-b2b-contract');
            const b2bTitle =
              doc.termsTitle ||
              settings.defaultContractTermsTitle ||
              standardB2bPreset?.title ||
              'SYARAT, KETENTUAN & BIAYA TAMBAHAN (SURCHARGE)';

            let standardTerms: string[] = [];
            if (doc.termsAndConditions && doc.termsAndConditions.length > 0) {
              standardTerms = doc.termsAndConditions.filter((t) => t && t.trim().length > 0);
            } else if (settings.defaultContractTerms && settings.defaultContractTerms.length > 0) {
              standardTerms = settings.defaultContractTerms.filter((t) => t && t.trim().length > 0);
            } else if (standardB2bPreset && standardB2bPreset.terms && standardB2bPreset.terms.length > 0) {
              standardTerms = standardB2bPreset.terms.filter((t) => t && t.trim().length > 0);
            } else {
              standardTerms = [
                'Harga kontrak bersifat NETT sudah termasuk Pajak Pemerintah & Pelayanan 21%, Welcome Drink, serta Sarapan Pagi 2 orang.',
                'Biaya Tambahan Musim Ramai (High & Peak Season - Idul Fitri, Libur Sekolah, Natal & Tahun Baru): Rp 250.000 - Rp 400.000 per kamar per malam.',
                'Waktu Check-in pukul 14.00 WIB dan Check-out pukul 12.00 WIB.',
                'Ketentuan Pembatalan: Pembatalan 1-5 kamar minimal 7 hari sebelum kedatangan. Pembatalan 6+ kamar minimal 14 hari sebelum kedatangan. No show dikenakan tagihan penuh 100%.',
                `Metode Pembayaran: Transfer ke rekening resmi ${settings.bankAccounts?.[0]?.accountHolder || settings.businessName || 'PT. HOLISTIK NUSANTARA GROUP'} sebelum tamu check-in atau dengan Surat Jaminan (Guarantee Letter) yang telah disetujui.`,
                'Komitmen Kamar (Room Night): Target minimal pemakaian 20 room nights per tahun kalender dengan evaluasi berkala per kuartal.',
              ];
            }

            if (standardTerms.length > 0) {
              chapters.push({
                id: 'contract_terms_standard',
                title: b2bTitle,
                terms: standardTerms,
                defaultAsBullet: true,
              });
            }
          }

          // Bab 2+: Activity terms for active package tables
          activePackageTables.forEach((table, tIdx) => {
            const tableTitle = (table.title || '').trim();
            const tableTitleLower = tableTitle.toLowerCase();

            const matchingPreset = allPresets.find((p) => {
              if (p.id === 'tc-table-' + table.id) return true;
              if (table.code && p.id.toLowerCase() === ('tc-table-' + table.code).toLowerCase()) return true;
              const pTitle = (p.title || '').trim().toLowerCase();
              if (pTitle === tableTitleLower) return true;
              if (
                tableTitleLower.includes('outbound') ||
                tableTitleLower.includes('outbond') ||
                tableTitleLower.includes('adventure') ||
                tableTitleLower.includes('atv')
              ) {
                return (
                  p.id === 'tc-atv-adventure' ||
                  pTitle.includes('atv') ||
                  pTitle.includes('outbound') ||
                  pTitle.includes('adventure')
                );
              }
              return false;
            });

            const tableTerms: string[] =
              matchingPreset && matchingPreset.terms && matchingPreset.terms.length > 0
                ? matchingPreset.terms.filter((t) => t && t.trim().length > 0)
                : [
                    `Pemesanan untuk ${tableTitle || 'Paket Aktivitas'} wajib dikonfirmasi selambat-lambatnya H-3 sebelum pelaksanaan acara.`,
                    'Deposit uang muka (DP) minimal 50% wajib disetorkan pada saat konfirmasi pemesanan tempat & aktivitas.',
                    'Pelunasan total biaya beserta finalisasi jumlah peserta wajib diselesaikan selambat-lambatnya H-1.',
                    'Peserta wajib mengikuti standar keselamatan dan instruksi pemandu/fasilitator lapangan.',
                  ];

            if (tableTerms.length > 0) {
              chapters.push({
                id: `contract_pkg_terms_${table.id || tIdx}`,
                title: matchingPreset?.title || tableTitle || 'Aturan Paket & Aktivitas',
                terms: tableTerms,
                defaultAsBullet: true,
              });
            }
          });

          // Bab 3+: General Clauses (Kesepakatan, Pembatalan, Force Majeure)
          const activeKlausul = getActiveContractKlausul(doc, settings);
          activeKlausul.forEach((k, kIdx) => {
            chapters.push({
              id: `contract_klausul_${k.id || kIdx}`,
              title: k.judul,
              isi: k.isi,
              defaultAsBullet: false,
            });
          });

          const cleanChapterTitle = (rawTitle: string): string => {
            if (!rawTitle) return '';
            return rawTitle.replace(/^\d+[\.\)]\s*/, '').trim();
          };

          return (
            <div className="space-y-3 pt-2">
              {chapters.map((chapter, cIdx) => {
                const chapterNumber = cIdx + 1;
                const cleanTitle = cleanChapterTitle(chapter.title);

                return (
                  <div
                    key={chapter.id || cIdx}
                    className="space-y-1.5 pt-1 print-break-inside-avoid"
                  >
                    <div className="border-b border-slate-300 pb-0.5 mb-1 flex items-baseline gap-1.5">
                      <h4 className="font-extrabold text-slate-950 text-[11.5px] uppercase tracking-wide">
                        <span className="text-slate-900">{chapterNumber}. </span>
                        {cleanTitle}
                      </h4>
                    </div>

                    <div className="space-y-0.5 text-xs text-slate-700">
                      {chapter.terms
                        ? renderFormattedClauseLines(chapter.terms, { defaultAsBullet: chapter.defaultAsBullet })
                        : renderFormattedClauseLines(chapter.isi || '', { defaultAsBullet: chapter.defaultAsBullet })}
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })()}

        {/* 7. Signatures & Official Reference — jangan dibelah antar halaman */}
        <div
          data-pdf-no-split
          className="pt-4 text-xs signature-block print-break-inside-avoid"
        >
          <div className="grid grid-cols-2 gap-8">
            <div>
              <p className="text-slate-700 font-medium">{settings.closingSalutation || 'Hormat Kami,'}</p>
              <div className="h-12" />
              <p className="font-bold text-slate-900 uppercase">
                {(doc.signatoryName && doc.signatoryName.trim()) || settings.signatoryName || 'Bukit Langit Campventure'}
              </p>
              <p className="text-[10px] text-emerald-800 font-semibold">
                {(doc.signatoryRole && doc.signatoryRole.trim()) || settings.signatoryRole || 'Reservation & Sales Management'}
              </p>
            </div>

            <div className="text-right">
              <p className="text-slate-700 font-medium">Disetujui & Diterima Oleh,</p>
              <div className="h-12" />
              <p className="font-bold text-slate-900 uppercase">
                {doc.recipientSignatoryName || doc.companyContactPerson || doc.guestName || '(....................................)'}
              </p>
              <p className="text-[10px] text-slate-500">
                {doc.recipientSignatoryRole || doc.companyContactTitle || 'Pihak Kedua / Mitra'}
              </p>
            </div>
          </div>

          <div className="pt-3 mt-4 border-t border-slate-200 text-[9.5px] text-slate-500 font-mono">
            No: {doc.documentNumber || '024/CR-TA/SM/BLC/IX/2026'}
          </div>
        </div>
      </div>
    );
  };

  // ==========================================
  // TEMPLATE: STANDARD FINANCIAL INVOICE / PROFORMA / ETC
  // ==========================================
  const renderStandardInvoiceTemplate = () => {
    const getDocTitle = () => {
      switch (doc.documentType) {
        case 'kwitansi_dp':
          return { title: 'KWITANSI PEMBAYARAN DP', subtitle: 'Official Down Payment Receipt' };
        case 'kwitansi_pelunasan':
          return { title: 'KWITANSI PELUNASAN RESMI', subtitle: 'Official Full Payment Receipt' };
        case 'booking_confirmation':
          return { title: 'KONFIRMASI RESERVASI RESMI', subtitle: 'Official Booking Confirmation' };
        case 'registration_card':
          return { title: 'REGISTRATION CARD / FORMULIR TAMU', subtitle: 'Guest Check-in Registration Form' };
        case 'hotel_voucher':
          return { title: 'HOTEL & STAY VOUCHER', subtitle: 'Official Accommodation Voucher' };
        case 'proforma':
          return { title: 'PROFORMA INVOICE', subtitle: 'Pre-Payment Commercial Invoice' };
        case 'pengajuan_dana':
          return { title: 'PENGAJUAN DANA / KOMISI AGEN', subtitle: 'Internal Fund Disbursement / Agent Commission Request' };
        default:
          return { title: 'INVOICE / TAGIHAN RESMI', subtitle: 'Official Bill & Invoice Document' };
      }
    };

    const docMeta = getDocTitle();
    const companyFallback = settings.businessName || 'PT. HOLISTIK NUSANTARA GROUP';
    const bank = doc.bankAccount || settings.bankAccounts?.[0] || {
      bankName: 'BCA (Bank Central Asia)',
      accountNumber: '1805554888',
      accountHolder: companyFallback,
      accountName: companyFallback,
    };

    const signatory = doc.signatory || {
      name: doc.signatoryName || settings.signatoryName || 'Manajemen Bukit Langit',
      position: doc.signatoryRole || settings.signatoryRole || 'Authorized Representative',
    };

    // Aturan per jenis dokumen (matrix):
    //
    //                    │ noPrice │ hidePayment │ hideBank │ bill-to label               │ signature-left        │ signature-right
    //  invoice           │   —     │     —       │    —     │ Ditujukan Kepada (Bill To)  │ Diterima & Disetujui  │ Hormat Kami
    //  proforma          │   —     │     ✓       │    —     │ Ditujukan Kepada (Bill To)  │ Diterima & Disetujui  │ Hormat Kami
    //  booking_confirm   │   —     │     —       │    —     │ Ditujukan Kepada (Bill To)  │ Diterima & Disetujui  │ Hormat Kami
    //  kwitansi_dp       │   —     │     —       │    —     │ Diterima Dari               │ Yang Membayar         │ Yang Menerima
    //  kwitansi_pelunasan│   —     │     —       │    ✓     │ Diterima Dari               │ Yang Membayar         │ Yang Menerima
    //  registration_card │   ✓     │     ✓       │    ✓     │ Data Tamu                   │ Tamu / Pemesan        │ Petugas Front Office
    //  hotel_voucher     │   ✓     │     ✓       │    ✓     │ Pemegang Voucher            │ (hide)                │ Diterbitkan Oleh
    //  pengajuan_dana    │   —     │     ✓       │    ✓     │ Diajukan Untuk (Nama Agen)  │ Diajukan Oleh         │ Disetujui Oleh
    //  corporate_contract│   —     │     —       │    —     │ Pihak Mitra                 │ Pihak Mitra           │ Pihak Hotel
    const dtype = doc.documentType;
    const noPrice = dtype === 'registration_card' || dtype === 'hotel_voucher';
    const hidePayment = noPrice || dtype === 'proforma' || dtype === 'pengajuan_dana';
    const hideBank =
      noPrice ||
      dtype === 'pengajuan_dana' ||
      dtype === 'kwitansi_pelunasan'; // sudah lunas → tidak perlu rek transfer lagi

    // Label dinamis untuk box "Bill To" & kedua tanda tangan
    const billToLabel = (() => {
      switch (dtype) {
        case 'kwitansi_dp':
        case 'kwitansi_pelunasan':
          return 'Diterima Dari:';
        case 'registration_card':
          return 'Data Tamu:';
        case 'hotel_voucher':
          return 'Pemegang Voucher:';
        case 'pengajuan_dana':
          return 'Diajukan Untuk (Nama Agen / Mitra):';
        case 'corporate_contract':
          return 'Pihak Mitra:';
        default:
          return 'Ditujukan Kepada (Bill To):';
      }
    })();

    const signatureLeft = (() => {
      switch (dtype) {
        case 'kwitansi_dp':
        case 'kwitansi_pelunasan':
          return { label: 'Yang Membayar,', role: 'Pihak Pembayar' };
        case 'registration_card':
          return { label: 'Tamu / Pihak Pemesan,', role: 'Tamu Terdaftar' };
        case 'hotel_voucher':
          return null; // voucher cuma 1 ttd (penerbit)
        case 'pengajuan_dana':
          return { label: 'Diajukan Oleh,', role: 'Pemohon / Admin' };
        default:
          return { label: 'Diterima & Disetujui Oleh,', role: 'Tamu / Pihak Pemesan' };
      }
    })();

    const signatureRight = (() => {
      switch (dtype) {
        case 'kwitansi_dp':
        case 'kwitansi_pelunasan':
          return { label: 'Yang Menerima Pembayaran,', role: 'Bagian Keuangan' };
        case 'registration_card':
          return { label: 'Petugas Front Office,', role: 'Front Office' };
        case 'hotel_voucher':
          return { label: 'Diterbitkan Oleh,', role: 'Manajemen Bukit Langit' };
        case 'pengajuan_dana':
          return { label: 'Disetujui Oleh,', role: 'Manajemen' };
        default:
          return {
            label: `Hormat Kami, ${settings.businessName || 'BUKIT LANGIT CAMPVENTURE'}`,
            role: 'Reservation & Sales Management',
          };
      }
    })();

    return (
      <div className="space-y-4 text-xs text-slate-800">
        {/* Document Banner & Metadata */}
        <div className="flex items-start justify-between bg-slate-50 border border-slate-200 rounded-xl p-4">
          <div>
            <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-emerald-800 text-white rounded-md">
              {doc.documentType.replace('_', ' ')}
            </span>
            <h1 className="text-xl font-black tracking-tight text-slate-900 mt-1.5 uppercase">
              {doc.documentTitle || docMeta.title}
            </h1>
            <p className="text-xs text-slate-500 font-medium">{docMeta.subtitle}</p>
          </div>

          <div className="text-right space-y-1">
            <div className="inline-block bg-white px-3 py-1.5 rounded-lg border border-slate-300">
              <p className="text-[10px] uppercase font-bold text-slate-400">Nomor Dokumen</p>
              <p className="text-sm font-mono font-bold text-slate-900">
                {doc.documentNumber || 'DRAFT/BL/---'}
              </p>
            </div>
            <div className="text-[11px] text-slate-600">
              <span className="text-slate-400">Tanggal: </span>
              <span className="font-semibold">{formatDateIndo(doc.documentDate || doc.date)}</span>
            </div>
            {doc.dueDate && (
              <div className="text-[11px] text-rose-700">
                <span className="text-slate-400">Jatuh Tempo: </span>
                <span className="font-semibold">{formatDateIndo(doc.dueDate)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Bill To & Stay Details Box */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-3.5 space-y-1">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
              {billToLabel}
            </p>
            <p className="text-sm font-bold text-slate-900 uppercase">
              {doc.guestName || doc.guestInfo?.name || 'Tamu Terhormat'}
            </p>
            {(doc.guestPhone || doc.guestInfo?.phone) && (
              <p className="text-slate-600 font-mono text-[11px]">
                Telp/WA: {doc.guestPhone || doc.guestInfo?.phone}
              </p>
            )}
            {(doc.guestEmail || doc.guestInfo?.email) && (
              <p className="text-slate-600 text-[11px]">
                Email: {doc.guestEmail || doc.guestInfo?.email}
              </p>
            )}
            {(doc.guestAddress || doc.guestInfo?.address) && (
              <p className="text-slate-500 text-[10px] leading-tight">
                {doc.guestAddress || doc.guestInfo?.address}
              </p>
            )}
          </div>

          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-3.5 space-y-1">
            <p className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
              {dtype === 'pengajuan_dana'
                ? 'Rincian Pencairan Dana:'
                : dtype === 'kwitansi_dp' || dtype === 'kwitansi_pelunasan'
                  ? 'Rincian Pembayaran:'
                  : 'Rincian Reservasi & Menginap:'}
            </p>
            {(doc.stayDate || doc.arrivalDate) && (
              <p className="text-slate-700 text-[11px]">
                <span className="text-slate-500">Tanggal Menginap: </span>
                <span className="font-semibold text-slate-900">
                  {doc.stayDate || `${doc.arrivalDate} s/d ${doc.departureDate || ''}`}
                </span>
              </p>
            )}
            {doc.roomType && (
              <p className="text-slate-700 text-[11px]">
                <span className="text-slate-500">Tipe Akomodasi: </span>
                <span className="font-semibold text-slate-900 uppercase">{doc.roomType}</span>
              </p>
            )}
            {doc.paymentMethod && (
              <p className="text-slate-700 text-[11px]">
                <span className="text-slate-500">Metode Bayar: </span>
                <span className="font-bold text-emerald-800 uppercase">{doc.paymentMethod}</span>
              </p>
            )}
          </div>
        </div>

        {/* Items Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-800 text-white font-bold text-[11px]">
                <th className="py-2.5 px-3 text-center w-12">No</th>
                <th className="py-2.5 px-3">Deskripsi Layanan / Item</th>
                <th className="py-2.5 px-3 text-center w-16">Qty</th>
                <th className="py-2.5 px-3 text-center w-20">Satuan</th>
                <th className="py-2.5 px-3 text-right w-28">Harga Satuan</th>
                <th className="py-2.5 px-3 text-right w-32">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {doc.items && doc.items.length > 0 ? (
                doc.items.map((item, index) => (
                  <tr
                    key={item.id || index}
                    className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}
                  >
                    <td className="py-2.5 px-3 text-center font-mono text-slate-400 text-[11px]">
                      {index + 1}
                    </td>
                    <td className="py-2.5 px-3">
                      <p className="font-bold text-slate-900">{item.description || '-'}</p>
                      {item.facilities && item.facilities.length > 0 && (
                        <p className="text-[10px] text-slate-500 mt-0.5">
                          Fasilitas: {Array.isArray(item.facilities) ? item.facilities.join(', ') : item.facilities}
                        </p>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-medium text-slate-800">
                      {item.quantity || 1}
                    </td>
                    <td className="py-2.5 px-3 text-center text-slate-500 text-[11px]">
                      {item.unit || 'Paket'}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                      {noPrice ? '—' : formatRupiah(item.unitPrice)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                      {noPrice ? '—' : formatRupiah(item.total)}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-400 italic">
                    Tidak ada rincian item.
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* Calculations & Terbilang */}
          <div className={`p-3.5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row justify-between gap-4 ${noPrice ? 'hidden' : ''}`}>
            <div className="flex-1 space-y-2">
              <div className="bg-white border border-slate-200 rounded-lg p-2.5">
                <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Terbilang:</p>
                <p className="text-xs font-semibold text-slate-800 italic mt-0.5 leading-snug">
                  # {terbilangText || 'Nol Rupiah'} #
                </p>
              </div>

              {!hidePayment && (
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-500 font-medium">Status Dokumen:</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full font-bold text-[10.5px] uppercase ${
                      doc.paymentStatus === 'LUNAS' || doc.paymentStatus === 'Lunas'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : doc.paymentStatus === 'DP'
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : 'bg-rose-100 text-rose-800 border border-rose-300'
                    }`}
                  >
                    {doc.paymentStatus || 'Belum Lunas'}
                  </span>
                </div>
              )}
            </div>

            <div className="w-64 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-mono font-medium">{formatRupiah(doc.subtotal)}</span>
              </div>

              {(doc.applyTax || doc.useTax) && (
                <div className="flex justify-between text-slate-600">
                  <span>PPN ({doc.taxRate || 10}%)</span>
                  <span className="font-mono font-medium">{formatRupiah(doc.taxAmount)}</span>
                </div>
              )}

              <div className="flex justify-between text-sm font-black text-slate-900 border-t border-slate-300 pt-1.5">
                <span>Total</span>
                <span className="font-mono font-black text-emerald-900">
                  {formatRupiah(doc.grandTotal ?? doc.totalAmount ?? 0)}
                </span>
              </div>

              {!hidePayment && (doc.dp ?? doc.downPaymentAmount ?? 0) > 0 && (
                <div className="flex justify-between text-amber-700 font-medium">
                  <span>
                    Uang Muka / DP
                    {doc.dpDate ? ` (${formatDateIndo(doc.dpDate)})` : ''}
                  </span>
                  <span className="font-mono">
                    - {formatRupiah(doc.dp ?? doc.downPaymentAmount ?? 0)}
                  </span>
                </div>
              )}

              {!hidePayment && ((doc.dp ?? doc.downPaymentAmount ?? 0) > 0 || (doc.remainingBalance ?? doc.remainingAmount ?? 0) > 0) && (
                <div className="flex justify-between text-xs font-bold text-slate-900 border-t border-slate-200 pt-1">
                  <span>Sisa Tagihan</span>
                  <span className="font-mono font-bold text-rose-700">
                    {formatRupiah(doc.remainingBalance ?? doc.remainingAmount ?? 0)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bank Information — disembunyikan utk reg_card, hotel_voucher, pengajuan_dana, kwitansi_pelunasan */}
        {!hideBank && bank && (
          <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-xl p-3 text-xs flex items-center justify-between">
            <div>
              <p className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider">
                Informasi Pembayaran Transfer Bank:
              </p>
              <p className="text-sm font-bold text-slate-900 mt-0.5">{bank.bankName}</p>
              <p className="text-sm font-mono font-black text-emerald-950 tracking-wider">
                {bank.accountNumber}
              </p>
              <p className="text-[11px] text-slate-700 font-medium">
                a.n. {bank.accountHolder || (bank as any).accountName || companyFallback}
              </p>
            </div>
            <div className="text-right text-[10px] text-emerald-800/80 max-w-xs leading-tight">
              <p>
                Harap sertakan nomor dokumen pada berita transfer dan kirimkan bukti pembayaran ke WhatsApp resmi kami.
              </p>
            </div>
          </div>
        )}

        {/* Terms & Conditions */}
        {getTermsList().length > 0 && (
          <div className="border border-slate-200 rounded-xl p-3.5 bg-white text-xs space-y-1.5">
            <p className="font-bold text-slate-900 uppercase tracking-wider text-[10px] border-b border-slate-100 pb-1">
              {doc.termsTitle || 'Syarat & Ketentuan (Terms & Conditions)'}
            </p>
            <ClauseList clauses={getTermsList()} />
          </div>
        )}

        {/* Signatures — label dinamis per DocumentType; jaga agar tidak dibelah antar halaman */}
        <div
          data-pdf-no-split
          className={`mt-6 pt-4 border-t border-slate-200 grid gap-8 text-xs ${
            signatureLeft ? 'grid-cols-2' : 'grid-cols-1 justify-items-center'
          }`}
        >
          {signatureLeft && (
            <div className="text-center space-y-10">
              <p className="text-[11px] font-semibold text-slate-600">{signatureLeft.label}</p>
              <div className="pt-8 border-b border-slate-400 w-48 mx-auto" />
              <div>
                <p className="font-bold text-slate-900 uppercase">
                  {dtype === 'pengajuan_dana'
                    ? doc.recipientSignatoryName ||
                      doc.recipientSignatory?.name ||
                      '(....................................)'
                    : doc.recipientSignatoryName ||
                      doc.recipientSignatory?.name ||
                      doc.guestName ||
                      '(....................................)'}
                </p>
                <p className="text-[10px] text-slate-500">{signatureLeft.role}</p>
              </div>
            </div>
          )}

          <div className="text-center space-y-10">
            <p className="text-[11px] font-semibold text-slate-600">{signatureRight.label}</p>
            <div className="pt-8 border-b border-slate-400 w-48 mx-auto" />
            <div>
              <p className="font-bold text-slate-900 uppercase">
                {signatory.name || 'Manajemen Bukit Langit'}
              </p>
              <p className="text-[10px] text-emerald-800 font-semibold">
                {signatory.position || signatureRight.role}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      id="printable-invoice-wrapper"
      className="w-full flex justify-center bg-slate-100/70 p-2 sm:p-6 overflow-auto print:p-0 print:bg-white"
    >
      <div
        ref={printableRef}
        id={domId}
        className="w-[794px] min-h-[1123px] bg-white text-slate-900 p-8 sm:p-10 font-sans shadow-lg border border-slate-200 shrink-0 relative flex flex-col justify-between box-border print:border-none print:shadow-none print:m-0 print:p-8"
        style={{
          boxSizing: 'border-box',
          fontFamily: "'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif",
        }}
      >
        {/* Optional Watermark */}
        {showWatermark && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5 select-none z-0">
            <BukitLangitLogo size="xl" iconOnly showText={false} variant="icon" />
          </div>
        )}

        <table className="w-full border-collapse print-page-table relative z-10">
          <thead className="print-header-group">
            <tr>
              <th className="font-normal text-left p-0 border-none bg-transparent">
                {renderHeader()}
              </th>
            </tr>
          </thead>
          <tbody className="print-body-group">
            <tr>
              <td className="font-normal text-left p-0 border-none bg-transparent align-top">
                <div className="w-full pt-1">
                  {doc.documentType === 'corporate_contract'
                    ? renderCorporateContractTemplate()
                    : renderStandardInvoiceTemplate()}
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DocumentPreview;
