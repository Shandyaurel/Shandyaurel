import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { NavigationGroup, NavigationModuleKey } from '../../types';
import { BusinessSettingsView } from '../settings/BusinessSettingsView';
import { UserManagementView } from '../settings/UserManagementView';
import { HotelBookingView } from '../hotel/HotelBookingView';
import { ATVBookingView } from '../atv/ATVBookingView';
import { InventoryView } from '../inventory/InventoryView';
import { AgentFeeView } from '../agent_fee/AgentFeeView';
import { BreakfastView } from '../breakfast/BreakfastView';
import { ExtraIncomeView } from '../extra_income/ExtraIncomeView';
import { DocumentEditorView } from '../documents/DocumentEditorView';
import { DocumentArchiveView } from '../documents/DocumentArchiveView';
import { ContractView } from '../contracts/ContractView';
import { PenawaranView } from '../penawaran/PenawaranView';
import { PartnerManagementView } from '../partners/PartnerManagementView';
import { LeadManagementView } from '../leads/LeadManagementView';
import { InfluencerManagementView } from '../influencers/InfluencerManagementView';
import { CalendarView } from '../calendar/CalendarView';
import { RundownView } from '../rundown/RundownView';
import { DashboardView } from '../dashboard/DashboardView';
import { MonthlyRevenueView } from '../monthly_revenue/MonthlyRevenueView';
import { CombinedReportsView } from '../reports/CombinedReportsView';
import { CombinedOrderView } from '../combined_orders/CombinedOrderView';
import { getStoredSettings } from '../../utils/storage';
import { getBusinessSettings } from '../../utils/firebase';
import { FinancialDocument, ClientContact, BusinessSettings } from '../../types';
import { ModulePlaceholder } from '../common/ModulePlaceholder';
import { Modal } from '../common/Modal';
import {
  LayoutDashboard,
  ShoppingBag,
  Hotel,
  Compass,
  Utensils,
  Coins,
  Boxes,
  Percent,
  FilePlus2,
  FileCheck,
  FileSignature,
  FileArchive,
  Users,
  Megaphone,
  Handshake,
  TrendingUp,
  BarChart3,
  CalendarDays,
  ListTodo,
  Settings,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Calendar,
  User,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const NAVIGATION_GROUPS: NavigationGroup[] = [
  {
    title: 'OPERASIONAL',
    items: [
      { id: 'dashboard', label: 'Dashboard', permissionKey: 'dashboard', iconName: 'LayoutDashboard' },
      { id: 'combined_orders', label: 'Order Gabungan', permissionKey: 'hotel', iconName: 'ShoppingBag' },
      { id: 'hotel', label: 'Hotel Booking', permissionKey: 'hotel', iconName: 'Hotel' },
      { id: 'atv', label: 'ATV Adventure', permissionKey: 'atv', iconName: 'Compass' },
      { id: 'breakfast', label: 'Breakfast / F&B', permissionKey: 'breakfast', iconName: 'Utensils' },
      { id: 'extra_income', label: 'Pendapatan Tambahan', permissionKey: 'hotel', iconName: 'Coins' },
      { id: 'inventory', label: 'Inventory', permissionKey: 'inventory', iconName: 'Boxes' },
      { id: 'agent_fee', label: 'Agent Fee', permissionKey: 'agent_fee', iconName: 'Percent' },
    ],
  },
  {
    title: 'DOKUMEN & CRM',
    items: [
      { id: 'create_document', label: 'Buat Dokumen', permissionKey: 'documents', iconName: 'FilePlus2' },
      { id: 'penawaran', label: 'Surat Penawaran', permissionKey: 'documents', iconName: 'FileSignature' },
      { id: 'contracts', label: 'Kontrak B2B', permissionKey: 'contracts', iconName: 'FileCheck' },
      { id: 'document_archive', label: 'Arsip Dokumen', permissionKey: 'documents', iconName: 'FileArchive' },
      { id: 'leads', label: 'Leads & Prospek', permissionKey: 'leads', iconName: 'Users' },
      { id: 'influencers', label: 'Influencer', permissionKey: 'influencers', iconName: 'Megaphone' },
      { id: 'partners', label: 'Mitra Bisnis', permissionKey: 'partners', iconName: 'Handshake' },
    ],
  },
  {
    title: 'ANALITIK',
    items: [
      { id: 'monthly_revenue', label: 'Perolehan Bulanan', permissionKey: 'reports', iconName: 'TrendingUp' },
      { id: 'reports', label: 'Laporan', permissionKey: 'reports', iconName: 'BarChart3' },
    ],
  },
  {
    title: 'TAMBAHAN',
    items: [
      { id: 'calendar', label: 'Kalender Reservasi', permissionKey: 'calendar', iconName: 'CalendarDays' },
      { id: 'rundown', label: 'Rundown Acara', permissionKey: 'rundown', iconName: 'ListTodo' },
    ],
  },
  {
    title: 'PENGATURAN',
    items: [
      { id: 'settings', label: 'Pengaturan Bisnis', permissionKey: 'settings', iconName: 'Settings', adminOnly: true },
      { id: 'users', label: 'User & Hak Akses', permissionKey: 'admin', iconName: 'ShieldCheck', adminOnly: true },
    ],
  },
];

const ICON_COMPONENTS: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard,
  ShoppingBag,
  Hotel,
  Compass,
  Utensils,
  Coins,
  Boxes,
  Percent,
  FilePlus2,
  FileCheck,
  FileSignature,
  FileArchive,
  Users,
  Megaphone,
  Handshake,
  TrendingUp,
  BarChart3,
  CalendarDays,
  ListTodo,
  Settings,
  ShieldCheck,
};

export const Shell: React.FC = () => {
  const { currentUser, userProfile, isAdmin, logout } = useAuth();

  const [activeModule, setActiveModule] = useState<NavigationModuleKey>('dashboard');
  const [editingDocument, setEditingDocument] = useState<FinancialDocument | null>(null);
  const [targetContractPartner, setTargetContractPartner] = useState<ClientContact | null>(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    return localStorage.getItem('bukit_langit_sidebar_collapsed') === 'true';
  });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState<boolean>(false);
  const [isLoggingOut, setIsLoggingOut] = useState<boolean>(false);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings>(() => getStoredSettings());

  useEffect(() => {
    let isMounted = true;
    getBusinessSettings()
      .then((settings) => {
        if (isMounted && settings) {
          setBusinessSettings(settings);
        }
      })
      .catch((err) => console.warn('Could not load live business settings:', err));

    const handleSettingsUpdate = () => {
      setBusinessSettings(getStoredSettings());
    };
    window.addEventListener('storage', handleSettingsUpdate);
    window.addEventListener('business_settings_updated', handleSettingsUpdate);

    return () => {
      isMounted = false;
      window.removeEventListener('storage', handleSettingsUpdate);
      window.removeEventListener('business_settings_updated', handleSettingsUpdate);
    };
  }, []);

  // Set default active module based on role and permissions
  useEffect(() => {
    if (isAdmin) {
      // Default to dashboard for admin
      setActiveModule('dashboard');
    } else if (userProfile?.permissions) {
      // Find the first module staff is allowed to see
      for (const group of NAVIGATION_GROUPS) {
        for (const item of group.items) {
          if (!item.adminOnly && userProfile.permissions[item.permissionKey]) {
            setActiveModule(item.id);
            return;
          }
        }
      }
    }
  }, [isAdmin, userProfile]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      localStorage.setItem('bukit_langit_sidebar_collapsed', String(next));
      return next;
    });
  };

  const handleLogoutConfirm = async () => {
    try {
      setIsLoggingOut(true);
      await logout();
    } finally {
      setIsLoggingOut(false);
      setIsLogoutModalOpen(false);
    }
  };

  // Helper to check if a navigation item should be visible
  const isItemVisible = (item: (typeof NAVIGATION_GROUPS)[0]['items'][0]) => {
    if (isAdmin) return true;
    if (item.adminOnly) return false;
    return !!userProfile?.permissions?.[item.permissionKey];
  };

  // Current formatted date in Indonesian
  const formattedToday = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  const displayName = userProfile?.displayName || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Pengguna';

  // Render content area based on active module
  const renderContent = () => {
    switch (activeModule) {
      case 'settings':
        return <BusinessSettingsView />;
      case 'users':
        return <UserManagementView />;
      case 'dashboard':
        return (
          <DashboardView
            onNavigateToModule={(mod) => {
              setActiveModule(mod as NavigationModuleKey);
            }}
          />
        );
      case 'combined_orders':
        return (
          <CombinedOrderView
            businessSettings={businessSettings}
            onNavigateToDocumentEditor={(doc) => {
              setEditingDocument(doc || null);
              setActiveModule('create_document');
            }}
          />
        );
      case 'hotel':
        return <HotelBookingView businessSettings={businessSettings} />;
      case 'atv':
        return <ATVBookingView businessSettings={businessSettings} />;
      case 'breakfast':
        return <BreakfastView />;
      case 'extra_income':
        return <ExtraIncomeView businessSettings={businessSettings} />;
      case 'inventory':
        return <InventoryView />;
      case 'agent_fee':
        return (
          <AgentFeeView
            onNavigateToDocumentEditor={(doc) => {
              setEditingDocument(doc || null);
              setActiveModule('create_document');
            }}
          />
        );
      case 'create_document':
        return (
          <DocumentEditorView
            initialDocument={editingDocument}
            onSaved={(doc) => {
              setEditingDocument(doc);
            }}
            onNavigateToArchive={() => {
              setActiveModule('document_archive');
            }}
          />
        );
      case 'contracts':
        return (
          <ContractView
            initialPartner={targetContractPartner}
          />
        );
      case 'penawaran':
        return <PenawaranView />;
      case 'document_archive':
        return (
          <DocumentArchiveView
            onEditDocument={(doc) => {
              setEditingDocument(doc);
              setActiveModule('create_document');
            }}
            onCreateNew={() => {
              setEditingDocument(null);
              setActiveModule('create_document');
            }}
          />
        );
      case 'leads':
        return (
          <LeadManagementView
            settings={getStoredSettings()}
            userEmail={currentUser?.email || ''}
            userName={displayName}
            onNavigateToDocument={(lead) => {
              const currentSettings = getStoredSettings();
              const defaultBank = currentSettings.bankAccounts?.[0] || {
                bankName: 'BCA',
                accountNumber: '1801289191',
                accountName: currentSettings.businessName || 'PT HOLISTIK NUSANTARA GROUP',
              };
              setEditingDocument({
                id: `doc_inv_${Date.now()}`,
                documentType: 'invoice',
                documentTitle: 'INVOICE TAGIHAN RESERVASI',
                documentNumber: '',
                documentDate: new Date().toISOString().split('T')[0],
                guestName: lead.guestName,
                guestPhone: lead.whatsAppNumber,
                guestOrganization: lead.groupName || '',
                stayDate: lead.plannedCheckInDate || '',
                subtotal: 0,
                taxRate: 0,
                taxAmount: 0,
                totalAmount: 0,
                useTax: false,
                paymentStatus: 'Draft',
                items: [],
                notes: lead.notes || '',
                bankAccount: defaultBank,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              });
              setActiveModule('create_document');
            }}
          />
        );
      case 'influencers':
        return (
          <InfluencerManagementView
            settings={getStoredSettings()}
            userEmail={currentUser?.email || ''}
            userName={displayName}
          />
        );
      case 'partners':
        return (
          <PartnerManagementView
            onNavigateToCreateContract={(partner) => {
              setTargetContractPartner(partner);
              setActiveModule('contracts');
            }}
          />
        );
      case 'monthly_revenue':
        return <MonthlyRevenueView />;
      case 'reports':
        return <CombinedReportsView />;
      case 'calendar':
        return <CalendarView />;
      case 'rundown':
        return <RundownView />;
      default:
        return <BusinessSettingsView />;
    }
  };

  return (
    <div id="app-shell" className="min-h-screen bg-[#F8FAFC] flex text-slate-900">
      {/* DESKTOP SIDEBAR */}
      <aside
        id="desktop-sidebar"
        className={`hidden lg:flex flex-col bg-white border-r border-slate-200 transition-all duration-300 z-30 sticky top-0 h-screen shrink-0 ${
          isSidebarCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-100">
          {!isSidebarCollapsed ? (
            <div className="flex items-center gap-2.5 min-w-0">
              {businessSettings?.logoUrl ? (
                <img
                  src={businessSettings.logoUrl}
                  alt={businessSettings.businessName || 'Logo'}
                  className="w-9 h-9 rounded-xl object-contain bg-white border border-slate-200 p-0.5 shrink-0 shadow-xs"
                />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Compass className="w-5 h-5" />
                </div>
              )}
              <div className="min-w-0">
                <h1 className="font-bold text-sm tracking-tight text-slate-900 truncate">
                  {businessSettings?.businessName || 'Bukit Langit'}
                </h1>
                <span className="text-[10px] text-slate-400 font-medium block truncate">
                  {businessSettings?.tagline || 'Sistem Terpadu'}
                </span>
              </div>
            </div>
          ) : (
            <div className="mx-auto flex items-center justify-center">
              {businessSettings?.logoUrl ? (
                <img
                  src={businessSettings.logoUrl}
                  alt={businessSettings.businessName || 'Logo'}
                  className="w-9 h-9 rounded-xl object-contain bg-white border border-slate-200 p-0.5 shadow-xs"
                />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Compass className="w-5 h-5" />
                </div>
              )}
            </div>
          )}

          <button
            id="sidebar-toggle-button"
            type="button"
            onClick={toggleSidebar}
            className={`p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors ${
              isSidebarCollapsed ? 'mx-auto mt-2 hidden' : ''
            }`}
            title={isSidebarCollapsed ? 'Perluas Sidebar' : 'Ciutkan Sidebar'}
          >
            {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Menu List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-6 scrollbar-thin">
          {NAVIGATION_GROUPS.map((group) => {
            const visibleItems = group.items.filter(isItemVisible);
            if (visibleItems.length === 0) return null;

            return (
              <div key={group.title} className="space-y-1">
                {!isSidebarCollapsed && (
                  <h3 className="px-3 text-[11px] font-bold text-slate-400 tracking-wider uppercase mb-1.5">
                    {group.title}
                  </h3>
                )}
                {visibleItems.map((item) => {
                  const Icon = ICON_COMPONENTS[item.iconName] || Sparkles;
                  const isActive = activeModule === item.id;

                  return (
                    <button
                      key={item.id}
                      id={`nav-item-${item.id}`}
                      type="button"
                      onClick={() => setActiveModule(item.id)}
                      title={isSidebarCollapsed ? item.label : undefined}
                      className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                        isActive
                          ? 'bg-blue-50 text-blue-700 font-semibold'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      } ${isSidebarCollapsed ? 'justify-center px-2' : ''}`}
                    >
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isActive ? 'text-blue-600' : 'text-slate-400'
                        }`}
                      />
                      {!isSidebarCollapsed && <span className="truncate">{item.label}</span>}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </div>

        {/* Sidebar Footer User Info */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/60">
          {!isSidebarCollapsed ? (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  {displayName[0]?.toUpperCase() || 'U'}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-800 truncate">{displayName}</div>
                  <div className="text-[10px] text-slate-500 font-medium">
                    {isAdmin ? 'Administrator' : 'Staff Operasional'}
                  </div>
                </div>
              </div>
              <button
                id="sidebar-logout-button"
                type="button"
                onClick={() => setIsLogoutModalOpen(true)}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                title="Keluar Akun"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              id="sidebar-collapsed-logout-button"
              type="button"
              onClick={() => setIsLogoutModalOpen(true)}
              className="w-full flex items-center justify-center p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
              title="Keluar Akun"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </aside>

      {/* MOBILE DRAWER SIDEBAR */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs"
            />

            {/* Off-canvas Menu */}
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="relative w-72 max-w-[80vw] bg-white h-full flex flex-col z-10 shadow-2xl"
            >
              <div className="h-16 flex items-center justify-between px-5 border-b border-slate-100">
                <div className="flex items-center gap-2.5 min-w-0">
                  {businessSettings?.logoUrl ? (
                    <img
                      src={businessSettings.logoUrl}
                      alt={businessSettings.businessName || 'Logo'}
                      className="w-8 h-8 rounded-xl object-contain bg-white border border-slate-200 p-0.5 shrink-0 shadow-xs"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Compass className="w-4 h-4" />
                    </div>
                  )}
                  <span className="font-bold text-sm text-slate-900 truncate">
                    {businessSettings?.businessName || 'Bukit Langit'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-6">
                {NAVIGATION_GROUPS.map((group) => {
                  const visibleItems = group.items.filter(isItemVisible);
                  if (visibleItems.length === 0) return null;

                  return (
                    <div key={group.title} className="space-y-1">
                      <h3 className="px-3 text-[11px] font-bold text-slate-400 tracking-wider uppercase mb-1">
                        {group.title}
                      </h3>
                      {visibleItems.map((item) => {
                        const Icon = ICON_COMPONENTS[item.iconName] || Sparkles;
                        const isActive = activeModule === item.id;

                        return (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => {
                              setActiveModule(item.id);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors cursor-pointer ${
                              isActive
                                ? 'bg-blue-50 text-blue-700 font-semibold'
                                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                            }`}
                          >
                            <Icon
                              className={`w-4 h-4 ${
                                isActive ? 'text-blue-600' : 'text-slate-400'
                              }`}
                            />
                            <span>{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  );
                })}
              </div>

              <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                    {displayName[0]?.toUpperCase() || 'U'}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-800 truncate">{displayName}</div>
                    <div className="text-[10px] text-slate-500">{isAdmin ? 'Admin' : 'Staff'}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setIsLogoutModalOpen(true);
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-600"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MAIN CONTENT WRAPPER */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* TOPBAR */}
        <header
          id="topbar"
          className="h-16 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-20"
        >
          <div className="flex items-center gap-3">
            {/* Mobile Hamburger */}
            <button
              id="mobile-menu-button"
              type="button"
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg"
              aria-label="Buka menu navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <h1 className="text-base font-bold text-slate-900 leading-tight">
                Selamat datang, {displayName}!
              </h1>
              <p className="text-xs text-slate-400 hidden sm:block flex items-center gap-1.5 mt-0.5">
                <Calendar className="w-3 h-3 inline-block" />
                <span>{formattedToday}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            {/* Role Badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
              {isAdmin ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
                  <span>Administrator</span>
                </>
              ) : (
                <>
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  <span>Staff Operasional</span>
                </>
              )}
            </div>

            {/* Avatar Pill */}
            <div className="flex items-center gap-2.5 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                {displayName[0]?.toUpperCase() || 'U'}
              </div>
              <button
                id="topbar-logout-button"
                type="button"
                onClick={() => setIsLogoutModalOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Keluar</span>
              </button>
            </div>
          </div>
        </header>

        {/* MAIN BODY AREA */}
        <main id="main-content-area" className="flex-1 p-4 sm:p-8 overflow-y-auto">
          <div className="max-w-7xl mx-auto">{renderContent()}</div>
        </main>
      </div>

      {/* LOGOUT CONFIRMATION MODAL */}
      <Modal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
        title="Konfirmasi Keluar Akun"
        description="Apakah Anda yakin ingin mengakhiri sesi kerja dan keluar dari sistem Bukit Langit?"
        confirmLabel="Ya, Keluar"
        cancelLabel="Tetap di Sini"
        onConfirm={handleLogoutConfirm}
        confirmVariant="danger"
        isLoading={isLoggingOut}
        iconType="warning"
      />
    </div>
  );
};
