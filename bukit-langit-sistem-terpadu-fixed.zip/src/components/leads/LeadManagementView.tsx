import React, { useState, useEffect, useMemo } from 'react';
import {
  Lead,
  LeadStatus,
  CampaignSource,
  BookingType,
  ActivityLogItem,
  BusinessSettings,
} from '../../types/document';
import {
  subscribeLeads,
  saveLead,
  recordLeadFollowUp,
  updateLeadStatus,
  deleteLead,
  updateLeadPromoStatus,
  updateLeadsPromoStatusBatch,
} from '../../utils/firebase';
import { formatDateForInput, formatDateToIndonesian } from '../../utils/formatter';
import {
  Users,
  Search,
  Filter,
  Plus,
  Phone,
  MessageCircle,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  TrendingUp,
  Send,
  Trash2,
  Edit,
  History,
  ArrowRight,
  Flame,
  List,
  Columns,
  RefreshCw,
  Sparkles,
  Layers,
  Upload,
  Download,
  Copy,
  Check,
  Megaphone,
  CheckSquare,
  Square,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import { DataImportModal } from '../common/DataImportModal';
import { BroadcastPromoModal } from './BroadcastPromoModal';

interface LeadManagementViewProps {
  settings: BusinessSettings;
  userEmail: string;
  userName?: string;
  onNavigateToDocument?: (lead: Lead) => void;
  showToast?: (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => void;
}

export type ViewTab = 'queue' | 'today' | 'kanban' | 'lost' | 'all';

/**
 * Auto-calculation of Next Follow-Up Date based on Business Settings:
 * 1. Tentative / New Lead / Warm Inquiry: X days (leadFollowUpDaysTentative, default 15) from base date.
 * 2. Confirmed / Fixed check-in date: X days (leadFollowUpDaysConfirmed, default 30) before check-in.
 */
export const computeAutoNextFollowUpDate = (
  lead: Partial<Lead>,
  settings: BusinessSettings,
  baseDate: Date = new Date()
): string => {
  const daysTentative = settings.leadFollowUpDaysTentative ?? 15;
  const daysConfirmed = settings.leadFollowUpDaysConfirmed ?? 30;

  // Case 1: Confirmed booking or fixed check-in (not tentative)
  if (lead.leadStatus === 'Booking Confirmed' || (!lead.isTentative && lead.plannedCheckInDate)) {
    if (lead.plannedCheckInDate) {
      const checkIn = new Date(lead.plannedCheckInDate);
      if (!isNaN(checkIn.getTime())) {
        const target = new Date(checkIn);
        target.setDate(target.getDate() - daysConfirmed);

        const now = new Date();
        now.setHours(0, 0, 0, 0);
        target.setHours(0, 0, 0, 0);

        if (target.getTime() <= now.getTime()) {
          const tomorrow = new Date(now);
          tomorrow.setDate(tomorrow.getDate() + 1);
          return formatDateForInput(tomorrow);
        }
        return formatDateForInput(target);
      }
    }
  }

  // Case 2: Tentative or New Lead / Warm Inquiry
  const target = new Date(baseDate);
  target.setDate(target.getDate() + daysTentative);
  return formatDateForInput(target);
};

export const LeadManagementView: React.FC<LeadManagementViewProps> = ({
  settings,
  userEmail,
  userName,
  onNavigateToDocument,
  showToast,
}) => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ViewTab>('queue');

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [picFilter, setPicFilter] = useState<string>('all');
  const [bookingTypeFilter, setBookingTypeFilter] = useState<string>('all');
  const [lostPromoFilter, setLostPromoFilter] = useState<'all' | 'allowed' | 'disallowed'>('all');

  // Multi-select for Lost Contacts & Bulk Actions
  const [selectedLostLeadIds, setSelectedLostLeadIds] = useState<string[]>([]);

  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isPromoBroadcastModalOpen, setIsPromoBroadcastModalOpen] = useState(false);

  const [followUpModalLead, setFollowUpModalLead] = useState<Lead | null>(null);
  const [followUpResult, setFollowUpResult] = useState('');
  const [followUpNote, setFollowUpNote] = useState('');
  const [followUpNextDate, setFollowUpNextDate] = useState('');

  const [statusChangeModalLead, setStatusChangeModalLead] = useState<Lead | null>(null);
  const [targetStatus, setTargetStatus] = useState<LeadStatus>('Warm Inquiry');
  const [statusReason, setStatusReason] = useState('');

  const [deleteModalLead, setDeleteModalLead] = useState<Lead | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  const [timelineModalLead, setTimelineModalLead] = useState<Lead | null>(null);
  const [draggedLeadId, setDraggedLeadId] = useState<string | null>(null);
  const [isSavingLead, setIsSavingLead] = useState<boolean>(false);

  // Default follow-up intervals & dropdown options
  const daysConfirmed = settings.leadFollowUpDaysConfirmed ?? 30;
  const daysTentative = settings.leadFollowUpDaysTentative ?? 15;

  const followUpResultsList = useMemo(() => {
    return settings.leadFollowUpResults && settings.leadFollowUpResults.length > 0
      ? settings.leadFollowUpResults
      : [
          'Tertarik, minta proposal & penawaran',
          'Minta waktu diskusi internal',
          'Menunggu persetujuan pimpinan / keluarga',
          'Menunggu kepastian tanggal menginap',
          'Butuh penawaran diskon / paket khusus',
          'Minta di-follow-up minggu depan',
          'Tidak merespon / pending',
          'Respon positif, segera transfer DP',
        ];
  }, [settings.leadFollowUpResults]);

  const lostReasonsList = useMemo(() => {
    return settings.leadLostReasons && settings.leadLostReasons.length > 0
      ? settings.leadLostReasons
      : [
          'Budget tidak cocok / Kemahalan',
          'Pilih venue/hotel lain',
          'Tanggal penuh / tidak tersedia',
          'Acara dibatalkan / ditunda',
          'Lokasi terlalu jauh',
          'Fasilitas tidak sesuai kebutuhan',
          'Tidak ada kabar / Ghosting',
          'Lainnya',
        ];
  }, [settings.leadLostReasons]);

  const campaignSourcesList = useMemo(() => {
    return settings.campaignSources && settings.campaignSources.length > 0
      ? settings.campaignSources
      : [
          'Instagram Ads',
          'TikTok',
          'Direct WA',
          'Website',
          'Referral',
          'Other',
        ];
  }, [settings.campaignSources]);

  // Realtime subscription
  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeLeads(
      (data) => {
        setLeads(data);
        setLoading(false);
      },
      (error) => {
        console.error('Error subscribing to leads:', error);
        setLoading(false);
        if (showToast) {
          showToast('error', 'Gagal Memuat Leads', error.message || 'Terjadi kendala koneksi.');
        }
      }
    );
    return () => unsubscribe();
  }, [showToast]);

  const todayStr = useMemo(() => formatDateForInput(new Date()), []);

  // Filter logic
  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      // Tab based filter
      if (activeTab === 'today') {
        if (lead.leadStatus === 'Booking Confirmed' || lead.leadStatus === 'Cancelled-Lost') {
          return false;
        }
        if (!lead.next_follow_up_date) return false;
        if (lead.next_follow_up_date > todayStr) return false;
      } else if (activeTab === 'queue') {
        if (lead.leadStatus === 'Booking Confirmed' || lead.leadStatus === 'Cancelled-Lost') {
          return false;
        }
      } else if (activeTab === 'lost') {
        if (lead.leadStatus !== 'Cancelled-Lost') {
          return false;
        }
        if (lostPromoFilter === 'allowed' && lead.allowPromoBroadcast === false) {
          return false;
        }
        if (lostPromoFilter === 'disallowed' && lead.allowPromoBroadcast !== false) {
          return false;
        }
      }

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = lead.guestName.toLowerCase().includes(query);
        const matchPhone = lead.whatsAppNumber.includes(query);
        const matchGroup = lead.groupName?.toLowerCase().includes(query);
        const matchNotes = lead.notes?.toLowerCase().includes(query);
        const matchPic =
          lead.picPerolehan?.toLowerCase().includes(query) ||
          lead.picFollowUp?.toLowerCase().includes(query);
        const matchLostReason = lead.lost_reason?.toLowerCase().includes(query);
        if (!matchName && !matchPhone && !matchGroup && !matchNotes && !matchPic && !matchLostReason) {
          return false;
        }
      }

      // Status filter (only applied when not in tabs that have strict status)
      if (activeTab === 'all' && statusFilter !== 'all' && lead.leadStatus !== statusFilter) {
        return false;
      }

      // Source filter
      if (sourceFilter !== 'all' && lead.campaignSource !== sourceFilter) {
        return false;
      }

      // PIC filter
      if (picFilter !== 'all') {
        const currentPic = lead.picFollowUp || lead.picPerolehan || '';
        if (currentPic !== picFilter) return false;
      }

      // Booking Type filter
      if (bookingTypeFilter !== 'all') {
        if (bookingTypeFilter === 'tentative' && !lead.isTentative) return false;
        if (bookingTypeFilter === 'personal' && lead.bookingType !== 'Personal') return false;
        if (bookingTypeFilter === 'grup' && lead.bookingType !== 'Grup') return false;
      }

      return true;
    });
  }, [leads, activeTab, todayStr, searchQuery, statusFilter, sourceFilter, picFilter, bookingTypeFilter, lostPromoFilter]);

  // Sort queue by follow up urgency
  const sortedLeads = useMemo(() => {
    if (activeTab === 'queue' || activeTab === 'today') {
      return [...filteredLeads].sort((a, b) => {
        const dateA = a.next_follow_up_date || '9999-99-99';
        const dateB = b.next_follow_up_date || '9999-99-99';
        return dateA.localeCompare(dateB);
      });
    }
    if (activeTab === 'lost') {
      return [...filteredLeads].sort((a, b) => (b.updatedAt || b.createdAt || '').localeCompare(a.updatedAt || a.createdAt || ''));
    }
    return filteredLeads;
  }, [filteredLeads, activeTab]);

  // Statistics
  const stats = useMemo(() => {
    const total = leads.length;
    const todayDue = leads.filter(
      (l) =>
        l.leadStatus !== 'Booking Confirmed' &&
        l.leadStatus !== 'Cancelled-Lost' &&
        l.next_follow_up_date &&
        l.next_follow_up_date <= todayStr
    ).length;
    const warm = leads.filter((l) => l.leadStatus === 'Warm Inquiry').length;
    const newLeads = leads.filter((l) => l.leadStatus === 'New Lead').length;
    const confirmed = leads.filter((l) => l.leadStatus === 'Booking Confirmed').length;
    const lost = leads.filter((l) => l.leadStatus === 'Cancelled-Lost').length;
    const lostEligiblePromo = leads.filter(
      (l) => l.leadStatus === 'Cancelled-Lost' && l.allowPromoBroadcast !== false
    ).length;
    const conversionRate = total > 0 ? Math.round((confirmed / total) * 100) : 0;

    return { total, todayDue, warm, newLeads, confirmed, lost, lostEligiblePromo, conversionRate };
  }, [leads, todayStr]);

  // Unique PIC list for filtering
  const allPics = useMemo(() => {
    const pics = new Set<string>();
    leads.forEach((l) => {
      if (l.picPerolehan) pics.add(l.picPerolehan);
      if (l.picFollowUp) pics.add(l.picFollowUp);
      if (l.picClosing) pics.add(l.picClosing);
    });
    return Array.from(pics).filter(Boolean);
  }, [leads]);

  // Toggle single lead promo broadcast status
  const handleTogglePromoStatus = async (lead: Lead) => {
    const current = lead.allowPromoBroadcast !== false;
    const nextVal = !current;

    // Optimistic local state update
    setLeads((prev) =>
      prev.map((l) => (l.id === lead.id ? { ...l, allowPromoBroadcast: nextVal } : l))
    );

    try {
      await updateLeadPromoStatus(lead.id, nextVal, userEmail);
      if (showToast) {
        showToast(
          'success',
          nextVal ? 'Izin Promo Diaktifkan' : 'Izin Promo Dinonaktifkan',
          `${lead.guestName} ${nextVal ? 'boleh dihubungi untuk penawaran promo.' : 'ditandai jangan dihubungi promo.'}`
        );
      }
    } catch (err: any) {
      console.error(err);
      // Revert local state
      setLeads((prev) =>
        prev.map((l) => (l.id === lead.id ? { ...l, allowPromoBroadcast: current } : l))
      );
      if (showToast) {
        showToast('error', 'Gagal Mengubah Izin Promo', err.message || 'Terjadi kesalahan sistem.');
      }
    }
  };

  // Bulk promo permission update
  const handleBatchTogglePromoStatus = async (allow: boolean) => {
    if (selectedLostLeadIds.length === 0) return;
    const ids = [...selectedLostLeadIds];

    // Optimistic local state
    setLeads((prev) =>
      prev.map((l) => (ids.includes(l.id) ? { ...l, allowPromoBroadcast: allow } : l))
    );

    try {
      await updateLeadsPromoStatusBatch(ids, allow, userEmail);
      if (showToast) {
        showToast(
          'success',
          'Berhasil Memperbarui',
          `${ids.length} kontak lost berhasil diatur ${allow ? 'boleh promo' : 'jangan hubungi promo'}.`
        );
      }
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Memperbarui Batch', err.message);
      }
    }
  };

  // Multi-select helpers
  const handleSelectAllLost = () => {
    if (selectedLostLeadIds.length === sortedLeads.length) {
      setSelectedLostLeadIds([]);
    } else {
      setSelectedLostLeadIds(sortedLeads.map((l) => l.id));
    }
  };

  const handleToggleSelectLead = (leadId: string) => {
    setSelectedLostLeadIds((prev) =>
      prev.includes(leadId) ? prev.filter((id) => id !== leadId) : [...prev, leadId]
    );
  };

  // Export Lost Contacts to CSV
  const handleExportLostContactsCsv = () => {
    const targetList = leads.filter((l) => {
      if (l.leadStatus !== 'Cancelled-Lost') return false;
      if (selectedLostLeadIds.length > 0) {
        return selectedLostLeadIds.includes(l.id);
      }
      return true;
    });

    if (targetList.length === 0) {
      if (showToast) showToast('warning', 'Tidak Ada Kontak', 'Tidak ada data kontak lost untuk diekspor.');
      return;
    }

    const headers = [
      'Nama Tamu',
      'Nomor WhatsApp',
      'Status Izin Promo',
      'Sumber Lead',
      'Rencana Menginap',
      'Alasan Batal',
      'Tipe Booking',
      'Catatan',
      'Tanggal Chat',
    ];

    const rows = targetList.map((l) => [
      `"${(l.guestName || '').replace(/"/g, '""')}"`,
      `"${(l.whatsAppNumber || '').replace(/"/g, '""')}"`,
      `"${l.allowPromoBroadcast !== false ? 'Boleh Promo (Aktif)' : 'Jangan Hubungi'}"`,
      `"${(l.campaignSource || '').replace(/"/g, '""')}"`,
      `"${l.plannedCheckInDate || ''}"`,
      `"${(l.lost_reason || '').replace(/"/g, '""')}"`,
      `"${l.bookingType || 'Personal'}"`,
      `"${(l.notes || '').replace(/"/g, '""')}"`,
      `"${l.chatDate || ''}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Kontak_Lost_Promo_BukitLangit_${formatDateForInput(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (showToast) {
      showToast('success', 'Ekspor CSV Berhasil', `${targetList.length} kontak lost berhasil diunduh ke CSV.`);
    }
  };

  // Copy Lost WhatsApp Numbers to clipboard
  const handleCopyLostPhones = (format: 'comma' | 'newline' = 'comma') => {
    const targetList = leads.filter((l) => {
      if (l.leadStatus !== 'Cancelled-Lost') return false;
      if (selectedLostLeadIds.length > 0) {
        return selectedLostLeadIds.includes(l.id);
      }
      return l.allowPromoBroadcast !== false;
    });

    if (targetList.length === 0) {
      if (showToast) showToast('warning', 'Tidak Ada Kontak', 'Tidak ada kontak lost yang mengizinkan promo.');
      return;
    }

    const phones = targetList
      .map((l) => {
        let clean = l.whatsAppNumber.replace(/[^0-9]/g, '');
        if (clean.startsWith('0')) clean = '62' + clean.substring(1);
        if (!clean.startsWith('62')) clean = '62' + clean;
        return clean;
      })
      .filter(Boolean);

    const textToCopy = format === 'comma' ? phones.join(', ') : phones.join('\n');
    navigator.clipboard.writeText(textToCopy);

    if (showToast) {
      showToast('success', 'Nomor WA Disalin!', `${phones.length} nomor WhatsApp kontak lost berhasil disalin.`);
    }
  };

  // WhatsApp Sender
  const handleOpenWhatsApp = (lead: Lead) => {
    let cleanPhone = lead.whatsAppNumber.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '62' + cleanPhone.substring(1);
    }
    if (!cleanPhone.startsWith('62')) {
      cleanPhone = '62' + cleanPhone;
    }

    const defaultMsg = `Halo Kak *${lead.guestName}*, salam hangat dari tim reservasi *${settings.businessName || 'Bukit Langit Campventure'}*. Mengingatkan kembali rencana menginap Kakak pada tanggal *${lead.plannedCheckInDate ? formatDateToIndonesian(lead.plannedCheckInDate) : '-'}*. Apakah ada persiapan kamar atau paket liburan yang ingin kami bantu?`;

    const encoded = encodeURIComponent(defaultMsg);
    window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
  };

  // Status helper badges
  const getStatusBadge = (status: LeadStatus) => {
    switch (status) {
      case 'New Lead':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></span>
            New Lead
          </span>
        );
      case 'Warm Inquiry':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Flame className="w-3.5 h-3.5 text-amber-600" />
            Warm Inquiry
          </span>
        );
      case 'Booking Confirmed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Booking Confirmed
          </span>
        );
      case 'Cancelled-Lost':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Cancelled / Lost
          </span>
        );
    }
  };

  // Overdue / Urgency tag calculation
  const getFollowUpUrgencyBadge = (nextDateStr?: string, status?: LeadStatus) => {
    if (status === 'Booking Confirmed') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 border border-emerald-200 px-2 py-0.5 rounded-full">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Closing Selesai
        </span>
      );
    }
    if (status === 'Cancelled-Lost') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-100/80 border border-rose-200 px-2 py-0.5 rounded-full">
          <XCircle className="w-3.5 h-3.5 text-rose-600" /> Lost
        </span>
      );
    }
    if (!nextDateStr) {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
          <Clock className="w-3 h-3" /> Belum dijadwalkan
        </span>
      );
    }

    if (nextDateStr < todayStr) {
      const diffMs = new Date(todayStr).getTime() - new Date(nextDateStr).getTime();
      const diffDays = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-700 bg-red-100 border border-red-300 px-2.5 py-0.5 rounded-full shadow-2xs animate-pulse">
          <AlertCircle className="w-3.5 h-3.5 text-red-600" /> JATUH TEMPO (Terlewat {diffDays} hari)
        </span>
      );
    }

    if (nextDateStr === todayStr) {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-full shadow-2xs animate-pulse">
          <Clock className="w-3.5 h-3.5 text-amber-600" /> JATUH TEMPO HARI INI
        </span>
      );
    }

    const diffMs = new Date(nextDateStr).getTime() - new Date(todayStr).getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
        <Calendar className="w-3 h-3 text-slate-500" /> Dalam {diffDays} hari ({formatDateToIndonesian(nextDateStr)})
      </span>
    );
  };

  // Follow-up handler with AUTO Next Date prefill
  const handleOpenFollowUpModal = (lead: Lead) => {
    setFollowUpModalLead(lead);
    setFollowUpResult(followUpResultsList[0] || '');
    setFollowUpNote('');

    // Auto schedule next date based on lead status & settings rules
    const autoNext = computeAutoNextFollowUpDate(lead, settings, new Date());
    setFollowUpNextDate(autoNext);
  };

  const handleSaveFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!followUpModalLead) return;

    try {
      const finalNextDate =
        followUpNextDate || computeAutoNextFollowUpDate(followUpModalLead, settings, new Date());

      await recordLeadFollowUp(
        followUpModalLead.id,
        {
          hasil: followUpResult,
          note: followUpNote,
          nextFollowUpDate: finalNextDate,
        },
        userEmail,
        userName
      );

      if (showToast) {
        showToast(
          'success',
          'Follow-up Dicatat',
          `Catatan follow-up untuk ${followUpModalLead.guestName} berhasil disimpan.`
        );
      }
      setFollowUpModalLead(null);
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Mencatat Follow-up', err.message || 'Terjadi kesalahan.');
      }
    }
  };

  // Status Change Handler
  const handleOpenStatusChangeModal = (lead: Lead, defaultStatus?: LeadStatus) => {
    setStatusChangeModalLead(lead);
    setTargetStatus(defaultStatus || (lead.leadStatus === 'New Lead' ? 'Warm Inquiry' : lead.leadStatus));
    setStatusReason('');
  };

  const handleSaveStatusChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusChangeModalLead) return;

    try {
      await updateLeadStatus(
        statusChangeModalLead.id,
        targetStatus,
        targetStatus === 'Cancelled-Lost' ? statusReason : statusReason || undefined,
        userEmail,
        userName
      );

      if (showToast) {
        showToast(
          'success',
          'Status Berhasil Diubah',
          `Status ${statusChangeModalLead.guestName} menjadi "${targetStatus}".`
        );
      }
      setStatusChangeModalLead(null);
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Mengubah Status', err.message || 'Terjadi kesalahan.');
      }
    }
  };

  // Quick Kanban Move
  const handleMoveKanban = async (leadId: string, newStatus: LeadStatus) => {
    try {
      await updateLeadStatus(leadId, newStatus, `Dipindahkan via Kanban ke ${newStatus}`, userEmail, userName);
      if (showToast) {
        showToast('success', 'Lead Dipindahkan', `Lead dipindahkan ke tahap ${newStatus}.`);
      }
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Memindahkan', err.message);
      }
    }
  };

  // Delete Lead
  const handleDeleteLeadConfirm = () => {
    if (!deleteModalLead) return;
    const target = deleteModalLead;
    const reason = deleteReason.trim();

    setDeleteModalLead(null);
    setDeleteReason('');
    if (showToast) {
      showToast('success', 'Lead Dihapus', `Data prospek ${target.guestName} telah dihapus.`);
    }

    deleteLead(target, userEmail, reason).catch((err: any) => {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Menghapus Lead', err?.message || 'Gagal sinkron ke server.');
      }
    });
  };

  // Form Lead Modal Open (Create or Edit)
  const handleOpenLeadForm = (leadToEdit?: Lead) => {
    if (leadToEdit) {
      setEditingLead({
        ...leadToEdit,
        allowPromoBroadcast: leadToEdit.allowPromoBroadcast !== undefined ? leadToEdit.allowPromoBroadcast : true,
      });
    } else {
      const newLeadId = `lead_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const defaultCheckIn = new Date();
      defaultCheckIn.setDate(defaultCheckIn.getDate() + 14);
      const checkInStr = formatDateForInput(defaultCheckIn);

      const templateObj: Partial<Lead> = {
        id: newLeadId,
        chatDate: todayStr,
        guestName: '',
        whatsAppNumber: '',
        campaignSource: campaignSourcesList[0] || 'Direct WA',
        plannedCheckInDate: checkInStr,
        bookingType: 'Personal',
        groupName: '',
        estimatedGuestCount: 2,
        leadStatus: 'New Lead',
        isTentative: false,
        follow_up_count: 0,
        allowPromoBroadcast: true,
        notes: '',
        picPerolehan: userName || userEmail.split('@')[0] || 'Sales Staff',
        activity_log: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      templateObj.next_follow_up_date = computeAutoNextFollowUpDate(templateObj, settings, new Date());
      setEditingLead(templateObj as Lead);
    }
    setIsFormModalOpen(true);
  };

  // Auto-calculate next follow up when check-in, tentative, or status changes in form
  const handleCheckInOrTentativeChange = (
    checkInDateStr: string,
    isTentativeVal: boolean,
    currentStatus?: LeadStatus
  ) => {
    if (!editingLead) return;

    const partialLead: Partial<Lead> = {
      ...editingLead,
      plannedCheckInDate: checkInDateStr,
      isTentative: isTentativeVal,
      leadStatus: currentStatus || editingLead.leadStatus,
    };

    const autoDate = computeAutoNextFollowUpDate(partialLead, settings, new Date());

    setEditingLead((prev) =>
      prev
        ? {
            ...prev,
            plannedCheckInDate: checkInDateStr,
            isTentative: isTentativeVal,
            next_follow_up_date: autoDate,
          }
        : null
    );
  };

  // Save Lead Form
  const handleSaveLeadForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLead || isSavingLead) return;

    if (!editingLead.guestName.trim()) {
      if (showToast) showToast('warning', 'Nama Tamu Wajib Diisi', 'Silakan masukkan nama tamu prospek.');
      return;
    }
    if (!editingLead.whatsAppNumber.trim()) {
      if (showToast) showToast('warning', 'Nomor WA Wajib Diisi', 'Silakan masukkan nomor WhatsApp aktif tamu.');
      return;
    }

    try {
      setIsSavingLead(true);
      const cleanLeadData: Lead = {
        ...editingLead,
        guestName: editingLead.guestName.trim(),
        whatsAppNumber: editingLead.whatsAppNumber.trim(),
        groupName: (editingLead.groupName || '').trim(),
        notes: (editingLead.notes || '').trim(),
        allowPromoBroadcast: editingLead.allowPromoBroadcast !== undefined ? editingLead.allowPromoBroadcast : true,
        next_follow_up_date:
          editingLead.next_follow_up_date || computeAutoNextFollowUpDate(editingLead, settings, new Date()),
      };

      await saveLead(cleanLeadData, userEmail, userName);
      if (showToast) {
        showToast('success', 'Data Prospek Disimpan', `Prospek ${cleanLeadData.guestName} berhasil disimpan ke sistem CRM.`);
      }
      setIsFormModalOpen(false);
      setEditingLead(null);
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Menyimpan Prospek', err.message || 'Terjadi kesalahan sistem.');
      }
    } finally {
      setIsSavingLead(false);
    }
  };

  // Kanban Column Definitions
  const kanbanColumns: { status: LeadStatus; title: string; color: string; border: string; bg: string }[] = [
    {
      status: 'New Lead',
      title: 'New Leads',
      color: 'text-blue-700',
      border: 'border-blue-300',
      bg: 'bg-blue-50/60',
    },
    {
      status: 'Warm Inquiry',
      title: 'Warm Inquiry (Negosiasi)',
      color: 'text-amber-700',
      border: 'border-amber-300',
      bg: 'bg-amber-50/60',
    },
    {
      status: 'Booking Confirmed',
      title: 'Booking Confirmed (Closing)',
      color: 'text-emerald-700',
      border: 'border-emerald-300',
      bg: 'bg-emerald-50/60',
    },
    {
      status: 'Cancelled-Lost',
      title: 'Cancelled / Lost',
      color: 'text-rose-700',
      border: 'border-rose-300',
      bg: 'bg-rose-50/60',
    },
  ];

  return (
    <div className="space-y-6">
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
              <Users className="w-7 h-7 text-emerald-600" />
              Leads & Reservasi CRM
            </h1>
            <span className="px-2.5 py-0.5 text-xs font-semibold bg-emerald-100 text-emerald-800 rounded-full border border-emerald-200">
              Jantung CRM
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Kelola prospek masuk, antrian follow-up otomatis, penawaran harga, dan database kontak lost untuk promo.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4 text-emerald-600" />
            <span>Import Excel/CSV</span>
          </button>
          <button
            onClick={() => handleOpenLeadForm()}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Tambah Prospek Baru
          </button>
        </div>
      </div>

      {/* METRICS / STATS CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {/* Total Leads */}
        <div
          onClick={() => {
            setActiveTab('all');
            setStatusFilter('all');
          }}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 shadow-xs flex items-center justify-between cursor-pointer transition-all"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Prospek</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{stats.total}</p>
            <p className="text-xs text-slate-400 mt-0.5">Semua data lead</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        {/* Follow-up Hari Ini / Overdue */}
        <div
          onClick={() => setActiveTab('today')}
          className={`bg-white p-4 rounded-xl border transition-all cursor-pointer shadow-xs flex items-center justify-between ${
            stats.todayDue > 0
              ? 'border-red-300 ring-2 ring-red-100 bg-red-50/30'
              : 'border-slate-200 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-medium text-red-600 uppercase tracking-wider">Jatuh Tempo</p>
              {stats.todayDue > 0 && <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>}
            </div>
            <p className="text-2xl font-bold text-red-700 mt-1">{stats.todayDue}</p>
            <p className="text-xs text-red-600/80 mt-0.5">Perlu follow-up</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Warm Inquiry */}
        <div
          onClick={() => {
            setActiveTab('queue');
            setStatusFilter('Warm Inquiry');
          }}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 shadow-xs flex items-center justify-between cursor-pointer transition-all"
        >
          <div>
            <p className="text-xs font-medium text-amber-600 uppercase tracking-wider">Warm Inquiry</p>
            <p className="text-2xl font-bold text-amber-700 mt-1">{stats.warm}</p>
            <p className="text-xs text-amber-600/80 mt-0.5">Tahap negosiasi</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center">
            <Flame className="w-5 h-5" />
          </div>
        </div>

        {/* Closing / Confirmed */}
        <div
          onClick={() => {
            setActiveTab('all');
            setStatusFilter('Booking Confirmed');
          }}
          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-slate-300 shadow-xs flex items-center justify-between cursor-pointer transition-all"
        >
          <div>
            <p className="text-xs font-medium text-emerald-600 uppercase tracking-wider">Closing</p>
            <div className="flex items-baseline gap-2 mt-1">
              <p className="text-2xl font-bold text-emerald-700">{stats.confirmed}</p>
              <span className="text-xs font-semibold text-emerald-600">({stats.conversionRate}%)</span>
            </div>
            <p className="text-xs text-emerald-600/80 mt-0.5">Booking confirmed</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Kontak Lost untuk Promo */}
        <div
          onClick={() => {
            setActiveTab('lost');
            setLostPromoFilter('all');
          }}
          className={`p-4 rounded-xl border transition-all cursor-pointer shadow-xs flex items-center justify-between ${
            activeTab === 'lost'
              ? 'border-purple-300 ring-2 ring-purple-100 bg-purple-50/40'
              : 'bg-white border-slate-200 hover:border-purple-200'
          }`}
        >
          <div>
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-bold text-purple-700 uppercase tracking-wider">Kontak Lost</p>
              <span className="w-2 h-2 rounded-full bg-purple-500"></span>
            </div>
            <div className="flex items-baseline gap-1.5 mt-1">
              <p className="text-2xl font-bold text-purple-900">{stats.lost}</p>
              <span className="text-xs font-semibold text-purple-700">({stats.lostEligiblePromo} promo)</span>
            </div>
            <p className="text-xs text-purple-600 mt-0.5">Database broadcast</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
            <Megaphone className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* TABS VIEW SWITCHER & FILTER BAR */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-4">
        {/* Top bar: Tabs + View Modes */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('queue')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'queue'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Clock className="w-4 h-4" />
              Antrian Follow-up
            </button>

            <button
              onClick={() => setActiveTab('today')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'today'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <AlertCircle className="w-4 h-4" />
              Jatuh Tempo ({stats.todayDue})
            </button>

            <button
              onClick={() => setActiveTab('kanban')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'kanban'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Columns className="w-4 h-4" />
              Papan Kanban
            </button>

            {/* TAB KHUSUS KONTAK LOST UNTUK PROMO */}
            <button
              onClick={() => setActiveTab('lost')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'lost'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-purple-700 hover:bg-purple-50 font-semibold'
              }`}
            >
              <Megaphone className="w-4 h-4 text-amber-300" />
              Kontak Lost & Promo ({stats.lost})
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <List className="w-4 h-4" />
              Semua Lead ({leads.length})
            </button>
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            Auto PIC dari user login: <strong className="text-slate-700">{userName || userEmail}</strong>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          {/* Search bar */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama tamu, WhatsApp, instansi/grup, alasan batal..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            />
          </div>

          {/* Status filter / Promo Filter */}
          {activeTab === 'lost' ? (
            <div>
              <select
                value={lostPromoFilter}
                onChange={(e) => setLostPromoFilter(e.target.value as any)}
                className="w-full px-3 py-2 bg-purple-50/70 border border-purple-200 rounded-lg text-sm font-semibold text-purple-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Semua Kontak Lost</option>
                <option value="allowed">Hanya Boleh Promo (Aktif)</option>
                <option value="disallowed">Jangan Hubungi Promo</option>
              </select>
            </div>
          ) : (
            <div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                disabled={activeTab === 'queue' || activeTab === 'today'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white disabled:opacity-60"
              >
                <option value="all">Semua Status</option>
                <option value="New Lead">New Lead</option>
                <option value="Warm Inquiry">Warm Inquiry</option>
                <option value="Booking Confirmed">Booking Confirmed</option>
                <option value="Cancelled-Lost">Cancelled / Lost</option>
              </select>
            </div>
          )}

          {/* Source filter */}
          <div>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            >
              <option value="all">Semua Sumber</option>
              {campaignSourcesList.map((src) => (
                <option key={src} value={src}>
                  {src}
                </option>
              ))}
            </select>
          </div>

          {/* PIC filter */}
          <div>
            <select
              value={picFilter}
              onChange={(e) => setPicFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            >
              <option value="all">Semua PIC</option>
              {allPics.map((pic) => (
                <option key={pic} value={pic}>
                  {pic}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* BULK ACTIONS BAR (When on 'lost' tab or items are selected) */}
        {activeTab === 'lost' && (
          <div className="bg-purple-50/80 border border-purple-200 p-3 rounded-xl flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleSelectAllLost}
                className="flex items-center gap-1.5 text-xs font-bold text-purple-900 hover:text-purple-700 cursor-pointer"
              >
                {selectedLostLeadIds.length > 0 && selectedLostLeadIds.length === sortedLeads.length ? (
                  <CheckSquare className="w-4 h-4 text-purple-700" />
                ) : (
                  <Square className="w-4 h-4 text-purple-400" />
                )}
                <span>
                  {selectedLostLeadIds.length > 0
                    ? `${selectedLostLeadIds.length} dari ${sortedLeads.length} Terpilih`
                    : `Pilih Semua (${sortedLeads.length})`}
                </span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setIsPromoBroadcastModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
              >
                <Megaphone className="w-3.5 h-3.5" />
                <span>Broadcast Promo WA</span>
              </button>

              <button
                type="button"
                onClick={() => handleCopyLostPhones('comma')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-purple-300 hover:bg-purple-100/60 text-purple-800 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-purple-600" />
                <span>Salin No. WA</span>
              </button>

              <button
                type="button"
                onClick={handleExportLostContactsCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-purple-300 hover:bg-purple-100/60 text-purple-800 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-purple-600" />
                <span>Ekspor CSV</span>
              </button>

              {selectedLostLeadIds.length > 0 && (
                <div className="flex items-center gap-1.5 pl-2 border-l border-purple-200">
                  <button
                    type="button"
                    onClick={() => handleBatchTogglePromoStatus(true)}
                    className="px-2.5 py-1 bg-emerald-100 text-emerald-800 hover:bg-emerald-200 rounded text-xs font-semibold cursor-pointer"
                  >
                    Boleh Promo (Bulk)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBatchTogglePromoStatus(false)}
                    className="px-2.5 py-1 bg-rose-100 text-rose-800 hover:bg-rose-200 rounded text-xs font-semibold cursor-pointer"
                  >
                    Jangan Promo (Bulk)
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* CONTENT VIEWS */}
      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto mb-3" />
          <p className="text-slate-600 font-medium">Memuat data leads realtime...</p>
        </div>
      ) : activeTab === 'kanban' ? (
        /* KANBAN BOARD VIEW */
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
          {kanbanColumns.map((col) => {
            const columnLeads = filteredLeads.filter((l) => l.leadStatus === col.status);
            return (
              <div
                key={col.status}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (draggedLeadId) {
                    handleMoveKanban(draggedLeadId, col.status);
                    setDraggedLeadId(null);
                  }
                }}
                className={`rounded-xl border ${col.border} ${col.bg} p-3 min-h-[500px] flex flex-col`}
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200/60">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-bold ${col.color}`}>{col.title}</span>
                    <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-white/80 text-slate-700 shadow-2xs">
                      {columnLeads.length}
                    </span>
                  </div>
                </div>

                {/* Lead cards list */}
                <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
                  {columnLeads.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-400 border border-dashed border-slate-300 rounded-lg bg-white/50">
                      Tidak ada lead di kolom ini
                    </div>
                  ) : (
                    columnLeads.map((lead) => (
                      <div
                        key={lead.id}
                        draggable
                        onDragStart={() => setDraggedLeadId(lead.id)}
                        className="bg-white rounded-lg p-3.5 border border-slate-200 shadow-2xs hover:shadow-xs transition-all space-y-2.5 cursor-grab active:cursor-grabbing"
                      >
                        {/* Top: Name & Type */}
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="font-bold text-slate-800 text-sm">{lead.guestName}</h4>
                            {lead.groupName && (
                              <p className="text-xs text-emerald-700 font-medium">🏢 {lead.groupName}</p>
                            )}
                          </div>
                          {lead.isTentative && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                              Tentatif
                            </span>
                          )}
                        </div>

                        {/* Dates & Source */}
                        <div className="text-xs text-slate-500 space-y-1 bg-slate-50 p-2 rounded">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400">Rencana Inap:</span>
                            <span className="font-medium text-slate-700">
                              {lead.plannedCheckInDate ? formatDateToIndonesian(lead.plannedCheckInDate) : '-'}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400">Sumber:</span>
                            <span className="font-medium text-slate-700">{lead.campaignSource}</span>
                          </div>
                        </div>

                        {/* Follow up status badge */}
                        <div className="flex items-center justify-between pt-1">
                          {getFollowUpUrgencyBadge(lead.next_follow_up_date, lead.leadStatus)}
                          <span className="text-[11px] text-slate-400 font-medium">
                            {lead.follow_up_count || 0}× FU
                          </span>
                        </div>

                        {/* Actions */}
                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1">
                          <button
                            onClick={() => handleOpenWhatsApp(lead)}
                            className="flex-1 py-1 px-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                            title="Chat WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            WA
                          </button>

                          <button
                            onClick={() => handleOpenFollowUpModal(lead)}
                            className="flex-1 py-1 px-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                            title="Catat Follow-up"
                          >
                            <Clock className="w-3.5 h-3.5" />
                            FU
                          </button>

                          <button
                            onClick={() => setTimelineModalLead(lead)}
                            className="p-1 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                            title="Histori Log"
                          >
                            <History className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleOpenLeadForm(lead)}
                            className="p-1 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* CARD / TABLE LIST VIEW */
        <div className="space-y-3">
          {sortedLeads.length === 0 ? (
            <div className="bg-white p-12 rounded-xl border border-slate-200 text-center">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-700">
                {activeTab === 'lost' ? 'Tidak Ada Kontak Lost' : 'Tidak Ada Data Lead'}
              </h3>
              <p className="text-sm text-slate-400 mt-1 max-w-md mx-auto">
                {activeTab === 'lost'
                  ? 'Belum ada lead yang berstatus Cancelled/Lost atau cocok dengan filter promo saat ini.'
                  : searchQuery || statusFilter !== 'all' || sourceFilter !== 'all'
                  ? 'Tidak ada lead yang cocok dengan filter atau pencarian Anda.'
                  : 'Belum ada data prospek reservasi. Klik "Tambah Prospek Baru" untuk memulai.'}
              </p>
              {activeTab !== 'lost' && (
                <button
                  onClick={() => handleOpenLeadForm()}
                  className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Tambah Prospek Sekarang
                </button>
              )}
            </div>
          ) : (
            sortedLeads.map((lead) => {
              const latestActivity =
                lead.activity_log && lead.activity_log.length > 0 ? lead.activity_log[0] : null;

              const isSelected = selectedLostLeadIds.includes(lead.id);
              const isPromoAllowed = lead.allowPromoBroadcast !== false;

              return (
                <div
                  key={lead.id}
                  className={`bg-white rounded-xl border p-5 shadow-2xs hover:shadow-xs transition-all space-y-4 ${
                    lead.leadStatus === 'Booking Confirmed'
                      ? 'border-emerald-200 bg-emerald-50/10'
                      : lead.leadStatus === 'Cancelled-Lost'
                      ? activeTab === 'lost'
                        ? 'border-purple-200 bg-purple-50/20'
                        : 'border-rose-200 bg-rose-50/10'
                      : lead.next_follow_up_date && lead.next_follow_up_date <= todayStr
                      ? 'border-red-300 ring-1 ring-red-200 bg-red-50/10'
                      : 'border-slate-200'
                  }`}
                >
                  {/* Top Row: Guest Info & Status */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      {/* Checkbox for Lost multi-select */}
                      {activeTab === 'lost' && (
                        <button
                          type="button"
                          onClick={() => handleToggleSelectLead(lead.id)}
                          className="mt-1 cursor-pointer"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-5 h-5 text-purple-700" />
                          ) : (
                            <Square className="w-5 h-5 text-slate-300 hover:text-purple-500" />
                          )}
                        </button>
                      )}

                      <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-base shrink-0 mt-0.5">
                        {lead.guestName.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-bold text-slate-800 text-base">{lead.guestName}</h3>
                          {getStatusBadge(lead.leadStatus)}
                          {lead.isTentative && (
                            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                              Tentatif (H-{daysTentative})
                            </span>
                          )}
                          <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                            {lead.bookingType === 'Grup' ? `Grup (${lead.estimatedGuestCount || 0} Tamu)` : 'Personal'}
                          </span>

                          {/* Penanda Izin Promo Khusus */}
                          {lead.leadStatus === 'Cancelled-Lost' && (
                            <button
                              type="button"
                              onClick={() => handleTogglePromoStatus(lead)}
                              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold border transition-colors cursor-pointer ${
                                isPromoAllowed
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                                  : 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                              }`}
                              title="Klik untuk mengubah status izin broadcast promo"
                            >
                              {isPromoAllowed ? (
                                <>
                                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                                  <span>Boleh Promo (Aktif)</span>
                                </>
                              ) : (
                                <>
                                  <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                                  <span>Jangan Hubungi Promo</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1">
                          <span className="flex items-center gap-1 font-mono text-slate-700 font-semibold">
                            <Phone className="w-3.5 h-3.5 text-slate-400" />
                            {lead.whatsAppNumber}
                          </span>
                          {lead.groupName && (
                            <span className="font-semibold text-emerald-700">🏢 {lead.groupName}</span>
                          )}
                          <span className="text-slate-400">
                            Sumber: <strong className="text-slate-600">{lead.campaignSource}</strong>
                          </span>
                          <span className="text-slate-400">
                            Chat Masuk: {formatDateToIndonesian(lead.chatDate || lead.createdAt)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Follow up Urgency Pill */}
                    <div className="flex items-center gap-2 shrink-0">
                      {getFollowUpUrgencyBadge(lead.next_follow_up_date, lead.leadStatus)}
                      <span className="text-xs font-semibold px-2 py-0.5 bg-slate-100 text-slate-600 rounded">
                        FU: {lead.follow_up_count || 0}×
                      </span>
                    </div>
                  </div>

                  {/* Middle Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50/80 p-3.5 rounded-lg text-xs">
                    {/* Stay & Next Schedule details */}
                    <div>
                      <span className="text-slate-400 block mb-0.5">Rencana Check-In:</span>
                      <p className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                        {lead.plannedCheckInDate ? formatDateToIndonesian(lead.plannedCheckInDate) : 'Belum pasti'}
                      </p>
                      <span className="text-slate-400 block mt-1.5 mb-0.5">Jadwal Follow-Up Berikutnya:</span>
                      <p className="font-semibold text-slate-800 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        {lead.next_follow_up_date ? formatDateToIndonesian(lead.next_follow_up_date) : '-'}
                      </p>
                    </div>

                    {/* PIC Attribution */}
                    <div>
                      <span className="text-slate-400 block mb-0.5">Penanggung Jawab (PIC):</span>
                      <p className="text-slate-700">
                        • Perolehan: <strong>{lead.picPerolehan || '-'}</strong>
                      </p>
                      <p className="text-slate-700 mt-0.5">
                        • Terakhir FU: <strong>{lead.picFollowUp || '-'}</strong>
                      </p>
                      {lead.picClosing && (
                        <p className="text-emerald-700 font-semibold mt-0.5">
                          • Closing: <strong>{lead.picClosing}</strong>
                        </p>
                      )}
                    </div>

                    {/* Latest Activity / Lost Reason */}
                    <div>
                      <span className="text-slate-400 block mb-0.5">Aktivitas Terakhir:</span>
                      {latestActivity ? (
                        <p className="text-slate-700 line-clamp-2">
                          <strong className="text-slate-900">{latestActivity.by_name || latestActivity.by}:</strong>{' '}
                          {latestActivity.hasil ? `"${latestActivity.hasil}"` : latestActivity.note || 'Pembaruan data'}
                        </p>
                      ) : (
                        <p className="text-slate-400 italic">Belum ada catatan aktivitas.</p>
                      )}
                      {lead.lost_reason && (
                        <div className="mt-1.5 p-1.5 bg-rose-50 border border-rose-200 rounded text-rose-700">
                          <strong>Alasan Lost:</strong> {lead.lost_reason}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Bottom Action Bar */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
                    <div className="flex flex-wrap items-center gap-2">
                      {/* WhatsApp Button */}
                      <button
                        onClick={() => handleOpenWhatsApp(lead)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        Chat WA
                      </button>

                      {/* Catat Follow-up */}
                      <button
                        onClick={() => handleOpenFollowUpModal(lead)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        Catat Follow-up
                      </button>

                      {/* Ubah Status */}
                      <button
                        onClick={() => handleOpenStatusChangeModal(lead)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        Ubah Status
                      </button>

                      {/* Tandai Lost */}
                      {lead.leadStatus !== 'Cancelled-Lost' && (
                        <button
                          onClick={() => handleOpenStatusChangeModal(lead, 'Cancelled-Lost')}
                          className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          Tandai Lost
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Timeline modal */}
                      <button
                        onClick={() => setTimelineModalLead(lead)}
                        className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      >
                        <History className="w-3.5 h-3.5" />
                        Timeline ({lead.activity_log?.length || 0})
                      </button>

                      {/* Edit lead */}
                      <button
                        onClick={() => handleOpenLeadForm(lead)}
                        className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        title="Edit Prospek"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      {/* Delete lead */}
                      <button
                        onClick={() => {
                          setDeleteModalLead(lead);
                          setDeleteReason('');
                        }}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="Hapus Prospek"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* MODAL 1: ADD / EDIT LEAD FORM */}
      {isFormModalOpen && editingLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-600" />
                {editingLead.id.startsWith('lead_') && editingLead.follow_up_count === 0
                  ? 'Tambah Prospek Reservasi Baru'
                  : 'Edit Data Prospek'}
              </h3>
              <button
                onClick={() => {
                  setIsFormModalOpen(false);
                  setEditingLead(null);
                }}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveLeadForm} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Guest Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Tamu / Pemesan <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Bpk. Bambang / Ibu Rina"
                    value={editingLead.guestName}
                    onChange={(e) =>
                      setEditingLead({ ...editingLead, guestName: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* WhatsApp Number */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nomor WhatsApp / Telp <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 081234567890"
                    value={editingLead.whatsAppNumber}
                    onChange={(e) =>
                      setEditingLead({ ...editingLead, whatsAppNumber: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Campaign Source */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Sumber Perolehan (Campaign Source)
                  </label>
                  <select
                    value={editingLead.campaignSource}
                    onChange={(e) =>
                      setEditingLead({ ...editingLead, campaignSource: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  >
                    {campaignSourcesList.map((src) => (
                      <option key={src} value={src}>
                        {src}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Chat Date */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal Chat Masuk
                  </label>
                  <input
                    type="date"
                    value={editingLead.chatDate || todayStr}
                    onChange={(e) => {
                      const newChatDate = e.target.value;
                      setEditingLead((prev) => {
                        if (!prev) return null;
                        const updated = { ...prev, chatDate: newChatDate };
                        updated.next_follow_up_date = computeAutoNextFollowUpDate(updated, settings, new Date(newChatDate));
                        return updated;
                      });
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                {/* Booking Type */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tipe Booking
                  </label>
                  <select
                    value={editingLead.bookingType}
                    onChange={(e) =>
                      setEditingLead({
                        ...editingLead,
                        bookingType: e.target.value as BookingType,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
                  >
                    <option value="Personal">Personal / Keluarga (FIT)</option>
                    <option value="Grup">Grup / Instansi / Event</option>
                  </select>
                </div>

                {/* Lead Status */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Lead Saat Ini
                  </label>
                  <select
                    value={editingLead.leadStatus}
                    onChange={(e) => {
                      const newStatus = e.target.value as LeadStatus;
                      handleCheckInOrTentativeChange(
                        editingLead.plannedCheckInDate,
                        editingLead.isTentative,
                        newStatus
                      );
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold"
                  >
                    <option value="New Lead">New Lead</option>
                    <option value="Warm Inquiry">Warm Inquiry</option>
                    <option value="Booking Confirmed">Booking Confirmed</option>
                    <option value="Cancelled-Lost">Cancelled / Lost</option>
                  </select>
                </div>
              </div>

              {/* Group specific fields */}
              {editingLead.bookingType === 'Grup' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-emerald-50/50 p-3 rounded-lg border border-emerald-100">
                  <div>
                    <label className="block text-xs font-semibold text-emerald-800 mb-1">
                      Nama Instansi / Komunitas / EO
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: PT. Sumber Makmur / Komunitas Gowes"
                      value={editingLead.groupName || ''}
                      onChange={(e) =>
                        setEditingLead({ ...editingLead, groupName: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-emerald-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-emerald-800 mb-1">
                      Estimasi Jumlah Peserta (Pax)
                    </label>
                    <input
                      type="number"
                      min="1"
                      placeholder="Contoh: 35"
                      value={editingLead.estimatedGuestCount || ''}
                      onChange={(e) =>
                        setEditingLead({
                          ...editingLead,
                          estimatedGuestCount: parseInt(e.target.value, 10) || 0,
                        })
                      }
                      className="w-full px-3 py-2 border border-emerald-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Planned Check In Date + Tentative Switch */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Rencana Tanggal Check-In
                    </label>
                    <input
                      type="date"
                      value={editingLead.plannedCheckInDate || ''}
                      disabled={editingLead.isTentative}
                      onChange={(e) =>
                        handleCheckInOrTentativeChange(e.target.value, editingLead.isTentative)
                      }
                      className={`w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 ${
                        editingLead.isTentative
                          ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                          : 'bg-white'
                      }`}
                    />
                    {editingLead.isTentative && (
                      <p className="text-[11px] text-slate-400 mt-1">
                        Terkunci karena lead ini <b>tentatif</b>. Hilangkan centang Tentatif untuk
                        mengisi tanggal.
                      </p>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-semibold text-slate-700">
                        Jadwal Follow-Up Berikutnya
                      </label>
                      <button
                        type="button"
                        onClick={() => {
                          const autoVal = computeAutoNextFollowUpDate(editingLead, settings, new Date());
                          setEditingLead({ ...editingLead, next_follow_up_date: autoVal });
                        }}
                        className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                      >
                        ⚡ Hitung Ulang Otomatis
                      </button>
                    </div>
                    <input
                      type="date"
                      value={editingLead.next_follow_up_date || ''}
                      onChange={(e) =>
                        setEditingLead({ ...editingLead, next_follow_up_date: e.target.value })
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 bg-white font-semibold text-amber-900"
                    />
                  </div>
                </div>

                {/* Tentative toggle */}
                <div className="flex items-center gap-3 pt-2">
                  <input
                    type="checkbox"
                    id="isTentativeCheckbox"
                    checked={editingLead.isTentative}
                    onChange={(e) =>
                      handleCheckInOrTentativeChange(editingLead.plannedCheckInDate, e.target.checked)
                    }
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                  />
                  <label htmlFor="isTentativeCheckbox" className="text-xs text-slate-700 cursor-pointer">
                    <strong>Tandai sebagai Booking Tentatif</strong> (Jadwal follow-up otomatis H+{daysTentative} hari setelah input/chat)
                  </label>
                </div>
              </div>

              {/* Promo Broadcast Permission Switch */}
              <div className="bg-purple-50/60 p-3.5 rounded-xl border border-purple-200 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                    <Megaphone className="w-4 h-4 text-purple-600" />
                    Izin Broadcast Promo & Penawaran
                  </p>
                  <p className="text-[11px] text-purple-700/80 mt-0.5">
                    Jika status menjadi Cancelled/Lost, kontak ini tetap dapat menerima broadcast voucher & diskon.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingLead.allowPromoBroadcast !== false}
                    onChange={(e) =>
                      setEditingLead({ ...editingLead, allowPromoBroadcast: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-700"></div>
                </label>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Catatan Kebutuhan / Permintaan Khusus Tamu
                </label>
                <textarea
                  rows={2}
                  placeholder="Contoh: Menanyakan glamping 2 tenda + paket BBQ & ATV adventure untuk weekend..."
                  value={editingLead.notes || ''}
                  onChange={(e) => setEditingLead({ ...editingLead, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsFormModalOpen(false);
                    setEditingLead(null);
                  }}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSavingLead}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer inline-flex items-center gap-2"
                >
                  {isSavingLead && (
                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  )}
                  <span>{isSavingLead ? 'Menyimpan...' : 'Simpan Data Prospek'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CATAT FOLLOW-UP */}
      {followUpModalLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  Catat Follow-Up: {followUpModalLead.guestName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Follow-up ke-{(followUpModalLead.follow_up_count || 0) + 1} • PIC: {userName || userEmail}
                </p>
              </div>
              <button
                onClick={() => setFollowUpModalLead(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveFollowUp} className="space-y-4">
              {/* Hasil Follow Up Dropdown */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Hasil / Respon Follow-Up <span className="text-red-500">*</span>
                </label>
                <select
                  value={followUpResult}
                  onChange={(e) => setFollowUpResult(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 bg-white"
                >
                  {followUpResultsList.map((res) => (
                    <option key={res} value={res}>
                      {res}
                    </option>
                  ))}
                </select>
              </div>

              {/* Additional notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Catatan Rincian Follow-Up (Opsional)
                </label>
                <textarea
                  rows={3}
                  placeholder="Tuliskan detail respon tamu, negosiasi harga, atau request khusus..."
                  value={followUpNote}
                  onChange={(e) => setFollowUpNote(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Next Follow Up Date with Auto-calculation Helper */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700">
                    Jadwal Follow-Up Berikutnya (Terisi Otomatis)
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const autoNext = computeAutoNextFollowUpDate(followUpModalLead, settings, new Date());
                      setFollowUpNextDate(autoNext);
                    }}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
                  >
                    ⚡ Hitung Sesuai Aturan
                  </button>
                </div>
                <input
                  type="date"
                  value={followUpNextDate}
                  onChange={(e) => setFollowUpNextDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 bg-white font-semibold text-slate-900"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  {followUpModalLead.isTentative
                    ? `Aturan: +${daysTentative} hari setelah follow-up untuk booking tentatif.`
                    : followUpModalLead.plannedCheckInDate
                    ? `Aturan: -${daysConfirmed} hari sebelum tanggal check-in (${formatDateToIndonesian(followUpModalLead.plannedCheckInDate)}).`
                    : `Aturan: +${daysTentative} hari berikutnya.`}
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setFollowUpModalLead(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Simpan Catatan Follow-Up
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: UBAH STATUS / TANDAI LOST */}
      {statusChangeModalLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <ArrowRight className="w-5 h-5 text-indigo-600" />
                Ubah Status Prospek
              </h3>
              <button
                onClick={() => setStatusChangeModalLead(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveStatusChange} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Pilih Status Baru
                </label>
                <select
                  value={targetStatus}
                  onChange={(e) => setTargetStatus(e.target.value as LeadStatus)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 bg-white font-semibold"
                >
                  <option value="New Lead">New Lead</option>
                  <option value="Warm Inquiry">Warm Inquiry</option>
                  <option value="Booking Confirmed">Booking Confirmed (Closing)</option>
                  <option value="Cancelled-Lost">Cancelled / Lost</option>
                </select>
              </div>

              {/* If Lost, select reason */}
              {targetStatus === 'Cancelled-Lost' ? (
                <div>
                  <label className="block text-xs font-semibold text-rose-700 mb-1">
                    Alasan Pembatalan / Lost <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    value={statusReason}
                    onChange={(e) => setStatusReason(e.target.value)}
                    className="w-full px-3 py-2 border border-rose-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500 bg-white"
                  >
                    <option value="">-- Pilih Alasan Lost --</option>
                    {lostReasonsList.map((reason) => (
                      <option key={reason} value={reason}>
                        {reason}
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-purple-700 mt-1">
                    💡 Lead berstatus Lost akan otomatis tersimpan di tab <strong>Kontak Lost</strong> untuk broadcast promo.
                  </p>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Catatan Perubahan Status (Opsional)
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Tamu setuju penawaran, lanjut pembuatan invoice..."
                    value={statusReason}
                    onChange={(e) => setStatusReason(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStatusChangeModalLead(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer ${
                    targetStatus === 'Cancelled-Lost'
                      ? 'bg-rose-600 hover:bg-rose-700'
                      : 'bg-indigo-600 hover:bg-indigo-700'
                  }`}
                >
                  Simpan Status Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: ACTIVITY LOG TIMELINE */}
      {timelineModalLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                  <History className="w-5 h-5 text-emerald-600" />
                  Timeline Log: {timelineModalLead.guestName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Rekam jejak interaksi & follow-up (Append-Only)
                </p>
              </div>
              <button
                onClick={() => setTimelineModalLead(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 max-h-[450px] overflow-y-auto pr-2 py-2">
              {!timelineModalLead.activity_log || timelineModalLead.activity_log.length === 0 ? (
                <p className="text-center text-sm text-slate-400 py-6">Belum ada riwayat aktivitas.</p>
              ) : (
                timelineModalLead.activity_log.map((act, index) => {
                  return (
                    <div key={act.id || index} className="flex gap-3 text-xs relative pb-2">
                      {index < timelineModalLead.activity_log.length - 1 && (
                        <div className="absolute left-3.5 top-6 bottom-0 w-0.5 bg-slate-200" />
                      )}

                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10 ${
                          act.type === 'created'
                            ? 'bg-blue-100 text-blue-700'
                            : act.type === 'closing'
                            ? 'bg-emerald-100 text-emerald-700'
                            : act.type === 'lost'
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}
                      >
                        {act.type === 'created' && <Plus className="w-3.5 h-3.5" />}
                        {act.type === 'closing' && <CheckCircle2 className="w-3.5 h-3.5" />}
                        {act.type === 'lost' && <XCircle className="w-3.5 h-3.5" />}
                        {act.type === 'follow_up' && <Clock className="w-3.5 h-3.5" />}
                        {act.type === 'status_change' && <ArrowRight className="w-3.5 h-3.5" />}
                      </div>

                      <div className="flex-1 bg-slate-50 p-3 rounded-lg border border-slate-100">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="font-bold text-slate-800">
                            {act.type === 'created' && 'Lead Baru Dibuat'}
                            {act.type === 'follow_up' && `Follow-Up ke-${act.followup_no || index + 1}`}
                            {act.type === 'closing' && 'Booking Confirmed (Closing)'}
                            {act.type === 'lost' && `Tandai Lost (${act.reason || 'Dibatalkan'})`}
                            {act.type === 'status_change' && `Status Diubah: ${act.to_status}`}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {act.ts ? new Date(act.ts).toLocaleString('id-ID') : '-'}
                          </span>
                        </div>

                        {act.hasil && (
                          <p className="font-medium text-slate-700 mt-0.5">
                            Hasil: <span className="text-slate-900">"{act.hasil}"</span>
                          </p>
                        )}

                        {act.note && <p className="text-slate-600 mt-0.5 italic">{act.note}</p>}

                        <div className="mt-2 text-[10px] text-slate-400 flex items-center justify-between border-t border-slate-200/50 pt-1">
                          <span>
                            Oleh: <strong>{act.by_name || act.by}</strong>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                onClick={() => setTimelineModalLead(null)}
                className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-semibold cursor-pointer hover:bg-slate-900"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: DELETE CONFIRMATION */}
      {deleteModalLead && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-slate-800">Hapus Data Prospek?</h3>
              <p className="text-sm text-slate-500">
                Data prospek <strong>{deleteModalLead.guestName}</strong> ({deleteModalLead.whatsAppNumber}) akan dihapus dan dicatat ke riwayat penghapusan (Audit History).
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Alasan Penghapusan (Opsional)
              </label>
              <input
                type="text"
                placeholder="Contoh: Duplikat data / Nomor salah..."
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setDeleteModalLead(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteLeadConfirm}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Ya, Hapus Prospek
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: BROADCAST PROMO TO LOST CONTACTS */}
      {isPromoBroadcastModalOpen && (
        <BroadcastPromoModal
          isOpen={isPromoBroadcastModalOpen}
          onClose={() => setIsPromoBroadcastModalOpen(false)}
          leads={
            selectedLostLeadIds.length > 0
              ? leads.filter((l) => selectedLostLeadIds.includes(l.id))
              : leads.filter((l) => l.leadStatus === 'Cancelled-Lost')
          }
          settings={settings}
          showToast={showToast}
        />
      )}

      {/* Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          moduleKey="leads"
          moduleTitle="Leads & Prospek CRM"
        />
      )}
    </div>
  );
};
export default LeadManagementView;
