import React, { useState, useMemo } from 'react';
import { Lead, BusinessSettings } from '../../types/document';
import {
  MessageCircle,
  Copy,
  Check,
  Send,
  Download,
  Search,
  Sparkles,
  Users,
  CheckCircle2,
  XCircle,
  Megaphone,
  X,
  ExternalLink,
} from 'lucide-react';
import { formatDateForInput } from '../../utils/formatter';

interface BroadcastPromoModalProps {
  isOpen: boolean;
  onClose: () => void;
  leads: Lead[];
  settings: BusinessSettings;
  showToast?: (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => void;
}

interface PromoTemplate {
  id: string;
  title: string;
  category: string;
  badge: string;
  text: string;
}

export const BroadcastPromoModal: React.FC<BroadcastPromoModalProps> = ({
  isOpen,
  onClose,
  leads,
  settings,
  showToast,
}) => {
  const bizName = settings.businessName || 'Bukit Langit Campventure';
  const bizPhone = settings.phone || '0812-5905-1120';

  const defaultTemplates: PromoTemplate[] = useMemo(
    () => [
      {
        id: 'tpl-flash-sale',
        title: 'Flash Sale Staycation & Liburan',
        category: 'Diskon Menginap',
        badge: 'Diskon 25%',
        text: `Halo Kak *{{nama}}*! 🌿\n\nAda kabar gembira dari *${bizName}*. Khusus minggu ini, kami menghadirkan promo *FLASH SALE STAYCATION* diskon up to 25% untuk tenda glamping & villa exclusive!\n\n✨ Fasilitas include:\n- Sarapan Pagi 2 Pax\n- Welcome Drink & Api Unggun\n- Akses Panorama Alam & Spot Foto Estetik\n\nYuk amankan tanggal liburan Kakak sebelum kuota penuh! Balas pesan ini untuk klaim voucher promonya ya Kak. Salam hangat dari tim kami! 🙏`,
      },
      {
        id: 'tpl-gathering-bbq',
        title: 'Paket Gathering, BBQ & Outbound',
        category: 'Paket Komunitas',
        badge: 'Spesial Grup',
        text: `Halo Kak *{{nama}}*, salam hangat dari *${bizName}*! 🏕️🔥\n\nSedang merencanakan acara gathering, reuni, atau liburan seru bareng rombongan/keluarga besar? Kami punya penawaran *PAKET SPESIAL GATHERING + FREE BBQ DINNER* untuk pemesanan bulan ini.\n\n🎯 Fasilitas lengkap:\n- Akomodasi Glamping Nyaman\n- BBQ Dinner & Api Unggun Syahdu\n- Pilihan Aktivitas ATV Adventure & Outbound Seru\n\nSilakan balas pesan ini jika Kakak ingin kami kirimkan proposal paket & simulasi budgetnya ya! 😊`,
      },
      {
        id: 'tpl-early-bird',
        title: 'Early Bird Liburan Panjang / Akhir Tahun',
        category: 'Early Bird',
        badge: 'Hemat',
        text: `Halo Kak *{{nama}}*! ✨\n\nKangen suasana sejuk pegunungan dan sunrise indah? *${bizName}* membuka promo *EARLY BIRD BOOKING* dengan harga khusus dan jaminan ketersediaan kamar pilihan.\n\nJangan sampai kehabisan slot di tanggal favorit Kakak. Dapatkan bonus welcome snack & free voucher ATV untuk setiap reservasi minggu ini!\n\nInfo & reservasi: ${bizPhone}\nKetik *PROMO* untuk respon cepat dari admin reservasi kami. Ditunggu kedatangannya Kak! 🌄`,
      },
      {
        id: 'tpl-custom',
        title: 'Template Pesan Kustom (Bebas Edit)',
        category: 'Kustom',
        badge: 'Manual',
        text: `Halo Kak *{{nama}}*, salam hangat dari *${bizName}*! Ada penawaran spesial untuk rencana liburan Kakak...`,
      },
    ],
    [bizName, bizPhone]
  );

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(defaultTemplates[0].id);
  const [messageTemplate, setMessageTemplate] = useState<string>(defaultTemplates[0].text);
  const [filterQuery, setFilterQuery] = useState('');
  const [copiedType, setCopiedType] = useState<'text' | 'phones_comma' | 'phones_lines' | null>(null);

  if (!isOpen) return null;

  // Filter out contacts that disallowed promo by default, but allow user to toggle view
  const eligibleLeads = leads.filter((l) => l.allowPromoBroadcast !== false);
  const ineligibleLeads = leads.filter((l) => l.allowPromoBroadcast === false);

  const displayedLeads = eligibleLeads.filter((l) => {
    if (!filterQuery.trim()) return true;
    const q = filterQuery.toLowerCase();
    return (
      l.guestName.toLowerCase().includes(q) ||
      l.whatsAppNumber.includes(q) ||
      l.groupName?.toLowerCase().includes(q)
    );
  });

  const handleSelectTemplate = (tpl: PromoTemplate) => {
    setSelectedTemplateId(tpl.id);
    setMessageTemplate(tpl.text);
  };

  const cleanPhone = (phoneStr: string) => {
    let clean = phoneStr.replace(/[^0-9]/g, '');
    if (clean.startsWith('0')) clean = '62' + clean.substring(1);
    if (!clean.startsWith('62')) clean = '62' + clean;
    return clean;
  };

  const getPersonalizedMessage = (guestName: string) => {
    return messageTemplate
      .replace(/{{nama}}/g, guestName || 'Kak')
      .replace(/{{bisnis}}/g, bizName)
      .replace(/{{telepon}}/g, bizPhone);
  };

  const handleSendDirectWa = (lead: Lead) => {
    const phone = cleanPhone(lead.whatsAppNumber);
    const msg = getPersonalizedMessage(lead.guestName);
    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank');
  };

  const handleCopyText = (text: string, type: 'text' | 'phones_comma' | 'phones_lines') => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
    if (showToast) {
      showToast('success', 'Berhasil Disalin', 'Teks berhasil disalin ke clipboard.');
    }
  };

  const handleCopyAllPhones = (separator: ',' | '\n') => {
    const phones = eligibleLeads.map((l) => cleanPhone(l.whatsAppNumber)).filter(Boolean);
    if (phones.length === 0) {
      if (showToast) showToast('warning', 'Tidak Ada Nomor', 'Tidak ada nomor WhatsApp yang boleh promo.');
      return;
    }
    const text = separator === ',' ? phones.join(', ') : phones.join('\n');
    handleCopyText(text, separator === ',' ? 'phones_comma' : 'phones_lines');
  };

  const handleDownloadCsv = () => {
    if (eligibleLeads.length === 0) {
      if (showToast) showToast('warning', 'Tidak Ada Kontak', 'Tidak ada kontak untuk diekspor.');
      return;
    }

    const headers = ['Nama Tamu', 'Nomor WhatsApp', 'Sumber Lead', 'Rencana Inap', 'Alasan Batal', 'Catatan'];
    const rows = eligibleLeads.map((l) => [
      `"${(l.guestName || '').replace(/"/g, '""')}"`,
      `"${cleanPhone(l.whatsAppNumber)}"`,
      `"${(l.campaignSource || '').replace(/"/g, '""')}"`,
      `"${l.plannedCheckInDate || ''}"`,
      `"${(l.lost_reason || '').replace(/"/g, '""')}"`,
      `"${(l.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Broadcast_Promo_Lost_Contacts_${formatDateForInput(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (showToast) {
      showToast('success', 'Ekspor CSV Berhasil', `${eligibleLeads.length} kontak berhasil diunduh.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full p-5 sm:p-6 shadow-2xl space-y-5 my-6 flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                Broadcast Promo Kontak Lost
              </h3>
              <p className="text-xs text-slate-500">
                Kirim penawaran promo ke prospek lost yang mengizinkan dihubungi kembali ({eligibleLeads.length} kontak aktif)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Two Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 overflow-y-auto flex-1 pr-1">
          {/* Left Column: Template Selection & Message Editor (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Template Selector Pills */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Pilih Template Promo:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {defaultTemplates.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => handleSelectTemplate(tpl)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      selectedTemplateId === tpl.id
                        ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-100 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                        {tpl.category}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 bg-white text-slate-600 rounded border border-slate-200 font-semibold">
                        {tpl.badge}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-slate-800 truncate">{tpl.title}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Template Textarea */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Isi Pesan WhatsApp:
                </label>
                <span className="text-[11px] text-slate-400">
                  Gunakan tag <code className="bg-slate-100 text-emerald-800 px-1 rounded">{'{{nama}}'}</code> untuk personalisasi
                </span>
              </div>
              <textarea
                rows={9}
                value={messageTemplate}
                onChange={(e) => setMessageTemplate(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl text-xs font-mono text-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50/40 leading-relaxed"
                placeholder="Tulis pesan promosi di sini..."
              />
            </div>

            {/* Copy Actions Bar */}
            <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
              <button
                type="button"
                onClick={() => handleCopyText(messageTemplate, 'text')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                {copiedType === 'text' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Teks Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin Pesan</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleCopyAllPhones(',')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                {copiedType === 'phones_comma' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Nomor Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin No. WA (Koma)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleCopyAllPhones('\n')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                {copiedType === 'phones_lines' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Nomor Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Salin No. WA (Baris)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDownloadCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer ml-auto"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Unduh CSV</span>
              </button>
            </div>
          </div>

          {/* Right Column: Contact Target List (5 Cols) */}
          <div className="lg:col-span-5 bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-600" />
                Target Penerima ({displayedLeads.length})
              </span>
              {ineligibleLeads.length > 0 && (
                <span className="text-[10px] text-slate-500">
                  {ineligibleLeads.length} kontak menolak promo
                </span>
              )}
            </div>

            {/* Search inside contacts */}
            <div className="relative mb-3">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari target penerima..."
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            {/* List */}
            <div className="space-y-2 overflow-y-auto flex-1 max-h-[340px] pr-1">
              {displayedLeads.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 bg-white rounded-lg border border-slate-200">
                  Tidak ada kontak yang cocok dengan pencarian.
                </div>
              ) : (
                displayedLeads.map((lead) => (
                  <div
                    key={lead.id}
                    className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs hover:border-emerald-300 transition-all flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-bold text-slate-800 truncate">{lead.guestName}</p>
                        <span className="text-[9px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 shrink-0">
                          Boleh Promo
                        </span>
                      </div>
                      <p className="text-[11px] font-mono text-slate-500 mt-0.5 truncate">
                        {lead.whatsAppNumber}
                        {lead.lost_reason && (
                          <span className="text-slate-400 ml-1.5 font-sans">
                            • {lead.lost_reason}
                          </span>
                        )}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleSendDirectWa(lead)}
                      className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-semibold flex items-center gap-1 shrink-0 shadow-2xs cursor-pointer transition-colors"
                      title="Kirim Pesan WhatsApp Personal"
                    >
                      <Send className="w-3 h-3" />
                      <span>Kirim</span>
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="mt-3 pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Klik <strong>Kirim</strong> untuk membuka chat WA per kontak dengan pesan terpersonalisasi.</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 shrink-0">
          <p className="text-xs text-slate-500">
            Pastikan pesan promosi mematuhi etika komunikasi dan kesepakatan pelanggan.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
