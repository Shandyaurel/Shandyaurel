import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  FileSpreadsheet,
  Printer,
  Filter,
  Calendar,
  Search,
  DollarSign,
  TrendingUp,
  CreditCard,
  Building2,
  Compass,
  Utensils,
  ShoppingBag,
  Handshake,
  CheckCircle2,
  Clock,
  ChevronRight,
  Download,
  FileText,
  X,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  Booking,
  ATVBooking,
  BreakfastRecord,
  ExtraIncomeItem,
  AgentFee,
  BusinessSettings,
} from '../../types';
import {
  subscribeBookings,
  subscribeATVBookings,
  subscribeBreakfast,
  subscribeExtraIncome,
  subscribeAgentFees,
  getBusinessSettings,
} from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatters';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';

type CategoryFilter = 'all' | 'hotel' | 'atv' | 'breakfast' | 'extra_income' | 'agent_fee';

interface UnifiedTransactionItem {
  id: string;
  date: string;
  category: 'Hotel' | 'ATV' | 'Sarapan' | 'Extra' | 'Komisi';
  refNumber: string;
  guestName: string;
  description: string;
  paymentMethod: string;
  revenue: number;
  costOrCommission: number;
  netIncome: number;
  status: string;
  originalItem: unknown;
}

export const CombinedReportsView: React.FC = () => {
  const { currentUser, userProfile } = useAuth();
  const { showSuccess, showError } = useToast();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [atvBookings, setAtvBookings] = useState<ATVBooking[]>([]);
  const [breakfastRecords, setBreakfastRecords] = useState<BreakfastRecord[]>([]);
  const [extraIncomeItems, setExtraIncomeItems] = useState<ExtraIncomeItem[]>([]);
  const [agentFees, setAgentFees] = useState<AgentFee[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | undefined>(undefined);

  // Filter States
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
  
  const [startDate, setStartDate] = useState<string>(`${currentYear}-${currentMonth}-01`);
  const [endDate, setEndDate] = useState<string>(
    new Date(currentYear, now.getMonth() + 1, 0).toISOString().split('T')[0]
  );
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState<string>('all');
  // Poin 10: basis tanggal laporan — 'transaction' (tgl order/bayar) atau 'stay' (tgl menginap/pelaksanaan)
  const [dateMode, setDateMode] = useState<'transaction' | 'stay'>('transaction');

  // Print Preview Modal State
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);
  const printContentRef = useRef<HTMLDivElement>(null);

  // Subscriptions
  useEffect(() => {
    let isMounted = true;

    getBusinessSettings().then((s) => {
      if (isMounted) setSettings(s);
    });

    const unsubBookings = subscribeBookings((data) => {
      if (isMounted) setBookings(data);
    });

    const unsubATV = subscribeATVBookings((data) => {
      if (isMounted) setAtvBookings(data);
    });

    const unsubBreakfast = subscribeBreakfast((data) => {
      if (isMounted) setBreakfastRecords(data);
    });

    const unsubExtra = subscribeExtraIncome((data) => {
      if (isMounted) setExtraIncomeItems(data);
    });

    const unsubFees = subscribeAgentFees((data) => {
      if (isMounted) setAgentFees(data);
    });

    return () => {
      isMounted = false;
      unsubBookings();
      unsubATV();
      unsubBreakfast();
      unsubExtra();
      unsubFees();
    };
  }, []);

  // Quick Date Presets
  const applyPreset = (preset: 'today' | '7days' | 'this_month' | 'last_month' | 'this_year') => {
    const today = new Date();
    const y = today.getFullYear();
    const m = today.getMonth();

    if (preset === 'today') {
      const dStr = today.toISOString().split('T')[0];
      setStartDate(dStr);
      setEndDate(dStr);
    } else if (preset === '7days') {
      const past7 = new Date();
      past7.setDate(today.getDate() - 6);
      setStartDate(past7.toISOString().split('T')[0]);
      setEndDate(today.toISOString().split('T')[0]);
    } else if (preset === 'this_month') {
      const start = `${y}-${String(m + 1).padStart(2, '0')}-01`;
      const end = new Date(y, m + 1, 0).toISOString().split('T')[0];
      setStartDate(start);
      setEndDate(end);
    } else if (preset === 'last_month') {
      const lastMonthDate = new Date(y, m - 1, 1);
      const ly = lastMonthDate.getFullYear();
      const lm = lastMonthDate.getMonth();
      const start = `${ly}-${String(lm + 1).padStart(2, '0')}-01`;
      const end = new Date(ly, lm + 1, 0).toISOString().split('T')[0];
      setStartDate(start);
      setEndDate(end);
    } else if (preset === 'this_year') {
      setStartDate(`${y}-01-01`);
      setEndDate(`${y}-12-31`);
    }
  };

  // Build Unified Transactions
  const unifiedTransactions = useMemo(() => {
    const list: UnifiedTransactionItem[] = [];

    // 1. Hotel Bookings
    bookings.forEach((b) => {
      const txDate = b.date || b.createdAt.split('T')[0];
      const stayDate = b.checkInDate || b.date || b.createdAt.split('T')[0];
      const date = dateMode === 'stay' ? stayDate : txDate;
      if (b.status === 'Cancelled') return;

      const roomDesc = b.rooms?.map((r) => `${r.roomType} (${r.roomQty}x)`).join(', ') || b.roomType || 'Kamar Glamping';
      const paymentMethod = b.pelunasanMethod || b.dpMethod || b.paymentMethod || 'Transfer';
      const revenue = b.pendapatan || 0;
      const commission = b.agentFee || 0;

      list.push({
        id: b.id,
        date,
        category: 'Hotel',
        refNumber: `HTL-${b.id.slice(-6).toUpperCase()}`,
        guestName: b.guestName,
        description: `${roomDesc} • ${b.checkInDate} s/d ${b.checkOutDate}`,
        paymentMethod,
        revenue,
        costOrCommission: commission,
        netIncome: revenue - commission,
        status: b.pendapatan >= b.grandTotal ? 'Lunas' : 'DP / Sebagian',
        originalItem: b,
      });
    });

    // 2. ATV Bookings
    atvBookings.forEach((a) => {
      const txDate = a.date || a.createdAt.split('T')[0];
      const stayDate = a.bookingDate || a.date || a.createdAt.split('T')[0];
      const date = dateMode === 'stay' ? stayDate : txDate;
      if (a.status === 'Cancelled') return;

      const trackDesc = a.tracks?.map((t) => `${t.trackType} (${t.qty}x)`).join(', ') || 'Sewa ATV';
      const paymentMethod = a.pelunasanMethod || a.dpMethod || a.paymentMethod || 'Cash';
      const revenue = a.pendapatan || 0;
      const commission = a.agentFee || 0;

      list.push({
        id: a.id,
        date,
        category: 'ATV',
        refNumber: `ATV-${a.id.slice(-6).toUpperCase()}`,
        guestName: a.guestName,
        description: `${trackDesc} • ${a.bookingTime || '09:00'}`,
        paymentMethod,
        revenue,
        costOrCommission: commission,
        netIncome: revenue - commission,
        status: a.pendapatan >= a.grandTotal ? 'Lunas' : 'DP / Sebagian',
        originalItem: a,
      });
    });

    // 3. Breakfast Records
    breakfastRecords.forEach((br) => {
      // Sarapan: tgl menginap = tgl disajikan (br.date); tgl transaksi = tgl input/booking
      const txDate = br.createdAt ? br.createdAt.split('T')[0] : br.date;
      const stayDate = br.date || (br.createdAt ? br.createdAt.split('T')[0] : '');
      const date = dateMode === 'stay' ? stayDate : txDate;
      if (br.status === 'Dibatalkan') return;

      const revenue = (br.qty || 0) * (br.price || 0);

      list.push({
        id: br.id,
        date,
        category: 'Sarapan',
        refNumber: `BRK-${br.id.slice(-6).toUpperCase()}`,
        guestName: br.guestName,
        description: `Sarapan (${br.qty} porsi) • ${br.roomType || ''} ${br.roomNumber || ''}`,
        paymentMethod: 'Include/Resto',
        revenue,
        costOrCommission: 0,
        netIncome: revenue,
        status: br.status || 'Disajikan',
        originalItem: br,
      });
    });

    // 4. Extra Income
    extraIncomeItems.forEach((ex) => {
      const date = ex.date || ex.createdAt.split('T')[0];
      const revenue = ex.totalPaid !== undefined ? ex.totalPaid : (ex.status === 'Lunas' ? ex.total : 0);
      const cost = Number(ex.cost) || 0;
      const calculatedLaba = ex.laba !== undefined ? Number(ex.laba) : (revenue - cost);

      list.push({
        id: ex.id,
        date,
        category: 'Extra',
        refNumber: `EXT-${ex.id.slice(-6).toUpperCase()}`,
        guestName: ex.guestName || 'Umum / Tamu',
        description: `${ex.description} (${ex.qty}x @${formatRupiah(ex.unitPrice)})`,
        paymentMethod: ex.paymentMethod || 'Cash',
        revenue,
        costOrCommission: cost,
        netIncome: calculatedLaba,
        status: ex.status || 'Lunas',
        originalItem: ex,
      });
    });

    // 5. Agent Fees (Komisi Keluar)
    agentFees.forEach((fee) => {
      const date = fee.date || fee.createdAt.split('T')[0];

      list.push({
        id: fee.id,
        date,
        category: 'Komisi',
        refNumber: `FEE-${fee.id.slice(-6).toUpperCase()}`,
        guestName: fee.name,
        description: `Komisi Agen/Partner • ${fee.category} (${fee.guestName || 'Klien'})`,
        paymentMethod: fee.bankName || 'Transfer Bank',
        revenue: 0,
        costOrCommission: fee.amount || 0,
        netIncome: -(fee.amount || 0),
        status: fee.status || 'Belum Dibayar',
        originalItem: fee,
      });
    });

    return list.sort((a, b) => (b.date > a.date ? 1 : -1));
  }, [bookings, atvBookings, breakfastRecords, extraIncomeItems, agentFees, dateMode]);

  // Filtered Transactions
  const filteredTransactions = useMemo(() => {
    return unifiedTransactions.filter((item) => {
      // Date Filter
      if (startDate && item.date < startDate) return false;
      if (endDate && item.date > endDate) return false;

      // Category Filter
      if (categoryFilter === 'hotel' && item.category !== 'Hotel') return false;
      if (categoryFilter === 'atv' && item.category !== 'ATV') return false;
      if (categoryFilter === 'breakfast' && item.category !== 'Sarapan') return false;
      if (categoryFilter === 'extra_income' && item.category !== 'Extra') return false;
      if (categoryFilter === 'agent_fee' && item.category !== 'Komisi') return false;

      // Payment Method Filter
      if (paymentMethodFilter !== 'all') {
        if (!item.paymentMethod.toLowerCase().includes(paymentMethodFilter.toLowerCase())) {
          return false;
        }
      }

      // Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = item.guestName.toLowerCase().includes(query);
        const matchDesc = item.description.toLowerCase().includes(query);
        const matchRef = item.refNumber.toLowerCase().includes(query);
        if (!matchName && !matchDesc && !matchRef) return false;
      }

      return true;
    });
  }, [unifiedTransactions, startDate, endDate, categoryFilter, paymentMethodFilter, searchQuery]);

  // Financial Summaries for Filtered Data
  const financialSummary = useMemo(() => {
    let totalOmzet = 0;
    let totalBiayaKomisi = 0;
    let totalNet = 0;

    filteredTransactions.forEach((item) => {
      totalOmzet += item.revenue;
      totalBiayaKomisi += item.costOrCommission;
      totalNet += item.netIncome;
    });

    return {
      totalOmzet,
      totalBiayaKomisi,
      totalNet,
      transactionCount: filteredTransactions.length,
    };
  }, [filteredTransactions]);

  // Payment Method Breakdown
  const paymentMethodBreakdown = useMemo(() => {
    const map: Record<string, { method: string; count: number; total: number }> = {};

    filteredTransactions.forEach((item) => {
      if (item.category === 'Komisi' || item.revenue === 0) return;
      const method = item.paymentMethod || 'Lainnya';
      if (!map[method]) {
        map[method] = { method, count: 0, total: 0 };
      }
      map[method].count += 1;
      map[method].total += item.revenue;
    });

    return Object.values(map).sort((a, b) => b.total - a.total);
  }, [filteredTransactions]);

  // Poin 10: Breakdown pendapatan per divisi/unit (Hotel, ATV, Sarapan, Extra)
  const divisionBreakdown = useMemo(() => {
    const map: Record<string, { category: string; count: number; revenue: number; net: number }> = {};
    filteredTransactions.forEach((item) => {
      if (item.category === 'Komisi') return;
      if (!map[item.category]) {
        map[item.category] = { category: item.category, count: 0, revenue: 0, net: 0 };
      }
      map[item.category].count += 1;
      map[item.category].revenue += item.revenue;
      map[item.category].net += item.netIncome;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, [filteredTransactions]);

  // Export to Excel (.xlsx)
  const handleExportExcel = () => {
    try {
      const exportRows: Record<string, unknown>[] = filteredTransactions.map((tx, idx) => ({
        No: idx + 1,
        Tanggal: tx.date,
        Kategori: tx.category,
        'No. Referensi': tx.refNumber,
        'Nama Tamu / Mitra': tx.guestName,
        'Rincian / Keterangan': tx.description,
        'Metode Bayar': tx.paymentMethod,
        'Pendapatan (Rp)': tx.revenue,
        'Biaya / Komisi (Rp)': tx.costOrCommission,
        'Laba Bersih (Rp)': tx.netIncome,
        Status: tx.status,
      }));

      // Summary Row
      exportRows.push({
        No: '',
        Tanggal: 'TOTAL PERIODE',
        Kategori: '',
        'No. Referensi': '',
        'Nama Tamu / Mitra': '',
        'Rincian / Keterangan': `${filteredTransactions.length} Transaksi`,
        'Metode Bayar': '',
        'Pendapatan (Rp)': financialSummary.totalOmzet,
        'Biaya / Komisi (Rp)': financialSummary.totalBiayaKomisi,
        'Laba Bersih (Rp)': financialSummary.totalNet,
        Status: '',
      });

      const ws = XLSX.utils.json_to_sheet(exportRows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Laporan Gabungan');

      const fileName = `Laporan_Gabungan_BukitLangit_${startDate}_sd_${endDate}.xlsx`;
      XLSX.writeFile(wb, fileName);

      showSuccess(`File ${fileName} berhasil diunduh.`, 'Ekspor Berhasil');
    } catch (err) {
      console.error(err);
      showError('Terjadi kesalahan saat membuat file Excel.', 'Gagal Ekspor');
    }
  };

  // Trigger Native Print
  const handlePrint = () => {
    window.print();
  };

  const getCategoryBadge = (cat: UnifiedTransactionItem['category']) => {
    switch (cat) {
      case 'Hotel':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-100 text-blue-800">Hotel</span>;
      case 'ATV':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-800">ATV</span>;
      case 'Sarapan':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">Sarapan</span>;
      case 'Extra':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-100 text-purple-800">Pendapatan Tambahan</span>;
      case 'Komisi':
        return <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-800">Komisi Agen</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-white/10 text-blue-200 border border-white/10 mb-3 backdrop-blur-xs">
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-300" />
              <span>Multi-Unit Financial Reporting & Bookkeeping</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Laporan Gabungan & Pembukuan
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Konsolidasi transaksi seluruh divisi (Hotel, ATV, Resto, Extra POS, Komisi Agen) dengan filter periode dan ekspor resmi.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Ekspor Excel</span>
            </button>
            <button
              type="button"
              onClick={() => setIsPrintModalOpen(true)}
              className="px-4 py-2.5 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-blue-600" />
              <span>Cetak / PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
        {/* Quick Date Presets */}
        <div className="flex flex-wrap items-center gap-2 pb-3 border-b border-slate-100">
          <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5 mr-1">
            <Filter className="w-3.5 h-3.5 text-blue-600" />
            <span>Preset Periode:</span>
          </span>
          <button
            type="button"
            onClick={() => applyPreset('today')}
            className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Hari Ini
          </button>
          <button
            type="button"
            onClick={() => applyPreset('7days')}
            className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            7 Hari Terakhir
          </button>
          <button
            type="button"
            onClick={() => applyPreset('this_month')}
            className="px-3 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg text-xs font-bold cursor-pointer transition-colors"
          >
            Bulan Ini
          </button>
          <button
            type="button"
            onClick={() => applyPreset('last_month')}
            className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Bulan Lalu
          </button>
          <button
            type="button"
            onClick={() => applyPreset('this_year')}
            className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Tahun Ini
          </button>
        </div>

        {/* Poin 10: Basis tanggal — TGL TRANSAKSI ↔ TGL MENGINAP (niru rsvsbl) */}
        <div className="flex items-center gap-2 flex-wrap mb-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase">Basis Tanggal:</span>
          <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200">
            <button
              type="button"
              onClick={() => setDateMode('transaction')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                dateMode === 'transaction' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              TGL TRANSAKSI
            </button>
            <button
              type="button"
              onClick={() => setDateMode('stay')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                dateMode === 'stay' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              TGL MENGINAP
            </button>
          </div>
          <span className="text-[10px] text-slate-400">
            {dateMode === 'transaction'
              ? 'Rentang dihitung dari tanggal order / pembayaran.'
              : 'Rentang dihitung dari tanggal menginap / pelaksanaan (check-in, ATV, sarapan).'}
          </span>
        </div>

        {/* Dynamic Filters Form */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
              Dari Tanggal
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full text-xs font-medium border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
              Sampai Tanggal
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full text-xs font-medium border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
              Kategori Unit
            </label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as CategoryFilter)}
              className="w-full text-xs font-medium border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Semua Kategori Unit</option>
              <option value="hotel">Kamar Glamping</option>
              <option value="atv">Wahana ATV</option>
              <option value="breakfast">Sarapan Resto</option>
              <option value="extra_income">Pendapatan Tambahan (POS)</option>
              <option value="agent_fee">Komisi Agen / Partner</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
              Metode Pembayaran
            </label>
            <select
              value={paymentMethodFilter}
              onChange={(e) => setPaymentMethodFilter(e.target.value)}
              className="w-full text-xs font-medium border border-slate-200 rounded-xl px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Semua Metode</option>
              <option value="Cash">Cash / Tunai</option>
              <option value="Transfer (PT)">Transfer (PT)</option>
              <option value="Transfer (Bu Ambar)">Transfer (Bu Ambar)</option>
              <option value="QRIS">QRIS</option>
              <option value="EDC">EDC Debit/Kredit</option>
              <option value="OTA">OTA / Online</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 uppercase block mb-1">
              Cari Transaksi
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Nama tamu / referensi..."
                className="w-full text-xs font-medium border border-slate-200 rounded-xl pl-9 pr-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Summary KPI Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Omzet Pendapatan
          </span>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {formatRupiah(financialSummary.totalOmzet)}
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            Dari {financialSummary.transactionCount} transaksi pada periode terpilih
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Biaya & Komisi Keluar
          </span>
          <div className="text-2xl font-black text-rose-900 mt-2">
            {formatRupiah(financialSummary.totalBiayaKomisi)}
          </div>
          <span className="text-xs text-rose-600 font-medium mt-1 block">
            Komisi agen + HPP pengeluaran barang POS
          </span>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Laba Bersih Operasional
          </span>
          <div className="text-2xl font-black text-emerald-900 mt-2">
            {formatRupiah(financialSummary.totalNet)}
          </div>
          <span className="text-xs text-emerald-600 font-bold mt-1 block">
            Omzet dikurangi biaya modal & komisi
          </span>
        </div>
      </div>

      {/* Poin 10: Breakdown Pendapatan per Divisi/Unit */}
      {divisionBreakdown.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>Breakdown Pendapatan per Divisi</span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {divisionBreakdown.map((item) => (
              <div key={item.category} className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-[11px] font-bold text-slate-700 block">{item.category}</span>
                <div className="text-xs font-black text-slate-900 mt-1 font-mono">{formatRupiah(item.revenue)}</div>
                <div className="flex items-center justify-between mt-0.5">
                  <span className="text-[10px] text-slate-400">{item.count} transaksi</span>
                  <span className="text-[10px] font-semibold text-emerald-600">Laba {formatRupiah(item.net)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Breakdown Metode Pembayaran */}
      {paymentMethodBreakdown.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-blue-600" />
            <span>Breakdown Distribusi Metode Pembayaran</span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {paymentMethodBreakdown.map((item) => (
              <div key={item.method} className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                <span className="text-[11px] font-bold text-slate-700 block truncate">{item.method}</span>
                <div className="text-xs font-black text-slate-900 mt-1 font-mono">{formatRupiah(item.total)}</div>
                <span className="text-[10px] text-slate-400 block">{item.count} transaksi</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Unified Master Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Rincian Transaksi Gabungan
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Menampilkan {filteredTransactions.length} transaksi dari rentang {startDate} s/d {endDate} · basis{' '}
              <span className="font-semibold text-slate-600">
                {dateMode === 'stay' ? 'Tgl Menginap' : 'Tgl Transaksi'}
              </span>
            </p>
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-400">
            Tidak ada transaksi yang cocok dengan kriteria filter yang dipilih.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4">Kategori</th>
                  <th className="py-3 px-4">No. Ref</th>
                  <th className="py-3 px-4">Nama Tamu / Mitra</th>
                  <th className="py-3 px-4">Rincian & Keterangan</th>
                  <th className="py-3 px-4">Metode Bayar</th>
                  <th className="py-3 px-4 text-right">Pendapatan</th>
                  <th className="py-3 px-4 text-right">Biaya/Komisi</th>
                  <th className="py-3 px-4 text-right">Laba Bersih</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-700 whitespace-nowrap">{tx.date}</td>
                    <td className="py-3 px-4 whitespace-nowrap">{getCategoryBadge(tx.category)}</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-700 whitespace-nowrap">{tx.refNumber}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">{tx.guestName}</td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate" title={tx.description}>
                      {tx.description}
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium whitespace-nowrap">{tx.paymentMethod}</td>
                    <td className="py-3 px-4 text-right font-black font-mono text-slate-900 whitespace-nowrap">
                      {formatRupiah(tx.revenue)}
                    </td>
                    <td className="py-3 px-4 text-right font-medium font-mono text-rose-600 whitespace-nowrap">
                      {tx.costOrCommission > 0 ? formatRupiah(tx.costOrCommission) : '-'}
                    </td>
                    <td className="py-3 px-4 text-right font-bold font-mono text-emerald-700 whitespace-nowrap">
                      {formatRupiah(tx.netIncome)}
                    </td>
                    <td className="py-3 px-4 text-center whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-900 text-white font-bold border-t-2 border-slate-900">
                  <td colSpan={6} className="py-3.5 px-4 font-black">
                    TOTAL KONSOLIDASI PERIODE
                  </td>
                  <td className="py-3.5 px-4 text-right font-black font-mono text-emerald-400 text-sm">
                    {formatRupiah(financialSummary.totalOmzet)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-black font-mono text-rose-300 text-sm">
                    {formatRupiah(financialSummary.totalBiayaKomisi)}
                  </td>
                  <td className="py-3.5 px-4 text-right font-black font-mono text-emerald-300 text-sm">
                    {formatRupiah(financialSummary.totalNet)}
                  </td>
                  <td className="py-3.5 px-4 text-center text-xs text-slate-300">
                    {filteredTransactions.length} Data
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* Clean Print Modal */}
      {isPrintModalOpen && (
        <Modal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          title="Pratinjau Cetak Laporan Keuangan"
          maxWidth="max-w-6xl"
        >
          <div className="space-y-6">
            {/* Modal Actions */}
            <div className="flex items-center justify-between bg-slate-100 p-3 rounded-xl no-print">
              <div className="text-xs text-slate-600">
                Gunakan orientasi <strong>Landscape</strong> atau <strong>Portrait</strong> untuk hasil cetak laporan terbaik.
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak Dokumen Sekarang</span>
                </button>
              </div>
            </div>

            {/* Printable Document Sheet (A4 Styling) */}
            <div
              ref={printContentRef}
              className="bg-white p-8 sm:p-12 rounded-xl shadow-lg border border-slate-200 text-slate-900 mx-auto max-w-5xl"
            >
              {/* Kop Surat Bukit Langit Campventure */}
              <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-center justify-between">
                <div>
                  <h1 className="text-xl font-black tracking-wide text-slate-900 uppercase">
                    {settings?.businessName || 'BUKIT LANGIT CAMPVENTURE'}
                  </h1>
                  <p className="text-xs text-slate-600 max-w-md mt-0.5">
                    {settings?.address || 'Jl. Bukit Langit No. 88, Puncak, Cisarua, Bogor'} • Telp: {settings?.phone || '0812-3456-7890'}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Laporan Keuangan</div>
                  <div className="text-sm font-black text-blue-900">KONSOLIDASI TRANSAKSI</div>
                  <div className="text-[11px] text-slate-500 mt-1 font-mono">
                    Periode: {startDate} s/d {endDate}
                  </div>
                </div>
              </div>

              {/* Summary Cards In Print */}
              <div className="grid grid-cols-3 gap-4 mb-6 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Omzet Pendapatan</span>
                  <span className="text-base font-black text-slate-900">{formatRupiah(financialSummary.totalOmzet)}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Biaya & Komisi</span>
                  <span className="text-base font-black text-rose-700">{formatRupiah(financialSummary.totalBiayaKomisi)}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Laba Bersih Operasional</span>
                  <span className="text-base font-black text-emerald-700">{formatRupiah(financialSummary.totalNet)}</span>
                </div>
              </div>

              {/* Transaction Table In Print */}
              <table className="w-full text-left text-[11px] border-collapse mb-8">
                <thead>
                  <tr className="bg-slate-100 border-y border-slate-300 font-bold text-slate-800">
                    <th className="py-2 px-2">No</th>
                    <th className="py-2 px-2">Tanggal</th>
                    <th className="py-2 px-2">Kategori</th>
                    <th className="py-2 px-2">No. Ref</th>
                    <th className="py-2 px-2">Nama Tamu</th>
                    <th className="py-2 px-2">Keterangan</th>
                    <th className="py-2 px-2 text-right">Pendapatan</th>
                    <th className="py-2 px-2 text-right">Biaya/Komisi</th>
                    <th className="py-2 px-2 text-right">Laba Bersih</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredTransactions.map((tx, idx) => (
                    <tr key={tx.id}>
                      <td className="py-1.5 px-2">{idx + 1}</td>
                      <td className="py-1.5 px-2 font-mono whitespace-nowrap">{tx.date}</td>
                      <td className="py-1.5 px-2">{tx.category}</td>
                      <td className="py-1.5 px-2 font-mono">{tx.refNumber}</td>
                      <td className="py-1.5 px-2 font-semibold">{tx.guestName}</td>
                      <td className="py-1.5 px-2 max-w-xs truncate">{tx.description}</td>
                      <td className="py-1.5 px-2 text-right font-mono font-bold">{formatRupiah(tx.revenue)}</td>
                      <td className="py-1.5 px-2 text-right font-mono text-rose-700">
                        {tx.costOrCommission > 0 ? formatRupiah(tx.costOrCommission) : '-'}
                      </td>
                      <td className="py-1.5 px-2 text-right font-mono font-bold text-emerald-800">
                        {formatRupiah(tx.netIncome)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-slate-900 font-bold text-slate-900 bg-slate-50">
                    <td colSpan={6} className="py-2.5 px-2 font-black">
                      TOTAL ({filteredTransactions.length} Transaksi)
                    </td>
                    <td className="py-2.5 px-2 text-right font-black font-mono">
                      {formatRupiah(financialSummary.totalOmzet)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-black font-mono text-rose-700">
                      {formatRupiah(financialSummary.totalBiayaKomisi)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-black font-mono text-emerald-800">
                      {formatRupiah(financialSummary.totalNet)}
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-12 pt-8 text-center text-xs">
                <div>
                  <div className="text-slate-500 mb-16">Dibuat Oleh (Finance & Accounting):</div>
                  <div className="font-bold border-t border-slate-400 pt-1 inline-block min-w-48 text-slate-900">
                    {userProfile?.displayName || currentUser?.email || 'Staff Keuangan'}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 mb-16">Disetujui Oleh (General Manager):</div>
                  <div className="font-bold border-t border-slate-400 pt-1 inline-block min-w-48 text-slate-900">
                    General Manager
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
