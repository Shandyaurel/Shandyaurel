import React, { useState, useEffect } from 'react';
import {
  FinancialDocument,
  BusinessSettings,
  ClientContact,
  RoomRateItem,
  PackageTable,
  MeetingPackageItem,
  KlausulKontrakItem,
} from '../../types';
import {
  getBusinessSettings,
  generateNextDocumentNumber,
  saveDocument,
  subscribePartners,
  linkPartnerContract,
  saveBusinessSettings,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateForInput } from '../../utils/formatter';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import {
  DEFAULT_SETTINGS,
  DEFAULT_ROOM_RATE_NOTES,
  DEFAULT_PAKET_RATE_NOTES,
  DEFAULT_ATV_RATE_NOTES,
  DEFAULT_KLAUSUL_KONTRAK,
  computeContractTerms,
  saveStoredSettings,
} from '../../utils/storage';
import { safeLocalStorageSetItem } from '../../utils/safeStorage';
import { DocumentPreview } from '../DocumentPreview';
import { WhatsAppShareModal } from '../documents/WhatsAppShareModal';
import {
  Building2,
  Save,
  Download,
  ArrowLeft,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  Loader2,
  Eye,
  CheckCircle2,
  ShieldCheck,
  Search,
  MessageSquare,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Zap,
} from 'lucide-react';

interface ContractEditorFormProps {
  initialContract?: FinancialDocument | null;
  targetPartner?: ClientContact | null;
  onSaved?: (doc: FinancialDocument) => void;
  onCancel?: () => void;
}

export const ContractEditorForm: React.FC<ContractEditorFormProps> = ({
  initialContract,
  targetPartner,
  onSaved,
  onCancel,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError, showWarning } = useToast();

  const [settings, setSettings] = useState<BusinessSettings>(DEFAULT_SETTINGS);
  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [selectedPartnerId, setSelectedPartnerId] = useState<string>(
    initialContract?.partnerId || targetPartner?.id || '',
  );
  const [partnerSearch, setPartnerSearch] = useState<string>('');
  const [isPartnerDropdownOpen, setIsPartnerDropdownOpen] = useState<boolean>(false);

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [showWhatsAppModal, setShowWhatsAppModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'form' | 'preview'>('form');
  const [isKlausulExpanded, setIsKlausulExpanded] = useState<boolean>(false);

  // Contract Identity
  const [docId, setDocId] = useState<string>(initialContract?.id || '');
  const [documentNumber, setDocumentNumber] = useState<string>(
    initialContract?.documentNumber || '',
  );
  const [documentDate, setDocumentDate] = useState<string>(
    initialContract?.documentDate || formatDateForInput(),
  );
  const [documentTitle, setDocumentTitle] = useState<string>(
    initialContract?.documentTitle || 'CONTRACT RATE TRAVEL AGENT & CORPORATE AGREEMENT',
  );

  // Period
  const [contractStartDate, setContractStartDate] = useState<string>(
    initialContract?.contractStartDate || formatDateForInput(),
  );
  const [contractEndDate, setContractEndDate] = useState<string>(() => {
    if (initialContract?.contractEndDate) return initialContract.contractEndDate;
    const end = new Date();
    end.setMonth(11, 31); // default: 31 Desember tahun berjalan
    return formatDateForInput(end);
  });
  const [contractPeriod, setContractPeriod] = useState<string>(() => {
    if (initialContract?.contractPeriod) return initialContract.contractPeriod;
    const M = [
      'JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI',
      'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER',
    ];
    const s = new Date();
    const e = new Date();
    e.setMonth(11, 31);
    return `${s.getDate()} ${M[s.getMonth()]} ${s.getFullYear()} – ${e.getDate()} ${M[e.getMonth()]} ${e.getFullYear()}`;
  });

  // Partner / Guest details
  const [guestName, setGuestName] = useState<string>(
    initialContract?.guestName || targetPartner?.name || '',
  );
  const [companyContactPerson, setCompanyContactPerson] = useState<string>(
    initialContract?.companyContactPerson || targetPartner?.contactPerson || '',
  );
  const [companyContactTitle, setCompanyContactTitle] = useState<string>(
    initialContract?.companyContactTitle || targetPartner?.contactPersonTitle || 'Tour Consultant & Procurement',
  );
  const [guestPhone, setGuestPhone] = useState<string>(
    initialContract?.guestPhone || targetPartner?.phone || '',
  );
  const [guestEmail, setGuestEmail] = useState<string>(
    initialContract?.guestEmail || targetPartner?.email || '',
  );
  const [guestAddress, setGuestAddress] = useState<string>(
    initialContract?.guestAddress || targetPartner?.address || '',
  );

  // Intro text
  const [contractIntroText, setContractIntroText] = useState<string>(
    initialContract?.contractIntroText ||
      `Salam hangat dari ${settings.businessName || 'BUKIT LANGIT CAMPVENTURE'}. Bersama ini kami sampaikan penawaran daftar harga kontrak resmi untuk perusahaan Anda sebagai berikut:`,
  );

  // Room Rates Table
  const [roomRateTableTitle, setRoomRateTableTitle] = useState<string>(
    initialContract?.roomRateTableTitle ||
      'DAFTAR HARGA KAMAR (WEEKDAY & WEEKEND / HARI BESAR / HIGH SEASON)',
  );
  const [roomRates, setRoomRates] = useState<RoomRateItem[]>(() => {
    if (initialContract?.roomRates && initialContract.roomRates.length > 0) {
      return initialContract.roomRates;
    }
    return settings.defaultRoomRates || [];
  });
  const [roomRateNotes, setRoomRateNotes] = useState<string>(
    initialContract?.roomRateNotes || settings.defaultRoomRateNotes || DEFAULT_ROOM_RATE_NOTES,
  );
  const [roomRateNotesEnabled, setRoomRateNotesEnabled] = useState<boolean>(
    initialContract?.roomRateNotesEnabled !== undefined
      ? initialContract.roomRateNotesEnabled
      : true,
  );

  // Package & Activity Tables
  const [packageTables, setPackageTables] = useState<PackageTable[]>(() => {
    if (initialContract?.packageTables && initialContract.packageTables.length > 0) {
      return initialContract.packageTables;
    }
    return settings.defaultPackageTables || [];
  });

  // Terms & Surcharge
  const [showTermsAndConditions, setShowTermsAndConditions] = useState<boolean>(
    initialContract?.showTermsAndConditions !== false,
  );
  const [termsAndConditions, setTermsAndConditions] = useState<string[]>(() => {
    if (initialContract?.termsAndConditions && initialContract.termsAndConditions.length > 0) {
      return initialContract.termsAndConditions;
    }
    return settings.defaultContractTerms || [];
  });

  // Klausul Baku
  const [klausulKontrak, setKlausulKontrak] = useState<KlausulKontrakItem[]>(() => {
    if (initialContract?.klausul_kontrak && initialContract.klausul_kontrak.length > 0) {
      return initialContract.klausul_kontrak;
    }
    return settings.klausul_kontrak || DEFAULT_KLAUSUL_KONTRAK;
  });

  // Signatories
  const [signatoryName, setSignatoryName] = useState<string>(
    initialContract?.signatoryName || settings.signatoryName || 'Bukit Langit Campventure',
  );
  const [signatoryRole, setSignatoryRole] = useState<string>(
    initialContract?.signatoryRole || settings.signatoryRole || 'Reservation & Sales Management',
  );
  const [recipientSignatoryName, setRecipientSignatoryName] = useState<string>(
    initialContract?.recipientSignatoryName || targetPartner?.contactPerson || '',
  );
  const [recipientSignatoryRole, setRecipientSignatoryRole] = useState<string>(
    initialContract?.recipientSignatoryRole || targetPartner?.contactPersonTitle || 'Authorized Representative',
  );

  // Load Settings & Partners
  useEffect(() => {
    getBusinessSettings()
      .then((s) => {
        setSettings(s);
        if (!initialContract?.id) {
          if (!documentNumber) {
            handleAutoGenerateNumber(s);
          }
          if (!roomRates || roomRates.length === 0) {
            setRoomRates(s.defaultRoomRates || []);
          }
          if (!packageTables || packageTables.length === 0) {
            setPackageTables(s.defaultPackageTables || []);
          }
        }
      })
      .catch(console.error);

    const unsubPartners = subscribePartners(
      (list) => setPartners(list),
      (err) => console.error('Failed to subscribe partners:', err),
    );

    return () => unsubPartners();
  }, []);

  // Handle partner selection
  const handleSelectPartner = (p: ClientContact) => {
    setSelectedPartnerId(p.id);
    setGuestName(p.name.toUpperCase());
    setCompanyContactPerson(p.contactPerson || '');
    setCompanyContactTitle(p.contactPersonTitle || 'Tour Consultant & Procurement');
    setGuestPhone(p.phone || '');
    setGuestEmail(p.email || '');
    setGuestAddress(p.address || '');
    setRecipientSignatoryName(p.contactPerson || p.name);
    setRecipientSignatoryRole(p.contactPersonTitle || 'Pihak Kedua / Mitra');
    setIsPartnerDropdownOpen(false);

    if (p.contractNumber && !documentNumber) {
      setDocumentNumber(p.contractNumber);
    }

    showSuccess(`Data mitra "${p.name}" berhasil diisi otomatis.`);
  };

  const handleAutoGenerateNumber = async (currentSettings?: BusinessSettings) => {
    const s = currentSettings || settings;
    try {
      const num = await generateNextDocumentNumber(s.documentPrefix || 'BL');
      const now = new Date();
      const monthRoman = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'][
        now.getMonth()
      ];
      const year = now.getFullYear();
      const formattedNum = `${num.docNumber}/CR-TA/SM/BLC/${monthRoman}/${year}`;
      setDocumentNumber(formattedNum);
    } catch {
      const rand = Math.floor(100 + Math.random() * 900);
      const romanMonths = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
      const n = new Date();
      setDocumentNumber(`${rand}/CR-TA/SM/BLC/${romanMonths[n.getMonth()]}/${n.getFullYear()}`);
    }
  };

  const handleSetToday = () => {
    const today = new Date();
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    const formatted = `${String(today.getDate()).padStart(2, '0')}-${months[today.getMonth()]}-${today.getFullYear()}`;
    setDocumentDate(formatted);
    showSuccess('Tanggal terbit diatur ke hari ini.');
  };

  const handleSetPeriodMonths = (monthsCount: number) => {
    const startDate = contractStartDate ? new Date(contractStartDate) : new Date();
    if (isNaN(startDate.getTime())) {
      startDate.setTime(Date.now());
    }
    const startStr = formatDateForInput(startDate);

    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + monthsCount);
    const endStr = formatDateForInput(endDate);

    const monthNamesID = [
      'JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI',
      'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER',
    ];
    const startFormatted = `${startDate.getDate()} ${monthNamesID[startDate.getMonth()]} ${startDate.getFullYear()}`;
    const endFormatted = `${endDate.getDate()} ${monthNamesID[endDate.getMonth()]} ${endDate.getFullYear()}`;
    const periodText = `${startFormatted} – ${endFormatted}`.toUpperCase();

    setContractStartDate(startStr);
    setContractEndDate(endStr);
    setContractPeriod(periodText);
    showSuccess(`Periode kontrak diatur (${monthsCount} Bulan).`);
  };

  // Poin 8: auto-format teks periode dari Tanggal Mulai + Tanggal Berakhir
  const formatPeriodFromDates = (startStr: string, endStr: string): string => {
    if (!startStr || !endStr) return '';
    const s = new Date(startStr);
    const e = new Date(endStr);
    if (isNaN(s.getTime()) || isNaN(e.getTime())) return '';
    const M = [
      'JANUARI', 'FEBRUARI', 'MARET', 'APRIL', 'MEI', 'JUNI',
      'JULI', 'AGUSTUS', 'SEPTEMBER', 'OKTOBER', 'NOVEMBER', 'DESEMBER',
    ];
    const sf = `${s.getDate()} ${M[s.getMonth()]} ${s.getFullYear()}`;
    const ef = `${e.getDate()} ${M[e.getMonth()]} ${e.getFullYear()}`;
    return `${sf} – ${ef}`.toUpperCase();
  };

  // Build current document representation
  const buildCurrentDocument = (): FinancialDocument => {
    const activePkgTables = packageTables.filter((pt) => pt.items && pt.items.length > 0);
    const calculatedTerms = computeContractTerms(
      {
        roomRates,
        packageTables: activePkgTables,
      } as any,
      settings,
    );

    return {
      id: docId || `contract_${Date.now()}`,
      documentType: 'corporate_contract',
      documentNumber: documentNumber.trim(),
      documentTitle,
      documentDate,
      date: documentDate,
      contractStartDate,
      contractEndDate,
      contractPeriod,
      partnerId: selectedPartnerId || undefined,

      guestName: guestName.trim(),
      companyContactPerson,
      companyContactTitle,
      guestPhone,
      guestEmail,
      guestAddress,

      contractIntroText,
      roomRateTableTitle,
      roomRates,
      roomRateNotes,
      roomRateNotesEnabled,
      footnoteKamarEnabled: roomRateNotesEnabled,

      packageTables: activePkgTables,

      showTermsAndConditions,
      termsAndConditions: termsAndConditions.length > 0 ? termsAndConditions : calculatedTerms,
      termsTitle: 'SYARAT, KETENTUAN & BIAYA TAMBAHAN (SURCHARGE)',

      klausul_kontrak: klausulKontrak,

      signatoryName,
      signatoryRole,
      recipientSignatoryName,
      recipientSignatoryRole,

      items: [],
      subtotal: 0,
      grandTotal: 0,
      totalAmount: 0,
      stayDate: contractPeriod || '',
      useTax: false,
      taxRate: 0,
      taxAmount: 0,
      paymentStatus: 'LUNAS',
      bankAccount: settings.bankAccounts?.[0] || {
        bankName: 'BRI',
        accountNumber: '000701002452566',
        accountHolder: settings.businessName || 'PT. HOLISTIK NUSANTARA GROUP',
        swiftCode: 'BRINIDJA',
      },

      createdAt: initialContract?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: initialContract?.createdBy || currentUser?.email || 'admin',
    };
  };

  const handleSave = async (andPrint = false) => {
    if (!guestName.trim()) {
      showError('Nama Travel Agent / Perusahaan (Mitra) wajib diisi.');
      return;
    }
    if (!documentNumber.trim()) {
      showError('Nomor Kontrak B2B wajib diisi.');
      return;
    }

    try {
      setIsSaving(true);
      const doc = buildCurrentDocument();
      await saveDocument(doc, currentUser?.email || 'admin');

      if (selectedPartnerId) {
        await linkPartnerContract(
          selectedPartnerId,
          doc,
          currentUser?.email || 'admin',
        );
      }

      setDocId(doc.id);
      showSuccess(`✅ Kontrak Resmi ${doc.documentNumber} (${doc.guestName}) BERHASIL DISIMPAN!`);

      if (onSaved) {
        onSaved(doc);
      }

      if (andPrint) {
        handleDownloadPdf();
      }
    } catch (err) {
      console.error('Save contract error:', err);
      showError('Gagal menyimpan kontrak ke Firestore.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      setIsDownloading(true);
      const doc = buildCurrentDocument();
      await generateDocumentPdf(doc, settings);
      showSuccess(`✅ File PDF berhasil diunduh!`);
    } catch (err) {
      console.error('Download PDF error:', err);
      showError('Gagal menghasilkan file PDF.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleSaveFormatAsDefault = async () => {
    try {
      const updatedSettings: BusinessSettings = {
        ...settings,
        defaultContractIntroText: contractIntroText,
        defaultRoomRateTableTitle: roomRateTableTitle,
        defaultRoomRateNotes: roomRateNotes,
        defaultRoomRateNotesEnabled: roomRateNotesEnabled,
        footnoteKamarEnabled: roomRateNotesEnabled,
        defaultRoomRates: roomRates,
        defaultPackageTables: packageTables,
        klausul_kontrak: klausulKontrak,
      };

      saveStoredSettings(updatedSettings);
      await saveBusinessSettings(updatedSettings, currentUser?.email || 'admin');
      setSettings(updatedSettings);
      showSuccess('Tersimpan ✓ Format ini berhasil disimpan sebagai Default Baru untuk semua kontrak berikutnya!');
    } catch (err) {
      console.error('Failed to save default settings:', err);
      showError('Gagal menyimpan format default.');
    }
  };

  const filteredPartners = partners.filter(
    (p) =>
      p.name.toLowerCase().includes(partnerSearch.toLowerCase()) ||
      (p.contactPerson && p.contactPerson.toLowerCase().includes(partnerSearch.toLowerCase())) ||
      (p.phone && p.phone.includes(partnerSearch)),
  );

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-800">
      {/* Top Sticky Header Bar */}
      <header className="sticky top-0 z-30 bg-slate-900 text-white px-4 sm:px-6 py-3.5 border-b border-slate-800 shadow-md flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Kembali ke Daftar Kontrak"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-400" />
              <h1 className="text-sm sm:text-base font-black tracking-wide uppercase">
                Editor Kontrak B2B / Rate Agreement
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" /> KONTRAK TERBIT
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              No: <span className="text-white font-bold">{documentNumber || 'DRAFT'}</span> | {guestName || 'Mitra Baru'}
            </p>
          </div>
        </div>

        {/* Tab switcher (Mobile) & Actions */}
        <div className="flex items-center gap-2">
          <div className="lg:hidden flex bg-slate-800 p-1 rounded-xl border border-slate-700">
            <button
              type="button"
              onClick={() => setActiveTab('form')}
              className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'form' ? 'bg-emerald-600 text-white' : 'text-slate-400'
              }`}
            >
              Form
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`px-3 py-1 text-xs font-bold rounded-lg cursor-pointer transition-colors ${
                activeTab === 'preview' ? 'bg-emerald-600 text-white' : 'text-slate-400'
              }`}
            >
              Pratinjau PDF
            </button>
          </div>

          <button
            type="button"
            onClick={() => handleSave(false)}
            disabled={isSaving}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700 disabled:opacity-50"
          >
            {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5 text-emerald-400" />}
            <span>Simpan Kontrak</span>
          </button>

          <button
            type="button"
            onClick={() => handleSave(true)}
            disabled={isSaving || isDownloading}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer disabled:opacity-50"
          >
            {isDownloading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            <span>Simpan & Cetak PDF</span>
          </button>

          <button
            type="button"
            onClick={() => setShowWhatsAppModal(true)}
            className="p-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl transition-colors cursor-pointer"
            title="Kirim ke WhatsApp"
          >
            <MessageSquare className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Split Grid */}
      <main className="flex-1 p-4 sm:p-6 max-w-[1600px] w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Panel (Left) */}
        <div
          className={`lg:col-span-6 space-y-5 ${
            activeTab === 'form' ? 'block' : 'hidden lg:block'
          }`}
        >
          {/* Status & Default Format Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white p-4 rounded-2xl shadow-sm border border-slate-700 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                    Status: Kontrak B2B Resmi Diterbitkan & Aktif
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[9.5px] font-extrabold bg-emerald-500 text-slate-950 uppercase">
                    Tersinkron di CRM
                  </span>
                </div>
                <p className="text-slate-300 text-xs mt-0.5">
                  No: <span className="font-mono font-bold text-white">{documentNumber}</span> • Berlaku: <span className="font-bold text-emerald-300">{contractPeriod}</span>
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleSaveFormatAsDefault}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/80 hover:bg-emerald-600 text-white text-[11px] font-bold rounded-xl border border-emerald-400/30 transition-all cursor-pointer shadow-sm"
              title="Simpan format ini sebagai default baru semua kontrak"
            >
              <Save className="w-3.5 h-3.5 text-emerald-200" />
              <span>Simpan Format Ini sbg Default Baru</span>
            </button>
          </div>

          {/* Section 1: Travel Agent / Corporate Partner Info */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-600" />
                <span>1. Informasi Travel Agent / Corporate Partner</span>
              </h2>

              {/* Searchable Partner Picker */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsPartnerDropdownOpen(!isPartnerDropdownOpen)}
                  className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{selectedPartnerId ? 'Ganti Mitra Bisnis' : 'Pilih dari Mitra Bisnis'}</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {isPartnerDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white border border-slate-200 rounded-2xl shadow-xl z-30 p-2 space-y-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={partnerSearch}
                        onChange={(e) => setPartnerSearch(e.target.value)}
                        placeholder="Cari nama mitra, PIC, telepon..."
                        className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                        autoFocus
                      />
                    </div>
                    <div className="max-h-56 overflow-y-auto space-y-1">
                      {filteredPartners.length > 0 ? (
                        filteredPartners.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => handleSelectPartner(p)}
                            className="w-full text-left p-2 hover:bg-emerald-50 rounded-xl transition-colors text-xs flex flex-col cursor-pointer"
                          >
                            <span className="font-bold text-slate-900 uppercase">{p.name}</span>
                            <span className="text-[10px] text-slate-500">
                              PIC: {p.contactPerson || '-'} • {p.phone}
                            </span>
                          </button>
                        ))
                      ) : (
                        <p className="text-center py-3 text-slate-400 text-xs italic">
                          Tidak ada data mitra ditemukan.
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Nama Travel Agent / Perusahaan (Mitra) *
                </label>
                <input
                  type="text"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value.toUpperCase())}
                  placeholder="PT. JADI LIBURAN INDONESIA"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold uppercase text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-slate-600">
                    Nomor Kontrak B2B *
                  </label>
                  <button
                    type="button"
                    onClick={() => handleAutoGenerateNumber()}
                    className="inline-flex items-center gap-1 text-[11px] text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    Auto Generate No.
                  </button>
                </div>
                <input
                  type="text"
                  value={documentNumber}
                  onChange={(e) => setDocumentNumber(e.target.value)}
                  placeholder="024/CR-TA/SM/BLC/IX/2026"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Nama PIC / Penanggung Jawab *
                </label>
                <input
                  type="text"
                  value={companyContactPerson}
                  onChange={(e) => setCompanyContactPerson(e.target.value)}
                  placeholder="Bapak Deny"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Jabatan PIC
                </label>
                <input
                  type="text"
                  value={companyContactTitle}
                  onChange={(e) => setCompanyContactTitle(e.target.value)}
                  placeholder="Tour Consultant & Procurement"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Nomor WhatsApp / Telepon PIC *
                </label>
                <input
                  type="text"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  placeholder="+62 812-3200-3610"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Email Resmi Mitra
                </label>
                <input
                  type="email"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                  placeholder="cs.jadiliburan@gmail.com"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Alamat Kantor Mitra
                </label>
                <input
                  type="text"
                  value={guestAddress}
                  onChange={(e) => setGuestAddress(e.target.value)}
                  placeholder="Jl. Raya Kuta No. 88, Badung, Bali"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Tanggal & Periode */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <span>2. Tanggal & Periode Masa Berlaku Kontrak</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-slate-600">
                    Tanggal Terbit Kontrak
                  </label>
                  <button
                    type="button"
                    onClick={handleSetToday}
                    className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold underline cursor-pointer"
                  >
                    Hari Ini (Today)
                  </button>
                </div>
                <input
                  type="date"
                  value={documentDate}
                  onChange={(e) => setDocumentDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Periode Kontrak <span className="text-emerald-600">(otomatis dari tanggal — bisa diedit)</span>
                </label>
                <input
                  type="text"
                  value={contractPeriod}
                  onChange={(e) => setContractPeriod(e.target.value.toUpperCase())}
                  placeholder="28 SEPTEMBER – 31 DESEMBER 2026"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs uppercase focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-bold text-slate-600">
                    Tanggal Mulai (Start Date)
                  </label>
                  <div className="flex gap-1 text-[10px]">
                    <button
                      type="button"
                      onClick={() => handleSetPeriodMonths(3)}
                      className="bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded font-semibold text-slate-700 cursor-pointer"
                    >
                      3 Bln
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSetPeriodMonths(6)}
                      className="bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded font-semibold text-slate-700 cursor-pointer"
                    >
                      6 Bln
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSetPeriodMonths(12)}
                      className="bg-emerald-100 hover:bg-emerald-200 px-1.5 py-0.5 rounded font-bold text-emerald-800 cursor-pointer"
                    >
                      1 Thn
                    </button>
                  </div>
                </div>
                <input
                  type="date"
                  value={contractStartDate}
                  onChange={(e) => {
                    const start = e.target.value;
                    setContractStartDate(start);
                    // Expiry ikut ke 31 Desember tahun Start Date (tetap bisa diubah manual).
                    let end = contractEndDate;
                    if (start) {
                      const d = new Date(start);
                      if (!isNaN(d.getTime())) {
                        const dec31 = new Date(d.getFullYear(), 11, 31);
                        end = formatDateForInput(dec31);
                        setContractEndDate(end);
                      }
                    }
                    const p = formatPeriodFromDates(start, end);
                    if (p) setContractPeriod(p);
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Tanggal Berakhir (Expiry Date) - <span className="text-rose-600 font-bold">Expiry Tracker</span>
                </label>
                <input
                  type="date"
                  value={contractEndDate}
                  onChange={(e) => {
                    setContractEndDate(e.target.value);
                    const p = formatPeriodFromDates(contractStartDate, e.target.value);
                    if (p) setContractPeriod(p);
                  }}
                  className="w-full px-3 py-2 bg-rose-50/50 border border-rose-200 rounded-xl font-bold text-rose-800 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Teks Pengantar Kontrak (Intro Text) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                3. Teks Pengantar Kontrak (Intro Text)
              </h2>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    const standardIntro = `Salam hangat dari ${settings.businessName || 'BUKIT LANGIT CAMPVENTURE'}. Bersama ini kami sampaikan penawaran daftar harga kontrak resmi untuk perusahaan Anda sebagai berikut:`;
                    setContractIntroText(standardIntro);
                    showSuccess('Teks pengantar dikembalikan ke teks standar.');
                  }}
                  className="text-[10px] text-slate-500 hover:text-slate-700 font-semibold px-2 py-0.5 rounded hover:bg-slate-100 cursor-pointer"
                >
                  Reset Standar
                </button>
                <button
                  type="button"
                  onClick={handleSaveFormatAsDefault}
                  className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-lg border border-emerald-200 cursor-pointer"
                >
                  <Save className="w-3 h-3 text-emerald-600" />
                  <span>Simpan sbg Default Baru</span>
                </button>
              </div>
            </div>

            <textarea
              rows={2}
              value={contractIntroText}
              onChange={(e) => setContractIntroText(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 leading-relaxed"
            />
          </div>

          {/* Section 4: Tabel Harga Kamar */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-600" />
                  <span>4. Tabel Harga Kamar B2B</span>
                </h2>
                <p className="text-[11px] text-slate-500">
                  Centang tipe kamar dari Master Settings atau sesuaikan tarif khusus untuk mitra ini.
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setRoomRates(settings.defaultRoomRates ? JSON.parse(JSON.stringify(settings.defaultRoomRates)) : []);
                    showSuccess('Semua kamar dari Master Settings terpilih.');
                  }}
                  className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg font-bold text-[10px] cursor-pointer"
                >
                  Pilih Semua
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRoomRates([]);
                    showSuccess('Tabel kamar dikosongkan.');
                  }}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold text-[10px] cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>

            {/* Room Rate Table Title Input */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Judul Tabel Harga Kamar (Tampil di Dokumen)
              </label>
              <input
                type="text"
                value={roomRateTableTitle}
                onChange={(e) => setRoomRateTableTitle(e.target.value.toUpperCase())}
                placeholder="DAFTAR HARGA KAMAR (WEEKDAY & WEEKEND / HARI BESAR / HIGH SEASON)"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold uppercase text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Room Checklist from Settings */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-slate-700 block">
                Pilih & Sesuaikan Tipe Kamar:
              </span>
              {settings.defaultRoomRates && settings.defaultRoomRates.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  {settings.defaultRoomRates.map((defaultRate, idx) => {
                    const isChecked = roomRates.some((r) => r.roomType === defaultRate.roomType);
                    return (
                      <label
                        key={defaultRate.id || idx}
                        className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                          isChecked
                            ? 'bg-emerald-50/80 border-emerald-300 shadow-2xs'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            const current = [...roomRates];
                            const existingIdx = current.findIndex((r) => r.roomType === defaultRate.roomType);
                            if (existingIdx >= 0) {
                              current.splice(existingIdx, 1);
                            } else {
                              current.push(JSON.parse(JSON.stringify(defaultRate)));
                            }
                            setRoomRates(current);
                          }}
                          className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                        />
                        <div className="flex-1 text-xs">
                          <div className="font-bold uppercase text-slate-800 flex items-center justify-between">
                            <span>{defaultRate.roomType}</span>
                            {defaultRate.code && (
                              <span className="px-1.5 py-0.5 bg-slate-200 text-slate-700 text-[9.5px] rounded font-mono font-bold">
                                {defaultRate.code}
                              </span>
                            )}
                          </div>
                          <div className="text-[10.5px] font-mono text-emerald-800 mt-0.5 flex gap-2">
                            <span>
                              Wkday: Rp {((defaultRate.weekdaySpecialRate || defaultRate.specialRate || 0) / 1000).toLocaleString('id-ID')}k
                            </span>
                            <span>
                              Wkend: Rp {((defaultRate.weekendSpecialRate || defaultRate.specialRate || 0) / 1000).toLocaleString('id-ID')}k
                            </span>
                          </div>
                          {defaultRate.inclusions && (
                            <div className="text-[10px] text-slate-500 truncate mt-0.5">
                              {defaultRate.inclusions}
                            </div>
                          )}
                        </div>
                      </label>
                    );
                  })}
                </div>
              ) : (
                <p className="text-center py-4 bg-slate-50 rounded-xl text-slate-400 text-xs italic">
                  Belum ada data kamar di Master Settings.
                </p>
              )}
            </div>

            {/* Footnote Kamar Editor */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="text-[11px] font-bold text-slate-700 uppercase flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={roomRateNotesEnabled}
                    onChange={(e) => setRoomRateNotesEnabled(e.target.checked)}
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5 cursor-pointer"
                  />
                  <span>Catatan Footnote (*) di Bawah Tabel Kamar</span>
                </label>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setRoomRateNotes(DEFAULT_ROOM_RATE_NOTES)}
                    className="text-[10px] text-slate-500 hover:text-slate-700 font-semibold px-2 py-0.5 rounded hover:bg-slate-200 cursor-pointer"
                  >
                    Reset Teks Standar
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveFormatAsDefault}
                    className="text-[10px] bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-200 cursor-pointer"
                  >
                    Simpan sbg Default
                  </button>
                </div>
              </div>
              <textarea
                rows={2}
                value={roomRateNotes}
                onChange={(e) => setRoomRateNotes(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono text-[11px] focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Section 5: Tabel Paket & Aktivitas */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>5. Tabel Paket & Aktivitas (ATV, Meeting, Outbound, dll)</span>
                </h2>
                <p className="text-[11px] text-slate-500">
                  Centang paket atau aktivitas yang ingin disertakan pada kontrak mitra ini.
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setPackageTables(settings.defaultPackageTables ? JSON.parse(JSON.stringify(settings.defaultPackageTables)) : []);
                    showSuccess('Semua paket & aktivitas dipilih.');
                  }}
                  className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg font-bold text-[10px] cursor-pointer"
                >
                  Pilih Semua
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPackageTables([]);
                    showSuccess('Daftar pilihan aktivitas dikosongkan.');
                  }}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold text-[10px] cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>

            {settings.defaultPackageTables && settings.defaultPackageTables.length > 0 ? (
              <div className="space-y-4">
                {settings.defaultPackageTables.map((defaultTable, tIdx) => {
                  const currentContractTable = packageTables.find(
                    (t) => (defaultTable.id && t.id === defaultTable.id) || t.title === defaultTable.title,
                  );
                  const selectedItemsCount = currentContractTable?.items?.length || 0;
                  const totalItemsInTable = defaultTable.items?.length || 0;
                  const isAllTableItemsChecked = totalItemsInTable > 0 && selectedItemsCount === totalItemsInTable;

                  return (
                    <div
                      key={defaultTable.id || tIdx}
                      className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-3"
                    >
                      {/* Table Header */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs uppercase text-slate-900 tracking-wide">
                            {defaultTable.title}
                          </span>
                          {defaultTable.code && (
                            <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 text-[9.5px] font-mono font-bold">
                              {defaultTable.code}
                            </span>
                          )}
                          <span
                            className={`text-[9.5px] font-bold px-2 py-0.5 rounded-full border ${
                              selectedItemsCount > 0
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : 'bg-slate-200 text-slate-600 border-slate-300'
                            }`}
                          >
                            {selectedItemsCount}/{totalItemsInTable} dipilih
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            const current = [...packageTables];
                            const tableIdx = current.findIndex(
                              (t) => (defaultTable.id && t.id === defaultTable.id) || t.title === defaultTable.title,
                            );
                            if (isAllTableItemsChecked) {
                              if (tableIdx >= 0) current.splice(tableIdx, 1);
                            } else {
                              if (tableIdx >= 0) {
                                current[tableIdx].items = JSON.parse(JSON.stringify(defaultTable.items || []));
                              } else {
                                current.push(JSON.parse(JSON.stringify(defaultTable)));
                              }
                            }
                            setPackageTables(current);
                          }}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                            isAllTableItemsChecked
                              ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {isAllTableItemsChecked ? 'Batal Pilih Semua di Tabel Ini' : 'Pilih Semua di Tabel Ini'}
                        </button>
                      </div>

                      {/* Items Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {defaultTable.items.map((item, itemIdx) => {
                          const isItemChecked = !!currentContractTable?.items?.some(
                            (i) => (item.id && i.id === item.id) || i.name === item.name,
                          );

                          return (
                            <label
                              key={item.id || itemIdx}
                              className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                                isItemChecked
                                  ? 'bg-emerald-50/80 border-emerald-300 shadow-2xs'
                                  : 'bg-white border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isItemChecked}
                                onChange={() => {
                                  const current = [...packageTables];
                                  let tableIndex = current.findIndex(
                                    (t) => (defaultTable.id && t.id === defaultTable.id) || t.title === defaultTable.title,
                                  );

                                  if (tableIndex >= 0) {
                                    const targetTable = current[tableIndex];
                                    const iIdx = targetTable.items?.findIndex(
                                      (i) => (item.id && i.id === item.id) || i.name === item.name,
                                    ) ?? -1;

                                    if (iIdx >= 0) {
                                      targetTable.items.splice(iIdx, 1);
                                      if (targetTable.items.length === 0) current.splice(tableIndex, 1);
                                    } else {
                                      if (!targetTable.items) targetTable.items = [];
                                      targetTable.items.push(JSON.parse(JSON.stringify(item)));
                                    }
                                  } else {
                                    current.push({
                                      ...defaultTable,
                                      items: [JSON.parse(JSON.stringify(item))],
                                    });
                                  }
                                  setPackageTables(current);
                                }}
                                className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                              />
                              <div className="flex-1 min-w-0 text-xs">
                                <div className="font-bold text-slate-900 uppercase flex items-center justify-between gap-1">
                                  <span className="truncate">{item.name}</span>
                                  {item.duration && (
                                    <span className="shrink-0 text-[9.5px] px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded font-semibold">
                                      {item.duration}
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10.5px] font-mono text-emerald-800 mt-0.5 flex items-center gap-2">
                                  <span className="font-bold">
                                    Rp {(item.specialRate || 0).toLocaleString('id-ID')} (NETT)
                                  </span>
                                  {item.publishedRate > 0 && (
                                    <span className="text-[10px] text-slate-400 line-through">
                                      Rp {item.publishedRate.toLocaleString('id-ID')}
                                    </span>
                                  )}
                                </div>
                                {item.inclusions && (
                                  <div className="text-[10px] text-slate-500 line-clamp-2 mt-0.5 leading-tight">
                                    {item.inclusions}
                                  </div>
                                )}
                              </div>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center py-4 bg-slate-50 rounded-xl text-slate-400 text-xs italic">
                Belum ada data paket di Master Settings.
              </p>
            )}
          </div>

          {/* Section 6: Syarat & Ketentuan Surcharge & Klausul Umum */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>6. Syarat, Ketentuan & Klausul Kontrak</span>
              </h2>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={showTermsAndConditions}
                  onChange={(e) => setShowTermsAndConditions(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer"
                />
                <div className="flex-1">
                  <div className="font-bold text-slate-900 text-xs">
                    Sertakan Syarat & Ketentuan Surcharge pada Dokumen
                  </div>
                  <p className="text-[10.5px] text-slate-500 mt-0.5">
                    Biaya tambahan musim ramai (High/Peak Season), aturan check-in/out, dan penjaminan pemesanan.
                  </p>
                </div>
              </label>
            </div>

            {/* Collapsible Klausul Baku */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div
                className="p-3 bg-slate-50 flex items-center justify-between cursor-pointer select-none"
                onClick={() => setIsKlausulExpanded(!isKlausulExpanded)}
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-bold text-slate-900 text-xs">
                      Klausul Umum Kontrak (Pembatalan, Kesepakatan, Force Majeure)
                    </span>
                    <p className="text-[10.5px] text-slate-500">
                      Pasal standar dicetak berurutan di akhir dokumen kontrak sebelum tanda tangan.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-emerald-700 text-xs font-bold">
                  <span>{isKlausulExpanded ? 'Tutup Editor' : 'Buka Editor Klausul'}</span>
                  {isKlausulExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </div>

              {isKlausulExpanded && (
                <div className="p-4 bg-white border-t border-slate-200 space-y-4">
                  {klausulKontrak.map((k, kIdx) => (
                    <div key={k.id || kIdx} className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-700 text-xs">{kIdx + 1}.</span>
                          <input
                            type="text"
                            value={k.judul}
                            onChange={(e) => {
                              const updated = [...klausulKontrak];
                              updated[kIdx].judul = e.target.value.toUpperCase();
                              setKlausulKontrak(updated);
                            }}
                            className="font-bold font-mono text-xs px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-slate-900"
                            placeholder="JUDUL KLAUSUL"
                          />
                        </div>
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={k.aktif !== false}
                            onChange={(e) => {
                              const updated = [...klausulKontrak];
                              updated[kIdx].aktif = e.target.checked;
                              setKlausulKontrak(updated);
                            }}
                            className="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300"
                          />
                          <span className="text-[11px] font-medium text-slate-600">
                            {k.aktif !== false ? 'Aktif' : 'Nonaktif'}
                          </span>
                        </label>
                      </div>
                      <textarea
                        rows={4}
                        value={k.isi}
                        onChange={(e) => {
                          const updated = [...klausulKontrak];
                          updated[kIdx].isi = e.target.value;
                          setKlausulKontrak(updated);
                        }}
                        className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg leading-relaxed focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Section 7: Penandatangan Perjanjian */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                7. Penandatangan Perjanjian
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="font-bold text-slate-900 block border-b border-slate-200 pb-1">
                  Pihak Pertama (Manajemen Bukit Langit):
                </span>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Nama Penandatangan:</label>
                  <input
                    type="text"
                    value={signatoryName}
                    onChange={(e) => setSignatoryName(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Jabatan:</label>
                  <input
                    type="text"
                    value={signatoryRole}
                    onChange={(e) => setSignatoryRole(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="font-bold text-slate-900 block border-b border-slate-200 pb-1">
                  Pihak Kedua (Mitra / Instansi):
                </span>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Nama Penandatangan Mitra:</label>
                  <input
                    type="text"
                    value={recipientSignatoryName}
                    onChange={(e) => setRecipientSignatoryName(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-0.5">Jabatan:</label>
                  <input
                    type="text"
                    value={recipientSignatoryRole}
                    onChange={(e) => setRecipientSignatoryRole(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Live PDF Preview Panel (Right) */}
        <div
          className={`lg:col-span-6 sticky top-4 ${
            activeTab === 'form' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col max-h-[88vh]">
            <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-900">
                  Pratinjau Dokumen PDF A4
                </span>
              </div>
              <button
                type="button"
                onClick={handleDownloadPdf}
                disabled={isDownloading}
                className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDownloading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                )}
                <span>Unduh PDF</span>
              </button>
            </div>

            <div className="p-3 bg-slate-100 overflow-x-hidden overflow-y-auto flex-1 flex justify-center">
              <div className="scale-[0.5] sm:scale-[0.62] md:scale-[0.7] lg:scale-[0.6] xl:scale-[0.68] origin-top">
                <DocumentPreview
                  document={buildCurrentDocument()}
                  settings={settings}
                />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Hidden Offscreen Container for Clean PDF Generation.
          Opacity penuh + id khusus 'printable-invoice-capture' supaya hasil PDF tidak blank
          (node ini off-screen jadi tetap tak terlihat user, tapi html2canvas menangkapnya penuh). */}
      <div
        style={{
          position: 'fixed',
          left: -9999,
          top: 0,
          width: '800px',
          opacity: 1,
          pointerEvents: 'none',
          zIndex: -999,
        }}
        aria-hidden="true"
      >
        <DocumentPreview
          document={buildCurrentDocument()}
          settings={settings}
          domId="printable-invoice-capture"
        />
      </div>

      {/* WhatsApp Share Modal */}
      {showWhatsAppModal && (
        <WhatsAppShareModal
          isOpen={showWhatsAppModal}
          onClose={() => setShowWhatsAppModal(false)}
          document={buildCurrentDocument()}
          settings={settings}
        />
      )}
    </div>
  );
};
