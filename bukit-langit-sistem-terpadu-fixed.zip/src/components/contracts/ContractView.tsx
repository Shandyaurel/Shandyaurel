import React, { useState } from 'react';
import { FinancialDocument, ClientContact } from '../../types';
import { ContractDatabaseView } from './ContractDatabaseView';
import { ContractEditorForm } from './ContractEditorForm';

interface ContractViewProps {
  initialPartner?: ClientContact | null;
}

export const ContractView: React.FC<ContractViewProps> = ({ initialPartner }) => {
  const [viewMode, setViewMode] = useState<'list' | 'editor'>(
    initialPartner ? 'editor' : 'list',
  );
  const [editingContract, setEditingContract] = useState<FinancialDocument | null>(null);
  const [targetPartner, setTargetPartner] = useState<ClientContact | null>(
    initialPartner || null,
  );

  React.useEffect(() => {
    if (initialPartner) {
      setTargetPartner(initialPartner);
      setEditingContract(null);
      setViewMode('editor');
    }
  }, [initialPartner]);

  const handleCreateNew = () => {
    setEditingContract(null);
    setTargetPartner(null);
    setViewMode('editor');
  };

  const handleEditContract = (contract: FinancialDocument) => {
    setEditingContract(contract);
    setTargetPartner(null);
    setViewMode('editor');
  };

  const handleSaved = (_doc: FinancialDocument) => {
    // Return to list or stay in editor
    setViewMode('list');
    setEditingContract(null);
  };

  return (
    <div className="space-y-6">
      {viewMode === 'list' ? (
        <ContractDatabaseView
          onCreateNew={handleCreateNew}
          onEditContract={handleEditContract}
        />
      ) : (
        <ContractEditorForm
          initialContract={editingContract}
          targetPartner={targetPartner}
          onSaved={handleSaved}
          onCancel={() => {
            setViewMode('list');
            setEditingContract(null);
            setTargetPartner(null);
          }}
        />
      )}
    </div>
  );
};
