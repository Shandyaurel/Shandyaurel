import React, { useState, useEffect } from 'react';
import { FinancialDocument, BusinessSettings } from '../../types';
import {
  subscribeDocuments,
  deleteDocument,
  saveDocument,
  generateNextDocumentNumber,
  getBusinessSettings,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateToIndonesian } from '../../utils/formatter';
import { generateDocumentPdf } from '../../utils/pdfHelper';
import { DEFAULT_SETTINGS } from '../../utils/storage';
import { DocumentPreview } from '../DocumentPreview';
import { WhatsAppShareModal } from '../documents/WhatsAppShareModal';
import { Modal } from '../common/Modal';
import {
  FileCheck,
  Search,
  Plus,
  Edit3,
  Trash2,
  Copy,
  Download,
  Eye,
  MessageSquare,
  Calendar,
  Building2,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface ContractDatabaseViewProps {
  onCreateNew: () => void;
  onEditContract: (contract: FinancialDocument) => void;
}

export const ContractDatabaseView: React.FC<ContractDatabaseViewProps> = ({
  onCreateNew,
  onEditContract,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const { showSuccess, showError } = useToast();

  const [contracts, setContracts] = useState<FinancialDocument[]>([]);
  const [settings, setSettings] = useState<BusinessSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'expiring' | 'expired'>('all');

  // Preview & Modal States
  const [previewContract, setPreviewContract] = useState<FinancialDocument | null>(null);
  const [printingContract, setPrintingContract] = useState<FinancialDocument | null>(null);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);
  const [whatsAppContract, setWhatsAppContract] = useState<FinancialDocument | null>(null);

  // Deletion State
  const [deletingContract, setDeletingContract] = useState<FinancialDocument | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Duplicate State
  const [duplicatingContract, setDuplicatingContract] = useState<FinancialDocument | null>(null);
  const [isDuplicating, setIsDuplicating] = useState<boolean>(false);

  useEffect(() => {
    getBusinessSettings()
      .then(setSettings)
      .catch(console.error);

    const unsub = subscribeDocuments(
      (docs) => {
        const corpContracts = docs.filter(
          (d) => d.documentType === 'corporate_contract',
        );
        setContracts(corpContracts);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error fetching contracts:', err);
        showError('Gagal memuat daftar kontrak dari server.');
        setIsLoading(false);
      },
    );

    return () => unsub();
  }, []);

  // Expiry calculation helper
  const getContractExpiryStatus = (doc: FinancialDocument) => {
    if (!doc.contractEndDate) {
      return { status: 'active', label: 'Aktif', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300', daysLeft: 999 };
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const end = new Date(doc.contractEndDate);
    end.setHours(0, 0, 0, 0);

    const diffTime = end.getTime() - today.getTime();
    const daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (daysLeft < 0) {
      return {
        status: 'expired',
        label: `Kadaluarsa (${Math.abs(daysLeft)} hari lalu)`,
        badgeClass: 'bg-rose-100 text-rose-800 border-rose-300',
        daysLeft,
      };
    } else if (daysLeft <= 30) {
      return {
        status: 'expiring',
        label: `Segera Berakhir (${daysLeft} hari lagi)`,
        badgeClass: 'bg-amber-100 text-amber-800 border-amber-300',
        daysLeft,
      };
    } else {
      return {
        status: 'active',
        label: `Aktif (${daysLeft} hari lagi)`,
        badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
        daysLeft,
      };
    }
  };

  // Filtered List
  const filteredContracts = contracts.filter((c) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      (c.documentNumber && c.documentNumber.toLowerCase().includes(q)) ||
      (c.guestName && c.guestName.toLowerCase().includes(q)) ||
      (c.guestOrganization && c.guestOrganization.toLowerCase().includes(q)) ||
      (c.companyContactPerson && c.companyContactPerson.toLowerCase().includes(q)) ||
      (c.guestPhone && c.guestPhone.includes(q));

    if (!matchesSearch) return false;

    const expiry = getContractExpiryStatus(c);
    if (statusFilter === 'active') return expiry.status === 'active';
    if (statusFilter === 'expiring') return expiry.status === 'expiring';
    if (statusFilter === 'expired') return expiry.status === 'expired';
    return true;
  });

  // KPI Calculations
  const totalCount = contracts.length;
  const activeCount = contracts.filter((c) => getContractExpiryStatus(c).status === 'active').length;
  const expiringCount = contracts.filter((c) => getContractExpiryStatus(c).status === 'expiring').length;
  const expiredCount = contracts.filter((c) => getContractExpiryStatus(c).status === 'expired').length;

  // Handle PDF Download
  const handleDownloadPdf = async (doc: FinancialDocument) => {
    try {
      setIsDownloadingPdf(true);
      setPrintingContract(doc);
      await new Promise((r) => setTimeout(r, 150));
      await generateDocumentPdf(doc, settings);
      showSuccess(`PDF Kontrak #${doc.documentNumber} berhasil diunduh.`);
    } catch (err) {
      showError((err as Error).message || 'Gagal mengunduh file PDF.');
    } finally {
      setIsDownloadingPdf(false);
      setPrintingContract(null);
    }
  };

  // Handle Duplication
  const handleDuplicateContract = async () => {
    if (!duplicatingContract) return;

    try {
      setIsDuplicating(true);
      const { docNumber } = await generateNextDocumentNumber('CTR');
      const now = new Date().toISOString();

      const newDocData: FinancialDocument = {
        ...duplicatingContract,
        id: '',
        documentNumber: docNumber,
        documentDate: now.split('T')[0],
        documentTitle: duplicatingContract.documentTitle || 'SURAT PERJANJIAN KERJASAMA (KONTRAK B2B)',
        createdAt: now,
        updatedAt: now,
      };

      const saved = await saveDocument(newDocData, currentUser?.email || 'admin');
      if (saved) {
        showSuccess(`Berhasil menduplikasi kontrak menjadi #${saved.documentNumber}`);
        setDuplicatingContract(null);
        onEditContract(saved);
      }
    } catch (err) {
      showError((err as Error).message || 'Gagal menduplikasi kontrak.');
    } finally {
      setIsDuplicating(false);
    }
  };

  // Handle Deletion (Optimistic)
  const handleDeleteConfirm = () => {
    if (!deletingContract) return;
    const target = deletingContract;
    const reason = deleteReason.trim() || 'Dihapus dari database kontrak B2B';
    const userEmail = currentUser?.email || 'admin';

    // (1) Tutup modal & tampilkan notifikasi segera (OPTIMISTIC <1 detik)
    setDeletingContract(null);
    setDeleteReason('');
    showSuccess(`Kontrak #${target.documentNumber} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteDocument(target, userEmail, reason).catch((err) => {
      console.error('Error deleting contract:', err);
      showError('Gagal sinkron hapus kontrak ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Quick Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <FileCheck className="w-5 h-5 text-blue-600" />
            <span>Database Kontrak B2B & Corporate Rate</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola arsip surat perjanjian kerjasama mitra travel agen, instansi korporat, dan masa berlaku tarif spesial.
          </p>
        </div>

        <button
          type="button"
          onClick={onCreateNew}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm cursor-pointer transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Buat Kontrak B2B Baru</span>
        </button>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Kontrak</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-xs">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalCount}</p>
          <span className="text-[11px] text-slate-400">Arsip perjanjian B2B</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700">Kontrak Aktif</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-xs">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-950 mt-2">{activeCount}</p>
          <span className="text-[11px] text-emerald-600 font-medium">Tarif berlaku aktif</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-700">Akan Berakhir</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-xs">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-950 mt-2">{expiringCount}</p>
          <span className="text-[11px] text-amber-600 font-medium">&lt; 30 hari lagi</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700">Kadaluarsa</span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold text-xs">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-950 mt-2">{expiredCount}</p>
          <span className="text-[11px] text-rose-600 font-medium">Perlu perpanjangan</span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nomor kontrak, mitra, PIC..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-all ${
              statusFilter === 'all'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua ({totalCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('active')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-all ${
              statusFilter === 'active'
                ? 'bg-white text-emerald-900 font-bold shadow-sm'
                : 'text-slate-600 hover:text-emerald-700'
            }`}
          >
            Aktif ({activeCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('expiring')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-all ${
              statusFilter === 'expiring'
                ? 'bg-white text-amber-900 font-bold shadow-sm'
                : 'text-slate-600 hover:text-amber-700'
            }`}
          >
            Akan Berakhir ({expiringCount})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('expired')}
            className={`px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap cursor-pointer transition-all ${
              statusFilter === 'expired'
                ? 'bg-white text-rose-900 font-bold shadow-sm'
                : 'text-slate-600 hover:text-rose-700'
            }`}
          >
            Kadaluarsa ({expiredCount})
          </button>
        </div>
      </div>

      {/* Contracts Table / List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600 mb-2" />
            <p className="text-xs">Memuat database kontrak B2B...</p>
          </div>
        ) : filteredContracts.length === 0 ? (
          <div className="p-12 text-center">
            <FileCheck className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800">
              Belum Ada Dokumen Kontrak
            </h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              {searchQuery
                ? 'Tidak ada kontrak yang sesuai dengan kriteria pencarian.'
                : 'Mulai buat kontrak B2B pertama untuk memberikan harga khusus travel agent atau korporat.'}
            </p>
            {!searchQuery && (
              <button
                type="button"
                onClick={onCreateNew}
                className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Buat Kontrak Sekarang</span>
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[11px] tracking-wider">
                  <th className="py-3 px-4">No. Kontrak & Tanggal</th>
                  <th className="py-3 px-4">Mitra / Perusahaan</th>
                  <th className="py-3 px-4">Masa Berlaku</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Tipe Tarif</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredContracts.map((c) => {
                  const expiry = getContractExpiryStatus(c);
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-mono font-bold text-slate-900 text-xs">
                          {c.documentNumber}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Terbit: {formatDateToIndonesian(c.documentDate || c.createdAt)}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                          <span>{c.guestName || 'Mitra Umum'}</span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {c.guestOrganization || c.guestAddress || '-'}
                        </div>
                        {c.companyContactPerson && (
                          <div className="text-[10px] text-blue-700 font-medium mt-0.5">
                            PIC: {c.companyContactPerson} {c.companyContactTitle ? `(${c.companyContactTitle})` : ''}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="text-xs font-semibold text-slate-800">
                          {c.contractPeriod ||
                            `${c.contractStartDate || '-'} s/d ${c.contractEndDate || '-'}`}
                        </div>
                        {c.contractEndDate && (
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            Hingga: {formatDateToIndonesian(c.contractEndDate)}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border ${expiry.badgeClass}`}
                        >
                          {expiry.label}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="text-xs text-slate-700 font-medium">
                          {(c.roomRates || []).length} Tipe Kamar
                        </div>
                        {c.includeMeetingPackages && (
                          <span className="text-[10px] text-purple-700 font-semibold block">
                            + Paket Meeting/Outbound
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            title="Pratinjau A4"
                            onClick={() => setPreviewContract(c)}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Unduh PDF"
                            onClick={() => handleDownloadPdf(c)}
                            disabled={isDownloadingPdf}
                            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
                          >
                            <Download className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Kirim Pesan WhatsApp"
                            onClick={() => setWhatsAppContract(c)}
                            className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg cursor-pointer"
                          >
                            <MessageSquare className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Duplikat Kontrak"
                            onClick={() => setDuplicatingContract(c)}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer"
                          >
                            <Copy className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Edit Kontrak"
                            onClick={() => onEditContract(c)}
                            className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {isAdmin && (
                            <button
                              type="button"
                              title="Hapus Kontrak"
                              onClick={() => setDeletingContract(c)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL 1: PREVIEW A4 & INSTANT DOWNLOAD */}
      {previewContract && (
        <Modal
          isOpen={Boolean(previewContract)}
          onClose={() => setPreviewContract(null)}
          title={`Pratinjau Kontrak #${previewContract.documentNumber} - ${previewContract.guestName}`}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <p className="text-xs font-bold text-slate-900">
                  {previewContract.guestName}
                </p>
                <p className="text-[11px] text-slate-500">
                  Masa Berlaku:{' '}
                  {previewContract.contractPeriod ||
                    `${previewContract.contractStartDate} s/d ${previewContract.contractEndDate}`}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setWhatsAppContract(previewContract)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Kirim WA</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadPdf(previewContract)}
                  disabled={isDownloadingPdf}
                  className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
                >
                  {isDownloadingPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  <span>Unduh PDF</span>
                </button>
              </div>
            </div>

            <div className="max-h-[68vh] overflow-y-auto bg-slate-100 p-3 rounded-xl flex justify-center border border-slate-200">
              <div className="scale-[0.62] sm:scale-[0.78] md:scale-[0.88] origin-top">
                <DocumentPreview
                  document={previewContract}
                  settings={settings}
                />
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* MODAL 2: DUPLICATE CONFIRMATION */}
      {duplicatingContract && (
        <Modal
          isOpen={Boolean(duplicatingContract)}
          onClose={() => setDuplicatingContract(null)}
          title="Duplikat Kontrak Kerjasama B2B"
          maxWidth="max-w-md"
        >
          <div className="space-y-4 text-xs">
            <p className="text-slate-600 leading-relaxed">
              Anda akan membuat salinan baru dari kontrak{' '}
              <strong className="text-slate-900">
                #{duplicatingContract.documentNumber} ({duplicatingContract.guestName})
              </strong>
              . Nomor kontrak baru akan otomatis di-generate secara berurutan.
            </p>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl space-y-1">
              <span className="font-bold text-blue-900 block">Detail Salinan:</span>
              <p className="text-blue-800">
                • Mitra: {duplicatingContract.guestName}
              </p>
              <p className="text-blue-800">
                • Periode: {duplicatingContract.contractPeriod || '1 Tahun'}
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDuplicatingContract(null)}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDuplicateContract}
                disabled={isDuplicating}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDuplicating && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Duplikat Sekarang</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* MODAL 3: DELETE CONFIRMATION WITH REASON */}
      {deletingContract && (
        <Modal
          isOpen={Boolean(deletingContract)}
          onClose={() => setDeletingContract(null)}
          title="Hapus Dokumen Kontrak B2B"
          maxWidth="max-w-md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Konfirmasi Penghapusan</p>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  Tindakan ini akan memindahkan rekaman kontrak ke arsip riwayat penghapusan <code>deletion_history</code> dan menghapusnya dari database aktif.
                </p>
              </div>
            </div>

            <p className="text-slate-700">
              Kontrak:{' '}
              <strong className="text-slate-900">
                #{deletingContract.documentNumber} - {deletingContract.guestName}
              </strong>
            </p>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Alasan Penghapusan (Wajib):
              </label>
              <textarea
                rows={3}
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                placeholder="Contoh: Kesalahan input nomor, kontrak dibatalkan, atau duplikat..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:bg-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setDeletingContract(null)}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={isDeleting || !deleteReason.trim()}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDeleting && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>Hapus Kontrak</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* MODAL 4: WHATSAPP SHARE */}
      {whatsAppContract && (
        <WhatsAppShareModal
          isOpen={Boolean(whatsAppContract)}
          onClose={() => setWhatsAppContract(null)}
          document={whatsAppContract}
          settings={settings}
        />
      )}

      {/* Offscreen unclipped container for instant high-res PDF generation.
          Opacity penuh + id khusus 'printable-invoice-capture' supaya PDF tidak blank. */}
      {printingContract && (
        <div
          style={{
            position: 'fixed',
            left: -9999,
            top: 0,
            width: '800px',
            opacity: 1,
            pointerEvents: 'none',
            zIndex: -999,
          }}
          aria-hidden="true"
        >
          <DocumentPreview
            document={printingContract}
            settings={settings}
            domId="printable-invoice-capture"
          />
        </div>
      )}
    </div>
  );
};
