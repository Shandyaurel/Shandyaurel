import React, { useState, useEffect, useMemo } from 'react';
import {
  DollarSign,
  CalendarCheck,
  Compass,
  TrendingUp,
  Users,
  Calendar,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  MessageCircle,
  ExternalLink,
  ChevronRight,
  FileText,
  CreditCard,
  Sparkles,
  ShoppingBag,
  Activity,
  CheckCircle2,
  AlertCircle,
  PhoneCall,
  Flame,
  Target,
  Sliders,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
  CartesianGrid,
} from 'recharts';
import {
  Booking,
  ATVBooking,
  BreakfastRecord,
  ExtraIncomeItem,
  Lead,
  SystemLog,
  BusinessSettings,
  MonthlyTarget,
} from '../../types';
import {
  subscribeBookings,
  subscribeATVBookings,
  subscribeBreakfast,
  subscribeExtraIncome,
  subscribeLeads,
  subscribeSystemLogs,
  getBusinessSettings,
  subscribeMonthlyTarget,
} from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatter';
import { useAuth } from '../../context/AuthContext';

interface DashboardViewProps {
  onNavigateToModule?: (moduleKey: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigateToModule }) => {
  const { currentUser, isAdmin } = useAuth();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [atvBookings, setAtvBookings] = useState<ATVBooking[]>([]);
  const [breakfastRecords, setBreakfastRecords] = useState<BreakfastRecord[]>([]);
  const [extraIncomeItems, setExtraIncomeItems] = useState<ExtraIncomeItem[]>([]);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | undefined>(undefined);
  const [monthlyTarget, setMonthlyTarget] = useState<MonthlyTarget | null>(null);
  const [defaultTarget, setDefaultTarget] = useState<MonthlyTarget | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Today and Month Calculation
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthIdx = now.getMonth(); // 0-11
  const todayStr = now.toISOString().split('T')[0];
  const currentMonthPrefix = `${currentYear}-${String(currentMonthIdx + 1).padStart(2, '0')}`;

  // Subscribe to real collections
  useEffect(() => {
    let isMounted = true;

    getBusinessSettings().then((s) => {
      if (isMounted) setSettings(s);
    });

    const unsubTarget = subscribeMonthlyTarget(currentMonthPrefix, (t) => {
      if (isMounted) setMonthlyTarget(t);
    });

    // Poin 1: target DEFAULT (dipakai kalau target bulan berjalan belum diisi)
    const unsubDefaultTarget = subscribeMonthlyTarget('default', (t) => {
      if (isMounted) setDefaultTarget(t);
    });

    const unsubBookings = subscribeBookings((data) => {
      if (isMounted) setBookings(data);
    });

    const unsubATV = subscribeATVBookings((data) => {
      if (isMounted) setAtvBookings(data);
    });

    const unsubBreakfast = subscribeBreakfast((data) => {
      if (isMounted) setBreakfastRecords(data);
    });

    const unsubExtra = subscribeExtraIncome((data) => {
      if (isMounted) setExtraIncomeItems(data);
    });

    const unsubLeads = subscribeLeads((data) => {
      if (isMounted) setLeads(data);
    });

    const unsubLogs = subscribeSystemLogs((data) => {
      if (isMounted) {
        setLogs(data);
        setIsLoading(false);
      }
    });

    return () => {
      isMounted = false;
      unsubTarget();
      unsubDefaultTarget();
      unsubBookings();
      unsubATV();
      unsubBreakfast();
      unsubExtra();
      unsubLeads();
      unsubLogs();
    };
  }, [currentMonthPrefix]);
  
  // Previous Month Prefix
  const prevMonthDate = new Date(currentYear, currentMonthIdx - 1, 1);
  const prevMonthPrefix = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}`;

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const currentMonthLabel = `${monthNames[currentMonthIdx]} ${currentYear}`;
  const prevMonthLabel = `${monthNames[prevMonthDate.getMonth()]} ${prevMonthDate.getFullYear()}`;

  // Helper date extractor
  const isMatchMonth = (dateStr: string | undefined, monthPrefix: string) => {
    if (!dateStr) return false;
    return dateStr.startsWith(monthPrefix);
  };

  // 1. Current Month & Prev Month Aggregations
  const metrics = useMemo(() => {
    // CURRENT MONTH
    // A. Hotel Bookings
    const currentMonthBookings = bookings.filter((b) => isMatchMonth(b.date || b.checkInDate || b.createdAt, currentMonthPrefix));
    const currentHotelRevenue = currentMonthBookings.reduce((sum, b) => {
      if (b.status === 'Cancelled') return sum;
      return sum + (b.pendapatan || 0);
    }, 0);
    const currentHotelCount = currentMonthBookings.filter((b) => b.status !== 'Cancelled').length;

    // B. ATV Bookings
    const currentMonthATV = atvBookings.filter((a) => isMatchMonth(a.date || a.bookingDate || a.createdAt, currentMonthPrefix));
    const currentATVRevenue = currentMonthATV.reduce((sum, a) => {
      if (a.status === 'Cancelled') return sum;
      return sum + (a.pendapatan || 0);
    }, 0);

    // C. Breakfast
    const currentMonthBreakfast = breakfastRecords.filter((br) => isMatchMonth(br.date || br.createdAt, currentMonthPrefix));
    const currentBreakfastRevenue = currentMonthBreakfast.reduce((sum, br) => {
      if (br.status === 'Dibatalkan') return sum;
      return sum + ((Number(br.qty) || 0) * (Number(br.price) || 0));
    }, 0);

    // D. Extra Income
    const currentMonthExtra = extraIncomeItems.filter((ex) => isMatchMonth(ex.date || ex.createdAt, currentMonthPrefix));
    const currentExtraRevenue = currentMonthExtra.reduce((sum, ex) => {
      const paid = ex.totalPaid !== undefined ? ex.totalPaid : (ex.status === 'Lunas' ? ex.total : 0);
      return sum + (paid || 0);
    }, 0);
    const currentExtraLaba = currentMonthExtra.reduce((sum, ex) => {
      const cost = Number(ex.cost) || 0;
      const total = Number(ex.total) || 0;
      const calculatedLaba = ex.laba !== undefined ? Number(ex.laba) : (total - cost);
      return sum + calculatedLaba;
    }, 0);

    // E. Leads
    const currentMonthLeads = leads.filter((l) => isMatchMonth(l.chatDate || l.createdAt, currentMonthPrefix));
    const currentLeadsCount = currentMonthLeads.length;

    const currentTotalRevenue = currentHotelRevenue + currentATVRevenue + currentBreakfastRevenue + currentExtraRevenue;

    // PREVIOUS MONTH
    const prevMonthBookings = bookings.filter((b) => isMatchMonth(b.date || b.checkInDate || b.createdAt, prevMonthPrefix));
    const prevHotelRevenue = prevMonthBookings.reduce((sum, b) => (b.status !== 'Cancelled' ? sum + (b.pendapatan || 0) : sum), 0);
    const prevHotelCount = prevMonthBookings.filter((b) => b.status !== 'Cancelled').length;

    const prevMonthATV = atvBookings.filter((a) => isMatchMonth(a.date || a.bookingDate || a.createdAt, prevMonthPrefix));
    const prevATVRevenue = prevMonthATV.reduce((sum, a) => (a.status !== 'Cancelled' ? sum + (a.pendapatan || 0) : sum), 0);

    const prevMonthBreakfast = breakfastRecords.filter((br) => isMatchMonth(br.date || br.createdAt, prevMonthPrefix));
    const prevBreakfastRevenue = prevMonthBreakfast.reduce((sum, br) => (br.status !== 'Dibatalkan' ? sum + ((br.qty || 0) * (br.price || 0)) : sum), 0);

    const prevMonthExtra = extraIncomeItems.filter((ex) => isMatchMonth(ex.date || ex.createdAt, prevMonthPrefix));
    const prevExtraRevenue = prevMonthExtra.reduce((sum, ex) => {
      const paid = ex.totalPaid !== undefined ? ex.totalPaid : (ex.status === 'Lunas' ? ex.total : 0);
      return sum + (paid || 0);
    }, 0);
    const prevExtraLaba = prevMonthExtra.reduce((sum, ex) => {
      const cost = Number(ex.cost) || 0;
      const total = Number(ex.total) || 0;
      return sum + (ex.laba !== undefined ? Number(ex.laba) : (total - cost));
    }, 0);

    const prevMonthLeads = leads.filter((l) => isMatchMonth(l.chatDate || l.createdAt, prevMonthPrefix));
    const prevLeadsCount = prevMonthLeads.length;

    const prevTotalRevenue = prevHotelRevenue + prevATVRevenue + prevBreakfastRevenue + prevExtraRevenue;

    // Calculate Delta %
    const calculateDelta = (current: number, prev: number) => {
      if (prev === 0) return current > 0 ? 100 : 0;
      return Math.round(((current - prev) / prev) * 100);
    };

    return {
      currentTotalRevenue,
      prevTotalRevenue,
      revenueDelta: calculateDelta(currentTotalRevenue, prevTotalRevenue),

      currentHotelRevenue,
      currentHotelCount,
      hotelCountDelta: calculateDelta(currentHotelCount, prevHotelCount),

      currentATVRevenue,
      atvDelta: calculateDelta(currentATVRevenue, prevATVRevenue),

      currentBreakfastRevenue,
      currentExtraRevenue,
      currentExtraLaba,
      extraLabaDelta: calculateDelta(currentExtraLaba, prevExtraLaba),

      currentLeadsCount,
      leadsDelta: calculateDelta(currentLeadsCount, prevLeadsCount),
    };
  }, [bookings, atvBookings, breakfastRecords, extraIncomeItems, leads, currentMonthPrefix, prevMonthPrefix]);

  // 2. Daily Area Chart Data for Current Month
  const dailyChartData = useMemo(() => {
    const daysInMonth = new Date(currentYear, currentMonthIdx + 1, 0).getDate();
    const result: Array<{
      day: string;
      dateLabel: string;
      kamar: number;
      atv: number;
      breakfast: number;
      extra: number;
      total: number;
    }> = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const dayStr = `${currentMonthPrefix}-${String(d).padStart(2, '0')}`;

      // Kamar
      const kamarTotal = bookings
        .filter((b) => (b.date === dayStr || b.checkInDate === dayStr) && b.status !== 'Cancelled')
        .reduce((sum, b) => sum + (b.pendapatan || 0), 0);

      // ATV
      const atvTotal = atvBookings
        .filter((a) => (a.date === dayStr || a.bookingDate === dayStr) && a.status !== 'Cancelled')
        .reduce((sum, a) => sum + (a.pendapatan || 0), 0);

      // Breakfast
      const breakfastTotal = breakfastRecords
        .filter((br) => br.date === dayStr && br.status !== 'Dibatalkan')
        .reduce((sum, br) => sum + ((br.qty || 0) * (br.price || 0)), 0);

      // Extra
      const extraTotal = extraIncomeItems
        .filter((ex) => ex.date === dayStr)
        .reduce((sum, ex) => {
          const paid = ex.totalPaid !== undefined ? ex.totalPaid : (ex.status === 'Lunas' ? ex.total : 0);
          return sum + (paid || 0);
        }, 0);

      const total = kamarTotal + atvTotal + breakfastTotal + extraTotal;

      result.push({
        day: `Tgl ${d}`,
        dateLabel: `${d} ${monthNames[currentMonthIdx].slice(0, 3)}`,
        kamar: kamarTotal,
        atv: atvTotal,
        breakfast: breakfastTotal,
        extra: extraTotal,
        total,
      });
    }

    return result;
  }, [bookings, atvBookings, breakfastRecords, extraIncomeItems, currentMonthPrefix, currentYear, currentMonthIdx, monthNames]);

  // 3. Donut Composition Data
  const compositionData = useMemo(() => {
    const data = [
      { name: 'Kamar Glamping', value: metrics.currentHotelRevenue, color: '#2563EB' },
      { name: 'ATV Adventure', value: metrics.currentATVRevenue, color: '#D97706' },
      { name: 'Sarapan Resto', value: metrics.currentBreakfastRevenue, color: '#059669' },
      { name: 'Pendapatan Tambahan', value: metrics.currentExtraRevenue, color: '#7C3AED' },
    ];
    return data.filter((item) => item.value > 0);
  }, [metrics]);

  // Target Dashboard Calculation (Hotel = Gabungan Kamar Net + Pendapatan Tambahan; ATV = Terpisah; Breakfast = Pengurang biaya)
  const targetMetrics = useMemo(() => {
    const breakfastCostPerPax = monthlyTarget?.breakfastCostPerPax ?? defaultTarget?.breakfastCostPerPax ?? settings?.breakfastCostPerPax ?? settings?.defaultBreakfastCostPerPax ?? 25000;

    const currentMonthBreakfast = breakfastRecords.filter((br) => (br.date || br.createdAt || '').startsWith(currentMonthPrefix));
    const totalBreakfastPax = currentMonthBreakfast.reduce((sum, br) => sum + (Number(br.qty) || 0), 0);

    const currentMonthBookings = bookings.filter((b) => (b.date || b.checkInDate || b.createdAt || '').startsWith(currentMonthPrefix) && b.status !== 'Cancelled');
    const totalRoomGuests = currentMonthBookings.reduce((sum, b) => {
      const roomPax = b.rooms?.reduce((rSum, r) => rSum + (r.roomQty || 1) * 2, 0) || 2;
      return sum + (Number(b.numberOfGuests) || roomPax);
    }, 0);

    const effectivePax = totalBreakfastPax > 0 ? totalBreakfastPax : totalRoomGuests;
    const breakfastDeduction = effectivePax * breakfastCostPerPax;

    const netKamarRevenue = Math.max(0, metrics.currentHotelRevenue - breakfastDeduction);
    // Hotel = target gabungan (pendapatan kamar net + Pendapatan Tambahan)
    const actualHotelNet = netKamarRevenue + metrics.currentExtraRevenue;
    const hotelTarget = monthlyTarget?.hotelTarget || defaultTarget?.hotelTarget || 0;
    const hotelPct = hotelTarget > 0 ? Math.min(100, Math.round((actualHotelNet / hotelTarget) * 100)) : 0;

    // ATV = target terpisah
    const actualAtv = metrics.currentATVRevenue;
    const atvTarget = monthlyTarget?.atvTarget || defaultTarget?.atvTarget || 0;
    const atvPct = atvTarget > 0 ? Math.min(100, Math.round((actualAtv / atvTarget) * 100)) : 0;

    return {
      breakfastCostPerPax,
      effectivePax,
      breakfastDeduction,
      netKamarRevenue,
      actualHotelNet,
      hotelTarget,
      hotelPct,
      actualAtv,
      atvTarget,
      atvPct,
    };
  }, [monthlyTarget, defaultTarget, settings, breakfastRecords, bookings, currentMonthPrefix, metrics]);

  // Laba Bersih Operasional (Poin 4): Gross − Komisi Agen − Biaya Sarapan − HPP Pendapatan Tambahan.
  // Komisi diambil dari field agentFee pada booking/ATV (BUKAN koleksi Agent Fee) agar tidak dobel hitung.
  const labaMetrics = useMemo(() => {
    const curBookings = bookings.filter(
      (b) => isMatchMonth(b.date || b.checkInDate || b.createdAt, currentMonthPrefix) && b.status !== 'Cancelled'
    );
    const curATV = atvBookings.filter(
      (a) => isMatchMonth(a.date || a.bookingDate || a.createdAt, currentMonthPrefix) && a.status !== 'Cancelled'
    );
    const curExtra = extraIncomeItems.filter((ex) => isMatchMonth(ex.date || ex.createdAt, currentMonthPrefix));

    // Pendapatan kotor = sama dengan headline "Pendapatan Bulan Ini" agar angka saling nyambung
    const grossRevenue = metrics.currentTotalRevenue;

    // Komisi Agen = agentFee pada booking + ATV (sumber tunggal, hindari dobel dgn modul Agent Fee)
    const komisiHotel = curBookings.reduce((s, b) => s + (Number(b.agentFee) || 0), 0);
    const komisiAtv = curATV.reduce((s, a) => s + (Number(a.agentFee) || 0), 0);
    const totalKomisi = komisiHotel + komisiAtv;

    // Biaya Sarapan (HPP F&B) = pakai perhitungan yang sama dgn target dashboard
    const biayaSarapan = targetMetrics.breakfastDeduction;

    // HPP Pendapatan Tambahan = modal item extra (sudah net di modulnya)
    const hppExtra = curExtra.reduce((s, ex) => {
      const cost = ex.cost !== undefined ? Number(ex.cost) : ex.totalHpp !== undefined ? Number(ex.totalHpp) : 0;
      return s + (cost || 0);
    }, 0);

    const totalBiaya = totalKomisi + biayaSarapan + hppExtra;
    const labaBersih = grossRevenue - totalBiaya;
    const marginPct = grossRevenue > 0 ? Math.round((labaBersih / grossRevenue) * 100) : 0;

    return {
      grossRevenue,
      komisiHotel,
      komisiAtv,
      totalKomisi,
      biayaSarapan,
      hppExtra,
      totalBiaya,
      labaBersih,
      marginPct,
    };
  }, [bookings, atvBookings, extraIncomeItems, currentMonthPrefix, metrics, targetMetrics]);

  // 4. Follow-up Hari Ini (leads where next_follow_up_date is today or overdue)
  const todayFollowUps = useMemo(() => {
    return leads
      .filter((lead) => {
        if (!lead.next_follow_up_date) return false;
        if (lead.leadStatus === 'Booking Confirmed' || lead.leadStatus === 'Cancelled-Lost') return false;
        return lead.next_follow_up_date <= todayStr;
      })
      .sort((a, b) => ((a.next_follow_up_date || '') > (b.next_follow_up_date || '') ? 1 : -1))
      .slice(0, 6);
  }, [leads, todayStr]);

  // 5. Recent System Activities (from logs)
  const recentActivities = useMemo(() => {
    return (logs || []).slice(0, 7);
  }, [logs]);

  const getLogIcon = (action: string, moduleName?: string) => {
    const act = (action + ' ' + (moduleName || '')).toLowerCase();
    if (act.includes('booking') || act.includes('hotel')) return <CalendarCheck className="w-4 h-4 text-blue-600" />;
    if (act.includes('atv')) return <Compass className="w-4 h-4 text-amber-600" />;
    if (act.includes('dokumen') || act.includes('invoice') || act.includes('kuitansi')) return <FileText className="w-4 h-4 text-indigo-600" />;
    if (act.includes('lead')) return <Users className="w-4 h-4 text-emerald-600" />;
    if (act.includes('extra') || act.includes('pos')) return <ShoppingBag className="w-4 h-4 text-purple-600" />;
    if (act.includes('bayar') || act.includes('transaksi')) return <CreditCard className="w-4 h-4 text-emerald-600" />;
    return <Activity className="w-4 h-4 text-slate-500" />;
  };

  const formatRelativeTime = (timestampStr?: string) => {
    if (!timestampStr) return '-';
    try {
      const date = new Date(timestampStr);
      const diffMs = Date.now() - date.getTime();
      const diffMin = Math.floor(diffMs / 60000);
      const diffHour = Math.floor(diffMin / 60);

      if (diffMin < 1) return 'Baru saja';
      if (diffMin < 60) return `${diffMin} mnt lalu`;
      if (diffHour < 24) return `${diffHour} jam lalu`;
      return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    } catch {
      return timestampStr;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-white/10 text-blue-200 border border-white/10 mb-3 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-300" />
              <span>Realtime Business Analytics • {currentMonthLabel}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Ringkasan Operasional & Pendapatan
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Agregasi pendapatan nyata dari Kamar Glamping, ATV Adventure, Sarapan F&B, dan Extra POS tanpa data estimasi.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right hidden sm:block bg-black/25 px-4 py-2 rounded-xl border border-white/10">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Periode Analisis</span>
              <span className="font-bold text-sm text-white flex items-center gap-1.5 justify-end">
                <Calendar className="w-3.5 h-3.5 text-blue-400" />
                <span>{currentMonthLabel}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 5 Real KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* KPI 1: Total Pendapatan Bulan Ini */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Pendapatan Bulan Ini
              </span>
              <div className="p-2 bg-blue-50 rounded-xl text-blue-600">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              {formatRupiah(metrics.currentTotalRevenue)}
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs mt-3 pt-3 border-t border-slate-100">
            {metrics.revenueDelta >= 0 ? (
              <span className="flex items-center text-emerald-600 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{metrics.revenueDelta}%
              </span>
            ) : (
              <span className="flex items-center text-rose-600 font-bold">
                <ArrowDownRight className="w-3.5 h-3.5" />
                {metrics.revenueDelta}%
              </span>
            )}
            <span className="text-slate-400 text-[11px]">vs {prevMonthLabel.split(' ')[0]}</span>
          </div>
        </div>

        {/* KPI 2: Jumlah Booking Hotel */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Booking Kamar
              </span>
              <div className="p-2 bg-indigo-50 rounded-xl text-indigo-600">
                <CalendarCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              {metrics.currentHotelCount} <span className="text-xs text-slate-400 font-normal">Reservasi</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs mt-3 pt-3 border-t border-slate-100">
            {metrics.hotelCountDelta >= 0 ? (
              <span className="flex items-center text-emerald-600 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{metrics.hotelCountDelta}%
              </span>
            ) : (
              <span className="flex items-center text-rose-600 font-bold">
                <ArrowDownRight className="w-3.5 h-3.5" />
                {metrics.hotelCountDelta}%
              </span>
            )}
            <span className="text-slate-400 text-[11px]">vs bulan lalu</span>
          </div>
        </div>

        {/* KPI 3: Pendapatan ATV */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Pendapatan ATV
              </span>
              <div className="p-2 bg-amber-50 rounded-xl text-amber-600">
                <Compass className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              {formatRupiah(metrics.currentATVRevenue)}
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs mt-3 pt-3 border-t border-slate-100">
            {metrics.atvDelta >= 0 ? (
              <span className="flex items-center text-emerald-600 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{metrics.atvDelta}%
              </span>
            ) : (
              <span className="flex items-center text-rose-600 font-bold">
                <ArrowDownRight className="w-3.5 h-3.5" />
                {metrics.atvDelta}%
              </span>
            )}
            <span className="text-slate-400 text-[11px]">vs bulan lalu</span>
          </div>
        </div>

        {/* KPI 4: Laba Pendapatan Tambahan */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Laba Pendapatan Tambahan
              </span>
              <div className="p-2 bg-purple-50 rounded-xl text-purple-600">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              {formatRupiah(metrics.currentExtraLaba)}
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs mt-3 pt-3 border-t border-slate-100">
            {metrics.extraLabaDelta >= 0 ? (
              <span className="flex items-center text-emerald-600 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{metrics.extraLabaDelta}%
              </span>
            ) : (
              <span className="flex items-center text-rose-600 font-bold">
                <ArrowDownRight className="w-3.5 h-3.5" />
                {metrics.extraLabaDelta}%
              </span>
            )}
            <span className="text-slate-400 text-[11px]">total - biaya</span>
          </div>
        </div>

        {/* KPI 5: Leads Baru */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Leads Baru
              </span>
              <div className="p-2 bg-emerald-50 rounded-xl text-emerald-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              {metrics.currentLeadsCount} <span className="text-xs text-slate-400 font-normal">Prospek</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs mt-3 pt-3 border-t border-slate-100">
            {metrics.leadsDelta >= 0 ? (
              <span className="flex items-center text-emerald-600 font-bold">
                <ArrowUpRight className="w-3.5 h-3.5" />
                +{metrics.leadsDelta}%
              </span>
            ) : (
              <span className="flex items-center text-rose-600 font-bold">
                <ArrowDownRight className="w-3.5 h-3.5" />
                {metrics.leadsDelta}%
              </span>
            )}
            <span className="text-slate-400 text-[11px]">vs bulan lalu</span>
          </div>
        </div>
      </div>

      {/* Target Dashboard Bulan Berjalan (Hotel Gabungan & ATV Terpisah) */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-blue-50 text-blue-700 rounded-lg">
                <Target className="w-4 h-4" />
              </span>
              <h3 className="font-bold text-base text-slate-900">
                Pencapaian Target Dashboard ({currentMonthLabel})
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Hotel = target gabungan (Kamar bersih setelah dikurangi sarapan + Pendapatan Tambahan). ATV = target terpisah.
            </p>
          </div>

          {isAdmin && onNavigateToModule && (
            <button
              type="button"
              onClick={() => onNavigateToModule('settings')}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-500" />
              <span>Atur Target Bulanan</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Target Hotel (Gabungan) */}
          <div className="bg-gradient-to-br from-blue-50/70 to-indigo-50/40 rounded-xl p-4 border border-blue-100 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-blue-600 tracking-wider">
                  Target Gabungan
                </span>
                <h4 className="text-sm font-bold text-slate-900">Hotel & Pendapatan Tambahan</h4>
              </div>
              <span className="text-xs font-extrabold px-2.5 py-1 bg-blue-600 text-white rounded-full">
                {targetMetrics.hotelPct}%
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Realisasi Bersih:</span>
                <span className="font-bold text-blue-950 font-mono">
                  {formatRupiah(targetMetrics.actualHotelNet)}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Target Bulanan:</span>
                <span className="font-bold text-slate-700 font-mono">
                  {targetMetrics.hotelTarget > 0 ? formatRupiah(targetMetrics.hotelTarget) : 'Belum Ditentukan'}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-blue-200/60 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${targetMetrics.hotelPct}%` }}
              />
            </div>

            <div className="text-[10px] text-slate-500 pt-1 border-t border-blue-100/80 flex items-center justify-between">
              <span>Kamar: {formatRupiah(metrics.currentHotelRevenue)}</span>
              <span className="text-rose-600">
                - B/F: {formatRupiah(targetMetrics.breakfastDeduction)}
              </span>
              <span className="text-purple-600">
                + Tambahan: {formatRupiah(metrics.currentExtraRevenue)}
              </span>
            </div>
          </div>

          {/* Target ATV (Terpisah) */}
          <div className="bg-gradient-to-br from-amber-50/70 to-orange-50/40 rounded-xl p-4 border border-amber-100 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-amber-700 tracking-wider">
                  Target Terpisah
                </span>
                <h4 className="text-sm font-bold text-slate-900">ATV Adventure</h4>
              </div>
              <span className="text-xs font-extrabold px-2.5 py-1 bg-amber-600 text-white rounded-full">
                {targetMetrics.atvPct}%
              </span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Realisasi ATV:</span>
                <span className="font-bold text-amber-950 font-mono">
                  {formatRupiah(targetMetrics.actualAtv)}
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500 font-medium">Target Bulanan:</span>
                <span className="font-bold text-slate-700 font-mono">
                  {targetMetrics.atvTarget > 0 ? formatRupiah(targetMetrics.atvTarget) : 'Belum Ditentukan'}
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-amber-200/60 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-amber-600 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${targetMetrics.atvPct}%` }}
              />
            </div>

            <div className="text-[10px] text-slate-500 pt-1 border-t border-amber-100/80 flex items-center justify-between">
              <span>Status: {targetMetrics.atvPct >= 100 ? 'Target Tercapai 🎉' : 'Dalam Proses'}</span>
              <span>Selisih: {targetMetrics.atvTarget > targetMetrics.actualAtv ? formatRupiah(targetMetrics.atvTarget - targetMetrics.actualAtv) : 'Surplus'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Laba Bersih Operasional (Poin 4) */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
                <TrendingUp className="w-4 h-4" />
              </span>
              <h3 className="font-bold text-base text-slate-900">
                Laba Bersih Operasional ({currentMonthLabel})
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Pendapatan kotor dikurangi komisi agen, biaya sarapan (F&amp;B), dan HPP pendapatan tambahan.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Angka Laba Bersih */}
          <div className="lg:col-span-1 bg-gradient-to-br from-emerald-50 to-teal-50/40 rounded-xl p-5 border border-emerald-100 flex flex-col justify-center">
            <span className="text-[10px] uppercase font-bold text-emerald-700 tracking-wider">
              Laba Bersih
            </span>
            <div className="text-2xl sm:text-3xl font-black text-emerald-700 mt-1 font-mono break-all">
              {formatRupiah(labaMetrics.labaBersih)}
            </div>
            <div className="flex items-center gap-1.5 mt-2 text-xs flex-wrap">
              <span className="px-2 py-0.5 bg-emerald-600 text-white rounded-full font-bold">
                Margin {labaMetrics.marginPct}%
              </span>
              <span className="text-slate-400 text-[11px]">dari pendapatan kotor</span>
            </div>
          </div>

          {/* Rincian pengurang */}
          <div className="lg:col-span-2 space-y-1">
            <div className="flex justify-between items-center text-sm py-2 border-b border-slate-100">
              <span className="text-slate-600 font-medium flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-blue-500" /> Pendapatan Kotor
              </span>
              <span className="font-bold text-slate-900 font-mono">
                {formatRupiah(labaMetrics.grossRevenue)}
              </span>
            </div>
            <div className="flex justify-between items-center text-sm py-1.5">
              <span className="text-slate-500">(&minus;) Komisi Agen</span>
              <span className="font-semibold text-rose-600 font-mono">
                &minus; {formatRupiah(labaMetrics.totalKomisi)}
              </span>
            </div>
            <div className="flex justify-between items-center text-sm py-1.5">
              <span className="text-slate-500">(&minus;) Biaya Sarapan (F&amp;B)</span>
              <span className="font-semibold text-rose-600 font-mono">
                &minus; {formatRupiah(labaMetrics.biayaSarapan)}
              </span>
            </div>
            <div className="flex justify-between items-center text-sm py-1.5 border-b border-slate-100">
              <span className="text-slate-500">(&minus;) HPP Pendapatan Tambahan</span>
              <span className="font-semibold text-rose-600 font-mono">
                &minus; {formatRupiah(labaMetrics.hppExtra)}
              </span>
            </div>
            <div className="flex justify-between items-center pt-2.5">
              <span className="text-slate-900 font-bold text-sm">Laba Bersih Operasional</span>
              <span className="font-black text-emerald-700 font-mono text-base">
                {formatRupiah(labaMetrics.labaBersih)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Area Chart: Daily Trend for Current Month (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Tren Pendapatan Harian ({currentMonthLabel})
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Akumulasi harian dari seluruh unit transaksi pada bulan berjalan
              </p>
            </div>
            <div className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-xl border border-blue-100">
              Total: {formatRupiah(metrics.currentTotalRevenue)}
            </div>
          </div>

          <div className="h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyChartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis
                  dataKey="dateLabel"
                  stroke="#94A3B8"
                  fontSize={10}
                  tickLine={false}
                  interval={3}
                />
                <YAxis
                  stroke="#94A3B8"
                  fontSize={10}
                  tickLine={false}
                  tickFormatter={(val) => `Rp ${(val / 1000000).toFixed(1)}M`}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1 border border-slate-800">
                          <div className="font-bold text-blue-300 mb-1">{data.day} ({data.dateLabel})</div>
                          <div className="flex justify-between gap-4 text-slate-300">
                            <span>Kamar:</span> <span className="font-mono">{formatRupiah(data.kamar)}</span>
                          </div>
                          <div className="flex justify-between gap-4 text-slate-300">
                            <span>ATV:</span> <span className="font-mono">{formatRupiah(data.atv)}</span>
                          </div>
                          <div className="flex justify-between gap-4 text-slate-300">
                            <span>Sarapan:</span> <span className="font-mono">{formatRupiah(data.breakfast)}</span>
                          </div>
                          <div className="flex justify-between gap-4 text-slate-300">
                            <span>Extra:</span> <span className="font-mono">{formatRupiah(data.extra)}</span>
                          </div>
                          <div className="border-t border-slate-700 pt-1 mt-1 font-bold text-emerald-400 flex justify-between gap-4">
                            <span>Total Hari Ini:</span>
                            <span className="font-mono">{formatRupiah(data.total)}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="total"
                  stroke="#2563EB"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Donut Chart: Komposisi Pendapatan Unit Bisnis */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Komposisi Pendapatan Unit
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Proporsi kontribusi tiap lini produk bulan ini
            </p>
          </div>

          <div className="h-64 w-full flex items-center justify-center my-2">
            {compositionData.length === 0 ? (
              <div className="text-center text-xs text-slate-400 py-8">
                Belum ada transaksi pendapatan pada bulan ini.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={compositionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {compositionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: unknown) => [formatRupiah(Number(value) || 0), 'Kontribusi']}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    formatter={(val) => <span className="text-xs text-slate-700 font-medium">{val}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-xs">
            <div className="bg-slate-50 p-2 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-semibold">Kamar Glamping</span>
              <span className="font-bold text-slate-900">{formatRupiah(metrics.currentHotelRevenue)}</span>
            </div>
            <div className="bg-slate-50 p-2 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-semibold">ATV Adventure</span>
              <span className="font-bold text-slate-900">{formatRupiah(metrics.currentATVRevenue)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Lists: Aktivitas Terbaru & Follow-up Hari Ini */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* List 1: Follow-up Hari Ini (Leads) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    Follow-up Hari Ini / Overdue
                  </h3>
                  <p className="text-xs text-slate-500">
                    Daftar prospek tamu yang jatuh tempo dihubungi hari ini
                  </p>
                </div>
              </div>

              {onNavigateToModule && (
                <button
                  type="button"
                  onClick={() => onNavigateToModule('leads')}
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                >
                  <span>Lihat CRM</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {todayFollowUps.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-500 space-y-1">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                <div className="font-bold text-slate-800">Semua Jadwal Follow-up Bersih!</div>
                <p className="text-slate-400">Tidak ada agenda kontak klien yang tertunda untuk hari ini.</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {todayFollowUps.map((lead) => {
                  const cleanPhone = (lead.whatsAppNumber || '').replace(/[^0-9]/g, '');
                  const waNumber = cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone;
                  const waUrl = `https://wa.me/${waNumber}?text=Halo%20Kak%20${encodeURIComponent(lead.guestName || '')},%20saya%20dari%20Bukit%20Langit%20Campventure%20ingin%20follow-up%20mengenai%20rencana%20kegiatan%20Anda.`;

                  const isOverdue = (lead.next_follow_up_date || '') < todayStr;
                  const picName = lead.picFollowUp || lead.picPerolehan || lead.picClosing || 'Belum di-assign';

                  return (
                    <div
                      key={lead.id}
                      className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200 transition-colors flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900 truncate">
                            {lead.guestName}
                          </span>
                          {lead.groupName && (
                            <span className="text-[10px] text-slate-500 truncate">
                              ({lead.groupName})
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                          <span className="font-medium text-slate-600">PIC: {picName}</span>
                          <span>•</span>
                          <span
                            className={`font-semibold px-2 py-0.5 rounded-md text-[10px] ${
                              isOverdue
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {isOverdue ? `Terlewat (${lead.next_follow_up_date})` : 'Hari Ini'}
                          </span>
                        </div>
                      </div>

                      {waNumber ? (
                        <a
                          href={waUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
                          title="Buka Chat WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Chat WA</span>
                        </a>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">No WA -</span>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-3 mt-4 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Daftar tersinkron langsung dari Leads Management</span>
            <span>{todayFollowUps.length} agenda aktif</span>
          </div>
        </div>

        {/* List 2: Aktivitas Terbaru (Logs) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    Aktivitas Sistem Terbaru
                  </h3>
                  <p className="text-xs text-slate-500">
                    Audit log real-time transaksi, pembuatan dokumen, dan leads
                  </p>
                </div>
              </div>
            </div>

            {recentActivities.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-500">
                Belum ada aktivitas tercatat pada sistem.
              </div>
            ) : (
              <div className="space-y-3">
                {recentActivities.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-start gap-3 text-xs border-b border-slate-100 pb-2.5 last:border-none last:pb-0"
                  >
                    <div className="p-2 rounded-xl bg-slate-100 shrink-0 mt-0.5">
                      {getLogIcon(log.action, log.module)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-900 truncate">
                          {log.action}
                        </span>
                        <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                          {formatRelativeTime(log.timestamp)}
                        </span>
                      </div>
                      <p className="text-slate-600 text-[11px] line-clamp-1 mt-0.5">
                        {log.details}
                      </p>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Oleh: {log.user || 'System'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-3 mt-4 border-t border-slate-100 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Audit trail otomatis untuk keamanan data</span>
            <span>Real-time listener aktif</span>
          </div>
        </div>
      </div>
    </div>
  );
};
