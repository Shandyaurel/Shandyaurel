import React, { useState, useEffect } from 'react';
import { BreakfastBulkEditHistoryItem } from '../../types';
import { Modal } from '../common/Modal';
import { formatRupiah, formatDateIndo } from '../../utils/formatters';
import { subscribeBreakfastBulkHistory, getBreakfastBulkHistoryLocal } from '../../utils/firebase';
import {
  History,
  User,
  Calendar,
  Clock,
  Coins,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Tag,
  AlertCircle,
} from 'lucide-react';

interface BreakfastBulkHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BreakfastBulkHistoryModal: React.FC<BreakfastBulkHistoryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [historyList, setHistoryList] = useState<BreakfastBulkEditHistoryItem[]>(() => {
    return getBreakfastBulkHistoryLocal();
  });
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const unsub = subscribeBreakfastBulkHistory((data) => {
      setHistoryList(data);
    });
    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Riwayat Edit Massal Sarapan / FnB"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-4 text-xs text-slate-700">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <p className="text-xs text-slate-500">
            Catatan log audit setiap aksi edit massal harga dan status sarapan oleh staf/admin.
          </p>
          <span className="font-bold text-xs text-slate-800">
            Total Sesi: {historyList.length}
          </span>
        </div>

        {historyList.length === 0 ? (
          <div className="py-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
            <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-slate-700 text-xs">Belum Ada Riwayat Edit Massal</h4>
            <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
              Setiap kali Anda menggunakan fitur edit massal untuk memperbarui harga atau status, riwayatnya akan tersimpan di sini.
            </p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[65vh] overflow-y-auto pr-1">
            {historyList.map((item) => {
              const isExpanded = expandedId === item.id;
              const dateObj = new Date(item.timestamp);
              const formattedTime = dateObj.toLocaleTimeString('id-ID', {
                hour: '2-digit',
                minute: '2-digit',
              });
              const formattedDateStr = formatDateIndo(item.timestamp.split('T')[0]);

              return (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-3 transition-colors hover:border-slate-300"
                >
                  {/* Top Bar: User & Time */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">
                        <User className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block leading-tight">
                          {item.userEmail}
                        </span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>
                            {formattedDateStr} pukul {formattedTime} WIB
                          </span>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-blue-50 text-blue-800 border border-blue-200 rounded-lg text-[11px] font-bold">
                        {item.affectedCount} data diperbarui
                      </span>
                      <button
                        type="button"
                        onClick={() => setExpandedId(isExpanded ? null : item.id)}
                        className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>{isExpanded ? 'Tutup Rincian' : 'Lihat Rincian'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Summary Chips */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80">
                      <span className="text-slate-400 font-semibold block text-[10px]">
                        Lingkup Tanggal:
                      </span>
                      <span className="font-bold text-slate-800">{item.dateDescription}</span>
                    </div>

                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80">
                      <span className="text-slate-400 font-semibold block text-[10px]">
                        Perubahan Harga:
                      </span>
                      {item.priceChanged && typeof item.newPrice === 'number' ? (
                        <span className="font-bold text-emerald-700">
                          {item.oldPriceSample !== undefined && (
                            <span className="line-through text-slate-400 font-normal mr-1">
                              {formatRupiah(item.oldPriceSample)}
                            </span>
                          )}
                          {formatRupiah(item.newPrice)} / pax
                        </span>
                      ) : (
                        <span className="text-slate-500">Harga tidak diubah</span>
                      )}
                    </div>

                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80">
                      <span className="text-slate-400 font-semibold block text-[10px]">
                        Perubahan Status:
                      </span>
                      {item.statusChanged && item.newStatus ? (
                        <span className="font-bold text-blue-700">
                          {item.oldStatusSample && (
                            <span className="text-slate-400 font-normal mr-1">
                              {item.oldStatusSample} →
                            </span>
                          )}
                          {item.newStatus}
                        </span>
                      ) : (
                        <span className="text-slate-500">Status tidak diubah</span>
                      )}
                    </div>
                  </div>

                  {/* Expandable Table: Affected Records Detail */}
                  {isExpanded && item.affectedRecords && item.affectedRecords.length > 0 && (
                    <div className="pt-2 border-t border-slate-100 space-y-1.5">
                      <span className="font-bold text-slate-700 text-[11px] block">
                        Rincian Data yang Terdampak ({item.affectedRecords.length} Tamu):
                      </span>
                      <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl bg-slate-50/50">
                        <table className="w-full text-left text-[11px]">
                          <thead className="bg-slate-100 text-slate-500 font-semibold sticky top-0">
                            <tr>
                              <th className="py-1.5 px-3">Tanggal</th>
                              <th className="py-1.5 px-3">Nama Tamu</th>
                              <th className="py-1.5 px-3">Kamar</th>
                              <th className="py-1.5 px-3 text-center">Porsi</th>
                              <th className="py-1.5 px-3 text-right">Harga Lama → Baru</th>
                              <th className="py-1.5 px-3 text-center">Status Lama → Baru</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200/60 text-slate-700">
                            {item.affectedRecords.map((rec, rIdx) => (
                              <tr key={rec.id || rIdx} className="hover:bg-white">
                                <td className="py-1.5 px-3 font-mono">{rec.date}</td>
                                <td className="py-1.5 px-3 font-bold text-slate-900">
                                  {rec.guestName}
                                </td>
                                <td className="py-1.5 px-3">{rec.roomNumber || '-'}</td>
                                <td className="py-1.5 px-3 text-center font-semibold">
                                  {rec.qty} pax
                                </td>
                                <td className="py-1.5 px-3 text-right font-mono">
                                  <span className="line-through text-slate-400 mr-1">
                                    {formatRupiah(rec.oldPrice)}
                                  </span>
                                  <span className="font-bold text-emerald-700">
                                    {formatRupiah(rec.newPrice)}
                                  </span>
                                </td>
                                <td className="py-1.5 px-3 text-center">
                                  <span className="text-slate-400 mr-1">{rec.oldStatus}</span>
                                  <span className="font-bold text-blue-700">→ {rec.newStatus}</span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="pt-2 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-black text-white font-bold rounded-xl cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </Modal>
  );
};
