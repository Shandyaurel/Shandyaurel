import React from 'react';
import { BreakfastRecord, BusinessSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatDateIndo } from '../../utils/formatters';
import { Printer, Utensils, Clock, CheckCircle2 } from 'lucide-react';

interface BreakfastVoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  vouchers: BreakfastRecord[];
  businessSettings?: BusinessSettings | null;
}

export const BreakfastVoucherModal: React.FC<BreakfastVoucherModalProps> = ({
  isOpen,
  onClose,
  vouchers,
  businessSettings,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const businessName = (businessSettings?.businessName || 'BUKIT LANGIT CAMPVENTURE').toUpperCase();

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Cetak Voucher Sarapan Tamu (${vouchers.length} Kupon • 8 per A4)`}
      maxWidth="max-w-4xl"
    >
      <div className="space-y-4">
        {/* Instruction toolbar */}
        <div className="flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              Format kupon potong (8 voucher per lembar A4 dengan garis putus gunting). Bagikan voucher ini kepada tamu saat check-in.
            </span>
          </div>
          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Semua Kupon</span>
          </button>
        </div>

        {/* Printable Grid Area: Exactly 8 vouchers per A4 page (2 columns x 4 rows) */}
        <div className="bg-slate-100 p-4 rounded-xl max-h-[75vh] overflow-y-auto print:bg-white print:p-0 print:overflow-visible">
          <div
            id="printable-voucher-grid"
            className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-[210mm] mx-auto print:grid-cols-2 print:gap-2 print:max-w-none"
          >
            {vouchers.map((v, index) => (
              <div
                key={v.id || index}
                className="bg-white border-2 border-dashed border-blue-900 rounded-xl p-3.5 flex flex-col justify-between shadow-2xs break-inside-avoid print:shadow-none print:p-3 print:m-1"
                style={{ minHeight: '160px' }}
              >
                {/* Header */}
                <div className="flex items-start justify-between border-b border-blue-100 pb-2 mb-2">
                  <div>
                    <span className="text-[9px] uppercase font-black tracking-widest text-slate-500 block">
                      BREAKFAST VOUCHER
                    </span>
                    <h3 className="text-xs font-black text-blue-900 tracking-tight">
                      {businessName}
                    </h3>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                      Room: {v.roomNumber || v.roomType || '-'}
                    </span>
                  </div>
                </div>

                {/* Content Details */}
                <div className="space-y-1.5 text-xs my-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-semibold">Nama Tamu:</span>
                    <span className="font-black text-slate-900 text-xs truncate max-w-[150px]">
                      {v.guestName}
                    </span>
                  </div>

                  <div className="flex items-center justify-between bg-blue-50/80 px-2 py-1 rounded-lg border border-blue-100">
                    <span className="text-[11px] font-bold text-blue-900">
                      Untuk: <span className="text-sm font-black text-blue-700">{v.qty} Orang</span>
                    </span>
                    <span className="text-[10px] font-bold text-slate-600 flex items-center gap-1">
                      <span>🕐 07.00 – 10.00 WIB</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                    <span>Tanggal: <strong className="text-slate-800">{formatDateIndo(v.date)}</strong></span>
                    <span className="font-mono text-[9px] text-slate-400">Ref: {v.id.substring(0, 12)}</span>
                  </div>
                </div>

                {/* Footer Note */}
                <div className="border-t border-slate-200 pt-1.5 mt-1 text-[8.5px] leading-tight text-slate-400 text-center italic">
                  Voucher beserta nomor kamar Anda wajib ditunjukkan kepada pramusaji pada saat pemesanan.
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl cursor-pointer"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak {vouchers.length} Kupon</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
