import React, { useState, useEffect, useMemo } from 'react';
import {
  BreakfastRecord,
  BusinessSettings,
  BreakfastBulkEditHistoryItem,
  BreakfastBulkRecordChange,
} from '../../types';
import {
  subscribeBreakfast,
  saveBreakfast,
  deleteBreakfast,
  getBusinessSettings,
  syncAllBookingsToBreakfast,
  bulkUpdateBreakfastRecords,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateIndo, getTodayDateString } from '../../utils/formatters';
import { BreakfastModal } from './BreakfastModal';
import { BreakfastVoucherModal } from './BreakfastVoucherModal';
import { BreakfastReportModal } from './BreakfastReportModal';
import { BreakfastBulkEditModal } from './BreakfastBulkEditModal';
import { BreakfastBulkHistoryModal } from './BreakfastBulkHistoryModal';
import { Modal } from '../common/Modal';
import { DataImportModal } from '../common/DataImportModal';
import { printBreakfastVouchers, printBreakfast } from '../../utils/breakfastPrintHelper';
import {
  Utensils,
  Plus,
  Search,
  Filter,
  Calendar,
  Printer,
  BarChart3,
  CheckSquare,
  Square,
  Edit2,
  Trash2,
  Coffee,
  CheckCircle2,
  Clock,
  Ban,
  Upload,
  Layers,
  Coins,
  History,
} from 'lucide-react';

export const BreakfastView: React.FC = () => {
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [records, setRecords] = useState<BreakfastRecord[]>([]);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [dateFilterPreset, setDateFilterPreset] = useState<'today' | 'thisMonth' | 'all' | 'custom'>('today');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Selected records for voucher printing / bulk edit
  const [selectedRecordIds, setSelectedRecordIds] = useState<string[]>([]);
  const [bulkStatus, setBulkStatus] = useState<string>('');
  const [bulkDate, setBulkDate] = useState<string>('');
  const [bulkPrice, setBulkPrice] = useState<string>('');

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [recordToEdit, setRecordToEdit] = useState<BreakfastRecord | null>(null);

  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState<boolean>(false);
  const [voucherList, setVoucherList] = useState<BreakfastRecord[]>([]);

  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isBulkEditModalOpen, setIsBulkEditModalOpen] = useState<boolean>(false);
  const [isBulkHistoryModalOpen, setIsBulkHistoryModalOpen] = useState<boolean>(false);

  const [recordToDelete, setRecordToDelete] = useState<BreakfastRecord | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const todayStr = getTodayDateString();
  const currentMonthStr = todayStr.substring(0, 7);

  // Realtime subscription
  useEffect(() => {
    setIsLoading(true);

    // Auto-sync any existing hotel bookings with includeBreakfast to breakfast records
    syncAllBookingsToBreakfast().catch((err) => {
      console.warn('Auto-sync bookings to breakfast skipped:', err);
    });

    const unsub = subscribeBreakfast(
      (data) => {
        setRecords(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error loading breakfast records:', error);
        showError('Gagal memuat data sarapan / breakfast.');
        setIsLoading(false);
      },
    );

    const loadSettings = () => {
      getBusinessSettings().then((s) => {
        if (s) setBusinessSettings(s);
      });
    };
    loadSettings();

    // Auto-refresh settings saat tab/window kembali ke fokus — tangkap perubahan
    // tanda tangan / harga sarapan tanpa harus refresh halaman.
    const onFocus = () => loadSettings();
    const onVisibility = () => {
      if (document.visibilityState === 'visible') loadSettings();
    };
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      unsub();
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [showError]);

  const todayCount = useMemo(() => {
    return records.filter(
      (r) => (r.date || (r.createdAt ? r.createdAt.split('T')[0] : '')) === todayStr,
    ).length;
  }, [records, todayStr]);

  const thisMonthCount = useMemo(() => {
    return records.filter((r) =>
      (r.date || (r.createdAt ? r.createdAt.split('T')[0] : '')).startsWith(currentMonthStr),
    ).length;
  }, [records, currentMonthStr]);

  // Filtered list
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      // Status
      if (filterStatus !== 'ALL' && (r.status || 'Direncanakan') !== filterStatus) {
        return false;
      }

      // Date
      const rDate = r.date || (r.createdAt ? r.createdAt.split('T')[0] : '');
      if (dateFilterPreset === 'today' && rDate !== todayStr) return false;
      if (dateFilterPreset === 'thisMonth' && !rDate.startsWith(currentMonthStr)) return false;
      if (dateFilterPreset === 'custom') {
        if (startDate && rDate < startDate) return false;
        if (endDate && rDate > endDate) return false;
      }

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchGuest = r.guestName.toLowerCase().includes(q);
        const matchRoomNo = r.roomNumber.toLowerCase().includes(q);
        const matchRoomType = r.roomType.toLowerCase().includes(q);
        const matchRoomName = r.roomName?.toLowerCase().includes(q);
        const matchNotes = r.notes?.toLowerCase().includes(q);
        if (!matchGuest && !matchRoomNo && !matchRoomType && !matchRoomName && !matchNotes) {
          return false;
        }
      }

      return true;
    });
  }, [records, filterStatus, dateFilterPreset, startDate, endDate, searchQuery, todayStr, currentMonthStr]);

  // Summary KPIs
  const kpi = useMemo(() => {
    let todayPax = 0;
    let thisMonthPax = 0;
    let filteredPax = 0;
    let filteredValue = 0;

    records.forEach((r) => {
      const d = r.date || r.createdAt.split('T')[0];
      const pax = Number(r.qty) || 0;
      if (d === todayStr) todayPax += pax;
      if (d.startsWith(currentMonthStr)) thisMonthPax += pax;
    });

    filteredRecords.forEach((r) => {
      const pax = Number(r.qty) || 0;
      filteredPax += pax;
      filteredValue += pax * (Number(r.price) || 0);
    });

    return {
      todayPax,
      thisMonthPax,
      filteredPax,
      filteredValue,
      filteredCount: filteredRecords.length,
    };
  }, [records, filteredRecords, todayStr, currentMonthStr]);

  // Select all handler
  const isAllSelected =
    filteredRecords.length > 0 &&
    filteredRecords.every((r) => selectedRecordIds.includes(r.id));

  const handleToggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedRecordIds([]);
    } else {
      setSelectedRecordIds(filteredRecords.map((r) => r.id));
    }
  };

  const handleToggleRow = (id: string) => {
    setSelectedRecordIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const handleOpenPrintVouchers = (itemsToPrint?: BreakfastRecord[]) => {
    if (itemsToPrint && itemsToPrint.length > 0) {
      setVoucherList(itemsToPrint);
      setIsVoucherModalOpen(true);
      return;
    }

    const selected = records.filter((r) => selectedRecordIds.includes(r.id));
    if (selected.length === 0) {
      showError('Pilih minimal satu data sarapan untuk mencetak voucher.');
      return;
    }
    setVoucherList(selected);
    setIsVoucherModalOpen(true);
  };

  const handleSaveRecord = async (payload: Partial<BreakfastRecord>) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    showSuccess(payload.id ? 'Data sarapan diperbarui' : 'Data sarapan berhasil ditambahkan');
    saveBreakfast(payload, userEmail).catch((err) => {
      console.error('Error saving breakfast record:', err);
      showError('Gagal sinkron sarapan ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  // Edit massal: terapkan harga, status, dan/atau tanggal ke semua record terpilih
  const handleBulkApply = async () => {
    if (selectedRecordIds.length === 0) return;
    const hasPrice = bulkPrice.trim() !== '' && !isNaN(Number(bulkPrice)) && Number(bulkPrice) >= 0;
    if (!bulkStatus && !bulkDate && !hasPrice) {
      showError('Pilih status, tanggal, atau masukkan harga baru untuk diterapkan.');
      return;
    }

    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const now = new Date().toISOString();
    const targetRecords = records.filter((r) => selectedRecordIds.includes(r.id));
    const newPriceNum = hasPrice ? Number(bulkPrice) : undefined;
    const newStatusVal = (bulkStatus as 'Direncanakan' | 'Disajikan' | 'Dibatalkan') || undefined;

    const updates = targetRecords.map((r) => ({
      recordId: r.id,
      newPrice: newPriceNum,
      newStatus: newStatusVal,
    }));

    const recordChanges: BreakfastBulkRecordChange[] = targetRecords.map((r) => ({
      id: r.id,
      guestName: r.guestName,
      roomNumber: r.roomNumber,
      date: bulkDate || r.date,
      qty: r.qty,
      oldPrice: r.price,
      newPrice: hasPrice ? Number(bulkPrice) : r.price,
      oldStatus: r.status || 'Direncanakan',
      newStatus: newStatusVal || (r.status || 'Direncanakan'),
    }));

    const historyItem: BreakfastBulkEditHistoryItem = {
      id: `bf_bulk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userEmail,
      timestamp: now,
      dateSelectionMode: 'selected',
      dateDescription: `${targetRecords.length} Data Dipilih di Tabel`,
      affectedCount: targetRecords.length,
      priceChanged: hasPrice,
      oldPriceSample: targetRecords[0]?.price,
      newPrice: newPriceNum,
      statusChanged: !!newStatusVal,
      oldStatusSample: targetRecords[0]?.status,
      newStatus: newStatusVal,
      affectedRecords: recordChanges,
    };

    try {
      await bulkUpdateBreakfastRecords(updates, historyItem, userEmail);
      if (bulkDate) {
        for (const r of targetRecords) {
          saveBreakfast({ id: r.id, date: bulkDate }, userEmail).catch(console.error);
        }
      }
      showSuccess(`Berhasil memperbarui ${targetRecords.length} data sarapan!`);
      setBulkStatus('');
      setBulkDate('');
      setBulkPrice('');
      setSelectedRecordIds([]);
    } catch (err) {
      console.error('Error bulk-updating breakfast records:', err);
      showError('Gagal melakukan edit massal: ' + (err instanceof Error ? err.message : 'Kesalahan jaringan.'));
    }
  };

  const handleConfirmDelete = () => {
    if (!recordToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const target = recordToDelete;
    const reason = deleteReason.trim();

    // (1) Tutup modal konfirmasi & beri notifikasi segera (OPTIMISTIC <1 detik)
    setRecordToDelete(null);
    setDeleteReason('');
    showSuccess(`Data sarapan ${target.guestName} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteBreakfast(target, userEmail, reason).catch((err) => {
      console.error('Error deleting breakfast record:', err);
      showError('Gagal sinkron hapus sarapan ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div id="breakfast-module" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Utensils className="w-6 h-6 text-blue-600" />
            <span>Manajemen Breakfast & F&B Restoran</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan sarapan tamu hotel/glamping, cetak voucher kupon dapur, dan rekapitulasi porsi harian.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* (1) PRINT VOUCHER - 8 per A4 cuttable */}
          <button
            type="button"
            onClick={() => {
              const list = selectedRecordIds.length > 0
                ? records.filter((r) => selectedRecordIds.includes(r.id))
                : filteredRecords;
              if (list.length === 0) {
                showError('Tidak ada data sarapan untuk dicetak voucher.');
                return;
              }
              printBreakfastVouchers(list, businessSettings, showError);
            }}
            className="px-3 py-2 bg-blue-900 hover:bg-blue-950 text-white font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Cetak kupon voucher tamu (8 voucher per lembar A4 siap gunting)"
          >
            <Printer className="w-3.5 h-3.5 text-blue-300" />
            <span>Print Voucher (8/Hal){selectedRecordIds.length > 0 ? ` (${selectedRecordIds.length})` : ''}</span>
          </button>

          {/* (2) PRINT GUEST - Resto A4 Monospace */}
          <button
            type="button"
            onClick={() => {
              if (filteredRecords.length === 0) {
                showError('Tidak ada data sarapan dalam filter saat ini.');
                return;
              }
              printBreakfast('guest', filteredRecords, businessSettings);
            }}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Cetak daftar sarapan tamu harian untuk tim restoran/dapur (A4 monospace)"
          >
            <Utensils className="w-3.5 h-3.5 text-amber-300" />
            <span>Print Guest (Resto)</span>
          </button>

          {/* (3) PRINT DETAIL - Accounting A4 Monospace */}
          <button
            type="button"
            onClick={() => {
              if (filteredRecords.length === 0) {
                showError('Tidak ada data sarapan dalam filter saat ini.');
                return;
              }
              printBreakfast('detail', filteredRecords, businessSettings, startDate, endDate);
            }}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl border border-slate-200 shadow-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Cetak laporan rincian harga & ringkasan untuk accounting"
          >
            <BarChart3 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Print Detail (Accounting)</span>
          </button>

          {/* (4) EDIT MASSAL (HARGA & STATUS) */}
          <button
            type="button"
            onClick={() => setIsBulkEditModalOpen(true)}
            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Edit massal harga dan status sarapan berdasarkan tanggal yang dipilih"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Edit Massal</span>
          </button>

          {/* (5) RIWAYAT EDIT MASSAL */}
          <button
            type="button"
            onClick={() => setIsBulkHistoryModalOpen(true)}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl border border-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Lihat riwayat audit edit massal harga dan status"
          >
            <History className="w-3.5 h-3.5 text-blue-600" />
            <span>Riwayat Edit</span>
          </button>

          <button
            type="button"
            onClick={() => setIsImportModalOpen(true)}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-blue-600" />
            <span>Import Excel</span>
          </button>

          <button
            id="btn-add-breakfast"
            type="button"
            onClick={() => {
              setRecordToEdit(null);
              setIsFormModalOpen(true);
            }}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Sarapan</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Porsi Hari Ini</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Coffee className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-blue-700 mt-2">{kpi.todayPax} Pax</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Kebutuhan sarapan hari ini</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Porsi Bulan Ini</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Utensils className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-emerald-700 mt-2">{kpi.thisMonthPax} Pax</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Total porsi bulan berjalan</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Kamar Terlayani</span>
            <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">{kpi.filteredCount} Kamar</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Sesuai filter aktif</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Nilai Porsi</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <span className="font-black text-xs">Rp</span>
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(kpi.filteredValue)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Estimasi nilai sarapan</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama tamu, nomor kamar, tipe kamar, catatan..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:border-blue-600"
            />
          </div>

          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Status</option>
              <option value="Direncanakan">Direncanakan</option>
              <option value="Disajikan">Sudah Disajikan</option>
              <option value="Dibatalkan">Dibatalkan</option>
            </select>
          </div>
        </div>

        {/* Date Filter Presets */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal:</span>
            </span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setDateFilterPreset('today')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg cursor-pointer transition-colors ${
                  dateFilterPreset === 'today'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Hari Ini ({todayCount})
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('thisMonth')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg cursor-pointer transition-colors ${
                  dateFilterPreset === 'thisMonth'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Bulan Ini ({thisMonthCount})
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg cursor-pointer transition-colors ${
                  dateFilterPreset === 'all'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua Jadwal ({records.length})
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('custom')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg cursor-pointer transition-colors ${
                  dateFilterPreset === 'custom'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Rentang
              </button>
            </div>

            {dateFilterPreset === 'custom' && (
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
                <span className="text-xs text-slate-400">s/d</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
            )}
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Total {filteredRecords.length} entri ({kpi.filteredPax} pax)
          </div>
        </div>
      </div>

      {/* Bulk action bar — muncul saat ada baris terpilih */}
      {selectedRecordIds.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl px-4 py-3 flex flex-wrap items-center gap-3">
          <span className="text-xs font-bold text-blue-900">
            {selectedRecordIds.length} data dipilih:
          </span>

          <button
            type="button"
            onClick={() => setIsBulkEditModalOpen(true)}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
            title="Buka dialog edit massal harga dan status lengkap dengan konfirmasi & riwayat"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Edit Massal (Harga & Status)</span>
          </button>

          <div className="h-4 w-px bg-blue-200 hidden sm:block" />

          {/* Quick inline controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-slate-700">
              <span className="font-semibold">Harga:</span>
              <div className="relative">
                <span className="absolute left-2 top-1 text-[10px] text-slate-400 font-bold">Rp</span>
                <input
                  type="number"
                  placeholder="35000"
                  value={bulkPrice}
                  onChange={(e) => setBulkPrice(e.target.value)}
                  className="w-24 pl-6 pr-2 py-1.5 bg-white border border-blue-200 rounded-lg text-xs font-semibold focus:outline-none"
                />
              </div>
            </div>

            <select
              value={bulkStatus}
              onChange={(e) => setBulkStatus(e.target.value)}
              className="px-2 py-1.5 bg-white border border-blue-200 rounded-lg text-xs font-semibold focus:outline-none"
            >
              <option value="">Ubah status…</option>
              <option value="Direncanakan">Direncanakan</option>
              <option value="Disajikan">Disajikan</option>
              <option value="Dibatalkan">Dibatalkan</option>
            </select>

            <div className="flex items-center gap-1 text-xs text-slate-700">
              <span className="font-semibold">Tgl:</span>
              <input
                type="date"
                value={bulkDate}
                onChange={(e) => setBulkDate(e.target.value)}
                className="px-2 py-1.5 bg-white border border-blue-200 rounded-lg text-xs focus:outline-none"
              />
            </div>

            <button
              type="button"
              onClick={handleBulkApply}
              className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 cursor-pointer shadow-2xs"
            >
              Terapkan Cepat
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              setSelectedRecordIds([]);
              setBulkPrice('');
              setBulkStatus('');
              setBulkDate('');
            }}
            className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-semibold hover:bg-slate-100 cursor-pointer ml-auto"
          >
            Batal Pilih
          </button>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center">
            <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Memuat data sarapan...</p>
          </div>
        ) : filteredRecords.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3 text-center w-10">
                    <button
                      type="button"
                      onClick={handleToggleSelectAll}
                      title="Pilih semua"
                      className="cursor-pointer text-slate-400 hover:text-blue-600"
                    >
                      {isAllSelected ? (
                        <CheckSquare className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4">Nama Tamu</th>
                  <th className="py-3 px-4">Kamar / Tenda</th>
                  <th className="py-3 px-4 text-center">Porsi (Pax)</th>
                  <th className="py-3 px-4 text-right">Harga & Total Nilai</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredRecords.map((record) => {
                  const isSelected = selectedRecordIds.includes(record.id);

                  return (
                    <tr
                      key={record.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isSelected ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleRow(record.id)}
                          className="cursor-pointer text-slate-400 hover:text-blue-600"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-slate-900">{formatDateIndo(record.date)}</div>
                        {record.bookingId && (
                          <div className="text-[10px] text-slate-400 font-mono">Ref: {record.bookingId}</div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{record.guestName}</div>
                        {record.notes && (
                          <div className="text-[11px] text-amber-700 max-w-xs truncate font-medium mt-0.5" title={record.notes}>
                            📝 {record.notes}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-blue-700">
                          {record.roomNumber}{' '}
                          {record.roomName && <span className="text-slate-600 font-normal">({record.roomName})</span>}
                        </div>
                        <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md">
                          {record.roomType}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="inline-block px-2.5 py-1 bg-blue-50 text-blue-800 font-extrabold rounded-lg text-xs">
                          {record.qty} Pax
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="font-extrabold text-slate-900">
                          {formatRupiah(record.qty * record.price)}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          @{formatRupiah(record.price)}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-center">
                        {record.status === 'Disajikan' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Disajikan</span>
                          </span>
                        ) : record.status === 'Dibatalkan' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <Ban className="w-3 h-3" />
                            <span>Dibatalkan</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                            <Clock className="w-3 h-3" />
                            <span>Direncanakan</span>
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            title="Cetak Voucher Kupon"
                            onClick={() => printBreakfastVouchers([record], businessSettings, showError)}
                            className="p-1.5 text-blue-900 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Edit Data"
                            onClick={() => {
                              setRecordToEdit(record);
                              setIsFormModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Hapus Data"
                            onClick={() => {
                              setRecordToDelete(record);
                              setDeleteReason('');
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center">
            <Utensils className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">Belum Ada Catatan Sarapan</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Tidak ada jadwal sarapan yang sesuai dengan filter atau tanggal yang dipilih.
            </p>
            {records.length > 0 && (
              <div className="mt-4">
                <p className="text-xs text-blue-800 font-medium mb-2.5">
                  Terdapat <strong>{records.length} data sarapan</strong> pada jadwal tanggal lainnya.
                </p>
                <button
                  type="button"
                  onClick={() => setDateFilterPreset('all')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Tampilkan Semua Jadwal Sarapan ({records.length})</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Form Modal */}
      {isFormModalOpen && (
        <BreakfastModal
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          recordToEdit={recordToEdit}
          onSave={handleSaveRecord}
        />
      )}

      {/* Voucher Modal */}
      {isVoucherModalOpen && (
        <BreakfastVoucherModal
          isOpen={isVoucherModalOpen}
          onClose={() => setIsVoucherModalOpen(false)}
          vouchers={voucherList}
          businessSettings={businessSettings}
        />
      )}

      {/* Report Modal */}
      {isReportModalOpen && (
        <BreakfastReportModal
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          records={records}
        />
      )}

      {/* Delete Modal */}
      <Modal
        isOpen={!!recordToDelete}
        onClose={() => setRecordToDelete(null)}
        title="Konfirmasi Hapus Data Sarapan"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus data sarapan tamu <strong>{recordToDelete?.guestName}</strong> ({recordToDelete?.qty} Porsi - Kamar{' '}
            {recordToDelete?.roomNumber})?
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Tamu membatalkan sarapan..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setRecordToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Data'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          moduleKey="breakfast"
          moduleTitle="Pesanan Sarapan F&B"
        />
      )}

      {/* Bulk Edit Modal (Harga & Status) */}
      {isBulkEditModalOpen && (
        <BreakfastBulkEditModal
          isOpen={isBulkEditModalOpen}
          onClose={() => setIsBulkEditModalOpen(false)}
          records={records}
          initialSelectedIds={selectedRecordIds}
          defaultPrice={businessSettings?.defaultBreakfastCostPerPax || 35000}
          onSuccess={() => {
            setSelectedRecordIds([]);
          }}
        />
      )}

      {/* Bulk History Modal */}
      {isBulkHistoryModalOpen && (
        <BreakfastBulkHistoryModal
          isOpen={isBulkHistoryModalOpen}
          onClose={() => setIsBulkHistoryModalOpen(false)}
        />
      )}
    </div>
  );
};
