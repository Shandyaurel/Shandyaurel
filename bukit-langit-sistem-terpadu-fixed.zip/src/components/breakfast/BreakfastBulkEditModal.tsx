import React, { useState, useMemo, useEffect } from 'react';
import { BreakfastRecord, BreakfastBulkEditHistoryItem, BreakfastBulkRecordChange } from '../../types';
import { Modal } from '../common/Modal';
import { formatRupiah, formatDateIndo, getTodayDateString } from '../../utils/formatters';
import { bulkUpdateBreakfastRecords } from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Plus,
  X,
  Coins,
  CheckSquare,
  Square,
  ArrowRight,
  Filter,
  Check,
  RotateCcw,
} from 'lucide-react';

interface BreakfastBulkEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: BreakfastRecord[];
  initialSelectedIds?: string[];
  defaultPrice?: number;
  onSuccess?: () => void;
}

type DateSelectionMode = 'single' | 'multiple' | 'range' | 'selected';

export const BreakfastBulkEditModal: React.FC<BreakfastBulkEditModalProps> = ({
  isOpen,
  onClose,
  records,
  initialSelectedIds = [],
  defaultPrice = 35000,
  onSuccess,
}) => {
  const { currentUser, userProfile } = useAuth();
  const { showSuccess, showError } = useToast();

  const today = getTodayDateString();

  // Mode pemilihan tanggal / data
  const [dateMode, setDateMode] = useState<DateSelectionMode>(() => {
    return initialSelectedIds.length > 0 ? 'selected' : 'single';
  });

  // Nilai tanggal
  const [singleDate, setSingleDate] = useState<string>(today);
  const [multiDates, setMultiDates] = useState<string[]>([today]);
  const [newMultiDateInput, setNewMultiDateInput] = useState<string>('');
  const [rangeStart, setRangeStart] = useState<string>(today);
  const [rangeEnd, setRangeEnd] = useState<string>(today);

  // Perubahan yang ingin diterapkan
  const [applyPriceChange, setApplyPriceChange] = useState<boolean>(true);
  const [newPrice, setNewPrice] = useState<number>(defaultPrice);
  const [priceInputStr, setPriceInputStr] = useState<string>(String(defaultPrice));

  const [applyStatusChange, setApplyStatusChange] = useState<boolean>(false);
  const [newStatus, setNewStatus] = useState<'Direncanakan' | 'Disajikan' | 'Dibatalkan'>('Disajikan');

  // Seleksi data spesifik yang akan diubah di antara data yang cocok
  const [selectedRecordIds, setSelectedRecordIds] = useState<Set<string>>(new Set());

  // Status konfirmasi & saving
  const [showConfirmStep, setShowConfirmStep] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Daftar tanggal yang memiliki data sarapan
  const availableDatesInRecords = useMemo(() => {
    const dates = new Set<string>();
    records.forEach((r) => {
      const d = (r.date || (r.createdAt ? r.createdAt.split('T')[0] : '')).trim().split('T')[0].split(' ')[0];
      if (d) dates.add(d);
    });
    return Array.from(dates).sort().reverse();
  }, [records]);

  // Sinkronisasi mode saat modal dibuka
  useEffect(() => {
    if (isOpen) {
      if (initialSelectedIds && initialSelectedIds.length > 0) {
        setDateMode('selected');
      } else {
        setDateMode('single');
      }
      setShowConfirmStep(false);
      setIsSaving(false);
    }
  }, [isOpen, initialSelectedIds]);

  // Filter records berdasarkan tanggal yang dipilih
  const dateMatchingRecords = useMemo(() => {
    return records.filter((r) => {
      const rDate = (r.date || (r.createdAt ? r.createdAt.split('T')[0] : '')).trim().split('T')[0].split(' ')[0];

      if (dateMode === 'single') {
        return rDate === singleDate;
      }
      if (dateMode === 'multiple') {
        return multiDates.includes(rDate);
      }
      if (dateMode === 'range') {
        if (!rangeStart && !rangeEnd) return true;
        const s = rangeStart && rangeEnd ? (rangeStart <= rangeEnd ? rangeStart : rangeEnd) : rangeStart;
        const e = rangeStart && rangeEnd ? (rangeStart <= rangeEnd ? rangeEnd : rangeStart) : rangeEnd;
        if (s && e) {
          return rDate >= s && rDate <= e;
        }
        if (s) return rDate >= s;
        if (e) return rDate <= e;
        return true;
      }
      if (dateMode === 'selected') {
        return initialSelectedIds.includes(r.id);
      }
      return false;
    });
  }, [records, dateMode, singleDate, multiDates, rangeStart, rangeEnd, initialSelectedIds]);

  // Otomatis centang semua data yang cocok saat filter tanggal berubah
  useEffect(() => {
    const ids = new Set(dateMatchingRecords.map((r) => r.id));
    setSelectedRecordIds(ids);
  }, [dateMatchingRecords]);

  // Update input harga lokal saat defaultPrice berubah
  useEffect(() => {
    if (defaultPrice > 0) {
      setNewPrice(defaultPrice);
      setPriceInputStr(String(defaultPrice));
    }
  }, [defaultPrice]);

  // Handle penambahan tanggal di mode multiple
  const handleAddMultiDate = () => {
    if (!newMultiDateInput) return;
    if (!multiDates.includes(newMultiDateInput)) {
      setMultiDates((prev) => [...prev, newMultiDateInput].sort());
      setNewMultiDateInput('');
    } else {
      showError('Tanggal tersebut sudah ada dalam daftar.');
    }
  };

  const handleRemoveMultiDate = (dToRemove: string) => {
    setMultiDates((prev) => prev.filter((d) => d !== dToRemove));
  };

  // Toggle seleksi baris
  const handleToggleRecord = (id: string) => {
    setSelectedRecordIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAllMatching = () => {
    setSelectedRecordIds(new Set(dateMatchingRecords.map((r) => r.id)));
  };

  const handleDeselectAllMatching = () => {
    setSelectedRecordIds(new Set());
  };

  // Data final yang akan diubah (harus cocok tanggal DAN dicentang user)
  const finalAffectedRecords = useMemo(() => {
    return dateMatchingRecords.filter((r) => selectedRecordIds.has(r.id));
  }, [dateMatchingRecords, selectedRecordIds]);

  // Keterangan deskripsi tanggal yang dipilih
  const dateDescription = useMemo(() => {
    if (dateMode === 'single') {
      return `Tanggal: ${formatDateIndo(singleDate)}`;
    }
    if (dateMode === 'multiple') {
      return `${multiDates.length} Tanggal (${multiDates.map((d) => formatDateIndo(d)).join(', ')})`;
    }
    if (dateMode === 'range') {
      return `Rentang: ${formatDateIndo(rangeStart)} s/d ${formatDateIndo(rangeEnd)}`;
    }
    return `Data Terpilih di Tabel (${initialSelectedIds.length} data)`;
  }, [dateMode, singleDate, multiDates, rangeStart, rangeEnd, initialSelectedIds]);

  // Validasi sebelum konfirmasi
  const handleProceedToConfirm = () => {
    if (!applyPriceChange && !applyStatusChange) {
      showError('Pilih setidaknya satu opsi perubahan: Ubah Harga atau Ubah Status.');
      return;
    }

    if (applyPriceChange && (isNaN(newPrice) || newPrice < 0)) {
      showError('Masukkan nominal harga baru yang valid.');
      return;
    }

    if (finalAffectedRecords.length === 0) {
      showError('Tidak ada data sarapan yang dipilih untuk diubah pada tanggal tersebut.');
      return;
    }

    setShowConfirmStep(true);
  };

  // Eksekusi penyimpanan perubahan massal
  const handleExecuteBulkEdit = async () => {
    if (finalAffectedRecords.length === 0) return;
    setIsSaving(true);

    try {
      const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
      const now = new Date().toISOString();

      const updates = finalAffectedRecords.map((r) => ({
        recordId: r.id,
        newPrice: applyPriceChange ? newPrice : undefined,
        newStatus: applyStatusChange ? newStatus : undefined,
      }));

      const recordChanges: BreakfastBulkRecordChange[] = finalAffectedRecords.map((r) => ({
        id: r.id,
        guestName: r.guestName,
        roomNumber: r.roomNumber,
        date: r.date,
        qty: r.qty,
        oldPrice: r.price,
        newPrice: applyPriceChange ? newPrice : r.price,
        oldStatus: r.status || 'Direncanakan',
        newStatus: applyStatusChange ? newStatus : (r.status || 'Direncanakan'),
      }));

      const historyItem: BreakfastBulkEditHistoryItem = {
        id: `bf_bulk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userEmail,
        timestamp: now,
        dateSelectionMode: dateMode,
        dateDescription,
        affectedCount: finalAffectedRecords.length,
        priceChanged: applyPriceChange,
        oldPriceSample: finalAffectedRecords[0]?.price,
        newPrice: applyPriceChange ? newPrice : undefined,
        statusChanged: applyStatusChange,
        oldStatusSample: finalAffectedRecords[0]?.status,
        newStatus: applyStatusChange ? newStatus : undefined,
        affectedRecords: recordChanges,
      };

      await bulkUpdateBreakfastRecords(updates, historyItem, userEmail);

      showSuccess(
        `Berhasil memperbarui ${finalAffectedRecords.length} data sarapan (${dateDescription})!`,
      );

      if (onSuccess) {
        onSuccess();
      }
      onClose();
    } catch (err) {
      console.error('Error executing bulk breakfast edit:', err);
      showError('Gagal melakukan edit massal sarapan: ' + (err instanceof Error ? err.message : 'Kesalahan jaringan.'));
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Edit Massal Sarapan / FnB (Harga & Status)"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-5 text-xs text-slate-700">
        {!showConfirmStep ? (
          <>
            {/* 1. Pilih Lingkup Tanggal / Data */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>1. Pilih Tanggal / Data yang Akan Diubah:</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  Harga & status hanya berubah pada tanggal yang dipilih
                </span>
              </div>

              {/* Mode Selector Tabs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setDateMode('single')}
                  className={`px-3 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer text-center ${
                    dateMode === 'single'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  Satu Tanggal
                </button>
                <button
                  type="button"
                  onClick={() => setDateMode('multiple')}
                  className={`px-3 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer text-center ${
                    dateMode === 'multiple'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  Beberapa Tanggal
                </button>
                <button
                  type="button"
                  onClick={() => setDateMode('range')}
                  className={`px-3 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer text-center ${
                    dateMode === 'range'
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  Rentang Tanggal
                </button>
                {initialSelectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setDateMode('selected')}
                    className={`px-3 py-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer text-center ${
                      dateMode === 'selected'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Data Terpilih ({initialSelectedIds.length})
                  </button>
                )}
              </div>

              {/* Mode 1: Single Date Picker */}
              {dateMode === 'single' && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="font-semibold text-slate-700">Tanggal Target:</label>
                    <input
                      type="date"
                      value={singleDate}
                      onChange={(e) => setSingleDate(e.target.value)}
                      className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-blue-500"
                    />
                    <span className="text-[11px] text-slate-500 font-medium">
                      ({formatDateIndo(singleDate)})
                    </span>
                  </div>

                  {availableDatesInRecords.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100">
                      <span className="text-[10px] text-slate-500 font-semibold mr-1">
                        Pilih cepat tanggal transaksi:
                      </span>
                      {availableDatesInRecords.slice(0, 6).map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setSingleDate(d)}
                          className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border cursor-pointer transition-colors ${
                            singleDate === d
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {formatDateIndo(d)}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Mode 2: Multiple Dates Picker */}
              {dateMode === 'multiple' && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="font-semibold text-slate-700">Tambah Tanggal:</label>
                    <input
                      type="date"
                      value={newMultiDateInput}
                      onChange={(e) => setNewMultiDateInput(e.target.value)}
                      className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-blue-500"
                    />
                    <button
                      type="button"
                      onClick={handleAddMultiDate}
                      className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah ke Daftar</span>
                    </button>
                  </div>

                  {availableDatesInRecords.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100">
                      <span className="text-[10px] text-slate-500 font-semibold mr-1">
                        Pilih cepat dari data sarapan:
                      </span>
                      {availableDatesInRecords.slice(0, 8).map((d) => {
                        const isAdded = multiDates.includes(d);
                        return (
                          <button
                            key={d}
                            type="button"
                            onClick={() => {
                              if (isAdded) {
                                handleRemoveMultiDate(d);
                              } else {
                                setMultiDates((prev) => [...prev, d].sort());
                              }
                            }}
                            className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border cursor-pointer transition-colors ${
                              isAdded
                                ? 'bg-blue-600 text-white border-blue-600'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {isAdded ? `✓ ${formatDateIndo(d)}` : `+ ${formatDateIndo(d)}`}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100">
                    <span className="text-[11px] text-slate-500 font-semibold mr-1">
                      Daftar Tanggal Terpilih ({multiDates.length}):
                    </span>
                    {multiDates.length === 0 ? (
                      <span className="text-rose-500 text-[11px]">Belum ada tanggal dipilih.</span>
                    ) : (
                      multiDates.map((d) => (
                        <span
                          key={d}
                          className="px-2.5 py-1 bg-blue-50 text-blue-800 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                        >
                          <span>{formatDateIndo(d)}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveMultiDate(d)}
                            className="p-0.5 hover:text-rose-600 rounded cursor-pointer"
                            title="Hapus tanggal ini"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Mode 3: Date Range Picker */}
              {dateMode === 'range' && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-2">
                      <label className="font-semibold text-slate-700">Mulai:</label>
                      <input
                        type="date"
                        value={rangeStart}
                        onChange={(e) => setRangeStart(e.target.value)}
                        className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <span className="text-slate-400">s/d</span>
                    <div className="flex items-center gap-2">
                      <label className="font-semibold text-slate-700">Sampai:</label>
                      <input
                        type="date"
                        value={rangeEnd}
                        onChange={(e) => setRangeEnd(e.target.value)}
                        className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  {availableDatesInRecords.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100">
                      <span className="text-[10px] text-slate-500 font-semibold mr-1">
                        Preset cepat:
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setRangeStart(today);
                          setRangeEnd(today);
                        }}
                        className="px-2 py-0.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[10px] font-semibold cursor-pointer"
                      >
                        Hari Ini
                      </button>
                      {availableDatesInRecords.length >= 2 && (
                        <button
                          type="button"
                          onClick={() => {
                            const sorted = [...availableDatesInRecords].sort();
                            setRangeStart(sorted[0]);
                            setRangeEnd(sorted[sorted.length - 1]);
                          }}
                          className="px-2 py-0.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md text-[10px] font-semibold cursor-pointer"
                        >
                          Semua Rentang Data ({formatDateIndo([...availableDatesInRecords].sort()[0])} s/d {formatDateIndo([...availableDatesInRecords].sort().reverse()[0])})
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Mode 4: Selected Table Rows */}
              {dateMode === 'selected' && (
                <div className="bg-white p-3 rounded-xl border border-slate-200 flex items-center gap-2 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>
                    Menggunakan <strong>{initialSelectedIds.length}</strong> data yang sedang dicentang di tabel.
                  </span>
                </div>
              )}
            </div>

            {/* 2. Form Input Perubahan: Harga & Status */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-4">
              <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                <Coins className="w-4 h-4 text-emerald-600" />
                <span>2. Nilai yang Akan Diubah:</span>
              </span>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Opsi 2A: Ubah Harga */}
                <div
                  className={`p-3.5 rounded-xl border transition-colors ${
                    applyPriceChange
                      ? 'bg-emerald-50/70 border-emerald-300'
                      : 'bg-slate-50 border-slate-200 opacity-80'
                  }`}
                >
                  <label className="flex items-center gap-2 font-bold text-slate-900 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={applyPriceChange}
                      onChange={(e) => setApplyPriceChange(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                    />
                    <span>Ubah Harga Sarapan (per Pax)</span>
                  </label>

                  {applyPriceChange && (
                    <div className="space-y-2 mt-2">
                      <div className="relative">
                        <span className="absolute left-3 top-2 font-bold text-slate-400 text-xs">
                          Rp
                        </span>
                        <input
                          type="number"
                          min="0"
                          step="1000"
                          value={priceInputStr}
                          onChange={(e) => {
                            setPriceInputStr(e.target.value);
                            setNewPrice(Number(e.target.value) || 0);
                          }}
                          placeholder="35000"
                          className="w-full pl-9 pr-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                        />
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-slate-500">Preset cepat:</span>
                        {[25000, 30000, 35000, 40000, 45000, 50000].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => {
                              setNewPrice(preset);
                              setPriceInputStr(String(preset));
                            }}
                            className="px-2 py-0.5 bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-md text-[10px] font-semibold cursor-pointer"
                          >
                            {formatRupiah(preset)}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Opsi 2B: Ubah Status */}
                <div
                  className={`p-3.5 rounded-xl border transition-colors ${
                    applyStatusChange
                      ? 'bg-blue-50/70 border-blue-300'
                      : 'bg-slate-50 border-slate-200 opacity-80'
                  }`}
                >
                  <label className="flex items-center gap-2 font-bold text-slate-900 cursor-pointer mb-2">
                    <input
                      type="checkbox"
                      checked={applyStatusChange}
                      onChange={(e) => setApplyStatusChange(e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300"
                    />
                    <span>Ubah Status Penyajian</span>
                  </label>

                  {applyStatusChange && (
                    <div className="mt-2">
                      <select
                        value={newStatus}
                        onChange={(e) =>
                          setNewStatus(
                            e.target.value as 'Direncanakan' | 'Disajikan' | 'Dibatalkan',
                          )
                        }
                        className="w-full px-3 py-2 bg-white border border-blue-300 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer"
                      >
                        <option value="Direncanakan">Direncanakan</option>
                        <option value="Disajikan">Disajikan (Selesai)</option>
                        <option value="Dibatalkan">Dibatalkan</option>
                      </select>
                      <span className="text-[10px] text-slate-500 mt-1 block">
                        Status lama akan diperbarui menjadi status yang dipilih.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 3. Daftar Data yang Terdampak & Pilihan Centang */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                    <Filter className="w-4 h-4 text-slate-600" />
                    <span>3. Data Terdampak ({finalAffectedRecords.length} dari {dateMatchingRecords.length} dipilih)</span>
                  </span>
                  <span className="text-[11px] text-slate-500 mt-0.5 block">
                    {dateDescription}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleSelectAllMatching}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold cursor-pointer"
                  >
                    Pilih Semua ({dateMatchingRecords.length})
                  </button>
                  <button
                    type="button"
                    onClick={handleDeselectAllMatching}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold cursor-pointer"
                  >
                    Batal Semua
                  </button>
                </div>
              </div>

              {dateMatchingRecords.length === 0 ? (
                <div className="p-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300">
                  <AlertTriangle className="w-6 h-6 text-amber-500 mx-auto mb-1" />
                  <p className="font-semibold text-slate-700 text-xs">
                    Tidak ada data sarapan yang cocok dengan {dateDescription}.
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Coba ubah pilihan tanggal di atas atau pilih tanggal yang memiliki transaksi sarapan.
                  </p>
                </div>
              ) : (
                <div className="max-h-56 overflow-y-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 sticky top-0">
                      <tr>
                        <th className="py-2 px-3 w-8 text-center">Pilih</th>
                        <th className="py-2 px-3">Tanggal</th>
                        <th className="py-2 px-3">Nama Tamu</th>
                        <th className="py-2 px-3">Kamar</th>
                        <th className="py-2 px-3 text-center">Porsi</th>
                        <th className="py-2 px-3 text-right">Harga Saat Ini</th>
                        <th className="py-2 px-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {dateMatchingRecords.map((r) => {
                        const isChecked = selectedRecordIds.has(r.id);
                        return (
                          <tr
                            key={r.id}
                            onClick={() => handleToggleRecord(r.id)}
                            className={`cursor-pointer transition-colors ${
                              isChecked ? 'bg-blue-50/40 hover:bg-blue-50/70' : 'hover:bg-slate-50'
                            }`}
                          >
                            <td className="py-2 px-3 text-center">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => {}}
                                className="w-4 h-4 text-blue-600 rounded cursor-pointer"
                              />
                            </td>
                            <td className="py-2 px-3 font-mono font-medium">{r.date}</td>
                            <td className="py-2 px-3 font-bold text-slate-900">{r.guestName}</td>
                            <td className="py-2 px-3 font-medium">
                              {r.roomType} {r.roomNumber ? `(${r.roomNumber})` : ''}
                            </td>
                            <td className="py-2 px-3 text-center font-bold">{r.qty} pax</td>
                            <td className="py-2 px-3 text-right font-mono font-semibold">
                              {formatRupiah(r.price)}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  r.status === 'Disajikan'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : r.status === 'Dibatalkan'
                                    ? 'bg-rose-100 text-rose-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {r.status || 'Direncanakan'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Bottom Actions Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
              <div>
                <span className="text-xs font-bold text-slate-900">
                  Total Data Terdampak: <span className="text-blue-600">{finalAffectedRecords.length} data</span>
                </span>
                <span className="text-[11px] text-slate-400 block">
                  Data sarapan di luar tanggal yang dipilih TIDAK akan diubah.
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  disabled={finalAffectedRecords.length === 0 || (!applyPriceChange && !applyStatusChange)}
                  onClick={handleProceedToConfirm}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
                >
                  <span>Lanjut Konfirmasi</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </>
        ) : (
          /* ================= STEP 2: KONFIRMASI PERUBAHAN ================= */
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm text-amber-950">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <span>Konfirmasi Sebelum Menyimpan Perubahan Massal</span>
              </div>
              <p className="text-xs text-amber-800">
                Mohon tinjau rincian perubahan di bawah ini secara teliti sebelum menyimpan. Perubahan akan dicatat dalam riwayat audit edit massal.
              </p>
            </div>

            {/* Ringkasan Perubahan */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
              <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                Ringkasan Tindakan:
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Lingkup Tanggal
                  </span>
                  <span className="font-bold text-slate-900 text-xs">{dateDescription}</span>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Perubahan Harga
                  </span>
                  {applyPriceChange ? (
                    <span className="font-bold text-emerald-700 text-xs">
                      Diubah menjadi {formatRupiah(newPrice)} / pax
                    </span>
                  ) : (
                    <span className="text-slate-500 text-xs">Tidak diubah (tetap)</span>
                  )}
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                    Perubahan Status
                  </span>
                  {applyStatusChange ? (
                    <span className="font-bold text-blue-700 text-xs">
                      Diubah menjadi {newStatus}
                    </span>
                  ) : (
                    <span className="text-slate-500 text-xs">Tidak diubah (tetap)</span>
                  )}
                </div>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-800">
                  Jumlah Data Terdampak:{' '}
                  <span className="text-blue-600 font-extrabold">{finalAffectedRecords.length} data sarapan</span>
                </span>
                <span className="text-[11px] text-slate-500 block mt-0.5">
                  Hanya {finalAffectedRecords.length} data di atas yang akan diperbarui. Data sarapan pada tanggal lain tidak akan terpengaruh.
                </span>
              </div>
            </div>

            {/* Pratinjau Daftar Rekaman */}
            <div className="max-h-52 overflow-y-auto border border-slate-200 rounded-xl bg-white">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="py-2 px-3">Tanggal</th>
                    <th className="py-2 px-3">Tamu</th>
                    <th className="py-2 px-3">Kamar</th>
                    <th className="py-2 px-3 text-center">Porsi</th>
                    <th className="py-2 px-3 text-right">Harga Baru</th>
                    <th className="py-2 px-3 text-center">Status Baru</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {finalAffectedRecords.map((r) => (
                    <tr key={r.id}>
                      <td className="py-2 px-3 font-mono">{r.date}</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{r.guestName}</td>
                      <td className="py-2 px-3">
                        {r.roomType} {r.roomNumber ? `(${r.roomNumber})` : ''}
                      </td>
                      <td className="py-2 px-3 text-center font-semibold">{r.qty} pax</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700">
                        {applyPriceChange ? (
                          <span>
                            <span className="line-through text-slate-400 font-normal mr-1">
                              {formatRupiah(r.price)}
                            </span>
                            {formatRupiah(newPrice)}
                          </span>
                        ) : (
                          formatRupiah(r.price)
                        )}
                      </td>
                      <td className="py-2 px-3 text-center font-bold">
                        {applyStatusChange ? (
                          <span className="text-blue-700">{newStatus}</span>
                        ) : (
                          <span>{r.status || 'Direncanakan'}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Tombol Aksi Konfirmasi */}
            <div className="flex flex-wrap items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                disabled={isSaving}
                onClick={() => setShowConfirmStep(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
              >
                Kembali Edit
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={handleExecuteBulkEdit}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Menyimpan Perubahan...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Ya, Terapkan Perubahan Massal ({finalAffectedRecords.length} Data)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
