import React, { useState, useEffect } from 'react';
import { BreakfastRecord, Booking } from '../../types';
import { Modal } from '../common/Modal';
import { subscribeBookings } from '../../utils/firebase';
import { getTodayDateString, formatRupiah } from '../../utils/formatters';
import {
  Utensils,
  Calendar,
  User,
  Home,
  Hash,
  DollarSign,
  FileText,
  Sparkles,
} from 'lucide-react';

interface BreakfastModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordToEdit?: BreakfastRecord | null;
  onSave: (payload: Partial<BreakfastRecord>) => Promise<void>;
}

export const BreakfastModal: React.FC<BreakfastModalProps> = ({
  isOpen,
  onClose,
  recordToEdit,
  onSave,
}) => {
  const [date, setDate] = useState<string>(getTodayDateString());
  const [guestName, setGuestName] = useState<string>('');
  const [roomType, setRoomType] = useState<string>('Standard Tent');
  const [roomNumber, setRoomNumber] = useState<string>('');
  const [roomName, setRoomName] = useState<string>('');
  const [qty, setQty] = useState<number>(2);
  const [price, setPrice] = useState<number>(35000);
  const [notes, setNotes] = useState<string>('');
  const [bookingId, setBookingId] = useState<string>('');
  const [status, setStatus] = useState<'Direncanakan' | 'Disajikan' | 'Dibatalkan'>('Direncanakan');

  // Bookings list for quick auto-fill
  const [activeBookings, setActiveBookings] = useState<Booking[]>([]);
  const [selectedBookingQuickId, setSelectedBookingQuickId] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    // Load bookings for quick draft option
    const unsub = subscribeBookings((list) => {
      setActiveBookings(list.filter((b) => b.status !== 'Cancelled'));
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (recordToEdit) {
      setDate(recordToEdit.date || getTodayDateString());
      setGuestName(recordToEdit.guestName || '');
      setRoomType(recordToEdit.roomType || 'Standard Tent');
      setRoomNumber(recordToEdit.roomNumber || '');
      setRoomName(recordToEdit.roomName || '');
      setQty(recordToEdit.qty || 1);
      setPrice(recordToEdit.price || 0);
      setNotes(recordToEdit.notes || '');
      setBookingId(recordToEdit.bookingId || '');
      setStatus(recordToEdit.status || 'Direncanakan');
      setSelectedBookingQuickId(recordToEdit.bookingId || '');
    } else {
      setDate(getTodayDateString());
      setGuestName('');
      setRoomType('Standard Tent');
      setRoomNumber('');
      setRoomName('');
      setQty(2);
      setPrice(35000);
      setNotes('');
      setBookingId('');
      setStatus('Direncanakan');
      setSelectedBookingQuickId('');
    }
    setErrorMsg('');
  }, [recordToEdit, isOpen]);

  const handleQuickSelectBooking = (id: string) => {
    setSelectedBookingQuickId(id);
    if (!id) return;

    const b = activeBookings.find((item) => item.id === id);
    if (b) {
      setGuestName(b.guestName || '');
      setBookingId(b.id);
      if (b.rooms && b.rooms.length > 0) {
        setRoomType(b.rooms[0].roomType || 'Standard Tent');
        // Total guests or room quantity * 2 as default
        const totalRooms = b.rooms.reduce((acc, r) => acc + (r.roomQty || 1), 0);
        setQty(totalRooms * 2);
      }
      setNotes(`Ditarik otomatis dari reservasi: ${b.id}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim()) {
      setErrorMsg('Nama tamu wajib diisi.');
      return;
    }
    if (!roomNumber.trim()) {
      setErrorMsg('Nomor kamar / tenda wajib diisi.');
      return;
    }
    if (qty <= 0) {
      setErrorMsg('Jumlah porsi minimal 1.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onSave({
        id: recordToEdit?.id,
        date: date || getTodayDateString(),
        guestName: guestName.trim(),
        roomType: roomType.trim(),
        roomNumber: roomNumber.trim(),
        roomName: roomName.trim() || undefined,
        qty: Number(qty) || 1,
        price: Number(price) || 0,
        notes: notes.trim() || undefined,
        bookingId: bookingId.trim() || undefined,
        status,
      });
      onClose();
    } catch (err) {
      console.error('Error saving breakfast:', err);
      setErrorMsg('Gagal menyimpan data sarapan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={recordToEdit ? 'Edit Catatan Sarapan / F&B' : 'Tambah Data Sarapan / Breakfast'}
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-medium">
            {errorMsg}
          </div>
        )}

        {/* Quick auto-fill from active hotel bookings */}
        {!recordToEdit && activeBookings.length > 0 && (
          <div className="p-3 bg-blue-50/70 border border-blue-200/80 rounded-xl space-y-1.5">
            <label className="font-bold text-blue-900 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Tarik Otomatis dari Reservasi Kamar:</span>
            </label>
            <select
              value={selectedBookingQuickId}
              onChange={(e) => handleQuickSelectBooking(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-white border border-blue-200 rounded-lg text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="">-- Buat Manual / Pilih Data Reservasi --</option>
              {activeBookings.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.guestName} ({b.checkInDate} s/d {b.checkOutDate}) — {b.rooms.map((r) => `${r.roomQty}x ${r.roomType}`).join(', ')}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Date & Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal Penyajian *</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Utensils className="w-3.5 h-3.5 text-slate-400" />
              <span>Status Pelayanan</span>
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'Direncanakan' | 'Disajikan' | 'Dibatalkan')}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:bg-white"
            >
              <option value="Direncanakan">Direncanakan (Siap Saji)</option>
              <option value="Disajikan">Sudah Disajikan (Selesai)</option>
              <option value="Dibatalkan">Dibatalkan</option>
            </select>
          </div>
        </div>

        {/* Guest Name */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span>Nama Tamu / Rombongan *</span>
          </label>
          <input
            type="text"
            required
            placeholder="Contoh: Ibu Rina (Keluarga Santoso)"
            value={guestName}
            onChange={(e) => setGuestName(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:bg-white"
          />
        </div>

        {/* Room Info */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Home className="w-3.5 h-3.5 text-slate-400" />
              <span>Tipe Kamar / Tenda *</span>
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: Deluxe Glamping"
              value={roomType}
              onChange={(e) => setRoomType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-slate-400" />
              <span>No. Kamar / Unit *</span>
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: T-01 / V-03"
              value={roomNumber}
              onChange={(e) => setRoomNumber(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Nama Unit (Opsional)
            </label>
            <input
              type="text"
              placeholder="Contoh: Sunset View"
              value={roomName}
              onChange={(e) => setRoomName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
            />
          </div>
        </div>

        {/* Porsi & Nilai */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Utensils className="w-3.5 h-3.5 text-blue-600" />
              <span>Jumlah Porsi (Pax) *</span>
            </label>
            <input
              type="number"
              min="1"
              required
              value={qty}
              onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-blue-700 focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Harga per Porsi (Rp)</span>
            </label>
            <input
              type="number"
              min="0"
              value={price || ''}
              onChange={(e) => setPrice(Math.max(0, parseInt(e.target.value) || 0))}
              placeholder="0"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
            />
            <div className="text-[10px] text-slate-500 mt-1">
              Total Nilai: <strong className="text-emerald-700">{formatRupiah(qty * price)}</strong>
            </div>
          </div>
        </div>

        {/* Catatan / Permintaan Khusus */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-slate-400" />
            <span>Catatan Khusus / Menu Request (Opsional)</span>
          </label>
          <input
            type="text"
            placeholder="Contoh: 1 porsi vegetarian tanpa pedas, antar ke tenda pukul 07.30..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'Menyimpan...' : recordToEdit ? 'Simpan Perubahan' : 'Simpan Sarapan'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
