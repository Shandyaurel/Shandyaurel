import React, { useState, useMemo } from 'react';
import { BreakfastRecord, BusinessSettings } from '../../types';
import { Modal } from '../common/Modal';
import { formatRupiah, formatDateIndo, getTodayDateString } from '../../utils/formatters';
import { Printer, Calendar, Utensils, DollarSign, Users } from 'lucide-react';

interface BreakfastReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: BreakfastRecord[];
  businessSettings?: BusinessSettings | null;
}

export const BreakfastReportModal: React.FC<BreakfastReportModalProps> = ({
  isOpen,
  onClose,
  records,
  businessSettings,
}) => {
  const today = getTodayDateString();
  const currentMonth = today.substring(0, 7);

  const [dateFilter, setDateFilter] = useState<'thisMonth' | 'today' | 'all' | 'custom'>('thisMonth');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  const defaultPrice = Number(
    businessSettings?.breakfastCostPerPax || businessSettings?.defaultBreakfastCostPerPax || 35000,
  );
  const businessName = (businessSettings?.businessName || 'BUKIT LANGIT CAMPVENTURE').toUpperCase();

  const filtered = useMemo(() => {
    return records.filter((r) => {
      const d = r.date || r.createdAt.split('T')[0];
      if (dateFilter === 'today' && d !== today) return false;
      if (dateFilter === 'thisMonth' && !d.startsWith(currentMonth)) return false;
      if (dateFilter === 'custom') {
        if (startDate && d < startDate) return false;
        if (endDate && d > endDate) return false;
      }
      return true;
    });
  }, [records, dateFilter, startDate, endDate, today, currentMonth]);

  // Overall totals & Room type grouping
  const summary = useMemo(() => {
    let grandTotalPax = 0;
    let grandTotalBiaya = 0;

    // Date grouping
    const dateGroupMap: Record<string, { date: string; roomTypes: string[]; totalPax: number; totalBiaya: number }> = {};
    // Type & price grouping
    const typePriceMap: Record<string, { type: string; price: number; pax: number; total: number }> = {};

    filtered.forEach((r) => {
      const d = r.date || r.createdAt.split('T')[0];
      const pax = Number(r.qty) || 0;
      const unitPrice = Number(r.price) || defaultPrice;
      const subtotal = pax * unitPrice;

      grandTotalPax += pax;
      grandTotalBiaya += subtotal;

      const rType = r.roomType || 'Standard Room';

      // Group by Date
      if (!dateGroupMap[d]) {
        dateGroupMap[d] = {
          date: d,
          roomTypes: [rType],
          totalPax: 0,
          totalBiaya: 0,
        };
      }
      if (!dateGroupMap[d].roomTypes.includes(rType)) {
        dateGroupMap[d].roomTypes.push(rType);
      }
      dateGroupMap[d].totalPax += pax;
      dateGroupMap[d].totalBiaya += subtotal;

      // Group by Type & Price
      const key = `${rType}_${unitPrice}`;
      if (!typePriceMap[key]) {
        typePriceMap[key] = {
          type: rType,
          price: unitPrice,
          pax: 0,
          total: 0,
        };
      }
      typePriceMap[key].pax += pax;
      typePriceMap[key].total += subtotal;
    });

    return {
      grandTotalPax,
      grandTotalBiaya,
      totalOrders: filtered.length,
      dateBreakdown: Object.values(dateGroupMap).sort((a, b) => b.date.localeCompare(a.date)),
      typePriceBreakdown: Object.values(typePriceMap),
    };
  }, [filtered, defaultPrice]);

  const handlePrint = () => {
    window.print();
  };

  const periodLabel =
    dateFilter === 'today'
      ? formatDateIndo(today)
      : dateFilter === 'thisMonth'
      ? `Bulan ${new Date().toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })}`
      : dateFilter === 'custom' && startDate && endDate
      ? `${formatDateIndo(startDate)} s/d ${formatDateIndo(endDate)}`
      : 'Semua Periode';

  if (!isOpen) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Print Detail — Laporan Accounting Breakfast (A4 Monospace)"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-4 text-xs">
        {/* Controls Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl print:hidden">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-700 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Periode Laporan:</span>
            </span>
            <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setDateFilter('today')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                  dateFilter === 'today' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Hari Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('thisMonth')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                  dateFilter === 'thisMonth' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Bulan Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('all')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                  dateFilter === 'all' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('custom')}
                className={`px-2.5 py-1 rounded-md font-semibold cursor-pointer ${
                  dateFilter === 'custom' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Rentang Tanggal
              </button>
            </div>

            {dateFilter === 'custom' && (
              <div className="flex items-center gap-1">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2 py-1 bg-white border border-slate-200 rounded-md"
                />
                <span>s/d</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2 py-1 bg-white border border-slate-200 rounded-md"
                />
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Laporan Lengkap</span>
          </button>
        </div>

        {/* Printable Paper Area (A4 Monospace Style with 2 Sections / Pages) */}
        <div className="bg-slate-100 p-4 rounded-xl max-h-[75vh] overflow-y-auto print:bg-white print:p-0 print:overflow-visible space-y-8">
          {/* ========================================================= */}
          {/* HALAMAN 1: RINCIAN TAMU (Accounting Detail)               */}
          {/* ========================================================= */}
          <div
            id="printable-accounting-detail"
            className="bg-white max-w-[210mm] mx-auto p-8 sm:p-12 shadow-sm border border-slate-300 font-mono text-slate-900 text-xs print:shadow-none print:border-none print:p-6 print:max-w-none print:break-after-page"
          >
            {/* Header */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
              <h1 className="text-lg font-black tracking-wider uppercase">{businessName}</h1>
              <h2 className="text-sm font-bold tracking-widest mt-0.5">LAPORAN RINCIAN BREAKFAST</h2>
              <p className="text-xs font-semibold mt-1">Periode: {periodLabel}</p>
            </div>

            {/* Table: Tamu | Kamar | Qty | Harga | Total */}
            <div className="mb-6">
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-900 text-slate-900 font-bold uppercase">
                    <th className="py-2 px-3 w-10 text-center">NO</th>
                    <th className="py-2 px-3">TAMU</th>
                    <th className="py-2 px-3 w-36">KAMAR</th>
                    <th className="py-2 px-3 w-16 text-right">QTY</th>
                    <th className="py-2 px-3 w-28 text-right">HARGA</th>
                    <th className="py-2 px-3 w-32 text-right">TOTAL</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                        Tidak ada data rincian breakfast pada periode ini.
                      </td>
                    </tr>
                  ) : (
                    filtered.map((r, idx) => {
                      const unitP = Number(r.price) || defaultPrice;
                      const tot = (Number(r.qty) || 0) * unitP;
                      return (
                        <tr
                          key={r.id || idx}
                          className="border-b border-dashed border-slate-400"
                        >
                          <td className="py-2 px-3 text-center">{idx + 1}</td>
                          <td className="py-2 px-3 font-semibold">{r.guestName}</td>
                          <td className="py-2 px-3">{r.roomNumber || r.roomType}</td>
                          <td className="py-2 px-3 text-right">{r.qty}</td>
                          <td className="py-2 px-3 text-right">{formatRupiah(unitP)}</td>
                          <td className="py-2 px-3 text-right font-bold">{formatRupiah(tot)}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Subtotal / Grand Total Section */}
            <div className="border-t-2 border-slate-900 pt-3 flex items-center justify-between font-bold text-xs sm:text-sm">
              <span>Total Pax: {summary.grandTotalPax} Pax</span>
              <span>Total Biaya: {formatRupiah(summary.grandTotalBiaya)}</span>
            </div>

            {/* Signatures: Dibuat Oleh ... Mengetahui */}
            <div className="grid grid-cols-2 gap-12 text-center mt-14 pt-4 text-xs break-inside-avoid">
              <div>
                <p className="font-bold mb-14">Dibuat Oleh,</p>
                <p className="tracking-widest">{businessSettings?.breakfastDibuatNama || '.........................'}</p>
                <p className="text-[11px] text-slate-600 mt-1">{businessSettings?.breakfastDibuatJabatan || 'Staf Accounting / F&B'}</p>
              </div>
              <div>
                <p className="font-bold mb-14">Mengetahui,</p>
                <p className="tracking-widest">{businessSettings?.breakfastMengetahuiNama || '.........................'}</p>
                <p className="text-[11px] text-slate-600 mt-1">{businessSettings?.breakfastMengetahuiJabatan || 'Operational Manager'}</p>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* HALAMAN RINGKASAN: REKAPITULASI ACCOUNTING & MANAGEMENT   */}
          {/* ========================================================= */}
          <div
            id="printable-accounting-summary"
            className="bg-white max-w-[210mm] mx-auto p-8 sm:p-12 shadow-sm border border-slate-300 font-mono text-slate-900 text-xs print:shadow-none print:border-none print:p-6 print:max-w-none"
          >
            {/* Header */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-6">
              <h1 className="text-lg font-black tracking-wider uppercase">{businessName}</h1>
              <h2 className="text-sm font-bold tracking-widest mt-0.5">
                RINGKASAN LAPORAN BREAKFAST / Periode {periodLabel}
              </h2>
            </div>

            {/* Section A: RINCIAN PER TANGGAL (Tanggal | Tipe Kamar | Total Pax | Total Biaya) */}
            <div className="mb-6">
              <h3 className="font-bold text-xs uppercase mb-2 border-b border-slate-400 pb-1">
                A. RINCIAN PER TANGGAL
              </h3>
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead>
                  <tr className="border-b-2 border-slate-900 font-bold uppercase">
                    <th className="py-2 px-3 w-32">TANGGAL</th>
                    <th className="py-2 px-3">TIPE KAMAR</th>
                    <th className="py-2 px-3 w-24 text-right">TOTAL PAX</th>
                    <th className="py-2 px-3 w-36 text-right">TOTAL BIAYA</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.dateBreakdown.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-slate-400 italic">
                        Tidak ada data tanggal.
                      </td>
                    </tr>
                  ) : (
                    summary.dateBreakdown.map((row, idx) => (
                      <tr key={row.date || idx} className="border-b border-dashed border-slate-300">
                        <td className="py-2 px-3 font-semibold">{formatDateIndo(row.date)}</td>
                        <td className="py-2 px-3 text-slate-700">{row.roomTypes.join(', ')}</td>
                        <td className="py-2 px-3 text-right font-bold">{row.totalPax} Pax</td>
                        <td className="py-2 px-3 text-right font-bold">{formatRupiah(row.totalBiaya)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Section B: Kotak REKAPAN TOTAL PER TIPE & HARGA */}
            <div className="mb-6 border-2 border-slate-800 p-4 rounded-lg bg-slate-50/60">
              <h3 className="font-bold text-xs uppercase mb-3 text-slate-900">
                B. REKAPAN TOTAL PER TIPE & HARGA
              </h3>
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead>
                  <tr className="border-b border-slate-400 font-bold uppercase">
                    <th className="py-1.5 px-2">TIPE KAMAR</th>
                    <th className="py-1.5 px-2 text-right">HARGA / PAX</th>
                    <th className="py-1.5 px-2 text-right">TOTAL PAX</th>
                    <th className="py-1.5 px-2 text-right">SUBTOTAL</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.typePriceBreakdown.map((item, idx) => (
                    <tr key={idx} className="border-b border-dashed border-slate-300">
                      <td className="py-1.5 px-2 font-semibold">{item.type}</td>
                      <td className="py-1.5 px-2 text-right">{formatRupiah(item.price)}</td>
                      <td className="py-1.5 px-2 text-right font-bold">{item.pax} Pax</td>
                      <td className="py-1.5 px-2 text-right font-bold">{formatRupiah(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Grand Total Summary Box */}
            <div className="border-t-2 border-slate-900 pt-3 flex items-center justify-between font-black text-sm bg-slate-100 p-3 rounded-md">
              <span>GRAND TOTAL SELURUHNYA: {summary.grandTotalPax} Pax</span>
              <span>TOTAL BIAYA KESELURUHAN: {formatRupiah(summary.grandTotalBiaya)}</span>
            </div>

            {/* Signatures: Admin ... Manager */}
            <div className="grid grid-cols-2 gap-12 text-center mt-14 pt-4 text-xs break-inside-avoid">
              <div>
                <p className="font-bold mb-14">Admin,</p>
                <p className="tracking-widest">{businessSettings?.breakfastDibuatNama || '.........................'}</p>
                <p className="text-[11px] text-slate-600 mt-1">{businessSettings?.breakfastDibuatJabatan || 'Staf Accounting / Admin'}</p>
              </div>
              <div>
                <p className="font-bold mb-14">Manager,</p>
                <p className="tracking-widest">{businessSettings?.breakfastMengetahuiNama || '.........................'}</p>
                <p className="text-[11px] text-slate-600 mt-1">{businessSettings?.breakfastMengetahuiJabatan || 'General / Operational Manager'}</p>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-3 border-t border-slate-300 text-[10px] text-slate-500 flex items-center justify-between">
              <span>Bukit Langit Campventure • Finance & Accounting</span>
              <span>Generated: {new Date().toLocaleDateString('id-ID')} {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB</span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl cursor-pointer"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Print Detail</span>
          </button>
        </div>
      </div>
    </Modal>
  );
};
