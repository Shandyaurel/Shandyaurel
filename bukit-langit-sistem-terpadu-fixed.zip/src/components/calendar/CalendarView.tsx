import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import type { Booking, ATVBooking, BusinessSettings } from '../../types';
import {
  subscribeBookings,
  subscribeATVBookings,
  getBusinessSettings,
} from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatter';
import { Modal } from '../common/Modal';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Hotel,
  Compass,
  Search,
  Filter,
  Eye,
  Layers,
  CalendarDays,
  ListFilter,
  Check,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type ViewMode = 'month' | 'week' | 'list';
type FilterType = 'all' | 'hotel' | 'atv';

interface CalendarEvent {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  type: 'hotel' | 'atv';
  status: string;
  totalPrice: number;
  details: Booking | ATVBooking;
}

const DAYS_ID = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const MONTHS_ID = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];

function getDaysInMonth(year: number, month: number): Date[] {
  const days: Date[] = [];
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  const startPad = firstDay.getDay();
  for (let i = startPad - 1; i >= 0; i--) {
    days.push(new Date(year, month, -i));
  }

  for (let d = 1; d <= lastDay.getDate(); d++) {
    days.push(new Date(year, month, d));
  }

  const endPad = 6 - lastDay.getDay();
  for (let i = 1; i <= endPad; i++) {
    days.push(new Date(year, month + 1, i));
  }

  return days;
}

function formatDate(d: Date): string {
  return d.toISOString().split('T')[0];
}

function getWeekDates(date: Date): Date[] {
  const start = new Date(date);
  start.setDate(start.getDate() - start.getDay());
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
}

export const CalendarView: React.FC = () => {
  const { isAllowed } = useAuth();
  const { showError } = useToast();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [atvBookings, setATVBookings] = useState<ATVBooking[]>([]);
  const [settings, setSettings] = useState<BusinessSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const [viewMode, setViewMode] = useState<ViewMode>('month');
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [search, setSearch] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const s = await getBusinessSettings();
        if (s) setSettings(s);
      } catch {}
    };
    loadSettings();
  }, []);

  useEffect(() => {
    if (!isAllowed('calendar')) return;
    let loaded = 0;
    const checkDone = () => { loaded++; if (loaded >= 2) setLoading(false); };

    const unsub1 = subscribeBookings((data) => { setBookings(data); checkDone(); });
    const unsub2 = subscribeATVBookings((data) => { setATVBookings(data); checkDone(); });

    return () => { unsub1(); unsub2(); };
  }, [isAllowed]);

  const calendarEvents = useMemo<CalendarEvent[]>(() => {
    const events: CalendarEvent[] = [];

    bookings.forEach((b) => {
      if (!b.checkInDate) return;
      events.push({
        id: b.id,
        title: `${b.guestName} — ${b.roomType || 'Hotel'}`,
        startDate: b.checkInDate,
        endDate: b.checkOutDate || b.checkInDate,
        type: 'hotel',
        status: b.status || 'confirmed',
        totalPrice: b.grandTotal || b.totalPrice || 0,
        details: b,
      });
    });

    atvBookings.forEach((a) => {
      if (!a.date) return;
      events.push({
        id: a.id,
        title: `${a.customerName} — ATV`,
        startDate: a.date,
        endDate: a.date,
        type: 'atv',
        status: a.status || 'confirmed',
        totalPrice: a.grandTotal || a.totalPrice || 0,
        details: a,
      });
    });

    if (search) {
      const q = search.toLowerCase();
      return events.filter((e) => e.title.toLowerCase().includes(q));
    }

    if (filterType !== 'all') {
      return events.filter((e) => e.type === filterType);
    }

    return events;
  }, [bookings, atvBookings, search, filterType]);

  const getEventsForDate = useCallback(
    (dateStr: string) => calendarEvents.filter((e) => dateStr >= e.startDate && dateStr <= e.endDate),
    [calendarEvents],
  );

  const navigateMonth = (dir: number) => {
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() + dir, 1));
  };

  const navigateWeek = (dir: number) => {
    setCurrentDate((prev) => {
      const d = new Date(prev);
      d.setDate(d.getDate() + dir * 7);
      return d;
    });
  };

  const goToday = () => setCurrentDate(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const todayStr = formatDate(new Date());

  const statusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-emerald-500';
      case 'checked_in': return 'bg-blue-500';
      case 'checked_out': return 'bg-slate-400';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-amber-500';
    }
  };

  const typeColor = (type: 'hotel' | 'atv') =>
    type === 'hotel' ? 'bg-sky-100 text-sky-700 border-sky-200' : 'bg-orange-100 text-orange-700 border-orange-200';

  const renderMonthView = () => {
    const days = getDaysInMonth(year, month);
    return (
      <div className="grid grid-cols-7 border-t border-l border-slate-200">
        {DAYS_ID.map((d) => (
          <div key={d} className="px-2 py-2 text-xs font-semibold text-slate-500 text-center border-r border-b border-slate-200 bg-slate-50">
            {d}
          </div>
        ))}
        {days.map((day, i) => {
          const dateStr = formatDate(day);
          const isCurrentMonth = day.getMonth() === month;
          const isToday = dateStr === todayStr;
          const dayEvents = getEventsForDate(dateStr);

          return (
            <div
              key={i}
              className={`min-h-[90px] border-r border-b border-slate-200 p-1 ${
                isCurrentMonth ? 'bg-white' : 'bg-slate-50/50'
              }`}
            >
              <div className={`text-xs mb-1 w-6 h-6 flex items-center justify-center rounded-full ${
                isToday ? 'bg-emerald-600 text-white font-bold' : isCurrentMonth ? 'text-slate-700' : 'text-slate-300'
              }`}>
                {day.getDate()}
              </div>
              <div className="space-y-0.5">
                {dayEvents.slice(0, 3).map((ev) => (
                  <button
                    key={ev.id}
                    onClick={() => setSelectedEvent(ev)}
                    className={`w-full text-left px-1.5 py-0.5 rounded text-[10px] font-medium truncate border ${typeColor(ev.type)} hover:opacity-80`}
                  >
                    {ev.type === 'hotel' ? <Hotel className="w-2.5 h-2.5 inline mr-0.5" /> : <Compass className="w-2.5 h-2.5 inline mr-0.5" />}
                    {ev.title.split('—')[0].trim()}
                  </button>
                ))}
                {dayEvents.length > 3 && (
                  <p className="text-[10px] text-slate-400 pl-1">+{dayEvents.length - 3} lainnya</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderWeekView = () => {
    const weekDates = getWeekDates(currentDate);
    return (
      <div className="grid grid-cols-7 border-t border-l border-slate-200">
        {weekDates.map((day, i) => {
          const dateStr = formatDate(day);
          const isToday = dateStr === todayStr;
          const dayEvents = getEventsForDate(dateStr);

          return (
            <div key={i} className="border-r border-b border-slate-200 min-h-[200px]">
              <div className={`px-2 py-2 text-center border-b border-slate-200 ${isToday ? 'bg-emerald-50' : 'bg-slate-50'}`}>
                <p className="text-[10px] text-slate-500">{DAYS_ID[i]}</p>
                <p className={`text-sm font-bold ${isToday ? 'text-emerald-600' : 'text-slate-700'}`}>{day.getDate()}</p>
              </div>
              <div className="p-1 space-y-1">
                {dayEvents.map((ev) => (
                  <button
                    key={ev.id}
                    onClick={() => setSelectedEvent(ev)}
                    className={`w-full text-left px-2 py-1.5 rounded-lg text-xs border ${typeColor(ev.type)} hover:opacity-80`}
                  >
                    <p className="font-medium truncate">{ev.title.split('—')[0].trim()}</p>
                    <p className="text-[10px] opacity-70">{formatRupiah(ev.totalPrice)}</p>
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderListView = () => {
    const sorted = [...calendarEvents].sort((a, b) => a.startDate.localeCompare(b.startDate));
    const grouped: Record<string, CalendarEvent[]> = {};
    sorted.forEach((ev) => {
      const key = ev.startDate;
      if (!grouped[key]) grouped[key] = [];
      grouped[key].push(ev);
    });

    return (
      <div className="space-y-4">
        {Object.entries(grouped).map(([date, evts]) => (
          <div key={date}>
            <p className="text-xs font-semibold text-slate-500 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1">
              {new Date(date + 'T00:00').toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
            <div className="space-y-2">
              {evts.map((ev) => (
                <button
                  key={ev.id}
                  onClick={() => setSelectedEvent(ev)}
                  className="w-full text-left flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 hover:border-slate-300 transition-all"
                >
                  <div className={`w-1.5 h-10 rounded-full ${ev.type === 'hotel' ? 'bg-sky-500' : 'bg-orange-500'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-800 truncate">{ev.title}</p>
                    <p className="text-xs text-slate-500">{ev.startDate !== ev.endDate ? `${ev.startDate} — ${ev.endDate}` : ev.startDate}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-800">{formatRupiah(ev.totalPrice)}</p>
                    <span className={`inline-block w-2 h-2 rounded-full ${statusColor(ev.status)}`} />
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
        {Object.keys(grouped).length === 0 && (
          <div className="text-center py-16 text-slate-400">
            <CalendarDays className="w-10 h-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Tidak ada event yang ditemukan.</p>
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-100 rounded-xl">
            <CalendarIcon className="w-5 h-5 text-emerald-700" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-800">Kalender Operasional</h2>
            <p className="text-xs text-slate-500">
              {calendarEvents.length} booking aktif
            </p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {/* Navigation */}
        <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-xl p-1">
          <button
            onClick={() => viewMode === 'month' ? navigateMonth(-1) : navigateWeek(-1)}
            className="p-1.5 hover:bg-slate-100 rounded-lg"
          >
            <ChevronLeft className="w-4 h-4 text-slate-600" />
          </button>
          <button
            onClick={goToday}
            className="px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-50 rounded-lg"
          >
            Hari Ini
          </button>
          <button
            onClick={() => viewMode === 'month' ? navigateMonth(1) : navigateWeek(1)}
            className="p-1.5 hover:bg-slate-100 rounded-lg"
          >
            <ChevronRight className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        <h3 className="text-sm font-bold text-slate-800">
          {MONTHS_ID[month]} {year}
        </h3>

        <div className="flex-1" />

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            placeholder="Cari..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-3 py-2 border border-slate-200 rounded-xl text-xs w-48"
          />
        </div>

        {/* Filter */}
        <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
          {([
            { key: 'all', label: 'Semua', icon: <Layers className="w-3 h-3" /> },
            { key: 'hotel', label: 'Hotel', icon: <Hotel className="w-3 h-3" /> },
            { key: 'atv', label: 'ATV', icon: <Compass className="w-3 h-3" /> },
          ] as const).map((f) => (
            <button
              key={f.key}
              onClick={() => setFilterType(f.key)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium ${
                filterType === f.key ? 'bg-white shadow-sm text-slate-800' : 'text-slate-500'
              }`}
            >
              {f.icon} {f.label}
            </button>
          ))}
        </div>

        {/* View mode */}
        <div className="flex gap-1 p-1 bg-slate-100 rounded-xl">
          {([
            { key: 'month', label: 'Bulan' },
            { key: 'week', label: 'Minggu' },
            { key: 'list', label: 'List' },
          ] as const).map((v) => (
            <button
              key={v.key}
              onClick={() => setViewMode(v.key)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium ${
                viewMode === v.key ? 'bg-white shadow-sm text-slate-800' : 'text-slate-500'
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Calendar content */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {viewMode === 'month' && renderMonthView()}
        {viewMode === 'week' && renderWeekView()}
        {viewMode === 'list' && renderListView()}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mt-4">
        {[
          { label: 'Total Hotel', value: calendarEvents.filter((e) => e.type === 'hotel').length, color: 'bg-sky-50 text-sky-700' },
          { label: 'Total ATV', value: calendarEvents.filter((e) => e.type === 'atv').length, color: 'bg-orange-50 text-orange-700' },
          { label: 'Hari Ini', value: getEventsForDate(todayStr).length, color: 'bg-emerald-50 text-emerald-700' },
          { label: 'Revenue', value: formatRupiah(calendarEvents.reduce((s, e) => s + e.totalPrice, 0)), color: 'bg-violet-50 text-violet-700' },
        ].map((stat) => (
          <div key={stat.label} className={`px-4 py-3 rounded-xl ${stat.color}`}>
            <p className="text-[10px] font-medium opacity-70">{stat.label}</p>
            <p className="text-lg font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Event detail modal */}
      {selectedEvent && (
        <Modal isOpen onClose={() => setSelectedEvent(null)} title="Detail Booking">
          <div className="space-y-3">
            <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${typeColor(selectedEvent.type)}`}>
              {selectedEvent.type === 'hotel' ? <Hotel className="w-3 h-3" /> : <Compass className="w-3 h-3" />}
              {selectedEvent.type === 'hotel' ? 'Hotel Booking' : 'ATV Booking'}
            </div>
            <h3 className="text-base font-bold text-slate-800">{selectedEvent.title}</h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-xs text-slate-500">Tanggal Mulai</p>
                <p className="font-medium">{selectedEvent.startDate}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Tanggal Selesai</p>
                <p className="font-medium">{selectedEvent.endDate}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Status</p>
                <span className={`inline-block w-2 h-2 rounded-full mr-1 ${statusColor(selectedEvent.status)}`} />
                <span className="font-medium capitalize">{selectedEvent.status.replace(/_/g, ' ')}</span>
              </div>
              <div>
                <p className="text-xs text-slate-500">Total</p>
                <p className="font-bold text-emerald-700">{formatRupiah(selectedEvent.totalPrice)}</p>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
