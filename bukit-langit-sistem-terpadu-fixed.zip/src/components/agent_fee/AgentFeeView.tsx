import React, { useState, useEffect, useMemo } from 'react';
import { AgentFee, AgentFeeStatus, FinancialDocument } from '../../types';
import {
  subscribeAgentFees,
  saveAgentFee,
  batchMarkAgentFeesAsPaid,
  deleteAgentFee,
  approveAgentFee,
  rejectAgentFee,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateIndo, getTodayDateString } from '../../utils/formatters';
import { angkaKeTerbilang } from '../../utils/terbilang';
import { AgentFeeModal } from './AgentFeeModal';
import { Modal } from '../common/Modal';
import {
  DollarSign,
  Users,
  CheckCircle2,
  Clock,
  Plus,
  Search,
  Filter,
  Calendar,
  Building,
  Edit2,
  Trash2,
  Printer,
  CheckSquare,
  Square,
  Sparkles,
  Check,
  X,
  XCircle,
  AlertCircle,
  FileText,
} from 'lucide-react';

interface AgentFeeViewProps {
  onNavigateToDocumentEditor?: (initialDoc?: FinancialDocument) => void;
}

export const AgentFeeView: React.FC<AgentFeeViewProps> = ({ onNavigateToDocumentEditor }) => {
  const { userProfile, currentUser, isAdmin } = useAuth();
  const { showSuccess, showError } = useToast();

  const [fees, setFees] = useState<AgentFee[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | AgentFeeStatus>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [dateFilterPreset, setDateFilterPreset] = useState<'all' | 'today' | 'thisMonth' | 'custom'>('thisMonth');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Selected row IDs for batch action
  const [selectedFeeIds, setSelectedFeeIds] = useState<string[]>([]);
  const [isBatchUpdating, setIsBatchUpdating] = useState<boolean>(false);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [feeToEdit, setFeeToEdit] = useState<AgentFee | null>(null);

  const [feeToDelete, setFeeToDelete] = useState<AgentFee | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const [feeToReject, setFeeToReject] = useState<AgentFee | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');
  const [isRejecting, setIsRejecting] = useState<boolean>(false);

  const todayStr = getTodayDateString();
  const currentMonthStr = todayStr.substring(0, 7);

  // Realtime subscription
  useEffect(() => {
    setIsLoading(true);
    const unsub = subscribeAgentFees(
      (data) => {
        setFees(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error loading agent fees:', error);
        showError('Gagal memuat data komisi / agent fee.');
        setIsLoading(false);
      },
    );
    return () => unsub();
  }, [showError]);

  // Filtered list
  const filteredFees = useMemo(() => {
    return fees.filter((fee) => {
      // Status
      if (filterStatus !== 'ALL' && fee.status !== filterStatus) return false;

      // Category
      if (filterCategory !== 'ALL' && fee.category !== filterCategory) return false;

      // Date
      const fDate = fee.date || (fee.createdAt ? fee.createdAt.split('T')[0] : '');
      if (dateFilterPreset === 'today' && fDate !== todayStr) return false;
      if (dateFilterPreset === 'thisMonth' && !fDate.startsWith(currentMonthStr)) return false;
      if (dateFilterPreset === 'custom') {
        if (startDate && fDate < startDate) return false;
        if (endDate && fDate > endDate) return false;
      }

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = fee.name.toLowerCase().includes(q);
        const matchGuest = fee.guestName?.toLowerCase().includes(q);
        const matchBank = fee.bankName?.toLowerCase().includes(q);
        const matchAccNo = fee.accountNumber?.toLowerCase().includes(q);
        const matchAccName = fee.accountName?.toLowerCase().includes(q);
        const matchBkId = fee.bookingId?.toLowerCase().includes(q);
        const matchNotes = fee.notes?.toLowerCase().includes(q);
        if (!matchName && !matchGuest && !matchBank && !matchAccNo && !matchAccName && !matchBkId && !matchNotes) {
          return false;
        }
      }

      return true;
    });
  }, [fees, filterStatus, filterCategory, dateFilterPreset, startDate, endDate, searchQuery, todayStr, currentMonthStr]);

  // KPI calculations per status
  const summary = useMemo(() => {
    let pendingAmount = 0;
    let pendingCount = 0;
    let approvedAmount = 0;
    let approvedCount = 0;
    let paidAmount = 0;
    let paidCount = 0;
    let rejectedAmount = 0;
    let rejectedCount = 0;

    fees.forEach((fee) => {
      const amt = Number(fee.amount) || 0;
      if (fee.status === 'Menunggu Persetujuan') {
        pendingAmount += amt;
        pendingCount++;
      } else if (fee.status === 'Disetujui' || fee.status === 'Belum Dibayar') {
        approvedAmount += amt;
        approvedCount++;
      } else if (fee.status === 'Sudah Dibayar') {
        paidAmount += amt;
        paidCount++;
      } else if (fee.status === 'Ditolak') {
        rejectedAmount += amt;
        rejectedCount++;
      }
    });

    const totalAmount = pendingAmount + approvedAmount + paidAmount + rejectedAmount;
    const totalCount = pendingCount + approvedCount + paidCount + rejectedCount;

    return {
      pendingAmount,
      pendingCount,
      approvedAmount,
      approvedCount,
      paidAmount,
      paidCount,
      rejectedAmount,
      rejectedCount,
      totalAmount,
      totalCount,
    };
  }, [fees]);

  // Selectable items for batch payment (Disetujui / Belum Dibayar)
  const selectableApprovedFees = useMemo(() => {
    return filteredFees.filter((f) => f.status === 'Disetujui' || f.status === 'Belum Dibayar');
  }, [filteredFees]);

  const isAllApprovedSelected =
    selectableApprovedFees.length > 0 &&
    selectableApprovedFees.every((f) => selectedFeeIds.includes(f.id));

  const handleToggleSelectAll = () => {
    if (isAllApprovedSelected) {
      setSelectedFeeIds([]);
    } else {
      setSelectedFeeIds(selectableApprovedFees.map((f) => f.id));
    }
  };

  const handleToggleRow = (id: string) => {
    setSelectedFeeIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleApproveFee = async (feeId: string) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    try {
      await approveAgentFee(feeId, userEmail);
      showSuccess('Pengajuan komisi berhasil disetujui');
    } catch (err) {
      console.error('Error approving fee:', err);
      showError('Gagal menyetujui pengajuan komisi');
    }
  };

  const handleConfirmRejectFee = async () => {
    if (!feeToReject) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    try {
      setIsRejecting(true);
      await rejectAgentFee(feeToReject.id, rejectReason.trim(), userEmail);
      showSuccess('Pengajuan komisi telah ditolak');
      setFeeToReject(null);
      setRejectReason('');
    } catch (err) {
      console.error('Error rejecting fee:', err);
      showError('Gagal menolak pengajuan komisi');
    } finally {
      setIsRejecting(false);
    }
  };

  const handleBatchMarkPaid = async () => {
    if (selectedFeeIds.length === 0) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    try {
      setIsBatchUpdating(true);
      await batchMarkAgentFeesAsPaid(selectedFeeIds, userEmail);
      showSuccess(`${selectedFeeIds.length} komisi agen berhasil ditandai Sudah Dibayar.`);
      setSelectedFeeIds([]);
    } catch (err) {
      console.error('Error batch updating agent fees:', err);
      showError('Gagal memperbarui status komisi agen.');
    } finally {
      setIsBatchUpdating(false);
    }
  };

  const handleSaveFee = async (payload: Partial<AgentFee>) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    showSuccess(payload.id ? 'Data komisi diperbarui' : 'Pengajuan komisi agen berhasil diajukan');
    saveAgentFee(payload, userEmail).catch((err) => {
      console.error('Error saving agent fee:', err);
      showError('Gagal sinkron komisi ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  const handleConfirmDelete = () => {
    if (!feeToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const target = feeToDelete;
    const reason = deleteReason.trim();

    // (1) Tutup modal konfirmasi & notifikasi segera (OPTIMISTIC <1 detik)
    setFeeToDelete(null);
    setDeleteReason('');
    showSuccess(`Komisi untuk ${target.name} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteAgentFee(target, userEmail, reason).catch((err) => {
      console.error('Error deleting agent fee:', err);
      showError('Gagal sinkron hapus komisi ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  // Buat dokumen resmi "Pengajuan Dana / Komisi Agen" (ber-kop) dari satu baris komisi
  const handleCreateCommissionDoc = (fee: AgentFee) => {
    const today = new Date().toISOString().split('T')[0];
    const amount = Number(fee.amount) || 0;
    const newDoc: FinancialDocument = {
      id: `doc_fee_${fee.id}_${Date.now()}`,
      documentType: 'pengajuan_dana',
      documentTitle: 'PENGAJUAN DANA / KOMISI AGEN',
      documentNumber: '',
      documentDate: fee.date || today,
      date: fee.date || today,
      guestName: fee.name,
      guestOrganization: fee.category ? `Kategori: ${fee.category}` : '',
      stayDate: fee.bookingId
        ? `Ref Booking: ${fee.bookingId}`
        : fee.orderId
        ? `Ref Order: ${fee.orderId}`
        : '',
      items: [
        {
          id: 'komisi-1',
          description: `Komisi Agen${fee.guestName ? ` — Tamu: ${fee.guestName}` : ''}${fee.bookingId ? ` (Ref: ${fee.bookingId})` : ''}`,
          quantity: 1,
          unit: 'Pengajuan',
          unitPrice: amount,
          total: amount,
        },
      ],
      subtotal: amount,
      discountAmount: 0,
      taxRate: 0,
      taxAmount: 0,
      useTax: false,
      totalAmount: amount,
      grandTotal: amount,
      terbilang: angkaKeTerbilang(amount),
      paymentStatus: fee.status === 'Sudah Dibayar' ? 'LUNAS' : 'BELUM LUNAS',
      paymentMethod: 'BANK TRANSFER',
      bankAccount: {
        bankName: fee.bankName || '',
        accountNumber: fee.accountNumber || '',
        accountName: fee.accountName || fee.name,
        accountHolder: fee.accountName || fee.name,
      },
      notes: `Pengajuan pencairan dana komisi untuk agen ${fee.name}.${fee.notes ? ` Catatan: ${fee.notes}` : ''}`.trim(),
      partnerId: fee.partnerId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (onNavigateToDocumentEditor) {
      onNavigateToDocumentEditor(newDoc);
      showSuccess('Dokumen Pengajuan Dana / Komisi Agen disiapkan. Silakan review & simpan.');
    } else {
      showError('Navigasi ke editor dokumen tidak tersedia.');
    }
  };

  // Poin 6: Buat SATU dokumen "Pengajuan Dana / Komisi Agen" dari BEBERAPA baris komisi terpilih (tabel + total).
  const handleCreateBatchCommissionDoc = () => {
    const selectedFees = fees.filter((f) => selectedFeeIds.includes(f.id));
    if (selectedFees.length === 0) return;
    if (selectedFees.length === 1) {
      // Hanya 1 baris → gunakan dokumen tunggal biasa
      handleCreateCommissionDoc(selectedFees[0]);
      setSelectedFeeIds([]);
      return;
    }
    const today = new Date().toISOString().split('T')[0];
    const items = selectedFees.map((fee, idx) => {
      const amount = Number(fee.amount) || 0;
      const bankInfo = [fee.bankName, fee.accountNumber].filter(Boolean).join(' ');
      const bankStr = bankInfo ? ` | ${bankInfo}${fee.accountName ? ` a.n ${fee.accountName}` : ''}` : '';
      const tamuStr = fee.guestName ? ` | Tamu: ${fee.guestName}` : '';
      const refStr = fee.bookingId ? ` (Ref: ${fee.bookingId})` : fee.orderId ? ` (Order: ${fee.orderId})` : '';
      return {
        id: `komisi-${idx + 1}`,
        description: `Komisi Agen: ${fee.name}${bankStr}${tamuStr}${refStr}`,
        quantity: 1,
        unit: 'Pengajuan',
        unitPrice: amount,
        total: amount,
      };
    });
    const totalAmount = items.reduce((s, it) => s + (it.total || 0), 0);
    const uniqueAccounts = Array.from(
      new Set(selectedFees.map((f) => `${f.bankName || ''}|${f.accountNumber || ''}|${f.accountName || ''}`))
    );
    const sameAccount = uniqueAccounts.length === 1 && Boolean(selectedFees[0].accountNumber);
    const allPaid = selectedFees.every((f) => f.status === 'Sudah Dibayar');
    const newDoc: FinancialDocument = {
      id: `doc_fee_batch_${Date.now()}`,
      documentType: 'pengajuan_dana',
      documentTitle: 'PENGAJUAN DANA / KOMISI AGEN',
      documentNumber: '',
      documentDate: today,
      date: today,
      guestName: sameAccount ? selectedFees[0].name : `Komisi ${selectedFees.length} Agen`,
      guestOrganization: `Rekap ${selectedFees.length} pengajuan komisi agen`,
      stayDate: '',
      items,
      subtotal: totalAmount,
      discountAmount: 0,
      taxRate: 0,
      taxAmount: 0,
      useTax: false,
      totalAmount: totalAmount,
      grandTotal: totalAmount,
      terbilang: angkaKeTerbilang(totalAmount),
      paymentStatus: allPaid ? 'LUNAS' : 'BELUM LUNAS',
      paymentMethod: 'BANK TRANSFER',
      bankAccount: {
        bankName: sameAccount ? selectedFees[0].bankName || '' : '(Beragam — lihat rincian per baris)',
        accountNumber: sameAccount ? selectedFees[0].accountNumber || '' : '',
        accountName: sameAccount ? selectedFees[0].accountName || selectedFees[0].name : '',
        accountHolder: sameAccount ? selectedFees[0].accountName || selectedFees[0].name : '',
      },
      notes: `Pengajuan pencairan dana untuk ${selectedFees.length} komisi agen (rekap gabungan).`,
      partnerId: sameAccount ? selectedFees[0].partnerId : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (onNavigateToDocumentEditor) {
      onNavigateToDocumentEditor(newDoc);
      setSelectedFeeIds([]);
      showSuccess(`Dokumen gabungan ${selectedFees.length} komisi disiapkan. Silakan review & simpan.`);
    } else {
      showError('Navigasi ke editor dokumen tidak tersedia.');
    }
  };

  return (
    <div id="agent-fee-module" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Users className="w-6 h-6 text-blue-600" />
            <span>Komisi & Fee Agen (Tour Leader / Mitra)</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan komisi pemesanan hotel dan sewa ATV untuk agen travel, tour leader, dan mitra Bukit Langit.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak Rekap</span>
          </button>

          <button
            id="btn-add-agent-fee"
            type="button"
            onClick={() => {
              setFeeToEdit(null);
              setIsModalOpen(true);
            }}
            className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Catatan Fee</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Menunggu Persetujuan */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-700 uppercase">Menunggu Persetujuan</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-amber-700 mt-2">
            {formatRupiah(summary.pendingAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{summary.pendingCount} Pengajuan perlu ditinjau</div>
        </div>

        {/* Disetujui */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-blue-700 uppercase">Disetujui (Siap Dibayar)</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-blue-700 mt-2">
            {formatRupiah(summary.approvedAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{summary.approvedCount} Klaim disetujui accounting</div>
        </div>

        {/* Sudah Dibayar */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-700 uppercase">Sudah Ditransfer (Lunas)</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <Check className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-emerald-700 mt-2">
            {formatRupiah(summary.paidAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{summary.paidCount} Transaksi komisi lunas</div>
        </div>

        {/* Ditolak */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-rose-700 uppercase">Ditolak</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <XCircle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-rose-700 mt-2">
            {formatRupiah(summary.rejectedAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">{summary.rejectedCount} Pengajuan ditolak</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama agen, tamu, no rekening, bank, booking ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Filter Status */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as 'ALL' | AgentFeeStatus)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Status Pengajuan</option>
              <option value="Menunggu Persetujuan">🟡 Menunggu Persetujuan</option>
              <option value="Disetujui">🔵 Disetujui (Siap Dibayar)</option>
              <option value="Sudah Dibayar">🟢 Sudah Dibayar (Lunas)</option>
              <option value="Ditolak">🔴 Ditolak</option>
            </select>
          </div>

          {/* Filter Kategori */}
          <div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Kategori</option>
              <option value="Hotel">Hotel</option>
              <option value="ATV">ATV</option>
              <option value="Paket Wisata">Paket Wisata</option>
              <option value="Outbound / Gathering">Outbound / Gathering</option>
              <option value="Lainnya">Lainnya</option>
            </select>
          </div>
        </div>

        {/* Date Filter Presets & Batch Action Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Periode:</span>
            </span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setDateFilterPreset('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'all'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('today')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'today'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Hari Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('thisMonth')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'thisMonth'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Bulan Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('custom')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'custom'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Rentang
              </button>
            </div>

            {dateFilterPreset === 'custom' && (
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
                <span className="text-xs text-slate-400">s/d</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
            )}
          </div>

          {/* Batch Action Toolbar when items selected */}
          {selectedFeeIds.length > 0 && (
            <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-xl animate-fade-in">
              <span className="text-xs font-bold text-blue-900">
                {selectedFeeIds.length} komisi dipilih
              </span>
              <button
                type="button"
                disabled={isBatchUpdating}
                onClick={handleBatchMarkPaid}
                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-xs flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{isBatchUpdating ? 'Memproses...' : 'Tandai Sudah Dibayar'}</span>
              </button>
              <button
                type="button"
                disabled={isBatchUpdating}
                onClick={handleCreateBatchCommissionDoc}
                title="Gabungkan komisi terpilih menjadi satu dokumen Pengajuan Dana"
                className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg shadow-xs flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Buat Dokumen Gabungan</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedFeeIds([])}
                className="text-xs text-slate-500 hover:text-slate-700 underline cursor-pointer"
              >
                Batal
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center">
            <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Memuat data fee agen...</p>
          </div>
        ) : filteredFees.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3 text-center w-10">
                    <button
                      type="button"
                      onClick={handleToggleSelectAll}
                      disabled={selectableApprovedFees.length === 0}
                      title="Pilih semua yang disetujui"
                      className="cursor-pointer text-slate-400 hover:text-slate-700 disabled:opacity-30"
                    >
                      {isAllApprovedSelected ? (
                        <CheckSquare className="w-4 h-4 text-blue-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-4">Tanggal & Ref</th>
                  <th className="py-3 px-4">Nama Agen / Mitra & Pengaju</th>
                  <th className="py-3 px-4">Tamu & Kategori</th>
                  <th className="py-3 px-4">Rekening Tujuan</th>
                  <th className="py-3 px-4 text-right">Nominal Komisi</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Aksi & Persetujuan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredFees.map((fee) => {
                  const isPaid = fee.status === 'Sudah Dibayar';
                  const isApproved = fee.status === 'Disetujui' || fee.status === 'Belum Dibayar';
                  const isPending = fee.status === 'Menunggu Persetujuan';
                  const isRejected = fee.status === 'Ditolak';
                  const isSelected = selectedFeeIds.includes(fee.id);

                  return (
                    <tr
                      key={fee.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isSelected ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <td className="py-3 px-3 text-center">
                        {isApproved ? (
                          <button
                            type="button"
                            onClick={() => handleToggleRow(fee.id)}
                            className="cursor-pointer text-slate-400 hover:text-blue-600"
                          >
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-blue-600" />
                            ) : (
                              <Square className="w-4 h-4" />
                            )}
                          </button>
                        ) : isPaid ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto opacity-40" />
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-slate-900">{formatDateIndo(fee.date)}</div>
                        {fee.bookingId && (
                          <div className="text-[10px] font-mono text-slate-400">Ref: {fee.bookingId}</div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{fee.name}</div>
                        {fee.submittedBy && (
                          <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                            <span>Diajukan oleh:</span>
                            <span className="font-medium text-slate-600">{fee.submittedBy.split('@')[0]}</span>
                          </div>
                        )}
                        {fee.notes && (
                          <div className="text-[11px] text-slate-500 max-w-xs truncate mt-0.5" title={fee.notes}>
                            {fee.notes}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">{fee.guestName || '-'}</div>
                        <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md font-semibold">
                          {fee.category}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-medium text-slate-800">
                          <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{fee.bankName}</span>
                          <span className="font-mono font-bold text-slate-900">{fee.accountNumber}</span>
                        </div>
                        {fee.accountName && (
                          <div className="text-[11px] text-slate-500">a.n. {fee.accountName}</div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <span className="text-sm font-extrabold text-slate-900">
                          {formatRupiah(fee.amount)}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] border ${
                            isPaid
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                              : isApproved
                              ? 'bg-blue-50 text-blue-700 border-blue-300'
                              : isRejected
                              ? 'bg-rose-50 text-rose-700 border-rose-300'
                              : 'bg-amber-50 text-amber-700 border-amber-300'
                          }`}
                        >
                          {isPaid ? (
                            <CheckCircle2 className="w-3 h-3" />
                          ) : isApproved ? (
                            <Check className="w-3 h-3" />
                          ) : isRejected ? (
                            <XCircle className="w-3 h-3" />
                          ) : (
                            <Clock className="w-3 h-3" />
                          )}
                          <span>{fee.status}</span>
                        </span>
                        {isPaid && fee.paidAt && (
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Dibayar: {formatDateIndo(fee.paidAt.split('T')[0])}
                          </div>
                        )}
                        {isRejected && fee.rejectionReason && (
                          <div className="text-[10px] text-rose-600 italic mt-0.5 max-w-[120px] truncate mx-auto" title={fee.rejectionReason}>
                            Alasan: {fee.rejectionReason}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Approval Actions for Admin/Accounting */}
                          {isPending && isAdmin && (
                            <div className="flex items-center gap-1 mr-1 border-r border-slate-200 pr-1.5">
                              <button
                                type="button"
                                title="Setujui Pengajuan"
                                onClick={() => handleApproveFee(fee.id)}
                                className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] flex items-center gap-1 shadow-xs cursor-pointer"
                              >
                                <Check className="w-3 h-3" />
                                <span>Setujui</span>
                              </button>
                              <button
                                type="button"
                                title="Tolak Pengajuan"
                                onClick={() => {
                                  setFeeToReject(fee);
                                  setRejectReason('');
                                }}
                                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                              >
                                <X className="w-3 h-3" />
                                <span>Tolak</span>
                              </button>
                            </div>
                          )}

                          {/* Quick Pay Action for Approved Fees */}
                          {isApproved && isAdmin && (
                            <button
                              type="button"
                              title="Tandai Sudah Dibayar"
                              onClick={() => batchMarkAgentFeesAsPaid([fee.id], userProfile?.email || currentUser?.email || 'admin@bolang.id')}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg font-bold text-[11px] flex items-center gap-1 cursor-pointer mr-1"
                            >
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Bayar</span>
                            </button>
                          )}

                          <button
                            type="button"
                            title="Buat Dokumen Pengajuan Dana / Komisi Agen"
                            onClick={() => handleCreateCommissionDoc(fee)}
                            className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 border border-indigo-200 rounded-lg font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors mr-1"
                          >
                            <FileText className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Buat Dokumen</span>
                          </button>
                          <button
                            type="button"
                            title="Edit Komisi"
                            onClick={() => {
                              setFeeToEdit(fee);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Hapus Catatan"
                            onClick={() => {
                              setFeeToDelete(fee);
                              setDeleteReason('');
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center">
            <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">Belum Ada Catatan Fee Agen</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Tidak ada catatan komisi agen yang sesuai dengan kriteria pencarian atau filter yang dipilih.
            </p>
          </div>
        )}
      </div>

      {/* Modal Add/Edit */}
      {isModalOpen && (
        <AgentFeeModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          feeToEdit={feeToEdit}
          onSave={handleSaveFee}
        />
      )}

      {/* Modal Delete */}
      <Modal
        isOpen={!!feeToDelete}
        onClose={() => setFeeToDelete(null)}
        title="Konfirmasi Hapus Catatan Fee Agen"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus catatan fee untuk <strong>{feeToDelete?.name}</strong> senilai{' '}
            <strong>{formatRupiah(feeToDelete?.amount || 0)}</strong>? Tindakan ini akan dicatat dalam riwayat penghapusan audit.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Booking dibatalkan / salah input..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setFeeToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Catatan'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
