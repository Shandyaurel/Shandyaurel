import React, { useState, useEffect, useMemo } from 'react';
import { AgentFee, AgentFeeStatus, Booking, ATVBooking, CombinedOrder, BusinessSettings, ClientContact } from '../../types';
import { Modal } from '../common/Modal';
import { formatRupiah, getTodayDateString } from '../../utils/formatters';
import {
  Users,
  CreditCard,
  Building,
  DollarSign,
  FileText,
  Calendar,
  User,
  Tag,
  Percent,
  Calculator,
  Link2,
  Sparkles,
  Handshake,
} from 'lucide-react';
import {
  subscribePartners,
  subscribeBookings,
  subscribeATVBookings,
  subscribeCombinedOrders,
  getBusinessSettings,
} from '../../utils/firebase';

interface AgentFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeToEdit?: AgentFee | null;
  onSave: (payload: Partial<AgentFee>) => Promise<void>;
}

const COMMON_BANKS = ['BCA', 'Mandiri', 'BRI', 'BNI', 'BSI', 'CIMB Niaga', 'Permata', 'BTPN / Jenius', 'Lainnya'];
const COMMON_CATEGORIES = ['Hotel', 'ATV', 'Paket Wisata', 'Outbound / Gathering', 'Lainnya'];

export const AgentFeeModal: React.FC<AgentFeeModalProps> = ({
  isOpen,
  onClose,
  feeToEdit,
  onSave,
}) => {
  const [date, setDate] = useState<string>(getTodayDateString());
  const [name, setName] = useState<string>('');
  const [partnerId, setPartnerId] = useState<string>('');
  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [hotelBookings, setHotelBookings] = useState<Booking[]>([]);
  const [atvBookings, setAtvBookings] = useState<ATVBooking[]>([]);
  const [combinedOrders, setCombinedOrders] = useState<CombinedOrder[]>([]);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);

  const [guestName, setGuestName] = useState<string>('');
  const [bookingId, setBookingId] = useState<string>('');
  const [category, setCategory] = useState<string>('Hotel');
  const [bankName, setBankName] = useState<string>('BCA');
  const [customBank, setCustomBank] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [accountName, setAccountName] = useState<string>('');

  // Calculation Mode: 'manual' | 'percentage'
  const [calcMode, setCalcMode] = useState<'manual' | 'percentage'>('manual');
  const [commissionPercent, setCommissionPercent] = useState<number>(10);
  const [invoiceTotal, setInvoiceTotal] = useState<number>(0);
  const [amount, setAmount] = useState<number>(0);

  const [status, setStatus] = useState<AgentFeeStatus>('Menunggu Persetujuan');
  const [notes, setNotes] = useState<string>('');

  // Transaction Search State
  const [transactionSearchQuery, setTransactionSearchQuery] = useState<string>('');
  const [isTransactionSearchOpen, setIsTransactionSearchOpen] = useState<boolean>(false);
  const [selectedTransactionSummary, setSelectedTransactionSummary] = useState<string>('');

  // Partner Search State
  const [partnerSearchQuery, setPartnerSearchQuery] = useState<string>('');
  const [isPartnerSearchOpen, setIsPartnerSearchOpen] = useState<boolean>(false);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    if (!isOpen) return;
    const unsubPartners = subscribePartners((list) => setPartners(list));
    const unsubHotel = subscribeBookings((list) => setHotelBookings(list));
    const unsubATV = subscribeATVBookings((list) => setAtvBookings(list));
    const unsubOrders = subscribeCombinedOrders((list) => setCombinedOrders(list));
    getBusinessSettings().then((s) => {
      if (s) setBusinessSettings(s);
    });

    return () => {
      unsubPartners();
      unsubHotel();
      unsubATV();
      unsubOrders();
    };
  }, [isOpen]);

  useEffect(() => {
    if (feeToEdit) {
      setDate(feeToEdit.date || getTodayDateString());
      setName(feeToEdit.name || '');
      setPartnerId(feeToEdit.partnerId || '');
      setGuestName(feeToEdit.guestName || '');
      setBookingId(feeToEdit.bookingId || '');
      setCategory(feeToEdit.category || 'Hotel');
      if (COMMON_BANKS.includes(feeToEdit.bankName)) {
        setBankName(feeToEdit.bankName);
        setCustomBank('');
      } else {
        setBankName('Lainnya');
        setCustomBank(feeToEdit.bankName || '');
      }
      setAccountNumber(feeToEdit.accountNumber || '');
      setAccountName(feeToEdit.accountName || '');
      setAmount(feeToEdit.amount || 0);
      setCalcMode('manual');
      setStatus(feeToEdit.status || 'Menunggu Persetujuan');
      setNotes(feeToEdit.notes || '');
      setSelectedTransactionSummary(feeToEdit.bookingId ? `ID: ${feeToEdit.bookingId}` : '');
    } else {
      setDate(getTodayDateString());
      setName('');
      setPartnerId('');
      setGuestName('');
      setBookingId('');
      setCategory('Hotel');
      setBankName('BCA');
      setCustomBank('');
      setAccountNumber('');
      setAccountName('');
      setCalcMode('manual');
      setCommissionPercent(10);
      setInvoiceTotal(0);
      setAmount(0);
      setStatus('Menunggu Persetujuan');
      setNotes('');
      setSelectedTransactionSummary('');
    }
    setTransactionSearchQuery('');
    setIsTransactionSearchOpen(false);
    setPartnerSearchQuery('');
    setIsPartnerSearchOpen(false);
    setErrorMsg('');
  }, [feeToEdit, isOpen]);

  // Recalculate amount if percentage or invoiceTotal changes in percentage mode
  useEffect(() => {
    if (calcMode === 'percentage') {
      const calculated = Math.round((Number(invoiceTotal || 0) * Number(commissionPercent || 0)) / 100);
      setAmount(calculated);
    }
  }, [calcMode, commissionPercent, invoiceTotal]);

  // Search filtered transactions across Order Gabungan, Hotel, and ATV
  const filteredTransactions = useMemo(() => {
    const q = transactionSearchQuery.toLowerCase().trim();
    const results: Array<{
      key: string;
      type: 'order' | 'hotel' | 'atv';
      title: string;
      subtitle: string;
      date: string;
      amount: number;
      badge: string;
      badgeColor: string;
    }> = [];

    // 1. Order Gabungan
    combinedOrders.forEach((o) => {
      const matchName = o.guestName.toLowerCase().includes(q);
      const matchNum = o.orderNumber.toLowerCase().includes(q);
      const matchDate = (o.date || '').includes(q);
      const matchVia = (o.bookingVia || '').toLowerCase().includes(q);
      if (!q || matchName || matchNum || matchDate || matchVia) {
        results.push({
          key: `order:${o.id}`,
          type: 'order',
          title: `Order #${o.orderNumber} - ${o.guestName}`,
          subtitle: `Sumber: ${o.bookingVia || 'Direct'} • Tgl: ${o.date || '-'}`,
          date: o.date || '',
          amount: o.grandTotal,
          badge: 'Order Gabungan',
          badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
        });
      }
    });

    // 2. Hotel Bookings
    hotelBookings.forEach((b) => {
      const matchName = b.guestName.toLowerCase().includes(q);
      const matchId = b.id.toLowerCase().includes(q);
      const matchDate = (b.date || b.checkInDate || '').includes(q);
      const matchVia = (b.bookingVia || '').toLowerCase().includes(q);
      if (!q || matchName || matchId || matchDate || matchVia) {
        results.push({
          key: `hotel:${b.id}`,
          type: 'hotel',
          title: `Hotel: ${b.guestName}`,
          subtitle: `Sumber: ${b.bookingVia || 'Direct'} • Tgl: ${b.checkInDate || b.date || '-'}`,
          date: b.checkInDate || b.date || '',
          amount: b.grandTotal,
          badge: 'Hotel',
          badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        });
      }
    });

    // 3. ATV Bookings
    atvBookings.forEach((a) => {
      const matchName = a.guestName.toLowerCase().includes(q);
      const matchId = a.id.toLowerCase().includes(q);
      const matchDate = (a.bookingDate || a.date || '').includes(q);
      const matchVia = (a.bookingVia || '').toLowerCase().includes(q);
      if (!q || matchName || matchId || matchDate || matchVia) {
        results.push({
          key: `atv:${a.id}`,
          type: 'atv',
          title: `ATV: ${a.guestName}`,
          subtitle: `Sumber: ${a.bookingVia || 'Direct'} • Tgl: ${a.bookingDate || a.date || '-'}`,
          date: a.bookingDate || a.date || '',
          amount: a.grandTotal || a.totalAmount || 0,
          badge: 'ATV',
          badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
        });
      }
    });

    return results.slice(0, 20);
  }, [transactionSearchQuery, combinedOrders, hotelBookings, atvBookings]);

  // Search filtered partners
  const filteredPartners = useMemo(() => {
    const q = partnerSearchQuery.toLowerCase().trim();
    if (!q) return partners.slice(0, 15);
    return partners
      .filter((p) => {
        const matchName = p.name.toLowerCase().includes(q);
        const matchDetail = (p.detail || '').toLowerCase().includes(q);
        const matchHome = (p.homeBase || '').toLowerCase().includes(q);
        const matchPhone = (p.phone || '').toLowerCase().includes(q);
        return matchName || matchDetail || matchHome || matchPhone;
      })
      .slice(0, 15);
  }, [partnerSearchQuery, partners]);

  // Handler when selecting a booking to auto-fill
  const handleSelectBookingRef = (selectedRefKey: string) => {
    if (!selectedRefKey) return;
    const [type, id] = selectedRefKey.split(':');

    if (type === 'hotel') {
      const b = hotelBookings.find((item) => item.id === id);
      if (b) {
        setBookingId(b.id);
        setGuestName(b.guestName);
        setCategory('Hotel');
        setInvoiceTotal(b.grandTotal);
        setSelectedTransactionSummary(`Hotel: ${b.guestName} (${formatRupiah(b.grandTotal)})`);
        if (b.partnerId) {
          setPartnerId(b.partnerId);
          const p = partners.find((pt) => pt.id === b.partnerId);
          if (p) setName(p.name);
        } else if (b.bookingVia && !['Walk in', 'Direct WA', 'Direct'].includes(b.bookingVia)) {
          setName(b.bookingVia);
        }
      }
    } else if (type === 'atv') {
      const a = atvBookings.find((item) => item.id === id);
      if (a) {
        setBookingId(a.id);
        setGuestName(a.guestName);
        setCategory('ATV');
        const tot = a.grandTotal || a.totalAmount || 0;
        setInvoiceTotal(tot);
        setSelectedTransactionSummary(`ATV: ${a.guestName} (${formatRupiah(tot)})`);
        if (a.partnerId) {
          setPartnerId(a.partnerId);
          const p = partners.find((pt) => pt.id === a.partnerId);
          if (p) setName(p.name);
        } else if (a.bookingVia && !['Walk in', 'Direct WA', 'Direct'].includes(a.bookingVia)) {
          setName(a.bookingVia);
        }
      }
    } else if (type === 'order') {
      const o = combinedOrders.find((item) => item.id === id);
      if (o) {
        setBookingId(o.orderNumber || o.id);
        setGuestName(o.guestName);
        setCategory('Paket Wisata');
        setInvoiceTotal(o.grandTotal);
        setSelectedTransactionSummary(`Order #${o.orderNumber} - ${o.guestName} (${formatRupiah(o.grandTotal)})`);
        if (o.partnerId) {
          setPartnerId(o.partnerId);
          const p = partners.find((pt) => pt.id === o.partnerId);
          if (p) setName(p.name);
        } else if (o.bookingVia && !['Walk in', 'Direct WA', 'Direct'].includes(o.bookingVia)) {
          setName(o.bookingVia);
        }
      }
    }

    setIsTransactionSearchOpen(false);
    setTransactionSearchQuery('');
  };

  const handleSelectPartner = (p: ClientContact) => {
    setPartnerId(p.id);
    setName(p.name);
    setIsPartnerSearchOpen(false);
    setPartnerSearchQuery('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Nama agen / mitra wajib diisi.');
      return;
    }
    if (amount <= 0) {
      setErrorMsg('Nominal fee/komisi harus lebih besar dari Rp 0.');
      return;
    }

    const finalBank = bankName === 'Lainnya' ? customBank.trim() || 'Transfer' : bankName;

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onSave({
        id: feeToEdit?.id,
        date: date || getTodayDateString(),
        name: name.trim(),
        partnerId: partnerId || undefined,
        guestName: guestName.trim() || '',
        bookingId: bookingId.trim() || '',
        category,
        bankName: finalBank,
        accountNumber: accountNumber.trim(),
        accountName: accountName.trim(),
        amount: Number(amount) || 0,
        status,
        notes: notes.trim() || '',
      });
      onClose();
    } catch (err) {
      console.error('Error saving agent fee:', err);
      setErrorMsg('Gagal menyimpan data komisi agen.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={feeToEdit ? 'Edit Catatan Komisi / Agent Fee' : 'Tambah Catatan Komisi / Agent Fee'}
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-medium">
            {errorMsg}
          </div>
        )}

        {/* 1. Auto-fill from Searchable Booking/Order */}
        <div className="p-3 bg-blue-50/60 border border-blue-200/70 rounded-xl space-y-2 relative">
          <div className="flex items-center justify-between">
            <span className="font-bold text-blue-900 flex items-center gap-1.5 text-[11px] uppercase tracking-wider">
              <Link2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Cari Transaksi untuk Auto-fill (Order / Hotel / ATV)</span>
            </span>
            <span className="text-[10px] text-blue-600 font-medium">Cari cepat</span>
          </div>

          {selectedTransactionSummary ? (
            <div className="p-2 bg-white border border-blue-300 rounded-lg flex items-center justify-between gap-2 shadow-2xs">
              <div className="flex items-center gap-1.5 min-w-0">
                <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span className="font-semibold text-slate-800 text-xs truncate">
                  Terkait: {selectedTransactionSummary}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedTransactionSummary('');
                  setBookingId('');
                  setGuestName('');
                  setInvoiceTotal(0);
                }}
                className="text-[11px] font-bold text-rose-600 hover:text-rose-800 shrink-0 px-2 py-0.5 rounded hover:bg-rose-50 cursor-pointer"
              >
                Ganti / Lepas
              </button>
            </div>
          ) : (
            <div className="relative">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Ketik nama tamu, no order, tanggal, atau agen..."
                  value={transactionSearchQuery}
                  onFocus={() => setIsTransactionSearchOpen(true)}
                  onChange={(e) => {
                    setTransactionSearchQuery(e.target.value);
                    setIsTransactionSearchOpen(true);
                  }}
                  className="w-full pl-8 pr-8 py-2 bg-white border border-blue-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
                />
                <span className="absolute left-2.5 top-2.5 text-slate-400">🔍</span>
                {transactionSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setTransactionSearchQuery('')}
                    className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 font-bold text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Search results dropdown */}
              {isTransactionSearchOpen && (
                <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg z-30 max-h-56 overflow-y-auto divide-y divide-slate-100">
                  <div className="p-1.5 bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                    <span>Hasil Pencarian Transaksi (Maks 20)</span>
                    <button
                      type="button"
                      onClick={() => setIsTransactionSearchOpen(false)}
                      className="text-slate-400 hover:text-slate-600 text-[11px]"
                    >
                      Tutup
                    </button>
                  </div>
                  {filteredTransactions.length > 0 ? (
                    filteredTransactions.map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => handleSelectBookingRef(item.key)}
                        className="w-full text-left p-2.5 hover:bg-blue-50/70 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[9.5px] font-bold border ${item.badgeColor}`}
                            >
                              {item.badge}
                            </span>
                            <span className="font-bold text-slate-900 text-xs truncate">{item.title}</span>
                          </div>
                          <div className="text-[10.5px] text-slate-500 mt-0.5 truncate">{item.subtitle}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-bold font-mono text-emerald-700 text-xs">
                            {formatRupiah(item.amount)}
                          </div>
                        </div>
                      </button>
                    ))
                  ) : (
                    <div className="p-4 text-center text-slate-400 text-xs">
                      Tidak ditemukan transaksi yang cocok dengan "{transactionSearchQuery}".
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Tanggal & Nama Agen / Mitra (Searchable) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal Transaksi *</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                <span>Nama Agen / Tour Leader / Mitra *</span>
              </span>
              {partnerId && (
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                  Mitra Tertaut
                </span>
              )}
            </label>

            {partners.length > 0 ? (
              <div className="space-y-1.5 relative">
                {/* Search Mitra Dropdown Input */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder="🔍 Cari & pilih dari Mitra Bisnis..."
                    value={partnerSearchQuery}
                    onFocus={() => setIsPartnerSearchOpen(true)}
                    onChange={(e) => {
                      setPartnerSearchQuery(e.target.value);
                      setIsPartnerSearchOpen(true);
                    }}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                  {partnerSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setPartnerSearchQuery('')}
                      className="absolute right-2.5 top-1.5 text-slate-400 hover:text-slate-600 font-bold text-xs"
                    >
                      ✕
                    </button>
                  )}

                  {isPartnerSearchOpen && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg z-30 max-h-48 overflow-y-auto divide-y divide-slate-100">
                      <div className="p-1.5 bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span>Pilih Mitra Bisnis ({filteredPartners.length})</span>
                        <button
                          type="button"
                          onClick={() => setIsPartnerSearchOpen(false)}
                          className="text-slate-400 hover:text-slate-600 text-[11px]"
                        >
                          Tutup
                        </button>
                      </div>
                      {filteredPartners.length > 0 ? (
                        filteredPartners.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => handleSelectPartner(p)}
                            className="w-full text-left p-2 hover:bg-blue-50/70 transition-colors flex items-center justify-between gap-1 text-xs cursor-pointer"
                          >
                            <div className="min-w-0">
                              <div className="font-bold text-slate-900 truncate">{p.name}</div>
                              <div className="text-[10px] text-slate-500 truncate">
                                {p.detail || p.homeBase || 'Mitra Travel'}
                              </div>
                            </div>
                            <span className="text-[10px] font-semibold text-slate-400 shrink-0">
                              {p.homeBase || 'Lokal'}
                            </span>
                          </button>
                        ))
                      ) : (
                        <div className="p-3 text-center text-slate-400 text-xs">
                          Mitra "{partnerSearchQuery}" tidak ditemukan.
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Direct input for agent name */}
                <input
                  type="text"
                  required
                  placeholder="Nama agen / tour leader yang menerima komisi..."
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (partnerId) setPartnerId('');
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:bg-white"
                />
              </div>
            ) : (
              <input
                type="text"
                required
                placeholder="Contoh: Bpk. Dani (Pesona Travel)..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:bg-white"
              />
            )}
          </div>
        </div>

        {/* Kategori & Cara Hitung Komisi */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              <span>Kategori Komisi</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              {COMMON_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5 text-blue-600" />
                <span>Metode Hitung Komisi</span>
              </span>
              <div className="inline-flex bg-slate-200 p-0.5 rounded-lg text-[10px]">
                <button
                  type="button"
                  onClick={() => setCalcMode('manual')}
                  className={`px-2 py-0.5 rounded-md font-semibold cursor-pointer ${
                    calcMode === 'manual' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Manual (Rp)
                </button>
                <button
                  type="button"
                  onClick={() => setCalcMode('percentage')}
                  className={`px-2 py-0.5 rounded-md font-semibold cursor-pointer ${
                    calcMode === 'percentage' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Otomatis (%)
                </button>
              </div>
            </label>

            {calcMode === 'manual' ? (
              <div>
                <input
                  type="number"
                  min="0"
                  required
                  value={amount || ''}
                  onChange={(e) => setAmount(Math.max(0, parseInt(e.target.value) || 0))}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-700 focus:bg-white"
                />
                {amount > 0 && (
                  <div className="text-[10px] text-emerald-600 font-semibold mt-1">
                    {formatRupiah(amount)}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-semibold text-blue-900 mb-0.5">Persen Komisi</label>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        step="0.5"
                        value={commissionPercent}
                        onChange={(e) => setCommissionPercent(Math.max(0, parseFloat(e.target.value) || 0))}
                        className="w-full px-2.5 py-1 bg-white border border-blue-300 rounded-lg text-xs font-bold text-blue-900 pr-6"
                      />
                      <span className="absolute right-2 top-1 text-xs font-bold text-slate-400">%</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold text-blue-900 mb-0.5">Total Nilai Invoice</label>
                    <input
                      type="number"
                      min="0"
                      step="10000"
                      value={invoiceTotal || ''}
                      onChange={(e) => setInvoiceTotal(Math.max(0, parseInt(e.target.value) || 0))}
                      placeholder="0"
                      className="w-full px-2.5 py-1 bg-white border border-blue-300 rounded-lg text-xs font-bold text-blue-900"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-blue-200 text-blue-950">
                  <span>Hasil Hitung ({commissionPercent}% × {formatRupiah(invoiceTotal)}):</span>
                  <span className="font-extrabold text-emerald-700 text-xs">{formatRupiah(amount)}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Info Tamu & Booking ID Ref (Opsional) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>Nama Tamu yang Dibawa (Opsional)</span>
            </label>
            <input
              type="text"
              placeholder="Contoh: Rombongan PT Maju Bersama"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>ID Booking / Order Terkait</span>
            </label>
            <input
              type="text"
              placeholder="Contoh: BK_1740001 / ORD-20260927-001"
              value={bookingId}
              onChange={(e) => setBookingId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:bg-white"
            />
          </div>
        </div>

        {/* Informasi Rekening Bank */}
        <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3">
          <div className="font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
            <Building className="w-3.5 h-3.5 text-slate-500" />
            <span>Rekening Tujuan Pembayaran Komisi</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div>
              <label className="block font-medium text-slate-600 mb-1 text-[11px]">Bank / E-Wallet</label>
              <select
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              >
                {COMMON_BANKS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
              {bankName === 'Lainnya' && (
                <input
                  type="text"
                  placeholder="Ketik nama bank..."
                  value={customBank}
                  onChange={(e) => setCustomBank(e.target.value)}
                  className="w-full mt-1.5 px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
              )}
            </div>

            <div>
              <label className="block font-medium text-slate-600 mb-1 text-[11px]">Nomor Rekening</label>
              <input
                type="text"
                placeholder="Contoh: 1234567890"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-semibold"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 mb-1 text-[11px]">Atas Nama (a.n.)</label>
              <input
                type="text"
                placeholder="Contoh: Dani Setiawan"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-medium"
              />
            </div>
          </div>
        </div>

        {/* Status Pembayaran */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span>Status Pembayaran Komisi</span>
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as AgentFeeStatus)}
              className={`w-full px-3 py-2 border rounded-xl text-xs font-bold ${
                status === 'Sudah Dibayar'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                  : status === 'Disetujui'
                  ? 'bg-blue-50 text-blue-700 border-blue-300'
                  : status === 'Ditolak'
                  ? 'bg-rose-50 text-rose-700 border-rose-300'
                  : 'bg-amber-50 text-amber-700 border-amber-300'
              }`}
            >
              <option value="Menunggu Persetujuan">Menunggu Persetujuan (Staff Claim)</option>
              <option value="Disetujui">Disetujui (Approved)</option>
              <option value="Sudah Dibayar">Sudah Dibayar (Lunas)</option>
              <option value="Ditolak">Ditolak (Rejected)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Catatan Khusus</span>
            </label>
            <input
              type="text"
              placeholder="Contoh: Ditransfer via BCA m-banking..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'Menyimpan...' : feeToEdit ? 'Simpan Perubahan' : 'Simpan Komisi'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
