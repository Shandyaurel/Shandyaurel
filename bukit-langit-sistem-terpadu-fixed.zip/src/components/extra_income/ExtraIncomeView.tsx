import React, { useState, useEffect, useMemo } from 'react';
import { ExtraIncomeItem, BusinessSettings, ExtraServiceCatalogItem } from '../../types';
import {
  subscribeExtraIncome,
  saveExtraIncome,
  deleteExtraIncome,
  subscribeExtraServiceCatalog,
  saveExtraServiceCatalogItem,
  deleteExtraServiceCatalogItem,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, formatDateIndo, getTodayDateString } from '../../utils/formatters';
import { getStoredSettings } from '../../utils/storage';
import { ExtraIncomeModal } from './ExtraIncomeModal';
import { Modal } from '../common/Modal';
import { TransactionQuickDocWAModal } from '../documents/TransactionQuickDocWAModal';
import {
  Coins,
  DollarSign,
  TrendingUp,
  Plus,
  Search,
  Calendar,
  Layers,
  Printer,
  Edit2,
  Trash2,
  CheckCircle2,
  Clock,
  Sparkles,
  PieChart,
  FileText,
  Package,
  BookOpen,
} from 'lucide-react';

interface ExtraIncomeViewProps {
  businessSettings?: BusinessSettings | null;
}

export const ExtraIncomeView: React.FC<ExtraIncomeViewProps> = ({ businessSettings: propSettings }) => {
  const settings = propSettings || getStoredSettings();
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [items, setItems] = useState<ExtraIncomeItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Tab switch: Transaksi | Katalog
  const [activeTab, setActiveTab] = useState<'transaksi' | 'katalog'>('transaksi');

  // Catalog state (dipakai di tab Katalog)
  const [catalogList, setCatalogList] = useState<ExtraServiceCatalogItem[]>([]);
  const [catalogSearch, setCatalogSearch] = useState<string>('');
  const [catalogFilterCat, setCatalogFilterCat] = useState<string>('ALL');
  const [catalogToDelete, setCatalogToDelete] = useState<ExtraServiceCatalogItem | null>(null);
  const [isDeletingCatalog, setIsDeletingCatalog] = useState<boolean>(false);
  const [editingCatalog, setEditingCatalog] = useState<ExtraServiceCatalogItem | null>(null);
  const [showCatalogForm, setShowCatalogForm] = useState<boolean>(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [dateFilterPreset, setDateFilterPreset] = useState<'thisMonth' | 'today' | 'all' | 'custom'>('thisMonth');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Modals
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [itemToEdit, setItemToEdit] = useState<ExtraIncomeItem | null>(null);
  const [quickDocItem, setQuickDocItem] = useState<ExtraIncomeItem | null>(null);

  const [itemToDelete, setItemToDelete] = useState<ExtraIncomeItem | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const todayStr = getTodayDateString();
  const currentMonthStr = todayStr.substring(0, 7);

  // Realtime subscription
  useEffect(() => {
    setIsLoading(true);
    const unsub = subscribeExtraIncome(
      (data) => {
        setItems(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error loading extra income:', error);
        showError('Gagal memuat data pendapatan ekstra (POS).');
        setIsLoading(false);
      },
    );
    return () => unsub();
  }, [showError]);

  // Subscribe katalog layanan extra
  useEffect(() => {
    const unsub = subscribeExtraServiceCatalog((list) => setCatalogList(list));
    return () => unsub();
  }, []);

  // Katalog derived data
  const catalogCategories = useMemo(
    () =>
      Array.from(new Set(catalogList.map((c) => c.category || 'Lainnya'))).sort((a, b) =>
        a.localeCompare(b),
      ),
    [catalogList],
  );

  const filteredCatalog = useMemo(() => {
    const q = catalogSearch.trim().toLowerCase();
    return catalogList
      .filter((c) => catalogFilterCat === 'ALL' || (c.category || 'Lainnya') === catalogFilterCat)
      .filter(
        (c) =>
          !q ||
          c.name.toLowerCase().includes(q) ||
          (c.category || '').toLowerCase().includes(q) ||
          (c.notes || '').toLowerCase().includes(q),
      )
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  }, [catalogList, catalogSearch, catalogFilterCat]);

  const sumHppOf = (c: ExtraServiceCatalogItem) =>
    (c.defaultCostBreakdown || []).reduce(
      (s, b) => s + (Number(b.amount) || (Number(b.qty) || 0) * (Number(b.unitPrice) || 0)),
      0,
    );

  const confirmDeleteCatalog = async () => {
    if (!catalogToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    setIsDeletingCatalog(true);
    try {
      await deleteExtraServiceCatalogItem(catalogToDelete, userEmail);
      showSuccess(`Item katalog "${catalogToDelete.name}" dihapus.`);
      setCatalogToDelete(null);
    } catch (err) {
      console.error(err);
      showError('Gagal menghapus item katalog.');
    } finally {
      setIsDeletingCatalog(false);
    }
  };

  // Filtered items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Status
      if (filterStatus !== 'ALL' && item.status !== filterStatus) return false;

      // Category
      if (filterCategory !== 'ALL' && item.category !== filterCategory) return false;

      // Date
      const d = item.date || (item.createdAt ? item.createdAt.split('T')[0] : '');
      if (dateFilterPreset === 'today' && d !== todayStr) return false;
      if (dateFilterPreset === 'thisMonth' && !d.startsWith(currentMonthStr)) return false;
      if (dateFilterPreset === 'custom') {
        if (startDate && d < startDate) return false;
        if (endDate && d > endDate) return false;
      }

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchDesc = item.description.toLowerCase().includes(q);
        const matchGuest = item.guestName?.toLowerCase().includes(q);
        const matchCat = item.category?.toLowerCase().includes(q);
        const matchNotes = item.notes?.toLowerCase().includes(q);
        if (!matchDesc && !matchGuest && !matchCat && !matchNotes) return false;
      }

      return true;
    });
  }, [items, filterStatus, filterCategory, dateFilterPreset, startDate, endDate, searchQuery, todayStr, currentMonthStr]);

  // Financial KPIs
  const summary = useMemo(() => {
    let totalGross = 0;
    let totalCost = 0;
    let totalProfit = 0;
    let paidCount = 0;
    let unpaidCount = 0;

    filteredItems.forEach((i) => {
      const gross = Number(i.total) || 0;
      const cost = Number(i.cost) || 0;
      const profit = Number(i.laba ?? (gross - cost));

      totalGross += gross;
      totalCost += cost;
      totalProfit += profit;

      if (i.status === 'Lunas') paidCount++;
      else unpaidCount++;
    });

    const profitMargin = totalGross > 0 ? Math.round((totalProfit / totalGross) * 100) : 0;

    return {
      totalGross,
      totalCost,
      totalProfit,
      profitMargin,
      paidCount,
      unpaidCount,
      totalTransactions: filteredItems.length,
    };
  }, [filteredItems]);

  const handleSaveItem = async (payload: Partial<ExtraIncomeItem>) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    showSuccess(payload.id ? 'Catatan pendapatan diperbarui' : 'Pendapatan ekstra berhasil disimpan');
    saveExtraIncome(payload, userEmail).catch((err) => {
      console.error('Error saving extra income:', err);
      showError('Gagal sinkron pendapatan ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  const handleConfirmDelete = () => {
    if (!itemToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const target = itemToDelete;
    const reason = deleteReason.trim();

    // (1) Tutup modal konfirmasi & beri notifikasi segera (OPTIMISTIC <1 detik)
    setItemToDelete(null);
    setDeleteReason('');
    showSuccess(`Data ${target.description} berhasil dihapus.`);

    // (2) Hapus di latar belakang TANPA await
    deleteExtraIncome(target, userEmail, reason).catch((err) => {
      console.error('Error deleting extra income item:', err);
      showError('Gagal sinkron hapus ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
    });
  };

  return (
    <div id="extra-income-module" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Coins className="w-6 h-6 text-blue-600" />
            <span>Pendapatan Tambahan & POS</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan kayu bakar, sewa perlengkapan, F&B tambahan, dan pelacakan biaya modal serta laba bersih.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'transaksi' ? (
            <>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Rekap</span>
              </button>

              <button
                id="btn-add-extra-income"
                type="button"
                onClick={() => {
                  setItemToEdit(null);
                  setIsModalOpen(true);
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Pendapatan Tambahan</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => {
                setEditingCatalog(null);
                setShowCatalogForm(true);
              }}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Item Katalog</span>
            </button>
          )}
        </div>
      </div>

      {/* Tab Switch */}
      <div className="border-b border-slate-200 flex gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('transaksi')}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wide border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'transaksi'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Coins className="w-4 h-4" />
          Transaksi
          <span className="text-[10px] font-mono bg-slate-100 text-slate-600 rounded-full px-1.5">
            {items.length}
          </span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('katalog')}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wide border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'katalog'
              ? 'border-blue-600 text-blue-700'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          Katalog Layanan Extra
          <span className="text-[10px] font-mono bg-slate-100 text-slate-600 rounded-full px-1.5">
            {catalogList.length}
          </span>
        </button>
      </div>

      {activeTab === 'katalog' ? (
        <CatalogSection
          list={filteredCatalog}
          allCount={catalogList.length}
          categories={catalogCategories}
          search={catalogSearch}
          setSearch={setCatalogSearch}
          filterCat={catalogFilterCat}
          setFilterCat={setCatalogFilterCat}
          sumHpp={sumHppOf}
          onEdit={(c) => {
            setEditingCatalog(c);
            setShowCatalogForm(true);
          }}
          onDelete={(c) => setCatalogToDelete(c)}
        />
      ) : (
      <>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total Gross */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase">Total Pendapatan (Gross)</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(summary.totalGross)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{summary.totalTransactions} Transaksi tercatat</div>
        </div>

        {/* Total Cost */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-rose-600 uppercase">Total Biaya Modal (Cost)</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <Layers className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-rose-700 mt-2">
            {formatRupiah(summary.totalCost)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Biaya belanja & bahan baku</div>
        </div>

        {/* Net Profit */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-emerald-600 uppercase">Total Laba Bersih (Profit)</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-emerald-700 mt-2">
            {formatRupiah(summary.totalProfit)}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Gross − Modal Biaya</div>
        </div>

        {/* Margin */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-purple-600 uppercase">Margin Keuntungan</span>
            <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <PieChart className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-purple-900 mt-2">{summary.profitMargin}%</div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-purple-600 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(0, summary.profitMargin))}%` }}
            />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari deskripsi, nama tamu, catatan..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Status */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Status Bayar</option>
              <option value="Lunas">Lunas (Selesai)</option>
              <option value="Belum Lunas">Belum Lunas (Pending)</option>
            </select>
          </div>

          {/* Kategori */}
          <div>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              <option value="ALL">Semua Kategori</option>
              <option value="Kayu Bakar & Api Unggun">Kayu Bakar & Api Unggun</option>
              <option value="Sewa Tenda & Matras">Sewa Tenda & Matras</option>
              <option value="F&B Tambahan & Snack">F&B Tambahan & Snack</option>
              <option value="Jasa Foto / Dokumentasi">Jasa Foto / Dokumentasi</option>
              <option value="Barbeque Set">Barbeque Set</option>
              <option value="Catering & BBQ">Catering & BBQ</option>
              <option value="Lainnya">Lainnya</option>
            </select>
          </div>
        </div>

        {/* Date Filter Presets */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Periode:</span>
            </span>
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setDateFilterPreset('thisMonth')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'thisMonth'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Bulan Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('today')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'today'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Hari Ini
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('all')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'all'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setDateFilterPreset('custom')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
                  dateFilterPreset === 'custom'
                    ? 'bg-white text-slate-900 font-bold shadow-xs'
                    : 'text-slate-600'
                }`}
              >
                Rentang
              </button>
            </div>

            {dateFilterPreset === 'custom' && (
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
                <span className="text-xs text-slate-400">s/d</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs"
                />
              </div>
            )}
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Total {filteredItems.length} transaksi ({summary.paidCount} lunas, {summary.unpaidCount} belum lunas)
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {isLoading ? (
          <div className="py-16 text-center">
            <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Memuat data pendapatan ekstra...</p>
          </div>
        ) : filteredItems.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-4">Tanggal</th>
                  <th className="py-3 px-4">Deskripsi & Kategori</th>
                  <th className="py-3 px-4">Tamu / Pemesan</th>
                  <th className="py-3 px-4 text-center">Qty</th>
                  <th className="py-3 px-4 text-right">Pemasukan (Gross)</th>
                  <th className="py-3 px-4 text-right">Biaya Modal</th>
                  <th className="py-3 px-4 text-right">Laba Bersih</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredItems.map((item) => {
                  const isLunas = item.status === 'Lunas';
                  const cost = Number(item.cost) || 0;
                  const profit = Number(item.laba ?? (item.total - cost));

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-slate-900">{formatDateIndo(item.date)}</div>
                        <div className="text-[10px] text-slate-400">{item.paymentMethod}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{item.description}</div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <span className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md font-medium">
                            {item.category || 'POS'}
                          </span>
                          {item.costBreakdown && item.costBreakdown.length > 0 && (
                            <span className="text-[10px] text-blue-600 font-medium">
                              • {item.costBreakdown.length} komponen biaya
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium text-slate-800">{item.guestName || '-'}</span>
                      </td>

                      <td className="py-3 px-4 text-center font-bold text-slate-900">
                        {item.qty}
                      </td>

                      <td className="py-3 px-4 text-right font-extrabold text-slate-900">
                        {formatRupiah(item.total)}
                      </td>

                      <td className="py-3 px-4 text-right font-semibold text-rose-700">
                        {cost > 0 ? formatRupiah(cost) : '-'}
                      </td>

                      <td className="py-3 px-4 text-right font-extrabold text-emerald-700">
                        {formatRupiah(profit)}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[10px] border ${
                            isLunas
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border-amber-200'
                          }`}
                        >
                          {isLunas ? (
                            <CheckCircle2 className="w-3 h-3" />
                          ) : (
                            <Clock className="w-3 h-3" />
                          )}
                          <span>{item.status}</span>
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            title="Dokumen & Salin WhatsApp"
                            onClick={() => setQuickDocItem(item)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Dokumen / WA</span>
                          </button>
                          <button
                            type="button"
                            title="Edit Catatan"
                            onClick={() => {
                              setItemToEdit(item);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            title="Hapus Catatan"
                            onClick={() => {
                              setItemToDelete(item);
                              setDeleteReason('');
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center">
            <Coins className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-semibold text-slate-700">Belum Ada Pendapatan Tambahan</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Klik tombol "Tambah Pendapatan Tambahan" untuk mencatat pemasukan sewa alat, F&B, atau kayu bakar.
            </p>
          </div>
        )}
      </div>

      </>
      )}

      {/* Catalog Form Modal (tab Katalog) */}
      {showCatalogForm && (
        <CatalogFormModal
          itemToEdit={editingCatalog}
          onClose={() => {
            setShowCatalogForm(false);
            setEditingCatalog(null);
          }}
          onSaved={() => {
            setShowCatalogForm(false);
            setEditingCatalog(null);
          }}
          userEmail={userProfile?.email || currentUser?.email || 'admin@bolang.id'}
          showSuccess={showSuccess}
          showError={showError}
        />
      )}

      {/* Catalog Delete Confirm */}
      <Modal
        isOpen={!!catalogToDelete}
        onClose={() => setCatalogToDelete(null)}
        title="Hapus Item Katalog?"
      >
        {catalogToDelete ? (
          <div className="space-y-3">
            <p className="text-sm text-slate-700">
              Item <strong>{catalogToDelete.name}</strong> akan dihapus dari katalog. Transaksi
              lama yang pernah pakai item ini tetap tersimpan.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setCatalogToDelete(null)}
                disabled={isDeletingCatalog}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg disabled:opacity-50"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeletingCatalog}
                onClick={confirmDeleteCatalog}
                className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50"
              >
                {isDeletingCatalog ? 'Menghapus…' : 'Hapus'}
              </button>
            </div>
          </div>
        ) : null}
      </Modal>

      {/* Form Modal */}
      {isModalOpen && (
        <ExtraIncomeModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          itemToEdit={itemToEdit}
          onSave={handleSaveItem}
          onOpenQuickDoc={(it) => setQuickDocItem(it)}
        />
      )}

      {/* Quick Action Modal: Dokumen & Salin WhatsApp */}
      {quickDocItem && (
        <TransactionQuickDocWAModal
          isOpen={!!quickDocItem}
          onClose={() => setQuickDocItem(null)}
          transaction={quickDocItem}
          moduleType="extra_income"
          businessSettings={settings}
        />
      )}

      {/* Delete Modal */}
      <Modal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        title="Konfirmasi Hapus Data Pendapatan Ekstra"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Hapus catatan <strong>{itemToDelete?.description}</strong> senilai{' '}
            <strong>{formatRupiah(itemToDelete?.total || 0)}</strong>? Tindakan ini akan dicatat dalam riwayat penghapusan audit.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Alasan Penghapusan (Opsional):</label>
            <input
              type="text"
              placeholder="Contoh: Transaksi dibatalkan / salah input..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setItemToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg disabled:opacity-50 cursor-pointer"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Catatan'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

// ============================================================
// CatalogSection — Tab "Katalog Layanan Extra" (list + search)
// ============================================================
interface CatalogSectionProps {
  list: ExtraServiceCatalogItem[];
  allCount: number;
  categories: string[];
  search: string;
  setSearch: (s: string) => void;
  filterCat: string;
  setFilterCat: (s: string) => void;
  sumHpp: (c: ExtraServiceCatalogItem) => number;
  onEdit: (c: ExtraServiceCatalogItem) => void;
  onDelete: (c: ExtraServiceCatalogItem) => void;
}
const CatalogSection: React.FC<CatalogSectionProps> = ({
  list,
  allCount,
  categories,
  search,
  setSearch,
  filterCat,
  setFilterCat,
  sumHpp,
  onEdit,
  onDelete,
}) => {
  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama / kategori / catatan…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-blue-400"
          />
        </div>
        <select
          value={filterCat}
          onChange={(e) => setFilterCat(e.target.value)}
          className="px-3 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
        >
          <option value="ALL">Semua Kategori ({allCount})</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* List */}
      {list.length === 0 ? (
        <div className="bg-white p-10 text-center rounded-2xl border border-dashed border-slate-200">
          <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <h4 className="text-sm font-semibold text-slate-700">Katalog Masih Kosong</h4>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Katalog menyimpan item layanan extra yang sering dijual (BBQ, Api Unggun, Electone,
            dll) beserta HPP &amp; harga jual default. Klik "Tambah Item Katalog" di atas.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-slate-50 text-left text-[11px] font-bold uppercase text-slate-600">
                <th className="px-3 py-2.5">Nama Item</th>
                <th className="px-3 py-2.5">Kategori</th>
                <th className="px-3 py-2.5 text-right">Harga Jual Default</th>
                <th className="px-3 py-2.5 text-right">HPP (Total)</th>
                <th className="px-3 py-2.5 text-right">Laba / unit</th>
                <th className="px-3 py-2.5 text-center">Komponen</th>
                <th className="px-3 py-2.5 w-24"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {list.map((c) => {
                const hpp = sumHpp(c);
                const laba = Math.max(0, (c.defaultSellingPrice || 0) - hpp);
                const margin =
                  c.defaultSellingPrice && c.defaultSellingPrice > 0
                    ? Math.round((laba / c.defaultSellingPrice) * 100)
                    : 0;
                return (
                  <tr key={c.id} className="hover:bg-slate-50/70">
                    <td className="px-3 py-2.5">
                      <div className="font-bold text-slate-800">{c.name}</div>
                      {c.notes ? (
                        <div className="text-[10px] text-slate-500 mt-0.5 line-clamp-1">
                          {c.notes}
                        </div>
                      ) : null}
                    </td>
                    <td className="px-3 py-2.5 text-slate-600">{c.category || 'Lainnya'}</td>
                    <td className="px-3 py-2.5 text-right font-bold text-slate-900 font-mono">
                      {c.defaultSellingPrice ? formatRupiah(c.defaultSellingPrice) : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-right text-rose-700 font-mono">
                      {hpp > 0 ? formatRupiah(hpp) : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono">
                      {c.defaultSellingPrice && c.defaultSellingPrice > 0 ? (
                        <span className={laba > 0 ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                          {formatRupiah(laba)}
                          <span className="text-[10px] text-slate-500 ml-1">({margin}%)</span>
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      {c.defaultCostBreakdown && c.defaultCostBreakdown.length > 0 ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-slate-600">
                          <Layers className="w-3 h-3" />
                          {c.defaultCostBreakdown.length}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-300">—</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onEdit(c)}
                          className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-md"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete(c)}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-md"
                          title="Hapus"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ============================================================
// CatalogFormModal — Form tambah/edit item katalog (ringkas)
// ============================================================
interface CatalogFormModalProps {
  itemToEdit: ExtraServiceCatalogItem | null;
  onClose: () => void;
  onSaved: () => void;
  userEmail: string;
  showSuccess: (m: string) => void;
  showError: (m: string) => void;
}
const CatalogFormModal: React.FC<CatalogFormModalProps> = ({
  itemToEdit,
  onClose,
  onSaved,
  userEmail,
  showSuccess,
  showError,
}) => {
  const [name, setName] = useState(itemToEdit?.name || '');
  const [category, setCategory] = useState(itemToEdit?.category || 'Lainnya');
  const [defaultSellingPrice, setDefaultSellingPrice] = useState<number>(
    itemToEdit?.defaultSellingPrice || 0,
  );
  const [notes, setNotes] = useState(itemToEdit?.notes || '');
  const [costItems, setCostItems] = useState(itemToEdit?.defaultCostBreakdown || []);
  const [isSaving, setIsSaving] = useState(false);

  const totalHpp = costItems.reduce(
    (s, c) => s + (Number(c.amount) || (Number(c.qty) || 0) * (Number(c.unitPrice) || 0)),
    0,
  );
  const laba = Math.max(0, defaultSellingPrice - totalHpp);

  const addCostRow = () =>
    setCostItems([
      ...costItems,
      {
        id: `cost_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        label: '',
        qty: 1,
        unitPrice: 0,
        amount: 0,
      },
    ]);

  const updateCost = (idx: number, patch: Partial<(typeof costItems)[number]>) => {
    const next = [...costItems];
    const row = { ...next[idx], ...patch };
    row.amount = (Number(row.qty) || 0) * (Number(row.unitPrice) || 0);
    next[idx] = row;
    setCostItems(next);
  };

  const removeCost = (idx: number) => setCostItems(costItems.filter((_, i) => i !== idx));

  const handleSave = async () => {
    if (!name.trim()) {
      showError('Nama item wajib diisi.');
      return;
    }
    setIsSaving(true);
    try {
      await saveExtraServiceCatalogItem(
        {
          id: itemToEdit?.id,
          name: name.trim(),
          category: category.trim() || 'Lainnya',
          defaultSellingPrice: Number(defaultSellingPrice) || 0,
          defaultCostBreakdown: costItems,
          notes: notes.trim(),
        },
        userEmail,
      );
      showSuccess(itemToEdit ? 'Item katalog diperbarui.' : 'Item katalog ditambahkan.');
      onSaved();
    } catch (err) {
      console.error(err);
      showError('Gagal menyimpan item katalog.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-2xl max-h-[94vh] bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div className="font-bold text-slate-800 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            {itemToEdit ? 'Ubah Item Katalog' : 'Tambah Item Katalog'}
          </div>
          <button type="button" onClick={onClose} className="p-1.5 hover:bg-slate-100 rounded-lg">
            <Trash2 className="w-5 h-5 text-slate-400 rotate-45 opacity-0" />
            <span className="sr-only">Tutup</span>
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-auto p-5 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                Nama Layanan / Barang *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="BBQ 4 Pax, Api Unggun, Electone, …"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-blue-400"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                Kategori
              </label>
              <input
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="F&B, Sewa Alat, Hiburan, …"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-blue-400"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
                Harga Jual Default
              </label>
              <input
                type="number"
                step="1000"
                value={defaultSellingPrice || 0}
                onChange={(e) => setDefaultSellingPrice(Math.max(0, Number(e.target.value) || 0))}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-right font-bold focus:outline-none"
              />
            </div>
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-emerald-800">Laba (Jual − HPP)</span>
              <span className="font-mono font-bold text-emerald-800 text-sm">
                {formatRupiah(laba)}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">
              Catatan
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Catatan internal — misal: standar porsi, variasi, dll."
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none"
            />
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div className="text-[11px] font-bold uppercase text-slate-600">
                Rincian HPP / Biaya Modal Default
              </div>
              <button
                type="button"
                onClick={addCostRow}
                className="px-2 py-1 bg-slate-800 text-white rounded-md text-[11px] font-semibold flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Komponen
              </button>
            </div>
            {costItems.length === 0 ? (
              <p className="text-[11px] text-slate-400 italic">
                Belum ada rincian. Isi komponen modal (misal bahan baku, kemasan) untuk hitung HPP
                otomatis.
              </p>
            ) : (
              <div className="space-y-1.5">
                {costItems.map((c, i) => (
                  <div key={c.id} className="grid grid-cols-12 gap-1.5 items-center">
                    <input
                      type="text"
                      placeholder="Label (mis. ayam)"
                      value={c.label}
                      onChange={(e) => updateCost(i, { label: e.target.value })}
                      className="col-span-5 px-2 py-1.5 border border-slate-200 rounded text-[11px] bg-white"
                    />
                    <input
                      type="number"
                      min="0"
                      placeholder="Qty"
                      value={c.qty || 0}
                      onChange={(e) => updateCost(i, { qty: Number(e.target.value) || 0 })}
                      className="col-span-2 px-1 py-1.5 border border-slate-200 rounded text-[11px] text-center bg-white"
                    />
                    <input
                      type="number"
                      step="500"
                      placeholder="Modal/unit"
                      value={c.unitPrice || 0}
                      onChange={(e) => updateCost(i, { unitPrice: Number(e.target.value) || 0 })}
                      className="col-span-3 px-2 py-1.5 border border-slate-200 rounded text-[11px] text-right bg-white"
                    />
                    <div className="col-span-1 text-right text-[10px] font-bold text-slate-700">
                      {formatRupiah(c.amount)}
                    </div>
                    <button
                      type="button"
                      onClick={() => removeCost(i)}
                      className="col-span-1 p-1 text-rose-500 hover:bg-rose-50 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex justify-end pt-1 text-[11px] text-slate-600 border-t border-slate-200">
                  Total HPP:{' '}
                  <span className="font-mono font-bold text-rose-700 ml-1">
                    {formatRupiah(totalHpp)}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-100 bg-slate-50">
          <button
            type="button"
            onClick={onClose}
            disabled={isSaving}
            className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100"
          >
            Batal
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 disabled:opacity-60"
          >
            {isSaving ? 'Menyimpan…' : itemToEdit ? 'Simpan Perubahan' : 'Tambah ke Katalog'}
          </button>
        </div>
      </div>
    </div>
  );
};
