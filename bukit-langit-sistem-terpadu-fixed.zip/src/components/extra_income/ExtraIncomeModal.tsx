import React, { useState, useEffect } from 'react';
import { ExtraIncomeItem, CostBreakdownItem, InventoryItem, ExtraServiceCatalogItem } from '../../types';
import { Modal } from '../common/Modal';
import {
  subscribeInventoryItems,
  getBusinessSettings,
  subscribeExtraServiceCatalog,
  saveExtraServiceCatalogItem,
  deleteExtraServiceCatalogItem,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { formatRupiah, getTodayDateString } from '../../utils/formatters';
import {
  Coins,
  Calendar,
  User,
  Tag,
  DollarSign,
  Plus,
  Trash2,
  Package,
  Layers,
  CreditCard,
  FileText,
  TrendingUp,
  BookMarked,
  Bookmark,
} from 'lucide-react';

interface ExtraIncomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemToEdit?: ExtraIncomeItem | null;
  onSave: (payload: Partial<ExtraIncomeItem>) => Promise<void>;
  onOpenQuickDoc?: (item: ExtraIncomeItem) => void;
}

const DEFAULT_CATEGORIES = [
  'Kayu Bakar & Api Unggun',
  'Sewa Tenda & Matras',
  'F&B Tambahan & Snack',
  'Jasa Foto / Dokumentasi',
  'Barbeque Set',
  'Catering & BBQ',
  'Lainnya',
];

const PAYMENT_METHODS = ['Cash / Tunai', 'Transfer BCA', 'Transfer Mandiri', 'Transfer BRI', 'QRIS', 'Lainnya'];

export const ExtraIncomeModal: React.FC<ExtraIncomeModalProps> = ({
  isOpen,
  onClose,
  itemToEdit,
  onSave,
  onOpenQuickDoc,
}) => {
  const [date, setDate] = useState<string>(getTodayDateString());
  const [guestName, setGuestName] = useState<string>('');
  const [category, setCategory] = useState<string>(DEFAULT_CATEGORIES[0]);
  const [categoriesList, setCategoriesList] = useState<string[]>(DEFAULT_CATEGORIES);
  const [description, setDescription] = useState<string>('');
  const [qty, setQty] = useState<number>(1);
  const [unitPrice, setUnitPrice] = useState<number>(50000);
  const [paymentMethod, setPaymentMethod] = useState<string>('Cash / Tunai');
  const [status, setStatus] = useState<'Lunas' | 'Belum Lunas'>('Lunas');
  const [totalPaid, setTotalPaid] = useState<number>(50000);
  const [notes, setNotes] = useState<string>('');

  // Cost breakdown
  const [costItems, setCostItems] = useState<CostBreakdownItem[]>([]);
  const [inventoryList, setInventoryList] = useState<InventoryItem[]>([]);

  // Katalog Layanan Extra (Poin 3+11)
  const [catalogList, setCatalogList] = useState<ExtraServiceCatalogItem[]>([]);
  const [selectedCatalogId, setSelectedCatalogId] = useState<string>('');
  const [isSavingCatalog, setIsSavingCatalog] = useState<boolean>(false);
  const [showCatalogManage, setShowCatalogManage] = useState<boolean>(false);
  const [catalogSearch, setCatalogSearch] = useState<string>(''); // cari item katalog
  const [catalogOpen, setCatalogOpen] = useState<boolean>(false);

  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    const unsub = subscribeInventoryItems((items) => {
      setInventoryList(items);
    });

    const unsubCatalog = subscribeExtraServiceCatalog((items) => {
      setCatalogList(items);
    });

    getBusinessSettings().then((s) => {
      if (s?.extraIncomeTypes && s.extraIncomeTypes.length > 0) {
        setCategoriesList(s.extraIncomeTypes);
      }
    });

    return () => {
      unsub();
      unsubCatalog();
    };
  }, []);

  useEffect(() => {
    if (itemToEdit) {
      setDate(itemToEdit.date || getTodayDateString());
      setGuestName(itemToEdit.guestName || '');
      setCategory(itemToEdit.category || DEFAULT_CATEGORIES[0]);
      setDescription(itemToEdit.description || '');
      setQty(itemToEdit.qty || 1);
      setUnitPrice(itemToEdit.unitPrice || 0);
      setPaymentMethod(itemToEdit.paymentMethod || 'Cash / Tunai');
      setStatus(itemToEdit.status || 'Lunas');
      setTotalPaid(itemToEdit.totalPaid ?? (itemToEdit.qty * itemToEdit.unitPrice));
      setNotes(itemToEdit.notes || '');
      setCostItems(itemToEdit.costBreakdown || []);
    } else {
      setDate(getTodayDateString());
      setGuestName('');
      setCategory(DEFAULT_CATEGORIES[0]);
      setDescription('');
      setQty(1);
      setUnitPrice(50000);
      setPaymentMethod('Cash / Tunai');
      setStatus('Lunas');
      setTotalPaid(50000);
      setNotes('');
      setCostItems([]);
    }
    setErrorMsg('');
  }, [itemToEdit, isOpen]);

  // Calculations
  const totalRevenue = (Number(qty) || 0) * (Number(unitPrice) || 0);
  const totalCost = costItems.reduce((acc, c) => acc + (Number(c.amount) || (Number(c.qty || 0) * Number(c.unitPrice || 0))), 0);
  const netProfit = totalRevenue - totalCost;
  const profitMargin = totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0;

  const handleAddCostRow = () => {
    const newRow: CostBreakdownItem = {
      id: `cost_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      label: '',
      qty: 1,
      unitPrice: 0,
      amount: 0,
    };
    setCostItems([...costItems, newRow]);
  };

  const handleUpdateCostRow = (
    index: number,
    field: keyof CostBreakdownItem,
    val: unknown,
  ) => {
    const updated = [...costItems];
    const row = { ...updated[index], [field]: val };

    if (field === 'qty' || field === 'unitPrice') {
      row.amount = (Number(row.qty) || 0) * (Number(row.unitPrice) || 0);
    }

    // Auto fill from inventory item if selected (label + harga modal/HPP otomatis)
    if (field === 'inventoryItemId' && val) {
      const inv = inventoryList.find((i) => i.id === val);
      if (inv) {
        if (!row.label) row.label = inv.name;
        row.unitPrice = Number(inv.hpp) || 0;
        row.amount = (Number(row.qty) || 0) * row.unitPrice;
      }
    }

    updated[index] = row;
    setCostItems(updated);
  };

  const handleRemoveCostRow = (index: number) => {
    const updated = [...costItems];
    updated.splice(index, 1);
    setCostItems(updated);
  };

  // Poin 3+11: pilih item dari katalog → auto-isi deskripsi, harga jual (jika ada), & rincian modal default
  const handleSelectCatalog = (id: string) => {
    setSelectedCatalogId(id);
    if (!id) return;
    const item = catalogList.find((c) => c.id === id);
    if (!item) return;
    setDescription(item.name || '');
    if (item.category) setCategory(item.category);
    if (item.defaultSellingPrice && item.defaultSellingPrice > 0) {
      setUnitPrice(item.defaultSellingPrice);
      setTotalPaid((Number(qty) || 1) * item.defaultSellingPrice);
    }
    const cloned: CostBreakdownItem[] = (item.defaultCostBreakdown || []).map((c, i) => ({
      id: `cost_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 5)}`,
      label: c.label || '',
      qty: Number(c.qty) || 1,
      unitPrice: Number(c.unitPrice) || 0,
      amount: (Number(c.qty) || 1) * (Number(c.unitPrice) || 0),
      inventoryItemId: c.inventoryItemId || undefined,
    }));
    setCostItems(cloned);
  };

  // Poin 3+11: simpan form saat ini sebagai item katalog (tambah baru / perbarui jika nama sama)
  const handleSaveToCatalog = async () => {
    if (!description.trim()) {
      showError('Isi deskripsi layanan dulu sebelum menyimpan ke katalog.');
      return;
    }
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const existing = catalogList.find(
      (c) => (c.name || '').toLowerCase() === description.trim().toLowerCase()
    );
    setIsSavingCatalog(true);
    try {
      await saveExtraServiceCatalogItem(
        {
          id: existing?.id,
          name: description.trim(),
          category: category,
          defaultSellingPrice: Number(unitPrice) || 0,
          defaultCostBreakdown: costItems.map((c) => ({
            id: c.id,
            label: c.label || '',
            qty: Number(c.qty) || 1,
            unitPrice: Number(c.unitPrice) || 0,
            amount: Number(c.amount) || 0,
            inventoryItemId: c.inventoryItemId,
          })),
        },
        userEmail,
      );
      showSuccess(
        existing
          ? `Item katalog "${description.trim()}" diperbarui.`
          : `"${description.trim()}" disimpan ke katalog layanan.`
      );
    } catch (err) {
      showError('Gagal menyimpan item katalog.');
    } finally {
      setIsSavingCatalog(false);
    }
  };

  // Poin 3+11: hapus item katalog
  const handleDeleteCatalog = async (item: ExtraServiceCatalogItem) => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    try {
      await deleteExtraServiceCatalogItem(item, userEmail);
      if (selectedCatalogId === item.id) setSelectedCatalogId('');
      showSuccess(`"${item.name}" dihapus dari katalog.`);
    } catch (err) {
      showError('Gagal menghapus item katalog.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      setErrorMsg('Deskripsi item / layanan pemasukan wajib diisi.');
      return;
    }
    if (qty <= 0) {
      setErrorMsg('Jumlah (Qty) minimal 1.');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg('');
      await onSave({
        id: itemToEdit?.id,
        date: date || getTodayDateString(),
        guestName: guestName.trim() || undefined,
        category,
        description: description.trim(),
        qty: Number(qty) || 1,
        unitPrice: Number(unitPrice) || 0,
        total: totalRevenue,
        totalPaid: Number(totalPaid) || 0,
        paymentMethod,
        status: Number(totalPaid) >= totalRevenue ? 'Lunas' : status,
        cost: totalCost,
        costBreakdown: costItems,
        laba: netProfit,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err) {
      console.error('Error saving extra income:', err);
      setErrorMsg('Gagal menyimpan catatan pendapatan tambahan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={itemToEdit ? 'Edit Pendapatan Tambahan / POS' : 'Tambah Pendapatan Tambahan / POS'}
      maxWidth="max-w-3xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {itemToEdit && onOpenQuickDoc && (
          <div className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-emerald-950">
                Shortcut Dokumen & WhatsApp Tersedia
              </span>
            </div>
            <button
              type="button"
              onClick={() => onOpenQuickDoc(itemToEdit)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Dokumen & WA</span>
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-medium">
            {errorMsg}
          </div>
        )}

        {/* Date, Category, Guest */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Tanggal Transaksi *</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-slate-400" />
              <span>Jenis / Kategori</span>
            </label>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                if (!description && e.target.value !== 'Lainnya') {
                  setDescription(e.target.value);
                }
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              {categoriesList.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>Nama Tamu / Pemesan (Opsional)</span>
            </label>
            <input
              type="text"
              placeholder="Contoh: Rombongan Tenda B-02"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
            />
          </div>
        </div>

        {/* Katalog Layanan Extra (Poin 3+11): pilih preset untuk auto-isi + kelola inline */}
        <div className="p-3 bg-indigo-50/60 rounded-2xl border border-indigo-200/70 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <BookMarked className="w-4 h-4 text-indigo-600" />
              <span className="font-bold text-indigo-900 text-xs">Katalog Layanan / Barang</span>
              <span className="text-[10px] text-indigo-500 hidden sm:inline">pilih untuk isi otomatis</span>
            </div>
            {catalogList.length > 0 && (
              <button
                type="button"
                onClick={() => setShowCatalogManage((v) => !v)}
                className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-800 underline cursor-pointer whitespace-nowrap"
              >
                {showCatalogManage ? 'Tutup Kelola' : `Kelola (${catalogList.length})`}
              </button>
            )}
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            {/* Combobox: ketik untuk mencari item katalog */}
            <div className="relative flex-1">
              <input
                type="text"
                value={catalogSearch}
                onChange={(e) => {
                  setCatalogSearch(e.target.value);
                  setCatalogOpen(true);
                }}
                onFocus={() => setCatalogOpen(true)}
                onBlur={() => setTimeout(() => setCatalogOpen(false), 150)}
                placeholder="Cari / pilih dari Katalog (opsional)…"
                className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              />
              {catalogOpen && (
                <div className="absolute z-20 mt-1 w-full max-h-52 overflow-auto bg-white border border-indigo-200 rounded-xl shadow-lg text-xs">
                  {catalogList.filter((c) =>
                    c.name.toLowerCase().includes(catalogSearch.trim().toLowerCase()),
                  ).length === 0 ? (
                    <div className="px-3 py-2 text-slate-400 italic">Tidak ada item cocok.</div>
                  ) : (
                    catalogList
                      .filter((c) =>
                        c.name.toLowerCase().includes(catalogSearch.trim().toLowerCase()),
                      )
                      .map((c) => (
                        <button
                          type="button"
                          key={c.id}
                          onMouseDown={(ev) => {
                            ev.preventDefault();
                            handleSelectCatalog(c.id);
                            setCatalogSearch(c.name);
                            setCatalogOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 hover:bg-indigo-50 flex justify-between gap-2 ${
                            selectedCatalogId === c.id ? 'bg-indigo-50 font-semibold' : ''
                          }`}
                        >
                          <span className="truncate">{c.name}</span>
                          {c.defaultSellingPrice ? (
                            <span className="font-mono text-slate-500 shrink-0">
                              {formatRupiah(c.defaultSellingPrice)}
                            </span>
                          ) : null}
                        </button>
                      ))
                  )}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={handleSaveToCatalog}
              disabled={isSavingCatalog}
              title="Simpan deskripsi, harga jual, & rincian modal saat ini sebagai item katalog"
              className="px-3 py-2 bg-white hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-semibold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50 whitespace-nowrap"
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>{isSavingCatalog ? 'Menyimpan...' : 'Simpan ke Katalog'}</span>
            </button>
          </div>
          {catalogList.length === 0 && (
            <p className="text-[10px] text-indigo-400 italic">
              Belum ada item katalog. Isi deskripsi, harga, &amp; rincian modal di bawah, lalu klik &quot;Simpan ke Katalog&quot; untuk membuat preset.
            </p>
          )}
          {showCatalogManage && catalogList.length > 0 && (
            <div className="bg-white border border-indigo-100 rounded-xl divide-y divide-slate-100 max-h-48 overflow-y-auto">
              {catalogList.map((c) => {
                const hpp = (c.defaultCostBreakdown || []).reduce((s, x) => s + (Number(x.amount) || 0), 0);
                return (
                  <div key={c.id} className="flex items-center justify-between gap-2 px-2.5 py-1.5">
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-800 text-[11px] truncate">{c.name}</p>
                      <p className="text-[10px] text-slate-400">
                        Jual: {c.defaultSellingPrice ? formatRupiah(c.defaultSellingPrice) : '—'} · Modal:{' '}
                        {formatRupiah(hpp)} · {(c.defaultCostBreakdown || []).length} komp.
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          handleSelectCatalog(c.id);
                          setShowCatalogManage(false);
                        }}
                        title="Muat ke form untuk diedit"
                        className="px-2 py-1 text-[10px] font-semibold text-indigo-600 hover:bg-indigo-50 rounded-lg cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCatalog(c)}
                        title="Hapus item katalog"
                        className="p-1 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
              <p className="text-[9px] text-slate-400 italic px-2.5 py-1">
                Edit = muat item ke form; ubah lalu klik &quot;Simpan ke Katalog&quot; untuk memperbarui (nama sama = diperbarui).
              </p>
            </div>
          )}
        </div>

        {/* Description, Qty, Unit Price */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="sm:col-span-2">
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              <span>Deskripsi Layanan / Barang *</span>
            </label>
            <input
              type="text"
              required
              placeholder="Contoh: 1 Ikat Kayu Bakar + Minyak Tanah"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Jumlah (Qty) *
            </label>
            <input
              type="number"
              min="1"
              required
              value={qty}
              onChange={(e) => {
                const val = Math.max(1, parseInt(e.target.value) || 1);
                setQty(val);
                setTotalPaid(val * unitPrice);
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-center focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Harga Satuan (Rp) *</span>
            </label>
            <input
              type="number"
              min="0"
              required
              value={unitPrice || ''}
              onChange={(e) => {
                const val = Math.max(0, parseInt(e.target.value) || 0);
                setUnitPrice(val);
                setTotalPaid(qty * val);
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-700 focus:bg-white"
            />
          </div>
        </div>

        {/* Cost Breakdown Repeater (Pelacakan Modal / Biaya) */}
        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-600" />
              <div>
                <h4 className="font-bold text-slate-800 text-xs">
                  Rincian Biaya Modal & Pengurangan Stok (Cost Breakdown)
                </h4>
                <p className="text-[10px] text-slate-500">
                  Opsional: Tambahkan komponen modal belanja/bahan baku & kaitkan ke item inventaris untuk potong stok otomatis.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddCostRow}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-blue-700 font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Biaya</span>
            </button>
          </div>

          {costItems.length > 0 ? (
            <div className="space-y-2">
              {costItems.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="grid grid-cols-1 sm:grid-cols-12 gap-2 p-2.5 bg-white border border-slate-200 rounded-xl items-center"
                >
                  <div className="sm:col-span-4">
                    <input
                      type="text"
                      placeholder="Nama komponen / bahan..."
                      value={item.label}
                      onChange={(e) => handleUpdateCostRow(idx, 'label', e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div className="sm:col-span-3">
                    <select
                      value={item.inventoryItemId || ''}
                      onChange={(e) => handleUpdateCostRow(idx, 'inventoryItemId', e.target.value)}
                      className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px]"
                    >
                      <option value="">-- Kaitkan Stok (Opsional) --</option>
                      {inventoryList.map((inv) => (
                        <option key={inv.id} value={inv.id}>
                          📦 {inv.name} ({inv.stock} {inv.unit})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <input
                      type="number"
                      min="1"
                      placeholder="Qty"
                      value={item.qty}
                      onChange={(e) =>
                        handleUpdateCostRow(idx, 'qty', Math.max(1, parseInt(e.target.value) || 1))
                      }
                      className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-center"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <input
                      type="number"
                      min="0"
                      placeholder="Biaya @ Rp"
                      value={item.unitPrice || ''}
                      onChange={(e) =>
                        handleUpdateCostRow(idx, 'unitPrice', Math.max(0, parseInt(e.target.value) || 0))
                      }
                      className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                    />
                  </div>

                  <div className="sm:col-span-1 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveCostRow(idx)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[11px] text-slate-400 italic">
              Belum ada komponen modal/biaya. Margin keuntungan dihitung 100% dari harga jual.
            </p>
          )}
        </div>

        {/* Realtime Profit & Financial Summary Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-blue-50/50 rounded-2xl border border-blue-200/70">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Pemasukan (Gross)</span>
            <span className="text-base font-black text-slate-900">{formatRupiah(totalRevenue)}</span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Total Biaya Modal (Cost)</span>
            <span className="text-base font-bold text-rose-700">{formatRupiah(totalCost)}</span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Estimasi Laba Bersih (Profit)</span>
            <span className="text-base font-black text-emerald-700">
              {formatRupiah(netProfit)} <span className="text-xs font-semibold">({profitMargin}%)</span>
            </span>
          </div>
        </div>

        {/* Payment details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span>Metode Pembayaran</span>
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white"
            >
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Status Pembayaran
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'Lunas' | 'Belum Lunas')}
              className={`w-full px-3 py-2 border rounded-xl text-xs font-bold ${
                status === 'Lunas'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                  : 'bg-amber-50 text-amber-700 border-amber-300'
              }`}
            >
              <option value="Lunas">Lunas (Diterima Penuh)</option>
              <option value="Belum Lunas">Belum Lunas (Pending / Kasbon)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Jumlah Diterima (Rp)
            </label>
            <input
              type="number"
              min="0"
              value={totalPaid || ''}
              onChange={(e) => setTotalPaid(Math.max(0, parseInt(e.target.value) || 0))}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white"
            />
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block font-semibold text-slate-700 mb-1">
            Catatan Tambahan (Opsional)
          </label>
          <input
            type="text"
            placeholder="Contoh: Diterima oleh staf kasir jaga..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
          >
            Batal
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-xs transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'Menyimpan...' : itemToEdit ? 'Simpan Perubahan' : 'Simpan Pendapatan Tambahan'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
