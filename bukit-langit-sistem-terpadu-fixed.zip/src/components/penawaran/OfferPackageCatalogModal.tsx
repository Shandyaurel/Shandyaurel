import React, { useEffect, useState } from 'react';
import {
  OfferPackageItem,
  OfferPackageComponent,
  QuotationCategory,
  QuotationItemGroup,
} from '../../types';
import {
  subscribeOfferPackages,
  saveOfferPackage,
  deleteOfferPackage,
} from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatters';
import { useToast } from '../../context/ToastContext';
import { X, Plus, Edit2, Trash2, Save, Package, Tag, Layers } from 'lucide-react';

const rid = () => `cmp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

interface OfferPackageCatalogModalProps {
  userEmail: string;
  onClose: () => void;
}

const CATEGORIES: QuotationCategory[] = ['Hotel', 'ATV', 'Extra'];
const GROUPS: QuotationItemGroup[] = ['Paket', 'Tambahan'];
const UNITS = ['pax', 'orang', 'set', 'paket', 'malam', 'unit', 'jam', 'hari'];

const emptyForm: Partial<OfferPackageItem> = {
  name: '',
  category: 'Extra',
  group: 'Paket',
  unit: 'pax',
  price: 0,
  description: '',
};

export const OfferPackageCatalogModal: React.FC<OfferPackageCatalogModalProps> = ({
  userEmail,
  onClose,
}) => {
  const { showSuccess, showError } = useToast();
  const [items, setItems] = useState<OfferPackageItem[]>([]);
  const [form, setForm] = useState<Partial<OfferPackageItem>>(emptyForm);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const unsub = subscribeOfferPackages((list) => setItems(list));
    return () => unsub();
  }, []);

  const resetForm = () => setForm(emptyForm);

  const handleEdit = (item: OfferPackageItem) => {
    setForm({ ...item, components: (item.components || []).map((c) => ({ ...c })) });
  };

  const components = form.components || [];
  const componentsTotal = components.reduce((a, c) => a + (Number(c.price) || 0), 0);

  const addComponent = () =>
    setForm((f) => ({
      ...f,
      components: [
        ...((f.components as OfferPackageComponent[]) || []),
        { id: rid(), name: '', category: f.category || 'Extra', price: 0, notes: '' },
      ],
    }));
  const patchComponent = (id: string, patch: Partial<OfferPackageComponent>) =>
    setForm((f) => ({
      ...f,
      components: ((f.components as OfferPackageComponent[]) || []).map((c) =>
        c.id === id ? { ...c, ...patch } : c,
      ),
    }));
  const removeComponent = (id: string) =>
    setForm((f) => ({
      ...f,
      components: ((f.components as OfferPackageComponent[]) || []).filter((c) => c.id !== id),
    }));

  const handleSave = async () => {
    if (!form.name || !form.name.trim()) {
      showError('Nama paket wajib diisi.');
      return;
    }
    setIsSaving(true);
    try {
      await saveOfferPackage(form, userEmail);
      showSuccess(form.id ? 'Paket diperbarui.' : 'Paket ditambahkan.');
      resetForm();
    } catch {
      showError('Gagal menyimpan paket.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (item: OfferPackageItem) => {
    try {
      await deleteOfferPackage(item, userEmail);
      showSuccess('Paket dihapus.');
      if (form.id === item.id) resetForm();
    } catch {
      showError('Gagal menghapus paket.');
    }
  };

  const catColor = (c: QuotationCategory) =>
    c === 'Hotel'
      ? 'bg-indigo-100 text-indigo-700'
      : c === 'ATV'
        ? 'bg-amber-100 text-amber-700'
        : 'bg-emerald-100 text-emerald-700';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-4xl max-h-[90vh] bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2 font-bold text-slate-800">
            <Package className="w-5 h-5 text-blue-600" />
            <span>Katalog Paket Penawaran</span>
            <span className="text-xs font-normal text-slate-400">({items.length} item)</span>
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-100 rounded-lg">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        <div className="flex-1 overflow-auto p-5 grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* FORM */}
          <div className="lg:col-span-1 bg-slate-50 rounded-xl p-4 border border-slate-200 h-fit">
            <div className="text-xs font-bold uppercase text-slate-500 mb-3 flex items-center gap-1.5">
              {form.id ? <Edit2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
              {form.id ? 'Ubah Paket' : 'Tambah Paket'}
            </div>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">Nama Paket / Item</label>
                <input
                  type="text"
                  value={form.name || ''}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Contoh: Paket Full Board Meeting"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-blue-400"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">Kategori</label>
                  <select
                    value={form.category}
                    onChange={(e) =>
                      setForm({ ...form, category: e.target.value as QuotationCategory })
                    }
                    className="w-full px-2 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">Grup Surat</label>
                  <select
                    value={form.group}
                    onChange={(e) =>
                      setForm({ ...form, group: e.target.value as QuotationItemGroup })
                    }
                    className="w-full px-2 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                  >
                    {GROUPS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">Satuan</label>
                  <input
                    type="text"
                    list="offer-units"
                    value={form.unit || ''}
                    onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                  />
                  <datalist id="offer-units">
                    {UNITS.map((u) => (
                      <option key={u} value={u} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">Harga Satuan</label>
                  {components.length > 0 ? (
                    <div className="w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-lg text-right font-mono text-slate-700">
                      {formatRupiah(componentsTotal)}
                      <span className="block text-[9px] text-blue-500 font-sans text-left">
                        otomatis dari rincian
                      </span>
                    </div>
                  ) : (
                    <input
                      type="number"
                      value={form.price ?? 0}
                      onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                    />
                  )}
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-600 mb-1">Keterangan (opsional)</label>
                <input
                  type="text"
                  value={form.description || ''}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                />
              </div>

              {/* Rincian paket (breakdown) */}
              <div className="border-t border-slate-200 pt-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1 text-[11px] font-bold uppercase text-slate-500">
                    <Layers className="w-3.5 h-3.5" /> Rincian Paket (opsional)
                  </div>
                  <button
                    onClick={addComponent}
                    className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 rounded-md text-[11px] font-bold text-slate-600 hover:bg-slate-100"
                  >
                    <Plus className="w-3 h-3" /> Komponen
                  </button>
                </div>
                {components.length === 0 ? (
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Pecah paket jadi komponen (mis. Menginap, ATV, Makan Malam). Tiap komponen punya
                    kategori sendiri utk rute saat Deal, dan harga paket dihitung otomatis dari
                    jumlahnya.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {components.map((c) => (
                      <div key={c.id} className="bg-white border border-slate-200 rounded-lg p-2 space-y-1.5">
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={c.name}
                            onChange={(e) => patchComponent(c.id, { name: e.target.value })}
                            placeholder="Nama komponen"
                            className="flex-1 px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden"
                          />
                          <button
                            onClick={() => removeComponent(c.id)}
                            className="p-1 text-rose-400 hover:bg-rose-50 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="grid grid-cols-2 gap-1.5">
                          <select
                            value={c.category}
                            onChange={(e) =>
                              patchComponent(c.id, { category: e.target.value as QuotationCategory })
                            }
                            className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden"
                          >
                            {CATEGORIES.map((cat) => (
                              <option key={cat} value={cat}>
                                {cat}
                              </option>
                            ))}
                          </select>
                          <input
                            type="number"
                            value={c.price}
                            onChange={(e) => patchComponent(c.id, { price: Number(e.target.value) })}
                            placeholder={`Harga/${form.unit || 'pax'}`}
                            className="px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden text-right"
                          />
                        </div>
                        <input
                          type="text"
                          value={c.notes || ''}
                          onChange={(e) => patchComponent(c.id, { notes: e.target.value })}
                          placeholder="Catatan / menu (mis. ayam bakar, nasi, es teh)"
                          className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md focus:outline-hidden"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 disabled:opacity-60"
                >
                  <Save className="w-4 h-4" />
                  {form.id ? 'Update' : 'Tambah'}
                </button>
                {form.id ? (
                  <button
                    onClick={resetForm}
                    className="px-3 py-2 bg-slate-200 text-slate-700 rounded-lg font-bold hover:bg-slate-300"
                  >
                    Batal
                  </button>
                ) : null}
              </div>
            </div>
          </div>

          {/* LIST */}
          <div className="lg:col-span-2">
            {items.length === 0 ? (
              <div className="text-center text-slate-400 py-10 text-sm">
                Belum ada paket. Tambahkan lewat form di samping.
              </div>
            ) : (
              <div className="space-y-2">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-3 py-2.5 hover:border-blue-300"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-sm text-slate-800 truncate">
                          {item.name}
                        </span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${catColor(item.category)}`}>
                          {item.category}
                        </span>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 flex items-center gap-0.5">
                          <Tag className="w-2.5 h-2.5" />
                          {item.group}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500">
                        {formatRupiah(item.price)} / {item.unit}
                        {item.components && item.components.length > 0
                          ? ` · ${item.components.length} rincian`
                          : ''}
                        {item.description ? ` · ${item.description}` : ''}
                      </div>
                    </div>
                    <button
                      onClick={() => handleEdit(item)}
                      className="p-1.5 text-slate-500 hover:bg-slate-100 rounded-lg"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(item)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferPackageCatalogModal;
