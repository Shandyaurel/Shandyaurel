import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Quotation,
  QuotationOption,
  QuotationItem,
  QuotationItemComponent,
  OfferPackageItem,
  QuotationCategory,
  DiscountType,
} from '../../types';
import { subscribeOfferPackages, saveQuotation } from '../../utils/firebase';
import { formatRupiah } from '../../utils/formatters';
import { useToast } from '../../context/ToastContext';
import {
  X,
  Trash2,
  Save,
  PackagePlus,
  PencilLine,
  ChevronDown,
  ChevronRight,
  Layers,
  Plus,
  Package,
  Search,
  Sparkles,
} from 'lucide-react';

interface QuotationEditorModalProps {
  quotation: Quotation | null;
  userEmail: string;
  onClose: () => void;
  onSaved: (id: string) => void;
}

const CATEGORIES: QuotationCategory[] = ['Hotel', 'ATV', 'Extra'];

const todayStr = () => new Date().toISOString().split('T')[0];
const rid = (p: string) => `${p}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

// Harga per satuan item: bila ada rincian = jumlah harga komponen, else harga manual.
const itemUnitPrice = (it: QuotationItem) =>
  it.components && it.components.length > 0
    ? it.components.reduce((a, c) => a + (Number(c.price) || 0), 0)
    : Number(it.price) || 0;
const itemTotal = (it: QuotationItem) => (Number(it.qty) || 0) * itemUnitPrice(it);

const makeSingleOption = (guestCount = 0): QuotationOption => ({
  id: rid('opt'),
  name: 'Paket Utama',
  capacityNote: '',
  guestCount,
  items: [],
  discountType: 'Nominal',
  discountValue: 0,
  subtotal: 0,
  discountAmount: 0,
  grandTotal: 0,
  notes: '',
});

export const QuotationEditorModal: React.FC<QuotationEditorModalProps> = ({
  quotation,
  userEmail,
  onClose,
  onSaved,
}) => {
  const { showSuccess, showError } = useToast();
  const [packages, setPackages] = useState<OfferPackageItem[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const savingRef = useRef(false);

  // Deteksi quotation lama multi-opsi (>1 opsi). Kalau ya → warning & edit opsi pertama saja.
  const legacyMulti = (quotation?.options?.length || 0) > 1;

  // Data klien / surat (level penawaran)
  const [clientName, setClientName] = useState(quotation?.clientName || '');
  const [clientOrganization, setClientOrganization] = useState(quotation?.clientOrganization || '');
  const [clientPhone, setClientPhone] = useState(quotation?.clientPhone || '');
  const [clientAddress, setClientAddress] = useState(quotation?.clientAddress || '');
  const [eventName, setEventName] = useState(quotation?.eventName || '');
  const [eventDate, setEventDate] = useState(quotation?.eventDate || '');
  const [date, setDate] = useState(quotation?.date || todayStr());
  const [validUntil, setValidUntil] = useState(quotation?.validUntil || '');
  const [introText, setIntroText] = useState(quotation?.introText || '');
  const [notes, setNotes] = useState(quotation?.notes || '');

  // Single opsi (hidden dari user — konsep "opsi" dihapus dari UI)
  const initialOption: QuotationOption =
    quotation?.options && quotation.options.length > 0
      ? { ...quotation.options[0], name: 'Paket Utama' }
      : makeSingleOption();

  const [opt, setOpt] = useState<QuotationOption>(initialOption);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  // Search katalog per section
  const [searchPaket, setSearchPaket] = useState('');
  const [searchAddon, setSearchAddon] = useState('');
  const [showCatalogPaket, setShowCatalogPaket] = useState(false);
  const [showCatalogAddon, setShowCatalogAddon] = useState(false);

  useEffect(() => {
    const unsub = subscribeOfferPackages((list) => setPackages(list));
    return () => unsub();
  }, []);

  // Items terpisah: group='Paket' vs group='Tambahan'
  const paketItems = opt.items.filter((it) => it.group === 'Paket');
  const addonItems = opt.items.filter((it) => it.group === 'Tambahan');

  // Katalog terfilter per section (otomatis hanya show paket group yang sesuai)
  const catalogPaket = useMemo(() => {
    const q = searchPaket.trim().toLowerCase();
    return packages
      .filter((p) => p.group === 'Paket')
      .filter((p) => !q || (p.name + ' ' + p.category).toLowerCase().includes(q));
  }, [packages, searchPaket]);

  const catalogAddon = useMemo(() => {
    const q = searchAddon.trim().toLowerCase();
    return packages
      .filter((p) => p.group === 'Tambahan')
      .filter((p) => !q || (p.name + ' ' + p.category).toLowerCase().includes(q));
  }, [packages, searchAddon]);

  // ---- Mutasi item ----
  const addFromPackage = (pkgId: string) => {
    const pkg = packages.find((p) => p.id === pkgId);
    if (!pkg) return;
    const newItemId = rid('qitem');
    const components: QuotationItemComponent[] = (pkg.components || []).map((c) => ({
      id: rid('qcmp'),
      name: c.name,
      category: c.category,
      price: Number(c.price) || 0,
      notes: c.notes || '',
    }));
    const newItem: QuotationItem = {
      id: newItemId,
      packageId: pkg.id,
      name: pkg.name,
      category: pkg.category,
      group: pkg.group,
      unit: pkg.unit,
      qty: pkg.group === 'Paket' ? opt.guestCount || 1 : 1,
      price: pkg.price,
      total: pkg.price,
      components,
    };
    setOpt((o) => ({ ...o, items: [...o.items, newItem] }));
    if (components.length > 0) setExpanded((e) => ({ ...e, [newItemId]: true }));
    if (pkg.group === 'Paket') {
      setShowCatalogPaket(false);
      setSearchPaket('');
    } else {
      setShowCatalogAddon(false);
      setSearchAddon('');
    }
  };

  const addManualItem = (group: 'Paket' | 'Tambahan') => {
    const newItem: QuotationItem = {
      id: rid('qitem'),
      name: '',
      category: group === 'Paket' ? 'Hotel' : 'Extra',
      group,
      unit: group === 'Paket' ? 'pax' : 'unit',
      qty: group === 'Paket' ? opt.guestCount || 1 : 1,
      price: 0,
      total: 0,
      components: [],
    };
    setOpt((o) => ({ ...o, items: [...o.items, newItem] }));
  };

  const patchItem = (itemId: string, patch: Partial<QuotationItem>) =>
    setOpt((o) => ({
      ...o,
      items: o.items.map((it) => (it.id === itemId ? { ...it, ...patch } : it)),
    }));

  const removeItem = (itemId: string) =>
    setOpt((o) => ({ ...o, items: o.items.filter((it) => it.id !== itemId) }));

  // ---- Mutasi komponen (rincian paket) ----
  const addComponent = (itemId: string) => {
    setOpt((o) => ({
      ...o,
      items: o.items.map((it) =>
        it.id === itemId
          ? {
              ...it,
              components: [
                ...(it.components || []),
                { id: rid('qcmp'), name: '', category: it.category, price: 0, notes: '' },
              ],
            }
          : it,
      ),
    }));
    setExpanded((e) => ({ ...e, [itemId]: true }));
  };

  const patchComponent = (
    itemId: string,
    compId: string,
    patch: Partial<QuotationItemComponent>,
  ) =>
    setOpt((o) => ({
      ...o,
      items: o.items.map((it) =>
        it.id === itemId
          ? {
              ...it,
              components: (it.components || []).map((c) =>
                c.id === compId ? { ...c, ...patch } : c,
              ),
            }
          : it,
      ),
    }));

  const removeComponent = (itemId: string, compId: string) =>
    setOpt((o) => ({
      ...o,
      items: o.items.map((it) =>
        it.id === itemId
          ? { ...it, components: (it.components || []).filter((c) => c.id !== compId) }
          : it,
      ),
    }));

  // ---- Total ----
  const totals = useMemo(() => {
    const subtotal = opt.items.reduce((a, it) => a + itemTotal(it), 0);
    const discountAmount =
      opt.discountType === 'Persen'
        ? Math.round((subtotal * (Number(opt.discountValue) || 0)) / 100)
        : Number(opt.discountValue) || 0;
    return { subtotal, discountAmount, grandTotal: Math.max(0, subtotal - discountAmount) };
  }, [opt.items, opt.discountType, opt.discountValue]);

  const handleSave = async () => {
    if (savingRef.current) return;
    if (!clientName.trim()) {
      showError('Nama klien wajib diisi.');
      return;
    }
    if (opt.items.length === 0) {
      showError('Tambahkan minimal satu item paket atau add-on.');
      return;
    }
    savingRef.current = true;
    setIsSaving(true);
    try {
      const finalOpt: QuotationOption = {
        ...opt,
        name: 'Paket Utama',
        subtotal: totals.subtotal,
        discountAmount: totals.discountAmount,
        grandTotal: totals.grandTotal,
      };
      const payload: Partial<Quotation> = {
        id: quotation?.id,
        quotationNumber: quotation?.quotationNumber,
        status: quotation?.status || 'Draft',
        convertedOrderId: quotation?.convertedOrderId,
        convertedOptionId: quotation?.convertedOptionId,
        convertedAt: quotation?.convertedAt,
        date,
        validUntil,
        clientName: clientName.trim(),
        clientOrganization,
        clientPhone,
        clientAddress,
        eventName,
        eventDate,
        options: [finalOpt], // selalu single opsi
        introText,
        notes,
      };
      const id = await saveQuotation(payload, userEmail);
      showSuccess('Surat penawaran disimpan.');
      onSaved(id);
    } catch {
      showError('Gagal menyimpan penawaran.');
    } finally {
      savingRef.current = false;
      setIsSaving(false);
    }
  };

  const inputCls =
    'w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:bg-white focus:outline-hidden focus:border-blue-400';
  const miniCls =
    'px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-md text-xs focus:bg-white focus:outline-hidden focus:border-blue-400';

  // ----- Render item row (digunakan untuk paket & addon) -----
  const renderItemRow = (it: QuotationItem) => {
    const hasBreakdown = (it.components || []).length > 0;
    const isOpen = !!expanded[it.id];
    const unit = itemUnitPrice(it);
    return (
      <div key={it.id} className="border border-slate-200 rounded-xl overflow-hidden bg-white">
        <div className="flex items-start gap-2 p-2.5">
          <button
            onClick={() => setExpanded((e) => ({ ...e, [it.id]: !isOpen }))}
            className={`mt-1 p-0.5 rounded ${
              hasBreakdown ? 'text-blue-600 hover:bg-blue-50' : 'text-slate-300'
            }`}
            title={hasBreakdown ? 'Lihat rincian' : 'Belum ada rincian'}
          >
            {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
          <div className="flex-1 grid grid-cols-2 md:grid-cols-[1.7fr_0.5fr_0.7fr_1fr] gap-2 items-center">
            <input
              className={miniCls + ' col-span-2 md:col-span-1'}
              placeholder="Nama item / paket"
              value={it.name}
              onChange={(e) => patchItem(it.id, { name: e.target.value })}
            />
            <input
              type="number"
              className={miniCls + ' text-right'}
              title="Qty"
              value={it.qty}
              onChange={(e) => patchItem(it.id, { qty: Number(e.target.value) })}
            />
            <input
              className={miniCls}
              title="Satuan"
              placeholder="pax / set / unit"
              value={it.unit}
              onChange={(e) => patchItem(it.id, { unit: e.target.value })}
            />
            {hasBreakdown ? (
              <div className="text-right font-mono text-slate-700 px-2">
                {formatRupiah(unit)}
                <span className="block text-[9px] text-blue-500 font-sans">dari rincian</span>
              </div>
            ) : (
              <input
                type="number"
                className={miniCls + ' text-right'}
                title="Harga satuan"
                value={it.price}
                onChange={(e) => patchItem(it.id, { price: Number(e.target.value) })}
              />
            )}
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {!hasBreakdown ? (
              <select
                className={miniCls}
                title="Kategori rute saat Deal"
                value={it.category}
                onChange={(e) =>
                  patchItem(it.id, { category: e.target.value as QuotationCategory })
                }
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            ) : (
              <span className="text-[10px] text-slate-400 w-14 text-center">
                rute ikut rincian
              </span>
            )}
            <button
              onClick={() => removeItem(it.id)}
              className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-md"
              title="Hapus item"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Rincian komponen */}
        {isOpen && (
          <div className="bg-slate-50 border-t border-slate-200 p-2.5">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500 uppercase">
                <Layers className="w-3.5 h-3.5" /> Rincian Paket
              </div>
              <button
                onClick={() => addComponent(it.id)}
                className="flex items-center gap-1 px-2 py-1 bg-white border border-slate-200 rounded-md text-[11px] font-bold text-slate-600 hover:bg-slate-100"
              >
                <Plus className="w-3 h-3" /> Komponen
              </button>
            </div>
            {(it.components || []).length === 0 ? (
              <div className="text-[11px] text-slate-400 py-2 text-center">
                Belum ada rincian. Klik "Komponen" untuk memecah paket (kamar, makan, ATV, dll).
              </div>
            ) : (
              <div className="space-y-1.5">
                <div className="hidden md:grid grid-cols-[1.4fr_0.7fr_0.9fr_1.4fr_auto] gap-2 px-1 text-[9px] font-bold uppercase text-slate-400">
                  <span>Komponen</span>
                  <span>Kategori</span>
                  <span className="text-right">Harga/{it.unit}</span>
                  <span>Catatan / menu</span>
                  <span />
                </div>
                {(it.components || []).map((c) => (
                  <div
                    key={c.id}
                    className="grid grid-cols-2 md:grid-cols-[1.4fr_0.7fr_0.9fr_1.4fr_auto] gap-2 items-center"
                  >
                    <input
                      className={miniCls + ' col-span-2 md:col-span-1 bg-white'}
                      placeholder="Menginap / Makan Malam / ATV…"
                      value={c.name}
                      onChange={(e) => patchComponent(it.id, c.id, { name: e.target.value })}
                    />
                    <select
                      className={miniCls + ' bg-white'}
                      value={c.category}
                      onChange={(e) =>
                        patchComponent(it.id, c.id, {
                          category: e.target.value as QuotationCategory,
                        })
                      }
                    >
                      {CATEGORIES.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                    <input
                      type="number"
                      className={miniCls + ' text-right bg-white'}
                      value={c.price}
                      onChange={(e) =>
                        patchComponent(it.id, c.id, { price: Number(e.target.value) })
                      }
                    />
                    <input
                      className={miniCls + ' bg-white'}
                      placeholder="mis. menu: ayam bakar, nasi, es teh"
                      value={c.notes || ''}
                      onChange={(e) => patchComponent(it.id, c.id, { notes: e.target.value })}
                    />
                    <button
                      onClick={() => removeComponent(it.id, c.id)}
                      className="p-1 text-rose-400 hover:bg-rose-50 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex justify-end pt-1 text-[11px] text-slate-500">
                  Total/{it.unit}:{' '}
                  <span className="font-mono font-bold text-slate-700 ml-1">
                    {formatRupiah(unit)}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Total baris */}
        <div className="flex items-center justify-between px-3 py-1.5 bg-slate-100/70 text-[11px]">
          <span className="text-slate-500">
            {it.qty} {it.unit} × {formatRupiah(unit)}
          </span>
          <span className="font-mono font-bold text-slate-700">
            {formatRupiah(itemTotal(it))}
          </span>
        </div>
      </div>
    );
  };

  // ----- Render dropdown katalog -----
  const renderCatalogDropdown = (
    list: OfferPackageItem[],
    search: string,
    setSearch: (s: string) => void,
    onPick: (id: string) => void,
    onClose: () => void,
    emptyHint: string,
  ) => (
    <div className="absolute z-30 left-0 right-0 mt-1 bg-white border border-blue-200 rounded-lg shadow-xl max-h-72 overflow-hidden flex flex-col">
      <div className="p-2 border-b border-slate-100 flex items-center gap-1.5 bg-slate-50">
        <Search className="w-3.5 h-3.5 text-slate-400" />
        <input
          autoFocus
          placeholder="Cari di katalog…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1 px-1 py-0.5 bg-transparent text-xs focus:outline-none"
        />
        <button onClick={onClose} className="text-[11px] text-slate-500 hover:bg-slate-200 px-1.5 py-0.5 rounded">
          Tutup
        </button>
      </div>
      <div className="overflow-y-auto">
        {list.length === 0 ? (
          <div className="p-3 text-[11px] text-slate-500 italic">{emptyHint}</div>
        ) : (
          list.slice(0, 50).map((p) => (
            <button
              key={p.id}
              onClick={() => onPick(p.id)}
              className="w-full px-3 py-2 text-left hover:bg-blue-50 border-b border-slate-50 flex items-center justify-between gap-2"
            >
              <span className="flex-1 min-w-0">
                <span className="block font-semibold text-slate-800 truncate">{p.name}</span>
                <span className="block text-[10px] text-slate-500">
                  [{p.category}] · {p.unit}
                  {p.components && p.components.length > 0 ? ` · ${p.components.length} komponen` : ''}
                </span>
              </span>
              <span className="text-[11px] font-bold text-blue-700 whitespace-nowrap">
                {formatRupiah(p.price)}/{p.unit}
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
      <div className="w-full max-w-5xl max-h-[94vh] bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 shrink-0">
          <div className="font-bold text-slate-800">
            {quotation ? 'Ubah Surat Penawaran' : 'Buat Surat Penawaran'}
            {quotation ? (
              <span className="text-xs font-mono text-slate-400 ml-2">
                #{quotation.quotationNumber}
              </span>
            ) : null}
          </div>
          <button onClick={onClose} className="p-1.5 hover:bg-slate-100 rounded-lg">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-auto p-5 space-y-5 text-xs">
          {legacyMulti ? (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-[11px] text-amber-800">
              <strong>Penawaran versi lama</strong> terdeteksi memiliki beberapa opsi paket. Saat
              disimpan, hanya opsi pertama ("Paket Utama") yang dipertahankan. Opsi lain akan
              hilang.
            </div>
          ) : null}

          {/* Data klien */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="text-[11px] font-bold uppercase text-slate-500">Data Klien</div>
              <input
                className={inputCls}
                placeholder="Nama klien / PIC *"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
              />
              <input
                className={inputCls}
                placeholder="Instansi / Perusahaan"
                value={clientOrganization}
                onChange={(e) => setClientOrganization(e.target.value)}
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  className={inputCls}
                  placeholder="No. WhatsApp / Telp"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                />
                <input
                  className={inputCls}
                  placeholder="Alamat (opsional)"
                  value={clientAddress}
                  onChange={(e) => setClientAddress(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-3">
              <div className="text-[11px] font-bold uppercase text-slate-500">Acara & Tanggal</div>
              <input
                className={inputCls}
                placeholder="Nama acara / gathering"
                value={eventName}
                onChange={(e) => setEventName(e.target.value)}
              />
              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="text-slate-500 block mb-0.5">Peserta</label>
                  <input
                    type="number"
                    min={0}
                    className={inputCls}
                    value={opt.guestCount || ''}
                    placeholder="Jml"
                    onChange={(e) =>
                      setOpt((o) => ({ ...o, guestCount: Number(e.target.value) || 0 }))
                    }
                  />
                </div>
                <div>
                  <label className="text-slate-500 block mb-0.5">Tgl Acara</label>
                  <input
                    type="date"
                    className={inputCls}
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-slate-500 block mb-0.5">Tgl Surat</label>
                  <input
                    type="date"
                    className={inputCls}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-slate-500 block mb-0.5">Berlaku s/d</label>
                  <input
                    type="date"
                    className={inputCls}
                    value={validUntil}
                    onChange={(e) => setValidUntil(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* ================= PAKET UTAMA ================= */}
          <div className="border border-blue-200 bg-blue-50/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                <Package className="w-4 h-4 text-blue-600" />
                Paket Utama
              </h4>
              <div className="relative flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowCatalogPaket((v) => !v);
                    setShowCatalogAddon(false);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-600 text-white rounded-lg font-bold text-xs hover:bg-blue-700"
                >
                  <PackagePlus className="w-3.5 h-3.5" /> Dari Katalog Paket
                </button>
                <button
                  onClick={() => addManualItem('Paket')}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-700 text-white rounded-lg font-bold text-xs hover:bg-slate-800"
                >
                  <PencilLine className="w-3.5 h-3.5" /> Manual
                </button>
                {showCatalogPaket &&
                  renderCatalogDropdown(
                    catalogPaket,
                    searchPaket,
                    setSearchPaket,
                    addFromPackage,
                    () => setShowCatalogPaket(false),
                    'Katalog paket kosong. Tambahkan di tombol "Katalog Paket" (header Penawaran).',
                  )}
              </div>
            </div>
            <p className="text-[11px] text-blue-800/70 -mt-1">
              Paket inti yang ditawarkan. Biasanya 1 item utama (mis. "Paket Gathering Full Board 2
              Hari 1 Malam"). Bisa punya rincian komponen (menginap, makan, ATV, dll).
            </p>

            {paketItems.length === 0 ? (
              <div className="text-center text-slate-400 py-6 border border-dashed border-blue-200 rounded-xl text-xs">
                Belum ada paket utama. Tambah dari katalog atau manual.
              </div>
            ) : (
              <div className="space-y-2">{paketItems.map(renderItemRow)}</div>
            )}
          </div>

          {/* ================= ADD-ON / UPGRADE ================= */}
          <div className="border border-amber-200 bg-amber-50/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                Add-on &amp; Upgrade (opsional)
              </h4>
              <div className="relative flex items-center gap-2">
                <button
                  onClick={() => {
                    setShowCatalogAddon((v) => !v);
                    setShowCatalogPaket(false);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-600 text-white rounded-lg font-bold text-xs hover:bg-amber-700"
                >
                  <PackagePlus className="w-3.5 h-3.5" /> Dari Katalog Add-on
                </button>
                <button
                  onClick={() => addManualItem('Tambahan')}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-700 text-white rounded-lg font-bold text-xs hover:bg-slate-800"
                >
                  <PencilLine className="w-3.5 h-3.5" /> Manual
                </button>
                {showCatalogAddon &&
                  renderCatalogDropdown(
                    catalogAddon,
                    searchAddon,
                    setSearchAddon,
                    addFromPackage,
                    () => setShowCatalogAddon(false),
                    'Katalog add-on kosong. Buat item katalog dengan grup "Tambahan" di modul Katalog Paket.',
                  )}
              </div>
            </div>
            <p className="text-[11px] text-amber-800/70 -mt-1">
              Item opsional di luar paket utama &mdash; mis. Electone (+Rp 500.000), Snack box
              (+Rp 25.000/pax), Extended checkout, dll. Customer boleh pilih atau skip.
            </p>

            {addonItems.length === 0 ? (
              <div className="text-center text-slate-400 py-6 border border-dashed border-amber-200 rounded-xl text-xs">
                Belum ada add-on. Tambah dari katalog atau manual kalau ada penambahan yang
                ditawarkan.
              </div>
            ) : (
              <div className="space-y-2">{addonItems.map(renderItemRow)}</div>
            )}
          </div>

          {/* ================= RINGKASAN TOTAL ================= */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 pt-4">
            <div className="space-y-3">
              <div>
                <label className="text-slate-500 block mb-1 font-semibold">
                  Paragraf Pembuka (opsional)
                </label>
                <textarea
                  rows={3}
                  className={inputCls}
                  placeholder="Dengan hormat, bersama surat ini kami sampaikan penawaran…"
                  value={introText}
                  onChange={(e) => setIntroText(e.target.value)}
                />
              </div>
              <div>
                <label className="text-slate-500 block mb-1 font-semibold">
                  Catatan &amp; Ketentuan
                </label>
                <textarea
                  rows={3}
                  className={inputCls}
                  placeholder="Syarat pembayaran, DP, ketentuan lain…"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
            </div>
            <div className="bg-slate-900 text-white border border-slate-700 rounded-xl p-4 h-fit space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-300">Subtotal</span>
                <span className="font-semibold">{formatRupiah(totals.subtotal)}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-300">Diskon</span>
                <div className="flex items-center gap-1">
                  <select
                    value={opt.discountType}
                    onChange={(e) =>
                      setOpt((o) => ({ ...o, discountType: e.target.value as DiscountType }))
                    }
                    className="px-1.5 py-1 bg-slate-800 border border-slate-600 rounded-md focus:outline-hidden"
                  >
                    <option value="Nominal">Rp</option>
                    <option value="Persen">%</option>
                  </select>
                  <input
                    type="number"
                    value={opt.discountValue || ''}
                    onChange={(e) =>
                      setOpt((o) => ({ ...o, discountValue: Number(e.target.value) }))
                    }
                    className="w-24 px-2 py-1 bg-slate-800 border border-slate-600 rounded-md focus:outline-hidden text-right"
                  />
                </div>
              </div>
              {totals.discountAmount > 0 ? (
                <div className="flex justify-between text-rose-300">
                  <span>Potongan</span>
                  <span>-{formatRupiah(totals.discountAmount)}</span>
                </div>
              ) : null}
              <div className="flex justify-between border-t border-slate-700 pt-2 font-black text-sm">
                <span>GRAND TOTAL</span>
                <span className="text-emerald-300">{formatRupiah(totals.grandTotal)}</span>
              </div>
              <p className="text-[10px] text-slate-400 pt-1 border-t border-slate-700">
                Add-on sudah masuk hitungan grand total di atas (kalau tidak diambil, hapus
                item-nya atau set qty 0).
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-100 shrink-0 bg-slate-50">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100"
          >
            Batal
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 disabled:opacity-60"
          >
            <Save className="w-4 h-4" />
            {isSaving ? 'Menyimpan…' : 'Simpan Penawaran'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuotationEditorModal;
