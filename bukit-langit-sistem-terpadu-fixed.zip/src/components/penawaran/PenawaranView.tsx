import React, { useEffect, useMemo, useState } from 'react';
import { Quotation, QuotationOption, QuotationStatus } from '../../types';
import {
  subscribeQuotations,
  deleteQuotation,
  convertQuotationToDeal,
  saveQuotation,
} from '../../utils/firebase';
import { getStoredSettings } from '../../utils/storage';
import { formatRupiah } from '../../utils/formatters';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Modal } from '../common/Modal';
import { QuotationEditorModal } from './QuotationEditorModal';
import { QuotationPrintView } from './QuotationPrintView';
import { OfferPackageCatalogModal } from './OfferPackageCatalogModal';
import {
  FileText,
  Plus,
  Package,
  Printer,
  Edit2,
  Trash2,
  CheckCircle2,
  Send,
  Search,
  Handshake,
  Ban,
  ExternalLink,
} from 'lucide-react';

const STATUS_META: Record<QuotationStatus, { label: string; cls: string }> = {
  Draft: { label: 'Draft', cls: 'bg-slate-100 text-slate-600' },
  Terkirim: { label: 'Terkirim', cls: 'bg-blue-100 text-blue-700' },
  Deal: { label: 'Deal ✓', cls: 'bg-emerald-100 text-emerald-700' },
  Batal: { label: 'Batal', cls: 'bg-rose-100 text-rose-600' },
};

// Total sebuah opsi (components-aware), tanpa bergantung field tersimpan.
const optionGrand = (opt: QuotationOption): number => {
  const subtotal = (opt.items || []).reduce((a, it) => {
    const unit =
      it.components && it.components.length > 0
        ? it.components.reduce((s, c) => s + (Number(c.price) || 0), 0)
        : Number(it.price) || 0;
    return a + (Number(it.qty) || 0) * unit;
  }, 0);
  const disc =
    opt.discountType === 'Persen'
      ? Math.round((subtotal * (Number(opt.discountValue) || 0)) / 100)
      : Number(opt.discountValue) || 0;
  return Math.max(0, subtotal - disc);
};
const quoteHeadline = (q: Quotation): number =>
  (q.options || []).reduce((m, o) => Math.max(m, optionGrand(o)), 0);

export const PenawaranView: React.FC = () => {
  const { currentUser } = useAuth();
  const { showSuccess, showError } = useToast();
  const userEmail = currentUser?.email || '';

  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | QuotationStatus>('ALL');

  const [editing, setEditing] = useState<Quotation | null>(null);
  const [showEditor, setShowEditor] = useState(false);
  const [printing, setPrinting] = useState<Quotation | null>(null);
  const [showCatalog, setShowCatalog] = useState(false);
  const [dealTarget, setDealTarget] = useState<Quotation | null>(null);
  const [dealOptionId, setDealOptionId] = useState<string>('');
  const [deleteTarget, setDeleteTarget] = useState<Quotation | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const openDeal = (q: Quotation) => {
    setDealTarget(q);
    // default: opsi termurah (paling mungkin disetujui), atau opsi pertama
    const opts = q.options || [];
    const cheapest = opts.reduce(
      (best, o) => (best && optionGrand(best) <= optionGrand(o) ? best : o),
      opts[0] as QuotationOption | undefined,
    );
    setDealOptionId(cheapest?.id || opts[0]?.id || '');
  };

  useEffect(() => {
    const unsub = subscribeQuotations((list) => setQuotations(list));
    return () => unsub();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return quotations.filter((item) => {
      if (filterStatus !== 'ALL' && item.status !== filterStatus) return false;
      if (!q) return true;
      return (
        item.clientName.toLowerCase().includes(q) ||
        (item.clientOrganization || '').toLowerCase().includes(q) ||
        (item.eventName || '').toLowerCase().includes(q) ||
        item.quotationNumber.toLowerCase().includes(q)
      );
    });
  }, [quotations, search, filterStatus]);

  const stats = useMemo(() => {
    const total = quotations.length;
    const deal = quotations.filter((q) => q.status === 'Deal').length;
    const pending = quotations.filter((q) => q.status === 'Draft' || q.status === 'Terkirim').length;
    const nilaiProspek = quotations
      .filter((q) => q.status === 'Draft' || q.status === 'Terkirim')
      .reduce((a, q) => a + quoteHeadline(q), 0);
    return { total, deal, pending, nilaiProspek };
  }, [quotations]);

  const openCreate = () => {
    setEditing(null);
    setShowEditor(true);
  };
  const openEdit = (q: Quotation) => {
    setEditing(q);
    setShowEditor(true);
  };

  const markStatus = async (q: Quotation, status: QuotationStatus) => {
    try {
      await saveQuotation({ ...q, status }, userEmail);
      showSuccess(`Status penawaran: ${status}.`);
    } catch {
      showError('Gagal memperbarui status.');
    }
  };

  const confirmDeal = async () => {
    if (!dealTarget) return;
    if (!dealOptionId) {
      showError('Pilih dulu paket yang disetujui klien.');
      return;
    }
    setIsProcessing(true);
    try {
      await convertQuotationToDeal(dealTarget, dealOptionId, userEmail);
      showSuccess('Penawaran jadi DEAL. Order dibuat di sistem (belum dibayar).');
      setDealTarget(null);
    } catch {
      showError('Gagal mengkonversi ke deal.');
    } finally {
      setIsProcessing(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setIsProcessing(true);
    try {
      await deleteQuotation(deleteTarget, userEmail);
      showSuccess('Penawaran dihapus.');
      setDeleteTarget(null);
    } catch {
      showError('Gagal menghapus penawaran.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <FileText className="w-6 h-6 text-blue-600" />
            Surat Penawaran
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Penawaran prospektif (belum dibayar). Tandai <b>Deal</b> untuk masuk ke sistem sebagai order.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowCatalog(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50"
          >
            <Package className="w-4 h-4" />
            Katalog Paket
          </button>
          <button
            onClick={openCreate}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700"
          >
            <Plus className="w-4 h-4" />
            Buat Penawaran
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200 rounded-xl p-3">
          <div className="text-[10px] uppercase text-slate-400 font-bold">Total Penawaran</div>
          <div className="text-lg font-black text-slate-800">{stats.total}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3">
          <div className="text-[10px] uppercase text-slate-400 font-bold">Menunggu / Prospek</div>
          <div className="text-lg font-black text-blue-600">{stats.pending}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3">
          <div className="text-[10px] uppercase text-slate-400 font-bold">Sudah Deal</div>
          <div className="text-lg font-black text-emerald-600">{stats.deal}</div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-3">
          <div className="text-[10px] uppercase text-slate-400 font-bold">Nilai Prospek</div>
          <div className="text-sm font-black text-slate-800">{formatRupiah(stats.nilaiProspek)}</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari klien, acara, atau nomor…"
            className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:border-blue-400"
          />
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          {(['ALL', 'Draft', 'Terkirim', 'Deal', 'Batal'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition ${
                filterStatus === s ? 'bg-white shadow-sm text-slate-800' : 'text-slate-500'
              }`}
            >
              {s === 'ALL' ? 'Semua' : s}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="text-center text-slate-400 py-16 border border-dashed border-slate-200 rounded-2xl">
          Belum ada surat penawaran. Klik <b>Buat Penawaran</b> untuk memulai.
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((q) => {
            const meta = STATUS_META[q.status];
            const isDeal = q.status === 'Deal';
            const isBatal = q.status === 'Batal';
            return (
              <div
                key={q.id}
                className="bg-white border border-slate-200 rounded-xl p-3.5 hover:border-blue-300 transition"
              >
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-slate-800">{q.clientName}</span>
                      {q.clientOrganization ? (
                        <span className="text-xs text-slate-500">· {q.clientOrganization}</span>
                      ) : null}
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${meta.cls}`}>
                        {meta.label}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2 flex-wrap">
                      <span className="font-mono">#{q.quotationNumber}</span>
                      {q.eventName ? <span>· {q.eventName}</span> : null}
                      <span>· {q.date}</span>
                      {(() => {
                        const opts = q.options || [];
                        const vals = opts.map(optionGrand);
                        const min = vals.length ? Math.min(...vals) : 0;
                        const max = vals.length ? Math.max(...vals) : 0;
                        const isSingle = opts.length === 1;
                        const items = isSingle ? opts[0].items || [] : [];
                        const paketCount = items.filter((it) => it.group === 'Paket').length;
                        const addonCount = items.filter(
                          (it) => it.group === 'Tambahan' && (Number(it.qty) || 0) > 0,
                        ).length;
                        return (
                          <>
                            <span>
                              {isSingle
                                ? `· ${paketCount} paket${addonCount > 0 ? ` + ${addonCount} add-on` : ''}`
                                : `· ${opts.length} opsi (versi lama)`}
                            </span>
                            <span className="font-bold text-slate-700">
                              ·{' '}
                              {min === max
                                ? formatRupiah(max)
                                : `${formatRupiah(min)} – ${formatRupiah(max)}`}
                            </span>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setPrinting(q)}
                      title="Cetak / Kirim"
                      className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                    {!isDeal ? (
                      <button
                        onClick={() => openEdit(q)}
                        title="Ubah"
                        className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                    ) : null}
                    {q.status === 'Draft' ? (
                      <button
                        onClick={() => markStatus(q, 'Terkirim')}
                        title="Tandai Terkirim"
                        className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    ) : null}
                    {!isDeal && !isBatal ? (
                      <>
                        <button
                          onClick={() => openDeal(q)}
                          title="Tandai Deal → masuk sistem"
                          className="flex items-center gap-1 px-2.5 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700"
                        >
                          <Handshake className="w-3.5 h-3.5" />
                          Deal
                        </button>
                        <button
                          onClick={() => markStatus(q, 'Batal')}
                          title="Batalkan"
                          className="p-2 text-rose-400 hover:bg-rose-50 rounded-lg"
                        >
                          <Ban className="w-4 h-4" />
                        </button>
                      </>
                    ) : null}
                    {!isDeal ? (
                      <button
                        onClick={() => setDeleteTarget(q)}
                        title="Hapus"
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    ) : null}
                  </div>
                </div>
                {isDeal && q.convertedOrderId ? (
                  <div className="mt-2 text-[11px] text-emerald-700 bg-emerald-50 rounded-lg px-2.5 py-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Sudah jadi order di sistem (belum dibayar). Catat pembayaran lewat Order Gabungan / Hotel / ATV.
                    <ExternalLink className="w-3 h-3" />
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}

      {/* Editor */}
      {showEditor ? (
        <QuotationEditorModal
          quotation={editing}
          userEmail={userEmail}
          onClose={() => setShowEditor(false)}
          onSaved={() => setShowEditor(false)}
        />
      ) : null}

      {/* Print / Output */}
      {printing ? (
        <QuotationPrintView
          quotation={printing}
          settings={getStoredSettings()}
          onClose={() => setPrinting(null)}
        />
      ) : null}

      {/* Catalog */}
      {showCatalog ? (
        <OfferPackageCatalogModal userEmail={userEmail} onClose={() => setShowCatalog(false)} />
      ) : null}

      {/* Deal confirm — pilih opsi yang disetujui klien */}
      {dealTarget ? (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-100">
              <Handshake className="w-5 h-5 text-emerald-600" />
              <div className="font-bold text-slate-800">Tandai sebagai Deal?</div>
            </div>
            <div className="p-5 overflow-auto text-xs space-y-3">
              <p className="text-slate-600">
                {(dealTarget.options || []).length > 1 ? (
                  <>
                    Pilih <b>paket yang disetujui klien</b> (penawaran versi lama memiliki beberapa paket).
                  </>
                ) : (
                  <>
                    Konfirmasi penawaran ini sebagai <b>DEAL</b>.
                  </>
                )}{' '}
                Isinya akan masuk ke sistem sebagai Order Gabungan — item/komponen <b>Hotel</b> → booking hotel,{' '}
                <b>ATV</b> → booking ATV, lainnya → Pendapatan Tambahan. Status pembayaran ={' '}
                <b>BELUM DIBAYAR</b> (DP &amp; pelunasan dicatat kemudian; DP masuk ke kamar lebih dulu).
              </p>
              <div className="space-y-2">
                {(dealTarget.options || []).map((o) => {
                  const picked = o.id === dealOptionId;
                  return (
                    <label
                      key={o.id}
                      className={`flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl border cursor-pointer transition ${
                        picked
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <input
                          type="radio"
                          name="deal-option"
                          checked={picked}
                          onChange={() => setDealOptionId(o.id)}
                          className="accent-emerald-600"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-800 truncate">{o.name}</div>
                          {o.capacityNote ? (
                            <div className="text-[11px] text-slate-500 truncate">{o.capacityNote}</div>
                          ) : null}
                        </div>
                      </div>
                      <div className="font-mono font-bold text-slate-700 shrink-0">
                        {formatRupiah(optionGrand(o))}
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-100 bg-slate-50">
              <button
                onClick={() => setDealTarget(null)}
                disabled={isProcessing}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100 disabled:opacity-60"
              >
                Batal
              </button>
              <button
                onClick={confirmDeal}
                disabled={isProcessing || !dealOptionId}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 disabled:opacity-60"
              >
                <Handshake className="w-4 h-4" />
                {isProcessing ? 'Memproses…' : 'Ya, Jadikan Deal'}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Delete confirm */}
      <Modal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Hapus penawaran?"
        description={
          deleteTarget
            ? `Surat penawaran #${deleteTarget.quotationNumber} (${deleteTarget.clientName}) akan dihapus permanen.`
            : ''
        }
        confirmLabel="Hapus"
        confirmVariant="danger"
        iconType="danger"
        isLoading={isProcessing}
      />
    </div>
  );
};

export default PenawaranView;
