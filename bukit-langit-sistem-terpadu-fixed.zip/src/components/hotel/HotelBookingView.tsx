import React, { useState, useEffect, useMemo } from 'react';
import { Booking, BusinessSettings, PaymentStatus, BookingStatus } from '../../types';
import {
  subscribeBookings,
  saveBooking,
  deleteBooking,
  deleteBookingsBatch,
  getBusinessSettings,
} from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  formatRupiah,
  formatDateIndo,
  getTodayDateString,
  calculatePaymentStatus,
  getPaymentStatusBadge,
} from '../../utils/formatters';
import { HotelBookingFormModal } from './HotelBookingFormModal';
import { HotelReportView } from './HotelReportView';
import { Modal } from '../common/Modal';
import { TransactionQuickDocWAModal } from '../documents/TransactionQuickDocWAModal';
import {
  Hotel,
  Plus,
  Search,
  Filter,
  BarChart3,
  Calendar,
  CreditCard,
  Edit2,
  Trash2,
  Phone,
  Utensils,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  CheckSquare,
  Square,
  FileText,
} from 'lucide-react';

interface HotelBookingViewProps {
  businessSettings?: BusinessSettings | null;
}

export const HotelBookingView: React.FC<HotelBookingViewProps> = ({ businessSettings }) => {
  const { userProfile, currentUser } = useAuth();
  const { showSuccess, showError } = useToast();

  const [activeTab, setActiveTab] = useState<'manage' | 'reports'>('manage');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Selection & Bulk Delete State
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState<boolean>(false);
  const [bulkDeleteReason, setBulkDeleteReason] = useState<string>('');

  // Filter States
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dateFilterType, setDateFilterType] = useState<'all' | 'today' | 'thisMonth' | 'custom'>('all');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [filterPaymentStatus, setFilterPaymentStatus] = useState<string>('all');
  const [filterOpStatus, setFilterOpStatus] = useState<string>('all');

  // Modal States
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [bookingToEdit, setBookingToEdit] = useState<Booking | null>(null);
  const [quickDocBooking, setQuickDocBooking] = useState<Booking | null>(null);

  // Delete Confirmation Modal State
  const [bookingToDelete, setBookingToDelete] = useState<Booking | null>(null);
  const [deleteReason, setDeleteReason] = useState<string>('');
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  // Subscribe to real-time bookings
  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeBookings(
      (data) => {
        setBookings(data);
        setIsLoading(false);
      },
      (error) => {
        console.error('Error fetching bookings:', error);
        showError('Gagal memuat data reservasi hotel.');
        setIsLoading(false);
      },
    );

    return () => unsubscribe();
  }, [showError]);

  // Quick stats calculation
  const stats = useMemo(() => {
    let totalPendapatan = 0;
    let lunasCount = 0;
    let dpCount = 0;
    let belumBayarCount = 0;

    bookings.forEach((b) => {
      if (b.status !== 'Cancelled') {
        totalPendapatan += b.pendapatan || (b.grandTotal - (b.agentFee || 0)) || 0;
      }
      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
      const st = calculatePaymentStatus(totalPaid, b.grandTotal);
      if (st === 'Lunas') lunasCount++;
      else if (st === 'DP') dpCount++;
      else belumBayarCount++;
    });

    return {
      total: bookings.length,
      totalPendapatan,
      lunasCount,
      dpCount,
      belumBayarCount,
    };
  }, [bookings]);

  // Filter logic
  const filteredBookings = useMemo(() => {
    const todayStr = getTodayDateString();
    const currentMonth = todayStr.substring(0, 7); // YYYY-MM

    return bookings.filter((b) => {
      // Search query matching
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = b.guestName.toLowerCase().includes(q);
        const matchPhone = b.guestPhone?.toLowerCase().includes(q);
        const matchId = b.id.toLowerCase().includes(q);
        const matchRoom = b.rooms?.some((r) => r.roomType.toLowerCase().includes(q)) || b.roomType?.toLowerCase().includes(q);
        if (!matchName && !matchPhone && !matchId && !matchRoom) return false;
      }

      // Date filtering (checks checkInDate or date)
      const bDate = b.checkInDate || b.date || '';
      if (dateFilterType === 'today') {
        if (b.checkInDate !== todayStr && b.date !== todayStr) return false;
      } else if (dateFilterType === 'thisMonth') {
        if (!bDate.startsWith(currentMonth)) return false;
      } else if (dateFilterType === 'custom') {
        if (customStartDate && bDate < customStartDate) return false;
        if (customEndDate && bDate > customEndDate) return false;
      }

      // Payment status filter
      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
      const payStatus = calculatePaymentStatus(totalPaid, b.grandTotal);
      if (filterPaymentStatus !== 'all' && payStatus !== filterPaymentStatus) {
        return false;
      }

      // Operational status filter
      if (filterOpStatus !== 'all' && b.status !== filterOpStatus) {
        return false;
      }

      return true;
    });
  }, [bookings, searchQuery, dateFilterType, customStartDate, customEndDate, filterPaymentStatus, filterOpStatus]);

  // Handlers
  const handleOpenAddModal = () => {
    setBookingToEdit(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEditModal = (booking: Booking) => {
    setBookingToEdit(booking);
    setIsFormModalOpen(true);
  };

  const handleSaveBooking = async (bookingData: Partial<Booking>): Promise<void> => {
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const isNew = !bookingData.id;

    // (1) Tampilkan toast "Reservasi tersimpan" segera (OPTIMISTIC)
    showSuccess(isNew ? 'Reservasi tersimpan' : 'Reservasi berhasil diperbarui');

    // (2) Panggil saveBooking TANPA await agar modal langsung menutup < 1 detik
    saveBooking(bookingData, userEmail)
      .then(async (savedId) => {
        const targetId = savedId || bookingData.id;
        // Booking saved successfully
      })
      .catch((err) => {
        console.error('Error saving booking to Firestore:', err);
        showError('Gagal sinkron ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  const handleDeleteClick = (booking: Booking) => {
    setBookingToDelete(booking);
    setDeleteReason('');
  };

  const handleConfirmDelete = () => {
    if (!bookingToDelete) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const targetBooking = bookingToDelete;
    const reason = deleteReason.trim();

    // (1) Langsung tutup modal konfirmasi dan tampilkan toast segera (OPTIMISTIC <1 detik)
    setBookingToDelete(null);
    setDeleteReason('');
    showSuccess(`Reservasi ${targetBooking.guestName} berhasil dihapus.`);

    // (2) Panggil deleteBooking TANPA await di latar belakang
    deleteBooking(targetBooking, userEmail, reason)
      .catch((err) => {
        console.error('Error deleting booking:', err);
        showError('Gagal sinkron hapus ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  // Selection Helpers
  const isAllSelected = filteredBookings.length > 0 && selectedIds.length === filteredBookings.length;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredBookings.map((b) => b.id));
    }
  };

  const toggleSelectRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleOpenBulkDeleteModal = () => {
    if (selectedIds.length === 0) return;
    setBulkDeleteReason('');
    setIsBulkDeleteModalOpen(true);
  };

  const handleConfirmBulkDelete = () => {
    if (selectedIds.length === 0) return;
    const userEmail = userProfile?.email || currentUser?.email || 'admin@bolang.id';
    const targetBookings = bookings.filter((b) => selectedIds.includes(b.id));
    const targetIds = [...selectedIds];
    const count = targetIds.length;
    const reason = bulkDeleteReason.trim();

    // (1) Tutup modal dan bersihkan pilihan segera (OPTIMISTIC <1 detik)
    setIsBulkDeleteModalOpen(false);
    setSelectedIds([]);
    setBulkDeleteReason('');
    showSuccess(`${count} reservasi hotel berhasil dihapus.`);

    // (2) Jalankan batch delete di latar belakang TANPA await di jalur UI
    deleteBookingsBatch(targetBookings, userEmail, reason)
      .catch((err) => {
        console.error('Error in batch delete bookings:', err);
        showError('Gagal sinkron hapus massal ke server: ' + (err instanceof Error ? err.message : 'Koneksi bermasalah.'));
      });
  };

  return (
    <div id="hotel-booking-module" className="space-y-6">
      {/* Top Header & Tab Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Hotel className="w-6 h-6 text-blue-600" />
            <span>Reservasi Hotel & Glamping</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola data pemesanan kamar, penghitungan diskon, DP/Pelunasan, dan laporan pendapatan.
          </p>
        </div>

        {/* View Switcher and Action Buttons */}
        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-slate-200/70 rounded-xl border border-slate-200 flex items-center">
            <button
              id="tab-manage-hotel"
              type="button"
              onClick={() => setActiveTab('manage')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeTab === 'manage'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Kelola Reservasi
            </button>
            <button
              id="tab-report-hotel"
              type="button"
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'reports'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Laporan & Analitik</span>
            </button>
          </div>

          {activeTab === 'manage' && (
            <button
              id="btn-add-hotel-booking"
              type="button"
              onClick={handleOpenAddModal}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Reservasi</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'reports' ? (
        <HotelReportView bookings={bookings} businessSettings={businessSettings} />
      ) : (
        <>
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Total Reservasi</span>
              <span className="text-lg font-bold text-slate-900">{stats.total}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Total Pendapatan</span>
              <span className="text-lg font-bold text-emerald-600">{formatRupiah(stats.totalPendapatan)}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Status Lunas</span>
              <span className="text-lg font-bold text-emerald-600">{stats.lunasCount}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Status DP</span>
              <span className="text-lg font-bold text-amber-600">{stats.dpCount}</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs col-span-2 sm:col-span-1">
              <span className="text-[11px] font-semibold text-slate-400 block uppercase">Belum Bayar</span>
              <span className="text-lg font-bold text-rose-600">{stats.belumBayarCount}</span>
            </div>
          </div>

          {/* Filter & Search Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              {/* Search Bar */}
              <div className="relative md:col-span-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="hotel-search-input"
                  type="text"
                  placeholder="Cari nama tamu, no. telepon, kamar, atau ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:bg-white focus:border-blue-600 transition-colors"
                />
              </div>

              {/* Payment Status Filter */}
              <div>
                <select
                  id="filter-hotel-payment-status"
                  value={filterPaymentStatus}
                  onChange={(e) => setFilterPaymentStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white focus:border-blue-600"
                >
                  <option value="all">Semua Status Bayar</option>
                  <option value="Lunas">Lunas</option>
                  <option value="DP">DP</option>
                  <option value="Belum Bayar">Belum Bayar</option>
                </select>
              </div>

              {/* Operational Status Filter */}
              <div>
                <select
                  id="filter-hotel-op-status"
                  value={filterOpStatus}
                  onChange={(e) => setFilterOpStatus(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white focus:border-blue-600"
                >
                  <option value="all">Semua Status Operasional</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Check-in">Check-in</option>
                  <option value="Check-out">Check-out</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            {/* Quick Date Filters */}
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100">
              <span className="text-xs text-slate-500 font-medium">Filter Tanggal:</span>
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setDateFilterType('all')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    dateFilterType === 'all' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Semua
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterType('today')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    dateFilterType === 'today' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Hari Ini
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterType('thisMonth')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    dateFilterType === 'thisMonth' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Bulan Ini
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterType('custom')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    dateFilterType === 'custom' ? 'bg-white text-slate-900 font-bold shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Kustom
                </button>
              </div>

              {dateFilterType === 'custom' && (
                <div className="flex items-center gap-1.5 animate-in fade-in duration-150">
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                    className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs text-slate-800"
                  />
                  <span className="text-xs text-slate-400">s/d</span>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                    className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs text-slate-800"
                  />
                </div>
              )}

              <span className="text-xs text-slate-400 ml-auto">
                Menampilkan <strong>{filteredBookings.length}</strong> data
              </span>
            </div>
          </div>

          {/* Bulk Selection Bar */}
          {selectedIds.length > 0 && (
            <div className="flex items-center justify-between bg-rose-50/90 border border-rose-200 p-3 rounded-xl text-xs text-rose-900 animate-in fade-in">
              <div className="flex items-center gap-2 font-semibold">
                <CheckSquare className="w-4 h-4 text-rose-600" />
                <span><strong>{selectedIds.length}</strong> reservasi dipilih</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedIds([])}
                  className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-rose-200 text-slate-700 rounded-lg font-medium cursor-pointer"
                >
                  Batal Pilihan
                </button>
                <button
                  type="button"
                  onClick={handleOpenBulkDeleteModal}
                  className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus Terpilih ({selectedIds.length})</span>
                </button>
              </div>
            </div>
          )}

          {/* Bookings Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {isLoading ? (
              <div className="py-16 text-center">
                <div className="w-8 h-8 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs text-slate-400">Memuat data reservasi...</p>
              </div>
            ) : filteredBookings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                      <th className="py-3 px-3 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={isAllSelected}
                          onChange={toggleSelectAll}
                          className="w-4 h-4 rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          title="Pilih Semua"
                        />
                      </th>
                      <th className="py-3 px-4">Tgl / Stay</th>
                      <th className="py-3 px-4">Tamu & Kontak</th>
                      <th className="py-3 px-4">Rincian Kamar</th>
                      <th className="py-3 px-4">Sumber</th>
                      <th className="py-3 px-4 text-right">Grand Total</th>
                      <th className="py-3 px-4 text-center">Status Bayar</th>
                      <th className="py-3 px-4 text-center">Operasional</th>
                      <th className="py-3 px-4 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {filteredBookings.map((b) => {
                      const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
                      const paymentStatus = calculatePaymentStatus(totalPaid, b.grandTotal);
                      const badge = getPaymentStatusBadge(paymentStatus);
                      const isRowSelected = selectedIds.includes(b.id);

                      const roomSummary = b.rooms && b.rooms.length > 0
                        ? b.rooms.map((r) => `${r.roomType} ×${r.roomQty} (${r.nights} mlm)`).join(', ')
                        : `${b.roomType || 'Standard'} ×${b.roomQty || 1} (${b.nights || 1} mlm)`;

                      return (
                        <tr
                          key={b.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            isRowSelected ? 'bg-blue-50/40' : ''
                          }`}
                        >
                          {/* Row Checkbox */}
                          <td className="py-3 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={isRowSelected}
                              onChange={() => toggleSelectRow(b.id)}
                              className="w-4 h-4 rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                            />
                          </td>

                          {/* Stay & Date */}
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">
                              {formatDateIndo(b.checkInDate)}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              Out: {formatDateIndo(b.checkOutDate)}
                            </div>
                          </td>

                          {/* Guest Name & Phone */}
                          <td className="py-3 px-4">
                            <div className="font-bold text-slate-900">{b.guestName}</div>
                            {b.guestPhone && (
                              <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span>{b.guestPhone}</span>
                              </div>
                            )}
                          </td>

                          {/* Rooms & Breakfast */}
                          <td className="py-3 px-4 max-w-xs">
                            <div className="font-medium text-slate-800 truncate" title={roomSummary}>
                              {roomSummary}
                            </div>
                            {b.includeBreakfast && (
                              <div className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded mt-0.5">
                                <Utensils className="w-2.5 h-2.5" />
                                <span>Incl. Breakfast</span>
                              </div>
                            )}
                          </td>

                          {/* Source */}
                          <td className="py-3 px-4">
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-medium rounded text-[11px]">
                              {b.bookingVia}
                            </span>
                          </td>

                          {/* Grand Total & Paid */}
                          <td className="py-3 px-4 text-right">
                            <div className="font-bold text-slate-900">
                              {formatRupiah(b.grandTotal)}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              Dibayar: {formatRupiah(totalPaid)}
                            </div>
                          </td>

                          {/* Payment Status Badge */}
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg} ${badge.text} ${badge.border}`}
                            >
                              {badge.label}
                            </span>
                          </td>

                          {/* Operational Status */}
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[11px] font-semibold ${
                                b.status === 'Confirmed'
                                  ? 'bg-blue-50 text-blue-700'
                                  : b.status === 'Check-in'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : b.status === 'Check-out'
                                  ? 'bg-slate-100 text-slate-600'
                                  : 'bg-rose-50 text-rose-600'
                              }`}
                            >
                              {b.status}
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setQuickDocBooking(b)}
                                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                                title="Buat Dokumen & Salin WhatsApp"
                              >
                                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Dokumen / WA</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEditModal(b)}
                                className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                title="Ubah Reservasi"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteClick(b)}
                                className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Hapus Reservasi"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-16 text-center">
                <Hotel className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-700">Belum Ada Data Reservasi</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Belum ada data reservasi yang tersimpan atau sesuai filter pencarian Anda. Klik tombol Tambah Reservasi di atas.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {/* Form Modal for Add/Edit */}
      {isFormModalOpen && (
        <HotelBookingFormModal
          isOpen={isFormModalOpen}
          onClose={() => setIsFormModalOpen(false)}
          bookingToEdit={bookingToEdit}
          onSave={handleSaveBooking}
          businessSettings={businessSettings}
          onOpenQuickDoc={(b) => setQuickDocBooking(b)}
        />
      )}

      {/* Quick Action Modal: Dokumen & Salin WhatsApp */}
      {quickDocBooking && (
        <TransactionQuickDocWAModal
          isOpen={!!quickDocBooking}
          onClose={() => setQuickDocBooking(null)}
          transaction={quickDocBooking}
          moduleType="hotel"
          businessSettings={businessSettings}
        />
      )}

      {/* Custom Single Delete Confirmation Modal (NO window.confirm) */}
      <Modal
        isOpen={!!bookingToDelete}
        onClose={() => setBookingToDelete(null)}
        title="Konfirmasi Hapus Reservasi"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Apakah Anda yakin ingin menghapus reservasi tamu{' '}
            <strong className="font-bold">{bookingToDelete?.guestName}</strong> (ID: {bookingToDelete?.id})?
            Data yang dihapus akan dicatat di riwayat penghapusan.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Alasan Penghapusan (Opsional):
            </label>
            <input
              type="text"
              placeholder="Contoh: Tamu membatalkan reservasi, salah input..."
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-blue-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setBookingToDelete(null)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              disabled={isDeleting}
              onClick={handleConfirmDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-50"
            >
              {isDeleting ? 'Menghapus...' : 'Hapus Reservasi'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Custom Bulk Delete Confirmation Modal */}
      <Modal
        isOpen={isBulkDeleteModalOpen}
        onClose={() => setIsBulkDeleteModalOpen(false)}
        title="Konfirmasi Hapus Massal Reservasi"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800">
            Apakah Anda yakin ingin menghapus <strong>{selectedIds.length} data reservasi hotel terpilih</strong>?
            Semua data terpilih beserta porsi sarapan terkait akan dihapus dan dicatat di riwayat penghapusan.
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Alasan Penghapusan Massal (Opsional):
            </label>
            <input
              type="text"
              placeholder="Contoh: Pembersihan data lama / pembatalan rombongan..."
              value={bulkDeleteReason}
              onChange={(e) => setBulkDeleteReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:bg-white focus:border-rose-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsBulkDeleteModalOpen(false)}
              className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium cursor-pointer"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleConfirmBulkDelete}
              className="px-4 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition-colors cursor-pointer"
            >
              Ya, Hapus {selectedIds.length} Reservasi
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
