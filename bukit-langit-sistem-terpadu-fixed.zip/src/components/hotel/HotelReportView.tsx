import React, { useState, useMemo } from 'react';
import { Booking, BusinessSettings } from '../../types';
import {
  formatRupiah,
  formatDateIndo,
  getTodayDateString,
  getPaymentStatusBadge,
  calculatePaymentStatus,
} from '../../utils/formatters';
import {
  Calendar,
  TrendingUp,
  CreditCard,
  Hotel,
  DollarSign,
  Printer,
  Users,
  Compass,
  ArrowUpDown,
  Filter,
  BarChart3,
} from 'lucide-react';

interface HotelReportViewProps {
  bookings: Booking[];
  businessSettings?: BusinessSettings | null;
}

export const HotelReportView: React.FC<HotelReportViewProps> = ({
  bookings,
  businessSettings,
}) => {
  // Report Filter State
  const [reportMode, setReportMode] = useState<'TRANSAKSI' | 'MENGINAP'>('TRANSAKSI');
  const [periodPreset, setPeriodPreset] = useState<'thisMonth' | 'lastMonth' | 'thisYear' | 'custom'>('thisMonth');

  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth(); // 0-11

  // Start and end of current month
  const firstDayThisMonth = new Date(currentYear, currentMonth, 1).toISOString().split('T')[0];
  const lastDayThisMonth = new Date(currentYear, currentMonth + 1, 0).toISOString().split('T')[0];

  const [startDate, setStartDate] = useState<string>(firstDayThisMonth);
  const [endDate, setEndDate] = useState<string>(lastDayThisMonth);

  // Handle Preset changes
  const handlePeriodPresetChange = (preset: 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom') => {
    setPeriodPreset(preset);
    if (preset === 'thisMonth') {
      const s = new Date(currentYear, currentMonth, 1).toISOString().split('T')[0];
      const e = new Date(currentYear, currentMonth + 1, 0).toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    } else if (preset === 'lastMonth') {
      const s = new Date(currentYear, currentMonth - 1, 1).toISOString().split('T')[0];
      const e = new Date(currentYear, currentMonth, 0).toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    } else if (preset === 'thisYear') {
      const s = `${currentYear}-01-01`;
      const e = `${currentYear}-12-31`;
      setStartDate(s);
      setEndDate(e);
    }
  };

  // Filtered Bookings based on Period and Mode
  const filteredBookings = useMemo(() => {
    return bookings.filter((b) => {
      // Exclude cancelled for revenue unless specified
      if (b.status === 'Cancelled') return false;

      const targetDate = reportMode === 'TRANSAKSI' ? b.date : (b.checkInDate || b.date);
      if (!targetDate) return false;

      if (startDate && targetDate < startDate) return false;
      if (endDate && targetDate > endDate) return false;
      return true;
    });
  }, [bookings, reportMode, startDate, endDate]);

  // Aggregate Metrics
  const metrics = useMemo(() => {
    let totalPendapatan = 0;
    let totalGrandTotal = 0;
    let totalDiscount = 0;
    let totalAgentFee = 0;
    let totalRoomsSold = 0;
    let totalNights = 0;
    let totalDibayar = 0;

    const paymentMethodMap: Record<string, { amount: number; count: number }> = {};
    const bookingSourceMap: Record<string, { amount: number; count: number }> = {};

    filteredBookings.forEach((b) => {
      totalPendapatan += b.pendapatan || (b.grandTotal - (b.agentFee || 0)) || 0;
      totalGrandTotal += b.grandTotal || 0;
      totalDiscount += b.discountAmount || 0;
      totalAgentFee += b.agentFee || 0;

      const paid = (b.dp || 0) + (b.pelunasan || 0);
      totalDibayar += paid;

      // Rooms count
      if (b.rooms && b.rooms.length > 0) {
        b.rooms.forEach((r) => {
          totalRoomsSold += Number(r.roomQty) || 1;
          totalNights += (Number(r.nights) || 1) * (Number(r.roomQty) || 1);
        });
      } else {
        totalRoomsSold += Number(b.roomQty) || 1;
        totalNights += (Number(b.nights) || 1) * (Number(b.roomQty) || 1);
      }

      // Booking Source aggregation
      const src = b.bookingVia || 'Walk in';
      if (!bookingSourceMap[src]) {
        bookingSourceMap[src] = { amount: 0, count: 0 };
      }
      bookingSourceMap[src].amount += b.grandTotal || 0;
      bookingSourceMap[src].count += 1;

      // Payment Breakdown: check paymentHistory if available, else check dp & pelunasan
      if (b.paymentHistory && b.paymentHistory.length > 0) {
        b.paymentHistory.forEach((p) => {
          const m = p.method || 'Lainnya';
          if (!paymentMethodMap[m]) {
            paymentMethodMap[m] = { amount: 0, count: 0 };
          }
          paymentMethodMap[m].amount += p.amount || 0;
          paymentMethodMap[m].count += 1;
        });
      } else {
        if (b.dp && b.dp > 0) {
          const m = b.dpMethod || 'Cash';
          if (!paymentMethodMap[m]) paymentMethodMap[m] = { amount: 0, count: 0 };
          paymentMethodMap[m].amount += b.dp;
          paymentMethodMap[m].count += 1;
        }
        if (b.pelunasan && b.pelunasan > 0) {
          const m = b.pelunasanMethod || 'Cash';
          if (!paymentMethodMap[m]) paymentMethodMap[m] = { amount: 0, count: 0 };
          paymentMethodMap[m].amount += b.pelunasan;
          paymentMethodMap[m].count += 1;
        }
      }
    });

    const avgBookingValue = filteredBookings.length > 0 ? Math.round(totalGrandTotal / filteredBookings.length) : 0;

    return {
      totalBookings: filteredBookings.length,
      totalPendapatan,
      totalGrandTotal,
      totalDiscount,
      totalAgentFee,
      totalRoomsSold,
      totalNights,
      totalDibayar,
      avgBookingValue,
      paymentMethodBreakdown: Object.entries(paymentMethodMap).sort((a, b) => b[1].amount - a[1].amount),
      bookingSourceBreakdown: Object.entries(bookingSourceMap).sort((a, b) => b[1].amount - a[1].amount),
    };
  }, [filteredBookings]);

  // Handle Print Action
  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="hotel-report-view" className="space-y-6">
      {/* Report Controls & Filter Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Mode Toggle: TRANSAKSI vs MENGINAP */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Mode Laporan:</span>
          <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setReportMode('TRANSAKSI')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                reportMode === 'TRANSAKSI'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mode Transaksi (`date`)
            </button>
            <button
              type="button"
              onClick={() => setReportMode('MENGINAP')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                reportMode === 'MENGINAP'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mode Menginap (`checkInDate`)
            </button>
          </div>
        </div>

        {/* Period Selector */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('thisMonth')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                periodPreset === 'thisMonth' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Bulan Ini
            </button>
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('lastMonth')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                periodPreset === 'lastMonth' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Bulan Lalu
            </button>
            <button
              type="button"
              onClick={() => handlePeriodPresetChange('thisYear')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                periodPreset === 'thisYear' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Tahun Ini
            </button>
            <button
              type="button"
              onClick={() => setPeriodPreset('custom')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                periodPreset === 'custom' ? 'bg-blue-600 text-white font-semibold' : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Kustom
            </button>
          </div>

          {/* Date Inputs */}
          <div className="flex items-center gap-1.5">
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:border-blue-600"
            />
            <span className="text-xs text-slate-400">s/d</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPeriodPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Print Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg transition-colors inline-flex items-center gap-1.5 cursor-pointer ml-auto sm:ml-0"
            title="Cetak Laporan"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Cetak / PDF</span>
          </button>
        </div>
      </div>

      {/* KPI Highlight Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Pendapatan Bersih */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Pendapatan Bersih
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.totalPendapatan)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Grand Total: {formatRupiah(metrics.totalGrandTotal)}
          </div>
        </div>

        {/* Jumlah Booking */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Reservasi
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <Hotel className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {metrics.totalBookings} Booking
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Total Unit Kamar: {metrics.totalRoomsSold} ({metrics.totalNights} Room Nights)
          </div>
        </div>

        {/* Rata-Rata Nilai Booking */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Rata-rata / Reservasi
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.avgBookingValue)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Agent Fee: {formatRupiah(metrics.totalAgentFee)}
          </div>
        </div>

        {/* Total Terbayar vs Piutang */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Realisasi Pembayaran
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-2">
            {formatRupiah(metrics.totalDibayar)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Diskon Diberikan: {formatRupiah(metrics.totalDiscount)}
          </div>
        </div>
      </div>

      {/* Breakdown Section: Payment Methods & Booking Sources */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Breakdown Per Metode Pembayaran */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Breakdown Metode Pembayaran</h3>
            </div>
            <span className="text-xs text-slate-400 font-medium">Dari Riwayat Pembayaran</span>
          </div>

          {metrics.paymentMethodBreakdown.length > 0 ? (
            <div className="space-y-3">
              {metrics.paymentMethodBreakdown.map(([method, data]) => {
                const percentage = metrics.totalDibayar > 0 ? Math.round((data.amount / metrics.totalDibayar) * 100) : 0;
                return (
                  <div key={method} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-800">{method}</span>
                        <span className="text-slate-400 text-[11px]">({data.count} transaksi)</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-900">{formatRupiah(data.amount)}</span>
                        <span className="text-slate-400 text-[11px] ml-1.5">({percentage}%)</span>
                      </div>
                    </div>
                    {/* Progress bar */}
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-400">
              Belum ada data transaksi pembayaran pada periode ini.
            </div>
          )}
        </div>

        {/* Breakdown Per Sumber Booking */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">Breakdown Sumber Reservasi (`bookingVia`)</h3>
            </div>
            <span className="text-xs text-slate-400 font-medium">Dari Grand Total</span>
          </div>

          {metrics.bookingSourceBreakdown.length > 0 ? (
            <div className="space-y-3">
              {metrics.bookingSourceBreakdown.map(([source, data]) => {
                const percentage = metrics.totalGrandTotal > 0 ? Math.round((data.amount / metrics.totalGrandTotal) * 100) : 0;
                return (
                  <div key={source} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-800">{source}</span>
                        <span className="text-slate-400 text-[11px]">({data.count} reservasi)</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-slate-900">{formatRupiah(data.amount)}</span>
                        <span className="text-slate-400 text-[11px] ml-1.5">({percentage}%)</span>
                      </div>
                    </div>
                    {/* Progress bar */}
                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-400">
              Belum ada data reservasi pada periode ini.
            </div>
          )}
        </div>
      </div>

      {/* Rincian Transaksi Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Rincian Reservasi Periode {formatDateIndo(startDate)} s/d {formatDateIndo(endDate)} ({filteredBookings.length})
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Tgl Transaksi</th>
                <th className="py-3 px-4">Tamu</th>
                <th className="py-3 px-4">Check In/Out</th>
                <th className="py-3 px-4">Sumber</th>
                <th className="py-3 px-4">Kamar</th>
                <th className="py-3 px-4 text-right">Grand Total</th>
                <th className="py-3 px-4 text-right">Terbayar</th>
                <th className="py-3 px-4 text-center">Status Bayar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredBookings.map((b) => {
                const totalPaid = (b.dp || 0) + (b.pelunasan || 0);
                const paymentStatus = calculatePaymentStatus(totalPaid, b.grandTotal);
                const badge = getPaymentStatusBadge(paymentStatus);

                const roomSummary = b.rooms && b.rooms.length > 0
                  ? b.rooms.map((r) => `${r.roomType} ×${r.roomQty}`).join(', ')
                  : `${b.roomType || 'Standard'} ×${b.roomQty || 1}`;

                return (
                  <tr key={b.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-medium text-slate-900">{formatDateIndo(b.date)}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{b.guestName}</td>
                    <td className="py-3 px-4 text-slate-500">
                      {formatDateIndo(b.checkInDate)} - {formatDateIndo(b.checkOutDate)}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 bg-slate-100 rounded text-[11px] text-slate-700 font-medium">
                        {b.bookingVia}
                      </span>
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate" title={roomSummary}>
                      {roomSummary}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-slate-900">
                      {formatRupiah(b.grandTotal)}
                    </td>
                    <td className="py-3 px-4 text-right font-medium text-slate-700">
                      {formatRupiah(totalPaid)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg} ${badge.text} ${badge.border}`}
                      >
                        {badge.label}
                      </span>
                    </td>
                  </tr>
                );
              })}

              {filteredBookings.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-400 text-xs">
                    Tidak ada reservasi yang sesuai dengan periode laporan ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
