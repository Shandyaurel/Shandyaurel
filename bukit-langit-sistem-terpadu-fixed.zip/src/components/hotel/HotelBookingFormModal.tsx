import React, { useState, useEffect } from 'react';
import {
  Booking,
  BookingRoomItem,
  DiscountType,
  BookingStatus,
  BusinessSettings,
  PaymentRecord,
  ClientContact,
} from '../../types';
import { subscribePartners } from '../../utils/firebase';
import {
  DEFAULT_BOOKING_SOURCES,
  DEFAULT_PAYMENT_METHODS,
  DEFAULT_ROOM_TYPES,
  formatRupiah,
  formatDateIndo,
  getTodayDateString,
  getCurrentTimeString,
  calculateBookingCalculations,
  getPaymentStatusBadge,
} from '../../utils/formatters';
import { Modal } from '../common/Modal';
import {
  Plus,
  Trash2,
  Hotel,
  Calendar,
  CreditCard,
  User,
  Clock,
  Sparkles,
  Utensils,
  Percent,
  CheckCircle,
  HelpCircle,
  Handshake,
  Building2,
  FileText,
} from 'lucide-react';

interface HotelBookingFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingToEdit?: Booking | null;
  onSave: (bookingData: Partial<Booking>) => Promise<void>;
  businessSettings?: BusinessSettings | null;
  onOpenQuickDoc?: (booking: Booking) => void;
}

export const HotelBookingFormModal: React.FC<HotelBookingFormModalProps> = ({
  isOpen,
  onClose,
  bookingToEdit,
  onSave,
  businessSettings,
  onOpenQuickDoc,
}) => {
  const isEditing = !!bookingToEdit;

  // Form State
  const [date, setDate] = useState<string>(getTodayDateString());
  const [checkInDate, setCheckInDate] = useState<string>(getTodayDateString());
  const [checkOutDate, setCheckOutDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  });
  const [guestName, setGuestName] = useState<string>('');
  const [guestPhone, setGuestPhone] = useState<string>('');
  const [guestEmail, setGuestEmail] = useState<string>('');
  const [sourceType, setSourceType] = useState<string>('Walk in');
  const [bookingVia, setBookingVia] = useState<string>('Walk in');
  const [partnerId, setPartnerId] = useState<string>('');
  const [partners, setPartners] = useState<ClientContact[]>([]);
  const [includeBreakfast, setIncludeBreakfast] = useState<boolean>(true);
  const [breakfastPaxPerNight, setBreakfastPaxPerNight] = useState<number>(2);
  const [status, setStatus] = useState<BookingStatus>('Confirmed');
  const [notes, setNotes] = useState<string>('');

  // Multi-room Repeater State
  const [rooms, setRooms] = useState<BookingRoomItem[]>([
    {
      roomType: DEFAULT_ROOM_TYPES[0].name,
      roomQty: 1,
      roomPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
      nights: 1,
      stayDate: getTodayDateString(),
    },
  ]);

  // Financial & Discount State
  const [discountType, setDiscountType] = useState<DiscountType>('Nominal');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [agentFee, setAgentFee] = useState<number>(0);

  // Payment State
  const [dp, setDp] = useState<number>(0);
  const [dpDate, setDpDate] = useState<string>(getTodayDateString());
  const [dpTime, setDpTime] = useState<string>(getCurrentTimeString());
  const [dpMethod, setDpMethod] = useState<string>('Transfer (PT)');

  const [pelunasan, setPelunasan] = useState<number>(0);
  const [pelunasanDate, setPelunasanDate] = useState<string>('');
  const [pelunasanTime, setPelunasanTime] = useState<string>('');
  const [pelunasanMethod, setPelunasanMethod] = useState<string>('Cash');

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  // Combined sources & payment methods
  const bookingSources = Array.from(
    new Set([...DEFAULT_BOOKING_SOURCES, ...(businessSettings?.customBookingSources || [])]),
  );
  const paymentMethods = Array.from(
    new Set([...DEFAULT_PAYMENT_METHODS, ...(businessSettings?.customPaymentMethods || [])]),
  );

  useEffect(() => {
    if (!isOpen) return;
    const unsub = subscribePartners(
      (list) => setPartners(list),
      (err) => console.error('Error fetching partners:', err),
    );
    return () => unsub();
  }, [isOpen]);

  // Populate when opening for edit or new
  useEffect(() => {
    if (!isOpen) return;

    if (bookingToEdit) {
      setDate(bookingToEdit.date || getTodayDateString());
      setCheckInDate(bookingToEdit.checkInDate || getTodayDateString());
      setCheckOutDate(bookingToEdit.checkOutDate || '');
      setGuestName(bookingToEdit.guestName || '');
      setGuestPhone(bookingToEdit.guestPhone || '');
      setGuestEmail(bookingToEdit.guestEmail || '');
      setBookingVia(bookingToEdit.bookingVia || 'Walk in');
      setPartnerId(bookingToEdit.partnerId || '');
      if (bookingToEdit.partnerId || (bookingToEdit.bookingVia && (bookingToEdit.bookingVia.toLowerCase().includes('mitra') || bookingToEdit.bookingVia.toLowerCase().includes('agent')))) {
        setSourceType('Tour Agent / Mitra');
      } else {
        setSourceType(bookingToEdit.bookingVia || 'Walk in');
      }
      setIncludeBreakfast(bookingToEdit.includeBreakfast ?? true);
      setBreakfastPaxPerNight(bookingToEdit.breakfastPaxPerNight ?? 2);
      setStatus(bookingToEdit.status || 'Confirmed');
      setNotes(bookingToEdit.notes || '');

      // Rooms
      if (bookingToEdit.rooms && bookingToEdit.rooms.length > 0) {
        setRooms(bookingToEdit.rooms.map((r) => ({ ...r })));
      } else {
        setRooms([
          {
            roomType: bookingToEdit.roomType || DEFAULT_ROOM_TYPES[0].name,
            roomQty: bookingToEdit.roomQty || 1,
            roomPrice: bookingToEdit.roomPrice || DEFAULT_ROOM_TYPES[0].defaultPrice,
            nights: bookingToEdit.nights || 1,
            stayDate: bookingToEdit.checkInDate || getTodayDateString(),
          },
        ]);
      }

      setDiscountType(bookingToEdit.discountType || 'Nominal');
      setDiscountValue(bookingToEdit.discountValue || 0);
      setAgentFee(bookingToEdit.agentFee || 0);

      setDp(bookingToEdit.dp || 0);
      setDpDate(bookingToEdit.dpDate || bookingToEdit.date || getTodayDateString());
      setDpTime(bookingToEdit.dpTime || '12:00');
      setDpMethod(bookingToEdit.dpMethod || 'Transfer (PT)');

      setPelunasan(bookingToEdit.pelunasan || 0);
      setPelunasanDate(bookingToEdit.pelunasanDate || '');
      setPelunasanTime(bookingToEdit.pelunasanTime || '');
      setPelunasanMethod(bookingToEdit.pelunasanMethod || 'Cash');
    } else {
      // Reset for new booking
      const today = getTodayDateString();
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      setDate(today);
      setCheckInDate(today);
      setCheckOutDate(tomorrowStr);
      setGuestName('');
      setGuestPhone('');
      setGuestEmail('');
      setSourceType('Walk in');
      setBookingVia('Walk in');
      setPartnerId('');
      setIncludeBreakfast(true);
      setBreakfastPaxPerNight(businessSettings?.breakfastDefaultPaxPerNight || 2);
      setStatus('Confirmed');
      setNotes('');

      setRooms([
        {
          roomType: DEFAULT_ROOM_TYPES[0].name,
          roomQty: 1,
          roomPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
          nights: 1,
          stayDate: today,
        },
      ]);

      setDiscountType('Nominal');
      setDiscountValue(0);
      setAgentFee(0);

      setDp(0);
      setDpDate(today);
      setDpTime(getCurrentTimeString());
      setDpMethod('Transfer (PT)');

      setPelunasan(0);
      setPelunasanDate('');
      setPelunasanTime('');
      setPelunasanMethod('Cash');
    }
    setFormError('');
  }, [isOpen, bookingToEdit]);

  // Recalculate nights when check-in or check-out changes
  const handleCheckDatesChange = (newIn: string, newOut: string) => {
    setCheckInDate(newIn);
    setCheckOutDate(newOut);

    if (newIn && newOut) {
      const inDate = new Date(newIn);
      const outDate = new Date(newOut);
      const diffTime = outDate.getTime() - inDate.getTime();
      const diffDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

      if (diffDays > 0) {
        setRooms((prev) =>
          prev.map((r) => ({
            ...r,
            nights: diffDays,
            stayDate: newIn,
          })),
        );
      }
    }
  };

  // Rooms repeater helpers
  const handleAddRoom = () => {
    setRooms((prev) => [
      ...prev,
      {
        roomType: DEFAULT_ROOM_TYPES[0].name,
        roomQty: 1,
        roomPrice: DEFAULT_ROOM_TYPES[0].defaultPrice,
        nights: rooms[0]?.nights || 1,
        stayDate: checkInDate,
      },
    ]);
  };

  const handleRemoveRoom = (index: number) => {
    if (rooms.length <= 1) return;
    setRooms((prev) => prev.filter((_, i) => i !== index));
  };

  const handleRoomFieldChange = (
    index: number,
    field: keyof BookingRoomItem,
    value: string | number,
  ) => {
    setRooms((prev) => {
      const copy = [...prev];
      const target = { ...copy[index] };

      if (field === 'roomType') {
        target.roomType = String(value);
        // auto-fill preset price if match
        const found = DEFAULT_ROOM_TYPES.find((p) => p.name === value);
        if (found) {
          target.roomPrice = found.defaultPrice;
        }
      } else if (field === 'roomQty') {
        target.roomQty = Math.max(1, Number(value) || 1);
      } else if (field === 'roomPrice') {
        target.roomPrice = Math.max(0, Number(value) || 0);
      } else if (field === 'nights') {
        target.nights = Math.max(1, Number(value) || 1);
      } else if (field === 'stayDate') {
        target.stayDate = String(value);
      }

      copy[index] = target;
      return copy;
    });
  };

  // Calculations
  const calc = calculateBookingCalculations({
    rooms,
    discountType,
    discountValue,
    agentFee,
    dp,
    pelunasan,
  });

  const paymentBadge = getPaymentStatusBadge(calc.paymentStatus);

  // Quick Pay Helper: set Pelunasan to remaining balance
  const handlePayFullRemaining = () => {
    const remaining = Math.max(0, calc.grandTotal - (Number(dp) || 0));
    setPelunasan(remaining);
    if (!pelunasanDate) setPelunasanDate(getTodayDateString());
    if (!pelunasanTime) setPelunasanTime(getCurrentTimeString());
  };

  // Submit Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!guestName.trim()) {
      setFormError('Nama tamu wajib diisi.');
      return;
    }

    if (rooms.length === 0) {
      setFormError('Minimal harus memilih 1 kamar.');
      return;
    }

    // Build payment history records
    const paymentHistory: PaymentRecord[] = [];
    if (dp > 0) {
      paymentHistory.push({
        id: `pay_dp_${Date.now()}`,
        date: dpDate || date || getTodayDateString(),
        time: dpTime || '12:00',
        amount: Number(dp),
        method: dpMethod,
        type: 'DP',
        notes: 'Pembayaran DP / Uang Muka',
      });
    }
    if (pelunasan > 0) {
      paymentHistory.push({
        id: `pay_lunas_${Date.now() + 1}`,
        date: pelunasanDate || date || getTodayDateString(),
        time: pelunasanTime || getCurrentTimeString(),
        amount: Number(pelunasan),
        method: pelunasanMethod,
        type: 'Pelunasan',
        notes: 'Pelunasan Pembayaran',
      });
    }

    const selectedPartnerObj = partnerId ? partners.find((p) => p.id === partnerId) : undefined;
    const finalBookingVia = partnerId && selectedPartnerObj ? selectedPartnerObj.name : bookingVia;

    const payload: Partial<Booking> = {
      ...(bookingToEdit ? { id: bookingToEdit.id } : {}),
      date,
      checkInDate,
      checkOutDate,
      guestName: guestName.trim(),
      guestPhone: guestPhone.trim(),
      guestEmail: guestEmail.trim(),
      bookingVia: finalBookingVia,
      partnerId: partnerId || undefined,
      partnerName: selectedPartnerObj ? selectedPartnerObj.name : undefined,
      rooms,
      discountType,
      discountValue: Number(discountValue) || 0,
      discountAmount: calc.discountAmount,
      agentFee: Number(agentFee) || 0,
      grandTotal: calc.grandTotal,
      dp: Number(dp) || 0,
      dpDate: dp > 0 ? dpDate : '',
      dpTime: dp > 0 ? dpTime : '',
      dpMethod: dp > 0 ? dpMethod : '',
      pelunasan: Number(pelunasan) || 0,
      pelunasanDate: pelunasan > 0 ? pelunasanDate : '',
      pelunasanTime: pelunasan > 0 ? pelunasanTime : '',
      pelunasanMethod: pelunasan > 0 ? pelunasanMethod : '',
      paymentHistory,
      pendapatan: calc.pendapatan,
      status,
      paymentMethod: dpMethod || pelunasanMethod || 'Cash',
      includeBreakfast,
      breakfastPaxPerNight: includeBreakfast ? breakfastPaxPerNight : undefined,
      notes: notes.trim(),
    };

    try {
      setIsSaving(true);
      await onSave(payload);
      onClose();
    } catch (err) {
      console.error('Error saving booking:', err);
      setFormError('Gagal menyimpan reservasi. Silakan periksa koneksi.');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  const selectedPartner = partnerId ? partners.find((p) => p.id === partnerId) : undefined;

  return (
    <div
      id="hotel-booking-form-modal"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
    >
      <div className="relative bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Hotel className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isEditing ? `Ubah Reservasi Kamar (${bookingToEdit.id})` : 'Tambah Reservasi Hotel / Glamping Baru'}
              </h2>
              <p className="text-xs text-slate-500">
                Lengkapi rincian kamar, diskon, dan catatan pembayaran tamu.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isEditing && bookingToEdit && onOpenQuickDoc && (
              <button
                type="button"
                onClick={() => onOpenQuickDoc(bookingToEdit)}
                className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Buka Dokumen & Salin WhatsApp"
              >
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                <span>Dokumen & WA</span>
              </button>
            )}
            <button
              id="btn-close-hotel-modal"
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {formError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-semibold text-rose-700">
              {formError}
            </div>
          )}

          {/* Section 1: Informasi Tamu & Tanggal */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-4">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <User className="w-4 h-4 text-blue-600" />
              <span>Informasi Tamu & Periode Menginap</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Tamu / Pemesan <span className="text-rose-500">*</span>
                </label>
                <input
                  id="hotel-guest-name"
                  type="text"
                  required
                  placeholder="Contoh: Bpk. Hendra Gunawan / Rombongan PT ABC"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Sumber Pemesanan
                </label>
                <select
                  id="hotel-booking-via"
                  value={sourceType}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSourceType(val);
                    if (val === 'Tour Agent / Mitra') {
                      if (!partnerId && partners.length > 0) {
                        setPartnerId(partners[0].id);
                        setBookingVia(partners[0].name);
                      }
                    } else {
                      setPartnerId('');
                      setBookingVia(val);
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-blue-600 font-medium"
                >
                  <option value="Walk in">Walk in (Langsung di Lokasi)</option>
                  <option value="Direct WA">Direct WhatsApp / Telepon</option>
                  <option value="Instagram">Instagram</option>
                  <option value="TikTok">TikTok</option>
                  <option value="Website">Website Resmi</option>
                  <option value="OTA">OTA (Agoda / Traveloka / Booking)</option>
                  <option value="Tour Agent / Mitra">Tour Agent / Mitra Bisnis</option>
                  {businessSettings?.customBookingSources?.filter((s) => !['Walk in', 'Direct WA', 'Instagram', 'TikTok', 'Website', 'OTA', 'Tour Agent / Mitra'].includes(s)).map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Sub-dropdown when Tour Agent / Mitra is selected */}
            {(sourceType === 'Tour Agent / Mitra' || partnerId) && (
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900">
                  <Handshake className="w-4 h-4 text-blue-600" />
                  <span>Pilih Mitra Bisnis / Travel Agent Terdaftar</span>
                </div>
                {partners.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
                    <select
                      value={partnerId}
                      onChange={(e) => {
                        const pId = e.target.value;
                        setPartnerId(pId);
                        const pObj = partners.find((p) => p.id === pId);
                        if (pObj) {
                          setBookingVia(pObj.name);
                        }
                      }}
                      className="w-full px-3 py-2 bg-white border border-blue-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    >
                      <option value="">-- Pilih Mitra --</option>
                      {partners.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} {p.detail ? `(${p.detail})` : ''} - {p.homeBase || 'Lokal'}
                        </option>
                      ))}
                    </select>
                    {selectedPartner && (
                      <div className="text-[11px] text-blue-800 bg-white px-2.5 py-1.5 rounded-lg border border-blue-100 flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span className="truncate">
                          PIC: <strong>{selectedPartner.contactPerson || '-'}</strong> | Telp: {selectedPartner.phone || '-'}
                        </span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    Belum ada mitra bisnis tersimpan. Anda dapat mendaftarkan mitra di menu <strong>Mitra Bisnis</strong>.
                  </p>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  No. WhatsApp / HP
                </label>
                <input
                  id="hotel-guest-phone"
                  type="text"
                  placeholder="08123456789"
                  value={guestPhone}
                  onChange={(e) => setGuestPhone(e.target.value)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tanggal Transaksi (`date`)
                </label>
                <input
                  id="hotel-transaction-date"
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Check-In
                </label>
                <input
                  id="hotel-checkin-date"
                  type="date"
                  required
                  value={checkInDate}
                  onChange={(e) => handleCheckDatesChange(e.target.value, checkOutDate)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Check-Out
                </label>
                <input
                  id="hotel-checkout-date"
                  type="date"
                  required
                  value={checkOutDate}
                  onChange={(e) => handleCheckDatesChange(checkInDate, e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:border-blue-600"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200/60">
              <div className="flex flex-wrap items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    id="hotel-include-breakfast"
                    type="checkbox"
                    checked={includeBreakfast}
                    onChange={(e) => setIncludeBreakfast(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded-sm border-slate-300 focus:ring-blue-500"
                  />
                  <span className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                    <Utensils className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Termasuk Sarapan (Include Breakfast)</span>
                  </span>
                </label>

                {includeBreakfast && (
                  <div className="flex items-center gap-2 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 text-xs">
                    <span className="font-semibold text-emerald-800">Porsi / Malam:</span>
                    <input
                      type="number"
                      min={1}
                      max={99}
                      value={breakfastPaxPerNight}
                      onChange={(e) => setBreakfastPaxPerNight(Math.max(1, parseInt(e.target.value, 10) || 1))}
                      className="w-14 px-2 py-0.5 bg-white border border-emerald-300 rounded text-center font-bold text-emerald-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] text-emerald-700 font-medium">Pax</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-600">Status Operasional:</label>
                <select
                  id="hotel-status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as BookingStatus)}
                  className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-hidden focus:border-blue-600"
                >
                  <option value="Confirmed">Confirmed</option>
                  <option value="Check-in">Check-in</option>
                  <option value="Check-out">Check-out</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Multi-Kamar Repeater */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <Hotel className="w-4 h-4 text-blue-600" />
                <span>Daftar Kamar & Tenda ({rooms.length})</span>
              </h3>
              <button
                id="btn-add-room-item"
                type="button"
                onClick={handleAddRoom}
                className="px-3 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Tipe Kamar</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {rooms.map((room, idx) => {
                const roomSubtotal = (Number(room.roomPrice) || 0) * (Number(room.roomQty) || 1) * (Number(room.nights) || 1);

                return (
                  <div
                    key={idx}
                    className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center gap-3"
                  >
                    <div className="flex-1 grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                      {/* Room Type */}
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Tipe Kamar #{idx + 1}
                        </label>
                        <div className="flex gap-1.5">
                          <select
                            value={room.roomType}
                            onChange={(e) => handleRoomFieldChange(idx, 'roomType', e.target.value)}
                            className="flex-1 px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 focus:outline-hidden focus:bg-white focus:border-blue-600"
                          >
                            {DEFAULT_ROOM_TYPES.map((p) => (
                              <option key={p.name} value={p.name}>
                                {p.name} ({formatRupiah(p.defaultPrice)})
                              </option>
                            ))}
                            <option value="Custom Room">Kustom Lainnya...</option>
                          </select>
                        </div>
                      </div>

                      {/* Quantity */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Jumlah Unit
                        </label>
                        <input
                          type="number"
                          min="1"
                          value={room.roomQty}
                          onChange={(e) => handleRoomFieldChange(idx, 'roomQty', e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 text-center focus:outline-hidden focus:bg-white focus:border-blue-600"
                        />
                      </div>

                      {/* Price per night */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Harga/Malam (Rp)
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="10000"
                          value={room.roomPrice}
                          onChange={(e) => handleRoomFieldChange(idx, 'roomPrice', e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 text-right focus:outline-hidden focus:bg-white focus:border-blue-600"
                        />
                      </div>
                    </div>

                    {/* Nights & Subtotal */}
                    <div className="flex items-center justify-between md:justify-end gap-3 border-t md:border-t-0 pt-2 md:pt-0 border-slate-100 shrink-0">
                      <div className="text-left md:text-right">
                        <div className="text-[10px] text-slate-400 font-medium">
                          {room.nights} malam × {room.roomQty} unit
                        </div>
                        <div className="text-xs font-bold text-slate-900">
                          {formatRupiah(roomSubtotal)}
                        </div>
                      </div>

                      {rooms.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveRoom(idx)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="Hapus Kamar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 3: Diskon & Agent Fee */}
          <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
              <Percent className="w-4 h-4 text-blue-600" />
              <span>Potongan Harga & Komisi Agent</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Discount Type */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tipe Diskon
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDiscountType('Nominal')}
                    className={`py-1.5 px-3 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      discountType === 'Nominal'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Nominal (Rp)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiscountType('Persen')}
                    className={`py-1.5 px-3 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      discountType === 'Persen'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Persen (%)
                  </button>
                </div>
              </div>

              {/* Discount Value */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nilai Diskon ({discountType === 'Persen' ? '%' : 'Rp'})
                </label>
                <input
                  id="hotel-discount-value"
                  type="number"
                  min="0"
                  max={discountType === 'Persen' ? 100 : undefined}
                  value={discountValue}
                  onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600 text-right"
                />
                {discountType === 'Persen' && (
                  <span className="text-[11px] text-slate-500 mt-0.5 block text-right">
                    Potongan: {formatRupiah(calc.discountAmount)}
                  </span>
                )}
              </div>

              {/* Agent Fee */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Agent Fee / Komisi (Rp)
                </label>
                <input
                  id="hotel-agent-fee"
                  type="number"
                  min="0"
                  step="10000"
                  value={agentFee}
                  onChange={(e) => setAgentFee(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:border-blue-600 text-right"
                />
                <span className="text-[11px] text-slate-500 mt-0.5 block text-right">
                  Dipotong dari Pendapatan
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Ringkasan Biaya Live */}
          <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-500 block font-medium">Subtotal Kamar</span>
              <span className="text-sm font-semibold text-slate-800">{formatRupiah(calc.subtotal)}</span>
            </div>
            {calc.discountAmount > 0 && (
              <div>
                <span className="text-xs text-rose-500 block font-medium">Diskon</span>
                <span className="text-sm font-semibold text-rose-600">−{formatRupiah(calc.discountAmount)}</span>
              </div>
            )}
            <div>
              <span className="text-xs text-blue-600 block font-bold uppercase tracking-wider">Grand Total</span>
              <span className="text-lg font-extrabold text-blue-900">{formatRupiah(calc.grandTotal)}</span>
            </div>
            <div>
              <span className="text-xs text-slate-500 block font-medium">Pendapatan Bersih</span>
              <span className="text-sm font-bold text-emerald-700">{formatRupiah(calc.pendapatan)}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Status Bayar:</span>
              <span
                className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${paymentBadge.bg} ${paymentBadge.text} ${paymentBadge.border}`}
              >
                {paymentBadge.label}
              </span>
            </div>
          </div>

          {/* Section 5: Pembayaran DP & Pelunasan */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-600" />
                <span>Pencatatan Pembayaran (DP & Pelunasan)</span>
              </h3>
              {calc.sisa > 0 && (
                <button
                  type="button"
                  onClick={handlePayFullRemaining}
                  className="text-xs text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
                >
                  Lunaskan Sisa ({formatRupiah(calc.sisa)})
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* DP Card */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>Uang Muka (DP)</span>
                  </span>
                  <span className="text-xs text-slate-400">Tahap 1</span>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Jumlah DP (Rp)
                  </label>
                  <input
                    id="hotel-dp-amount"
                    type="number"
                    min="0"
                    step="10000"
                    placeholder="0"
                    value={dp}
                    onChange={(e) => setDp(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:bg-white focus:border-blue-600 font-semibold text-right"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Tanggal DP</label>
                    <input
                      type="date"
                      value={dpDate}
                      onChange={(e) => setDpDate(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Jam DP</label>
                    <input
                      type="time"
                      value={dpTime}
                      onChange={(e) => setDpTime(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Metode Bayar DP</label>
                  <select
                    value={dpMethod}
                    onChange={(e) => setDpMethod(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                  >
                    {paymentMethods.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Pelunasan Card */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>Pelunasan</span>
                  </span>
                  <span className="text-xs text-slate-400">Tahap 2</span>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Jumlah Pelunasan (Rp)
                  </label>
                  <input
                    id="hotel-pelunasan-amount"
                    type="number"
                    min="0"
                    step="10000"
                    placeholder="0"
                    value={pelunasan}
                    onChange={(e) => setPelunasan(Number(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-hidden focus:bg-white focus:border-blue-600 font-semibold text-right"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Tanggal Lunas</label>
                    <input
                      type="date"
                      value={pelunasanDate}
                      onChange={(e) => setPelunasanDate(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Jam Lunas</label>
                    <input
                      type="time"
                      value={pelunasanTime}
                      onChange={(e) => setPelunasanTime(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">Metode Pelunasan</label>
                  <select
                    value={pelunasanMethod}
                    onChange={(e) => setPelunasanMethod(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:bg-white"
                  >
                    {paymentMethods.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Payment Summary Footer */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
              <div className="text-slate-600">
                Total Telah Dibayar: <strong className="text-slate-900">{formatRupiah(calc.totalDibayar)}</strong>
              </div>
              <div className="text-slate-600">
                Sisa Tagihan:{' '}
                <strong className={calc.sisa > 0 ? 'text-rose-600 font-bold' : 'text-emerald-600 font-bold'}>
                  {formatRupiah(calc.sisa)}
                </strong>
              </div>
            </div>
          </div>

          {/* Section 6: Catatan Tambahan */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Catatan Khusus / Permintaan Tamu (Opsional)
            </label>
            <textarea
              id="hotel-notes"
              rows={2}
              placeholder="Contoh: Tambah extra bed 1 pcs, request dekat area api unggun..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:border-blue-600"
            />
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              id="btn-cancel-hotel-modal"
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-xs rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              id="btn-submit-hotel-modal"
              type="submit"
              disabled={isSaving}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition-colors shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Menyimpan...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'Simpan Perubahan' : 'Simpan Reservasi'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
