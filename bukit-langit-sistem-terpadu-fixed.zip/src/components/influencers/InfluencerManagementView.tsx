import React, { useState, useEffect, useMemo } from 'react';
import {
  Influencer,
  InfluencerPipelineStatus,
  FollowerTier,
  CollaborationType,
  BusinessSettings,
} from '../../types/document';
import {
  subscribeInfluencers,
  saveInfluencer,
  updateInfluencerStatus,
  updateInfluencerRating,
  deleteInfluencer,
} from '../../utils/firebase';
import { formatRupiah, formatDateForInput, formatDateToIndonesian } from '../../utils/formatter';
import {
  Sparkles,
  Search,
  Filter,
  Plus,
  Phone,
  MessageCircle,
  Calendar,
  Star,
  ExternalLink,
  Trash2,
  Edit,
  Columns,
  List,
  RefreshCw,
  Award,
  Video,
  Instagram,
  MapPin,
  CheckCircle2,
  Clock,
  XCircle,
  Send,
  Eye,
  TrendingUp,
  Tag,
  Upload,
} from 'lucide-react';
import { DataImportModal } from '../common/DataImportModal';

interface InfluencerManagementViewProps {
  settings: BusinessSettings;
  userEmail: string;
  userName?: string;
  showToast?: (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => void;
}

type ViewMode = 'pipeline' | 'database';

export const InfluencerManagementView: React.FC<InfluencerManagementViewProps> = ({
  settings,
  userEmail,
  userName,
  showToast,
}) => {
  const [influencers, setInfluencers] = useState<Influencer[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<ViewMode>('pipeline');

  // Filters & search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [collabTypeFilter, setCollabTypeFilter] = useState<string>('all');
  const [nicheFilter, setNicheFilter] = useState<string>('all');
  const [cityFilter, setCityFilter] = useState<string>('all');

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [editingInfluencer, setEditingInfluencer] = useState<Influencer | null>(null);

  const [deleteModalItem, setDeleteModalItem] = useState<Influencer | null>(null);
  const [deleteReason, setDeleteReason] = useState('');

  const [contentUrlModalItem, setContentUrlModalItem] = useState<Influencer | null>(null);
  const [newContentUrl, setNewContentUrl] = useState('');

  // Niche kustom ("Lainnya") yang diketik manual
  const [customNiche, setCustomNiche] = useState('');

  const [draggedId, setDraggedId] = useState<string | null>(null);

  // Available options
  const defaultNiches = useMemo(() => {
    return settings.influencerNicheCategories && settings.influencerNicheCategories.length > 0
      ? settings.influencerNicheCategories
      : ['Travel & Adventure', 'Staycation & Glamping', 'Culinary', 'Family', 'Lifestyle'];
  }, [settings.influencerNicheCategories]);

  const defaultCities = useMemo(() => {
    return settings.influencerCities && settings.influencerCities.length > 0
      ? settings.influencerCities
      : ['Banyuwangi', 'Surabaya', 'Malang', 'Bali', 'Jakarta', 'Bandung', 'Yogyakarta', 'Semarang', 'Jember'];
  }, [settings.influencerCities]);

  // Subscribe to collection
  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeInfluencers(
      (data) => {
        setInfluencers(data);
        setLoading(false);
      },
      (error) => {
        console.error('Error loading influencers:', error);
        setLoading(false);
        if (showToast) {
          showToast('error', 'Gagal Memuat Influencer', error.message || 'Terjadi kendala.');
        }
      }
    );
    return () => unsubscribe();
  }, [showToast]);

  // Filtered List
  const filteredInfluencers = useMemo(() => {
    return influencers.filter((inf) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = inf.influencerName.toLowerCase().includes(q);
        const matchIg = inf.instagramHandle?.toLowerCase().includes(q);
        const matchTiktok = inf.tikTokHandle?.toLowerCase().includes(q);
        const matchCity = inf.domicileCity.toLowerCase().includes(q);
        const matchPhone = inf.adminWhatsApp.includes(q);
        if (!matchName && !matchIg && !matchTiktok && !matchCity && !matchPhone) {
          return false;
        }
      }

      if (statusFilter !== 'all' && inf.pipelineStatus !== statusFilter) return false;
      if (tierFilter !== 'all' && inf.followerTier !== tierFilter) return false;
      if (collabTypeFilter !== 'all' && inf.collaborationType !== collabTypeFilter) return false;
      if (nicheFilter !== 'all' && !inf.nicheCategory.includes(nicheFilter)) return false;
      if (cityFilter !== 'all' && inf.domicileCity !== cityFilter) return false;

      return true;
    });
  }, [influencers, searchQuery, statusFilter, tierFilter, collabTypeFilter, nicheFilter, cityFilter]);

  // Stats
  const stats = useMemo(() => {
    const total = influencers.length;
    const confirmed = influencers.filter((i) => i.pipelineStatus === 'Confirmed').length;
    const completed = influencers.filter((i) => i.pipelineStatus === 'Completed').length;
    const withRating = influencers.filter((i) => i.performanceRating && i.performanceRating > 0);
    const avgRating =
      withRating.length > 0
        ? (
            withRating.reduce((acc, curr) => acc + (curr.performanceRating || 0), 0) /
            withRating.length
          ).toFixed(1)
        : '0';

    return { total, confirmed, completed, avgRating, totalRated: withRating.length };
  }, [influencers]);

  // Status Badge
  const getPipelineBadge = (status: InfluencerPipelineStatus) => {
    switch (status) {
      case 'Prospect':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            Prospect
          </span>
        );
      case 'Contacted':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Send className="w-3 h-3 text-blue-600" />
            Contacted
          </span>
        );
      case 'Confirmed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <Calendar className="w-3 h-3 text-purple-600" />
            Confirmed Visit
          </span>
        );
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Completed
          </span>
        );
      case 'Declined':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-600" />
            Declined
          </span>
        );
    }
  };

  // Follower tier badge
  const getTierBadge = (tier: FollowerTier) => {
    return (
      <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
        {tier}
      </span>
    );
  };

  // Send WhatsApp message
  const handleOpenWhatsApp = (inf: Influencer) => {
    let cleanPhone = inf.adminWhatsApp.replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '62' + cleanPhone.substring(1);
    }
    if (!cleanPhone.startsWith('62')) {
      cleanPhone = '62' + cleanPhone;
    }

    const senderName = userName || userEmail.split('@')[0] || 'Marketing Team';
    const bizName = settings.businessName || 'Bukit Langit Campventure';
    const igHandle = inf.instagramHandle ? `@${inf.instagramHandle.replace('@', '')}` : '';
    const nicheStr = inf.nicheCategory.join(', ');

    const defaultMsg = `Halo Kak *${inf.influencerName}* ${igHandle} & Tim, salam hangat dari *${bizName}* 🌲✨

Perkenalkan saya *${senderName}* dari tim Marketing *${bizName}*. Kami sangat mengapresiasi karya dan konten inspiratif Kakak di bidang ${nicheStr || 'lifestyle & travel'}.

Kami memiliki kawasan Glamping & Outdoor Resort yang asri di ${settings.city || 'Banyuwangi'}. Melihat profil Kakak yang sangat sesuai, kami bermaksud menawarkan kerjasama (*${inf.collaborationType}*).

Apakah saat ini Kakak open for collaboration? Bila berkenan, kami sangat senang untuk mengirimkan detail brief & rencana kunjungan.

Terima kasih banyak ya Kak! 🙏
*${bizName}*`;

    const encoded = encodeURIComponent(defaultMsg);
    window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
  };

  // Star rating update
  const handleRatingClick = async (inf: Influencer, rating: number) => {
    try {
      await updateInfluencerRating(inf.id, rating, userEmail);
      if (showToast) {
        showToast('success', 'Rating Disimpan', `Rating performa ${inf.influencerName} diperbarui jadi ${rating} bintang.`);
      }
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Memperbarui Rating', err.message);
      }
    }
  };

  // Status Change
  const handleStatusChange = async (infId: string, newStatus: InfluencerPipelineStatus) => {
    try {
      await updateInfluencerStatus(infId, newStatus, userEmail);
      if (showToast) {
        showToast('success', 'Status Diperbarui', `Pipeline influencer dipindahkan ke ${newStatus}.`);
      }
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Mengubah Status', err.message);
      }
    }
  };

  // Form Modal Open
  const handleOpenFormModal = (item?: Influencer) => {
    if (item) {
      setEditingInfluencer(item);
    } else {
      setEditingInfluencer({
        id: `inf_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        influencerName: '',
        instagramHandle: '',
        tikTokHandle: '',
        nicheCategory: ['Travel & Adventure', 'Staycation & Glamping'],
        domicileCity: 'Banyuwangi',
        adminWhatsApp: '',
        followerTier: 'Micro (10K-100K)',
        collaborationType: 'Full Barter',
        ratecardFee: 0,
        pipelineStatus: 'Prospect',
        scheduledVisitDate: '',
        contentUrl: '',
        performanceRating: 5,
        briefNotes: '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
    setIsFormModalOpen(true);
  };

  // Save Form
  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInfluencer) return;

    if (!editingInfluencer.influencerName.trim()) {
      if (showToast) showToast('warning', 'Nama Influencer Wajib Diisi', 'Silakan isi nama influencer/KOL.');
      return;
    }
    if (!editingInfluencer.adminWhatsApp.trim()) {
      if (showToast) showToast('warning', 'Nomor WA Wajib Diisi', 'Silakan isi kontak WhatsApp admin/talent.');
      return;
    }

    try {
      await saveInfluencer(editingInfluencer, userEmail);
      if (showToast) {
        showToast('success', 'Data Influencer Disimpan', `Profil ${editingInfluencer.influencerName} berhasil disimpan.`);
      }
      setIsFormModalOpen(false);
      setEditingInfluencer(null);
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Menyimpan', err.message || 'Terjadi kesalahan.');
      }
    }
  };

  // Delete (Optimistic)
  const handleDeleteConfirm = () => {
    if (!deleteModalItem) return;
    const target = deleteModalItem;
    const reason = deleteReason.trim();

    // (1) Tutup modal & notifikasi segera (OPTIMISTIC <1 detik)
    setDeleteModalItem(null);
    setDeleteReason('');
    if (showToast) {
      showToast('success', 'Data Dihapus', `Data influencer ${target.influencerName} telah dihapus.`);
    }

    // (2) Hapus di latar belakang TANPA await
    deleteInfluencer(target, userEmail, reason).catch((err: any) => {
      console.error('Error deleting influencer:', err);
      if (showToast) {
        showToast('error', 'Gagal Menghapus', err?.message || 'Gagal sinkron hapus ke server.');
      }
    });
  };

  // Save Content URL
  const handleSaveContentUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contentUrlModalItem) return;

    try {
      const updated = {
        ...contentUrlModalItem,
        contentUrl: newContentUrl.trim(),
        pipelineStatus: 'Completed' as InfluencerPipelineStatus,
      };
      await saveInfluencer(updated, userEmail);
      if (showToast) {
        showToast('success', 'Tautan Konten Disimpan', 'Tautan konten hasil review berhasil ditambahkan.');
      }
      setContentUrlModalItem(null);
      setNewContentUrl('');
    } catch (err: any) {
      console.error(err);
      if (showToast) {
        showToast('error', 'Gagal Menyimpan URL', err.message);
      }
    }
  };

  // Pipeline Columns
  const pipelineColumns: { status: InfluencerPipelineStatus; title: string; color: string; border: string; bg: string }[] = [
    {
      status: 'Prospect',
      title: 'Prospect (Riset)',
      color: 'text-slate-700',
      border: 'border-slate-300',
      bg: 'bg-slate-50/60',
    },
    {
      status: 'Contacted',
      title: 'Contacted (Penawaran)',
      color: 'text-blue-700',
      border: 'border-blue-300',
      bg: 'bg-blue-50/60',
    },
    {
      status: 'Confirmed',
      title: 'Confirmed (Jadwal Visit)',
      color: 'text-purple-700',
      border: 'border-purple-300',
      bg: 'bg-purple-50/60',
    },
    {
      status: 'Completed',
      title: 'Completed (Review Tayang)',
      color: 'text-emerald-700',
      border: 'border-emerald-300',
      bg: 'bg-emerald-50/60',
    },
    {
      status: 'Declined',
      title: 'Declined',
      color: 'text-rose-700',
      border: 'border-rose-300',
      bg: 'bg-rose-50/60',
    },
  ];

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
              <Sparkles className="w-7 h-7 text-purple-600" />
              Influencer & KOL CRM
            </h1>
            <span className="px-2.5 py-0.5 text-xs font-semibold bg-purple-100 text-purple-800 rounded-full border border-purple-200">
              Endorsement Pipeline
            </span>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Database talent, penawaran kolaborasi barter & paid, jadwal kunjungan staycation, serta rekap hasil performa konten.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4 text-purple-600" />
            <span>Import Excel/CSV</span>
          </button>
          <button
            onClick={() => handleOpenFormModal()}
            className="flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Tambah Influencer
          </button>
        </div>
      </div>

      {/* STATS METRICS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Total Database */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Database</p>
            <p className="text-2xl font-bold text-slate-800 mt-1">{stats.total}</p>
            <p className="text-xs text-slate-400 mt-0.5">KOL & Content Creator</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center">
            <Instagram className="w-5 h-5" />
          </div>
        </div>

        {/* Confirmed Visits */}
        <div className="bg-white p-4 rounded-xl border border-purple-200 bg-purple-50/30 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-purple-700 uppercase tracking-wider">Visit Terjadwal</p>
            <p className="text-2xl font-bold text-purple-800 mt-1">{stats.confirmed}</p>
            <p className="text-xs text-purple-600/80 mt-0.5">Siap datang ke resort</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* Completed */}
        <div className="bg-white p-4 rounded-xl border border-emerald-200 bg-emerald-50/30 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-emerald-700 uppercase tracking-wider">Konten Tayang</p>
            <p className="text-2xl font-bold text-emerald-800 mt-1">{stats.completed}</p>
            <p className="text-xs text-emerald-600/80 mt-0.5">Kolaborasi selesai</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
            <Video className="w-5 h-5" />
          </div>
        </div>

        {/* Average Rating */}
        <div className="bg-white p-4 rounded-xl border border-amber-200 bg-amber-50/30 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-amber-700 uppercase tracking-wider">Rata-Rata Rating</p>
            <div className="flex items-center gap-1.5 mt-1">
              <p className="text-2xl font-bold text-amber-800">{stats.avgRating}</p>
              <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
            </div>
            <p className="text-xs text-amber-600/80 mt-0.5">Dari {stats.totalRated} review performa</p>
          </div>
          <div className="w-11 h-11 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* FILTER & VIEW BAR */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('pipeline')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                viewMode === 'pipeline'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Columns className="w-4 h-4" />
              Pipeline Board
            </button>

            <button
              onClick={() => setViewMode('database')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                viewMode === 'database'
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <List className="w-4 h-4" />
              Database View ({influencers.length})
            </button>
          </div>

          <div className="text-xs text-slate-500">
            Dikelola oleh tim Marketing & Public Relations
          </div>
        </div>

        {/* Filter inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-6 gap-3">
          {/* Search bar */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama, handle IG, TikTok, kota..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:bg-white"
            />
          </div>

          {/* Follower Tier filter */}
          <div>
            <select
              value={tierFilter}
              onChange={(e) => setTierFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">Semua Tier</option>
              <option value="Nano (<10K)">Nano (&lt;10K)</option>
              <option value="Micro (10K-100K)">Micro (10K-100K)</option>
              <option value="Mid (100K-500K)">Mid (100K-500K)</option>
              <option value="Macro (>500K)">Macro (&gt;500K)</option>
            </select>
          </div>

          {/* Collab Type */}
          <div>
            <select
              value={collabTypeFilter}
              onChange={(e) => setCollabTypeFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">Semua Skema</option>
              <option value="Full Barter">Full Barter</option>
              <option value="Paid">Paid Endorsement</option>
              <option value="Barter + Fee">Barter + Fee</option>
            </select>
          </div>

          {/* Niche */}
          <div>
            <select
              value={nicheFilter}
              onChange={(e) => setNicheFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">Semua Niche</option>
              {defaultNiches.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>

          {/* City */}
          <div>
            <select
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
            >
              <option value="all">Semua Kota</option>
              {defaultCities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* CONTENT VIEWS */}
      {loading ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <RefreshCw className="w-8 h-8 text-purple-600 animate-spin mx-auto mb-3" />
          <p className="text-slate-600 font-medium">Memuat data influencer...</p>
        </div>
      ) : viewMode === 'pipeline' ? (
        /* PIPELINE KANBAN VIEW */
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3.5 items-start overflow-x-auto">
          {pipelineColumns.map((col) => {
            const colItems = filteredInfluencers.filter((i) => i.pipelineStatus === col.status);
            return (
              <div
                key={col.status}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  if (draggedId) {
                    handleStatusChange(draggedId, col.status);
                    setDraggedId(null);
                  }
                }}
                className={`rounded-xl border ${col.border} ${col.bg} p-3 min-h-[500px] flex flex-col`}
              >
                {/* Column header */}
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200/60">
                  <span className={`text-xs font-bold ${col.color}`}>{col.title}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-white/80 text-slate-700 shadow-2xs">
                    {colItems.length}
                  </span>
                </div>

                {/* Card items */}
                <div className="space-y-3 flex-1 overflow-y-auto max-h-[700px] pr-1">
                  {colItems.length === 0 ? (
                    <div className="p-6 text-center text-xs text-slate-400 border border-dashed border-slate-300 rounded-lg bg-white/50">
                      Kosong
                    </div>
                  ) : (
                    colItems.map((inf) => (
                      <div
                        key={inf.id}
                        draggable
                        onDragStart={() => setDraggedId(inf.id)}
                        className="bg-white rounded-lg p-3.5 border border-slate-200 shadow-2xs hover:shadow-xs transition-all space-y-2.5 cursor-grab active:cursor-grabbing"
                      >
                        {/* Name & Tier */}
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="font-bold text-slate-800 text-sm">{inf.influencerName}</h4>
                            <p className="text-xs text-purple-700 font-medium">
                              @{inf.instagramHandle || inf.tikTokHandle || '-'}
                            </p>
                          </div>
                          {getTierBadge(inf.followerTier)}
                        </div>

                        {/* City & Niche */}
                        <div className="flex flex-wrap items-center gap-1 text-[11px]">
                          <span className="inline-flex items-center gap-0.5 text-slate-500 font-medium">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            {inf.domicileCity}
                          </span>
                          <span className="text-slate-300">•</span>
                          <span className="text-slate-600 font-medium">
                            {inf.collaborationType}
                          </span>
                        </div>

                        {/* Scheduled visit / Ratecard */}
                        {inf.scheduledVisitDate && (
                          <div className="bg-purple-50 p-1.5 rounded text-[11px] text-purple-800 flex items-center gap-1 font-semibold">
                            <Calendar className="w-3.5 h-3.5 text-purple-600" />
                            Visit: {formatDateToIndonesian(inf.scheduledVisitDate)}
                          </div>
                        )}

                        {/* Interactive Star Rating */}
                        <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                          <div className="flex items-center gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                onClick={() => handleRatingClick(inf, star)}
                                className={`w-3.5 h-3.5 cursor-pointer transition-colors ${
                                  star <= (inf.performanceRating || 0)
                                    ? 'fill-amber-400 text-amber-500'
                                    : 'text-slate-200 hover:text-amber-300'
                                }`}
                              />
                            ))}
                          </div>

                          {inf.contentUrl ? (
                            <a
                              href={inf.contentUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                              title="Lihat Link Konten"
                            >
                              <Video className="w-3.5 h-3.5" />
                              Konten
                            </a>
                          ) : (
                            <button
                              onClick={() => {
                                setContentUrlModalItem(inf);
                                setNewContentUrl(inf.contentUrl || '');
                              }}
                              className="text-[11px] text-slate-400 hover:text-purple-600 font-medium cursor-pointer"
                            >
                              + URL
                            </button>
                          )}
                        </div>

                        {/* Action buttons */}
                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1">
                          <button
                            onClick={() => handleOpenWhatsApp(inf)}
                            className="flex-1 py-1 px-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            Chat WA
                          </button>

                          <button
                            onClick={() => handleOpenFormModal(inf)}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded cursor-pointer"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* DATABASE VIEW (CARDS / TABLE) */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredInfluencers.length === 0 ? (
            <div className="col-span-full bg-white p-12 rounded-xl border border-slate-200 text-center">
              <Sparkles className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-700">Tidak Ada Data Influencer</h3>
              <p className="text-sm text-slate-400 mt-1 max-w-md mx-auto">
                Belum ada profil talent yang cocok dengan pencarian Anda. Klik tombol "Tambah Influencer" untuk mencatat data baru.
              </p>
            </div>
          ) : (
            filteredInfluencers.map((inf) => (
              <div
                key={inf.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs hover:shadow-xs transition-all space-y-4 flex flex-col justify-between"
              >
                <div>
                  {/* Top */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-bold text-slate-800 text-base">{inf.influencerName}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        {inf.instagramHandle && (
                          <span className="text-xs text-purple-700 font-semibold flex items-center gap-1">
                            <Instagram className="w-3.5 h-3.5" />
                            @{inf.instagramHandle.replace('@', '')}
                          </span>
                        )}
                        {inf.tikTokHandle && (
                          <span className="text-xs text-slate-600 font-medium flex items-center gap-1">
                            <Video className="w-3.5 h-3.5" />
                            @{inf.tikTokHandle.replace('@', '')}
                          </span>
                        )}
                      </div>
                    </div>
                    {getPipelineBadge(inf.pipelineStatus)}
                  </div>

                  {/* Badges */}
                  <div className="flex flex-wrap items-center gap-1.5 mt-3">
                    {getTierBadge(inf.followerTier)}
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                      {inf.collaborationType}
                    </span>
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-50 text-slate-600 flex items-center gap-0.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {inf.domicileCity}
                    </span>
                  </div>

                  {/* Niche Categories */}
                  <div className="flex flex-wrap gap-1 mt-2.5">
                    {inf.nicheCategory.map((n) => (
                      <span
                        key={n}
                        className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-100"
                      >
                        {n}
                      </span>
                    ))}
                  </div>

                  {/* Rate Card & Visit info */}
                  <div className="mt-3 p-2.5 bg-slate-50 rounded-lg text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Rate Card:</span>
                      <span className="font-bold text-slate-700">
                        {inf.ratecardFee > 0 ? formatRupiah(inf.ratecardFee) : 'Barter / Free'}
                      </span>
                    </div>
                    {inf.scheduledVisitDate && (
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Jadwal Visit:</span>
                        <span className="font-semibold text-purple-700">
                          {formatDateToIndonesian(inf.scheduledVisitDate)}
                        </span>
                      </div>
                    )}
                    {inf.briefNotes && (
                      <p className="text-slate-500 italic mt-1 pt-1 border-t border-slate-200/60 line-clamp-2">
                        "{inf.briefNotes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Rating & Action Bar */}
                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">Performa Konten:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          onClick={() => handleRatingClick(inf, star)}
                          className={`w-4 h-4 cursor-pointer transition-colors ${
                            star <= (inf.performanceRating || 0)
                              ? 'fill-amber-400 text-amber-500'
                              : 'text-slate-200 hover:text-amber-300'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleOpenWhatsApp(inf)}
                      className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      Chat WA
                    </button>

                    {inf.contentUrl ? (
                      <a
                        href={inf.contentUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="py-1.5 px-2.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Link
                      </a>
                    ) : (
                      <button
                        onClick={() => {
                          setContentUrlModalItem(inf);
                          setNewContentUrl('');
                        }}
                        className="py-1.5 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        + Link
                      </button>
                    )}

                    <button
                      onClick={() => handleOpenFormModal(inf)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        setDeleteModalItem(inf);
                        setDeleteReason('');
                      }}
                      className="p-1.5 text-rose-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Hapus"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* MODAL 1: ADD / EDIT INFLUENCER */}
      {isFormModalOpen && editingInfluencer && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                {editingInfluencer.id.startsWith('inf_') && !editingInfluencer.influencerName
                  ? 'Tambah Influencer / KOL Baru'
                  : 'Edit Data Influencer'}
              </h3>
              <button
                onClick={() => {
                  setIsFormModalOpen(false);
                  setEditingInfluencer(null);
                }}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Name */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nama Influencer / Talent <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Jessica Aurelia"
                    value={editingInfluencer.influencerName}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        influencerName: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* WhatsApp */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    WhatsApp Admin / Talent <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 081234567890"
                    value={editingInfluencer.adminWhatsApp}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        adminWhatsApp: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Instagram Handle */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Handle Instagram
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: @jessica_travels"
                    value={editingInfluencer.instagramHandle || ''}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        instagramHandle: e.target.value.replace(/^@/, ''),
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* TikTok Handle */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Handle TikTok (Opsional)
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: @jessicavlog"
                    value={editingInfluencer.tikTokHandle || ''}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        tikTokHandle: e.target.value.replace(/^@/, ''),
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Domicile City */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kota Domisili
                  </label>
                  <select
                    value={editingInfluencer.domicileCity}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        domicileCity: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 bg-white"
                  >
                    {defaultCities.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Follower Tier */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Follower Tier
                  </label>
                  <select
                    value={editingInfluencer.followerTier}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        followerTier: e.target.value as FollowerTier,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 bg-white font-semibold text-purple-900"
                  >
                    <option value="Nano (<10K)">Nano (&lt;10K)</option>
                    <option value="Micro (10K-100K)">Micro (10K-100K)</option>
                    <option value="Mid (100K-500K)">Mid (100K-500K)</option>
                    <option value="Macro (>500K)">Macro (&gt;500K)</option>
                  </select>
                </div>

                {/* Collaboration Type */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tipe Kolaborasi
                  </label>
                  <select
                    value={editingInfluencer.collaborationType}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        collaborationType: e.target.value as CollaborationType,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 bg-white"
                  >
                    <option value="Full Barter">Full Barter (Staycation Free)</option>
                    <option value="Paid">Paid Endorsement</option>
                    <option value="Barter + Fee">Barter + Sisa Fee</option>
                  </select>
                </div>

                {/* Rate Card Fee */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Rate Card / Budget Fee (Rp)
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0 untuk barter"
                    value={editingInfluencer.ratecardFee || ''}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        ratecardFee: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                {/* Pipeline Status */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Status Pipeline Kolaborasi
                  </label>
                  <select
                    value={editingInfluencer.pipelineStatus}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        pipelineStatus: e.target.value as InfluencerPipelineStatus,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 bg-white font-semibold"
                  >
                    <option value="Prospect">Prospect (Riset / Belum Kontak)</option>
                    <option value="Contacted">Contacted (Penawaran Terkirim)</option>
                    <option value="Confirmed">Confirmed (Deal & Jadwal Visit)</option>
                    <option value="Completed">Completed (Konten Review Tayang)</option>
                    <option value="Declined">Declined (Menolak)</option>
                  </select>
                </div>

                {/* Scheduled Visit Date */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Rencana Tanggal Visit / Menginap
                  </label>
                  <input
                    type="date"
                    value={editingInfluencer.scheduledVisitDate || ''}
                    onChange={(e) =>
                      setEditingInfluencer({
                        ...editingInfluencer,
                        scheduledVisitDate: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {/* Niche Categories selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Kategori Niche Konten
                </label>
                <div className="flex flex-wrap gap-2">
                  {defaultNiches.map((niche) => {
                    const isSelected = editingInfluencer.nicheCategory.includes(niche);
                    return (
                      <button
                        type="button"
                        key={niche}
                        onClick={() => {
                          const current = editingInfluencer.nicheCategory;
                          const next = isSelected
                            ? current.filter((x) => x !== niche)
                            : [...current, niche];
                          setEditingInfluencer({
                            ...editingInfluencer,
                            nicheCategory: next,
                          });
                        }}
                        className={`text-xs px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-purple-600 text-white border-purple-600 font-semibold'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {niche}
                      </button>
                    );
                  })}
                  {/* Niche kustom yang sudah dipilih (di luar daftar default) */}
                  {editingInfluencer.nicheCategory
                    .filter((n) => !defaultNiches.includes(n))
                    .map((n) => (
                      <button
                        type="button"
                        key={n}
                        onClick={() =>
                          setEditingInfluencer({
                            ...editingInfluencer,
                            nicheCategory: editingInfluencer.nicheCategory.filter((x) => x !== n),
                          })
                        }
                        className="text-xs px-2.5 py-1 rounded-full border bg-purple-600 text-white border-purple-600 font-semibold"
                        title="Klik untuk hapus"
                      >
                        {n} ✕
                      </button>
                    ))}
                </div>
                {/* Input niche "Lainnya" (ketik manual) */}
                <div className="flex gap-2 mt-2">
                  <input
                    type="text"
                    value={customNiche}
                    onChange={(e) => setCustomNiche(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        const v = customNiche.trim();
                        if (v && !editingInfluencer.nicheCategory.includes(v)) {
                          setEditingInfluencer({
                            ...editingInfluencer,
                            nicheCategory: [...editingInfluencer.nicheCategory, v],
                          });
                        }
                        setCustomNiche('');
                      }
                    }}
                    placeholder="Niche lain — ketik lalu Enter / klik Tambah"
                    className="flex-1 text-xs px-3 py-1.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const v = customNiche.trim();
                      if (v && !editingInfluencer.nicheCategory.includes(v)) {
                        setEditingInfluencer({
                          ...editingInfluencer,
                          nicheCategory: [...editingInfluencer.nicheCategory, v],
                        });
                      }
                      setCustomNiche('');
                    }}
                    className="text-xs px-3 py-1.5 bg-slate-700 text-white rounded-lg font-bold hover:bg-slate-800"
                  >
                    Tambah
                  </button>
                </div>
              </div>

              {/* Brief Notes */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Catatan Briefing / Deliverables
                </label>
                <textarea
                  rows={2}
                  placeholder="Contoh: 1x Reels feed review kamar glamping + 3x story selama staycation..."
                  value={editingInfluencer.briefNotes || ''}
                  onChange={(e) =>
                    setEditingInfluencer({
                      ...editingInfluencer,
                      briefNotes: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsFormModalOpen(false);
                    setEditingInfluencer(null);
                  }}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  Simpan Profil Influencer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD CONTENT URL */}
      {contentUrlModalItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Video className="w-5 h-5 text-purple-600" />
                Tautan Hasil Konten Review
              </h3>
              <button
                onClick={() => setContentUrlModalItem(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer text-xl font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveContentUrl} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  URL / Tautan Post Reels / TikTok / YouTube
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://www.instagram.com/reel/..."
                  value={newContentUrl}
                  onChange={(e) => setNewContentUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Menyimpan URL ini akan otomatis menandai status menjadi <strong>Completed</strong>.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setContentUrlModalItem(null)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold shadow-xs cursor-pointer"
                >
                  Simpan Tautan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: DELETE CONFIRMATION (NO WINDOW.CONFIRM) */}
      {deleteModalItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-lg font-bold text-slate-800">Hapus Profil Influencer?</h3>
              <p className="text-sm text-slate-500">
                Data influencer <strong>{deleteModalItem.influencerName}</strong> (@{deleteModalItem.instagramHandle || '-'}) akan dihapus dan dicatat di riwayat audit.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Alasan Penghapusan (Opsional)
              </label>
              <input
                type="text"
                placeholder="Contoh: Akun tidak aktif / duplikat..."
                value={deleteReason}
                onChange={(e) => setDeleteReason(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => setDeleteModalItem(null)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-semibold transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Ya, Hapus Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          moduleKey="influencers"
          moduleTitle="Influencer & KOL"
        />
      )}
    </div>
  );
};
export default InfluencerManagementView;
