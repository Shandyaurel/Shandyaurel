import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  Upload,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Database,
  FileText,
  Layers,
} from 'lucide-react';
import { Modal } from './Modal';
import {
  MODULE_TEMPLATES,
  downloadExcelTemplate,
  mapExcelRowsToDocuments,
} from '../../utils/migrationHelpers';
import { bulkImportDocuments, BulkImportResult } from '../../utils/firebase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

interface DataImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  moduleKey: string;
  moduleTitle: string;
  onImportComplete?: () => void;
}

export const DataImportModal: React.FC<DataImportModalProps> = ({
  isOpen,
  onClose,
  moduleKey,
  moduleTitle,
  onImportComplete,
}) => {
  const { currentUser } = useAuth();
  const { showSuccess, showError, showWarning } = useToast();

  const [step, setStep] = useState<'upload' | 'preview' | 'processing' | 'done'>('upload');
  const [fileName, setFileName] = useState<string>('');
  const [rawRows, setRawRows] = useState<Record<string, any>[]>([]);
  const [parsedDocs, setParsedDocs] = useState<Record<string, any>[]>([]);
  const [overwriteDuplicates, setOverwriteDuplicates] = useState<boolean>(false);
  const [importProgress, setImportProgress] = useState<number>(0);
  const [processedCount, setProcessedCount] = useState<number>(0);
  const [importResult, setImportResult] = useState<BulkImportResult | null>(null);
  const [isParsing, setIsParsing] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const config = MODULE_TEMPLATES[moduleKey];

  const handleReset = () => {
    setStep('upload');
    setFileName('');
    setRawRows([]);
    setParsedDocs([]);
    setImportProgress(0);
    setProcessedCount(0);
    setImportResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleClose = () => {
    handleReset();
    onClose();
  };

  const handleDownloadTemplate = () => {
    downloadExcelTemplate(moduleKey);
    showSuccess(`Template Excel ${moduleTitle} berhasil diunduh.`, 'Template Siap');
  };

  // Handle file upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsParsing(true);

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet);

      if (!json || json.length === 0) {
        showError('File Excel kosong atau tidak memiliki baris data.', 'Gagal Membaca File');
        setIsParsing(false);
        return;
      }

      setRawRows(json);

      // Map to typed objects
      const targetCollection = config?.collectionName || moduleKey;
      const mapped = mapExcelRowsToDocuments(moduleKey, json, currentUser?.email || 'admin');
      setParsedDocs(mapped);
      setStep('preview');
    } catch (err: any) {
      console.error(err);
      showError('Format file tidak didukung atau rusak. Gunakan file .xlsx atau .csv.', 'Format Salah');
    } finally {
      setIsParsing(false);
    }
  };

  // Execute Bulk Save
  const handleExecuteImport = async () => {
    if (parsedDocs.length === 0) return;

    setStep('processing');
    setImportProgress(0);
    setProcessedCount(0);

    const targetCollection = config?.collectionName || moduleKey;

    try {
      const result = await bulkImportDocuments(
        targetCollection,
        parsedDocs,
        currentUser?.email || 'admin',
        overwriteDuplicates,
        (percent, current, total) => {
          setImportProgress(percent);
          setProcessedCount(current);
        },
      );

      setImportResult(result);
      setStep('done');
      showSuccess(
        `Berhasil mengimpor ${result.inserted} data baru (${result.updated} diperbarui, ${result.skipped} dilewati).`,
        'Impor Selesai',
      );
      if (onImportComplete) {
        onImportComplete();
      }
    } catch (err: any) {
      console.error(err);
      showError('Terjadi kesalahan saat menyimpan data ke database.', 'Gagal Impor');
      setStep('preview');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={`Impor Massal Excel / CSV — ${moduleTitle}`}
      maxWidth="max-w-4xl"
    >
      <div className="space-y-6">
        {/* Step 1: Upload & Download Template */}
        {step === 'upload' && (
          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="p-3 bg-blue-600 text-white rounded-xl shadow-xs shrink-0">
                  <FileSpreadsheet className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-blue-950">
                    Gunakan Format Standar {moduleTitle}
                  </h4>
                  <p className="text-xs text-blue-800 mt-0.5 max-w-lg">
                    Unduh file template resmi agar nama kolom dan tipe data sesuai dengan skema sistem.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleDownloadTemplate}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Template (.xlsx)</span>
              </button>
            </div>

            {/* Dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50 hover:bg-blue-50/40 rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-colors"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-12 h-12 bg-white rounded-full shadow-xs border border-slate-200 flex items-center justify-center mx-auto mb-3 text-blue-600">
                <Upload className="w-6 h-6" />
              </div>
              <h5 className="font-bold text-sm text-slate-800">
                Klik untuk unggah atau seret file spreadsheet ke sini
              </h5>
              <p className="text-xs text-slate-500 mt-1">
                Mendukung file Excel (.xlsx, .xls) dan CSV berformat tabel
              </p>
            </div>
          </div>
        )}

        {/* Step 2: Preview & Duplicate Resolution */}
        {step === 'preview' && (
          <div className="space-y-4">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="flex items-center gap-2.5">
                <FileText className="w-4 h-4 text-blue-600" />
                <span className="font-bold text-xs text-slate-800">
                  {fileName} ({parsedDocs.length} baris data terdeteksi)
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
                >
                  Ganti File
                </button>
              </div>
            </div>

            {/* Duplicate policy selection */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs space-y-2">
              <div className="font-bold text-amber-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                <span>Aturan Penanganan Duplikasi ID / Rekaman yang Ada</span>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-amber-950 pt-1">
                <label className="flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="radio"
                    name="duplicatePolicy"
                    checked={!overwriteDuplicates}
                    onChange={() => setOverwriteDuplicates(false)}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span>Lewati rekaman jika ID sudah ada (Lebih Aman)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer font-medium">
                  <input
                    type="radio"
                    name="duplicatePolicy"
                    checked={overwriteDuplicates}
                    onChange={() => setOverwriteDuplicates(true)}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span>Timpa / Perbarui data jika ID sama</span>
                </label>
              </div>
            </div>

            {/* Data Table Preview (First 50 items) */}
            <div className="border border-slate-200 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 sticky top-0 border-b border-slate-200 font-bold text-slate-700">
                  <tr>
                    <th className="py-2.5 px-3">No</th>
                    <th className="py-2.5 px-3">ID Dokumen</th>
                    {Object.keys(rawRows[0] || {})
                      .slice(0, 5)
                      .map((key) => (
                        <th key={key} className="py-2.5 px-3 whitespace-nowrap">
                          {key}
                        </th>
                      ))}
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {parsedDocs.slice(0, 50).map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-mono text-slate-500">{idx + 1}</td>
                      <td className="py-2 px-3 font-mono text-blue-700 font-medium truncate max-w-[120px]">
                        {row.id}
                      </td>
                      {Object.keys(rawRows[0] || {})
                        .slice(0, 5)
                        .map((key) => (
                          <td key={key} className="py-2 px-3 truncate max-w-[160px] text-slate-700">
                            {String(rawRows[idx]?.[key] ?? '-')}
                          </td>
                        ))}
                      <td className="py-2 px-3 text-center whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          Siap Impor
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {parsedDocs.length > 50 && (
              <p className="text-[11px] text-slate-400 text-center">
                Menampilkan 50 dari total {parsedDocs.length} baris data yang akan diimpor.
              </p>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={handleReset}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleExecuteImport}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Mulai Simpan {parsedDocs.length} Data ke Database</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Processing & Progress */}
        {step === 'processing' && (
          <div className="py-12 px-4 text-center space-y-4">
            <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center mx-auto text-blue-600 animate-spin">
              <RefreshCw className="w-7 h-7" />
            </div>
            <div>
              <h4 className="font-bold text-base text-slate-900">
                Menyimpan Data Massal ke Firestore...
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                Sedang memproses {processedCount} dari {parsedDocs.length} data ({importProgress}%)
              </p>
            </div>

            <div className="w-full max-w-md mx-auto bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
              <div
                className="bg-blue-600 h-full transition-all duration-300 rounded-full"
                style={{ width: `${importProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Step 4: Done Report */}
        {step === 'done' && importResult && (
          <div className="py-6 space-y-6">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="font-black text-lg text-slate-900">
                Proses Impor Massal Selesai!
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Seluruh data valid telah berhasil dikomit ke Firestore koleksi `{config?.collectionName || moduleKey}`.
              </p>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Data</span>
                <span className="font-black text-base text-slate-900">{importResult.total}</span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-[10px] text-emerald-600 uppercase font-bold block">Data Baru</span>
                <span className="font-black text-base text-emerald-700">{importResult.inserted}</span>
              </div>
              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200">
                <span className="text-[10px] text-blue-600 uppercase font-bold block">Diperbarui</span>
                <span className="font-black text-base text-blue-700">{importResult.updated}</span>
              </div>
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                <span className="text-[10px] text-amber-600 uppercase font-bold block">Dilewati</span>
                <span className="font-black text-base text-amber-700">{importResult.skipped}</span>
              </div>
            </div>

            <div className="flex items-center justify-center pt-2">
              <button
                type="button"
                onClick={handleClose}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                Tutup & Lihat Data
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
