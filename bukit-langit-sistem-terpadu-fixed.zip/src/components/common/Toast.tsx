import React from 'react';
import { ToastMessage } from '../../types';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onDismiss }) => {
  return (
    <div
      id="toast-container"
      className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md w-full pointer-events-none px-4 sm:px-0"
    >
      <AnimatePresence>
        {toasts.map((toast) => {
          let Icon = Info;
          let bgColor = 'bg-white border-blue-200 text-blue-900';
          let iconColor = 'text-blue-600 bg-blue-50';

          if (toast.type === 'success') {
            Icon = CheckCircle2;
            bgColor = 'bg-white border-emerald-200 text-emerald-950';
            iconColor = 'text-emerald-600 bg-emerald-50';
          } else if (toast.type === 'error') {
            Icon = AlertCircle;
            bgColor = 'bg-white border-rose-200 text-rose-950';
            iconColor = 'text-rose-600 bg-rose-50';
          } else if (toast.type === 'warning') {
            Icon = AlertTriangle;
            bgColor = 'bg-white border-amber-200 text-amber-950';
            iconColor = 'text-amber-600 bg-amber-50';
          }

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
              id={`toast-item-${toast.id}`}
              className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-lg ${bgColor}`}
            >
              <div className={`p-1.5 rounded-lg shrink-0 ${iconColor}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0 pt-0.5">
                {toast.title && (
                  <h4 className="text-sm font-semibold mb-0.5 text-slate-900">{toast.title}</h4>
                )}
                <p className="text-sm text-slate-600 leading-snug">{toast.message}</p>
              </div>
              <button
                id={`toast-dismiss-${toast.id}`}
                onClick={() => onDismiss(toast.id)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors"
                aria-label="Tutup notifikasi"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
