import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertCircle, X, Check, AlertTriangle, Info } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm?: () => void;
  confirmVariant?: 'primary' | 'danger' | 'warning';
  isLoading?: boolean;
  iconType?: 'danger' | 'warning' | 'info' | 'success';
  maxWidth?: string;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  description,
  children,
  confirmLabel,
  cancelLabel = 'Batal',
  onConfirm,
  confirmVariant = 'primary',
  isLoading = false,
  iconType,
  maxWidth = 'max-w-lg',
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen && !isLoading) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isLoading, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          id="custom-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.2 }}
            id="custom-modal-content"
            className={`w-full ${maxWidth} bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col`}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between p-6 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                {iconType === 'danger' && (
                  <div className="p-2.5 rounded-xl bg-rose-50 text-rose-600">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                )}
                {iconType === 'warning' && (
                  <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                )}
                {iconType === 'info' && (
                  <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600">
                    <Info className="w-6 h-6" />
                  </div>
                )}
                {iconType === 'success' && (
                  <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600">
                    <Check className="w-6 h-6" />
                  </div>
                )}
                <div>
                  <h3 className="text-lg font-bold text-slate-900 leading-snug">{title}</h3>
                  {description && (
                    <p className="text-sm text-slate-500 mt-0.5">{description}</p>
                  )}
                </div>
              </div>
              <button
                id="modal-close-button"
                onClick={onClose}
                disabled={isLoading}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors disabled:opacity-50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            {children && <div className="p-6 text-sm text-slate-600">{children}</div>}

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-3 p-4 bg-slate-50 border-t border-slate-100">
              <button
                id="modal-cancel-button"
                type="button"
                onClick={onClose}
                disabled={isLoading}
                className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors disabled:opacity-50 shadow-xs"
              >
                {cancelLabel}
              </button>
              {onConfirm && (
                <button
                  id="modal-confirm-button"
                  type="button"
                  onClick={onConfirm}
                  disabled={isLoading}
                  className={`px-4 py-2 text-sm font-medium rounded-lg text-white transition-colors shadow-xs flex items-center gap-2 disabled:opacity-50 ${
                    confirmVariant === 'danger'
                      ? 'bg-rose-600 hover:bg-rose-700'
                      : confirmVariant === 'warning'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Memproses...</span>
                    </>
                  ) : (
                    confirmLabel || 'Konfirmasi'
                  )}
                </button>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
