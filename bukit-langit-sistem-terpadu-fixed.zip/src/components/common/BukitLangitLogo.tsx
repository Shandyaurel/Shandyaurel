import React, { useState } from 'react';
import { getStoredSettings } from '../../utils/storage';

interface BukitLangitLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'icon' | 'badge';
  dark?: boolean;
  logoUrl?: string;
  businessName?: string;
  tagline?: string;
  showText?: boolean;
  iconOnly?: boolean;
}

export const BukitLangitLogo: React.FC<BukitLangitLogoProps> = ({
  className = '',
  size = 'md',
  variant = 'full',
  dark = false,
  logoUrl: propLogoUrl,
  businessName: propBizName,
  tagline: propTagline,
  showText = true,
  iconOnly = false,
}) => {
  const [imgError, setImgError] = useState(false);

  // Fallback to stored settings if not directly passed
  const storedSettings = typeof window !== 'undefined' ? getStoredSettings() : null;
  const activeLogoUrl = propLogoUrl || storedSettings?.logoUrl;
  const activeBizName = propBizName || storedSettings?.businessName || 'BUKIT LANGIT';
  const activeTagline = propTagline || storedSettings?.tagline || 'CAMP & RESORT';

  const isIconOnly = iconOnly || showText === false || variant === 'icon';

  const iconDimensions = {
    sm: 'w-6 h-6',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const titleSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  const subtitleSizes = {
    sm: 'text-[9px]',
    md: 'text-[11px]',
    lg: 'text-xs',
    xl: 'text-sm',
  };

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Mountain + Tent Logo Icon or Custom Logo Image */}
      <div
        className={`${iconDimensions[size]} rounded-2xl flex items-center justify-center shrink-0 shadow-xs overflow-hidden ${
          dark ? 'bg-white text-emerald-900' : 'bg-emerald-900 text-amber-400'
        }`}
      >
        {activeLogoUrl && !imgError ? (
          <img
            src={activeLogoUrl}
            alt={activeBizName}
            className="w-full h-full object-contain p-1 rounded-xl"
            onError={() => setImgError(true)}
          />
        ) : (
          <svg
            viewBox="0 0 48 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-4/5 h-4/5"
          >
            {/* Mountains */}
            <path
              d="M8 38L20 16L29 30L34 22L42 38H8Z"
              fill="currentColor"
              fillOpacity="0.25"
            />
            <path
              d="M6 38L18 14L28 32"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M24 25L32 10L44 38"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            {/* Sun / Moon Crescent */}
            <circle cx="36" cy="12" r="3.5" fill="#FBBF24" />
            {/* Base horizon line */}
            <line
              x1="4"
              y1="38"
              x2="44"
              y2="38"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        )}
      </div>

      {!isIconOnly && (
        <div className="flex flex-col">
          <span
            className={`font-black tracking-wider uppercase font-serif leading-none ${titleSizes[size]} ${
              dark ? 'text-white' : 'text-slate-900'
            }`}
          >
            {activeBizName}
          </span>
          <span
            className={`font-medium tracking-widest uppercase text-emerald-600 mt-1 ${subtitleSizes[size]}`}
          >
            {activeTagline}
          </span>
        </div>
      )}
    </div>
  );
};

export default BukitLangitLogo;
