import React from 'react';
import { NavigationModuleKey } from '../../types';
import {
  LayoutDashboard,
  Hotel,
  Compass,
  Utensils,
  Coins,
  Boxes,
  Percent,
  FilePlus2,
  FileCheck,
  FileArchive,
  Users,
  Megaphone,
  Handshake,
  TrendingUp,
  BarChart3,
  CalendarDays,
  ListTodo,
  Clock,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';
import { motion } from 'motion/react';

interface ModulePlaceholderProps {
  moduleKey: NavigationModuleKey;
  title: string;
  category: string;
  description: string;
}

const ICON_MAP: Record<NavigationModuleKey, React.ComponentType<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  combined_orders: ShoppingBag,
  hotel: Hotel,
  atv: Compass,
  breakfast: Utensils,
  extra_income: Coins,
  inventory: Boxes,
  agent_fee: Percent,
  create_document: FilePlus2,
  contracts: FileCheck,
  penawaran: FilePlus2,
  document_archive: FileArchive,
  leads: Users,
  influencers: Megaphone,
  partners: Handshake,
  monthly_revenue: TrendingUp,
  reports: BarChart3,
  calendar: CalendarDays,
  rundown: ListTodo,
  settings: Sparkles,
  users: Users,
};

export const ModulePlaceholder: React.FC<ModulePlaceholderProps> = ({
  moduleKey,
  title,
  category,
  description,
}) => {
  const Icon = ICON_MAP[moduleKey] || Sparkles;

  return (
    <div id={`module-placeholder-${moduleKey}`} className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-md border border-blue-100">
            {category}
          </span>
          <span className="text-xs text-slate-400 font-medium">• Roadmap Bukit Langit</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900">{title}</h2>
        <p className="text-sm text-slate-500 mt-1">{description}</p>
      </div>

      {/* Modern Placeholder Card */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 shadow-sm text-center flex flex-col items-center justify-center min-h-[380px]"
      >
        <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center mb-5 shadow-xs">
          <Icon className="w-8 h-8" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 mb-3">
          <Clock className="w-3.5 h-3.5" />
          <span>Modul ini dibangun pada tahap berikutnya</span>
        </div>

        <h3 className="text-lg font-bold text-slate-900 mb-2">
          Layanan {title} Segera Hadir
        </h3>

        <p className="text-sm text-slate-500 max-w-md leading-relaxed mb-6">
          Koleksi Firestore dan antarmuka interaktif untuk fitur {title} telah disiapkan dan akan diaktifkan secara bertahap pada pembaruan berikutnya sesuai roadmap operasional Bukit Langit.
        </p>

        <div className="flex flex-wrap gap-2 justify-center text-xs text-slate-400 bg-slate-50 border border-slate-100 p-3 rounded-xl max-w-md w-full">
          <span className="font-medium text-slate-600">Status Koleksi:</span>
          <span>Siap dihubungkan ke Firestore</span>
        </div>
      </motion.div>
    </div>
  );
};
