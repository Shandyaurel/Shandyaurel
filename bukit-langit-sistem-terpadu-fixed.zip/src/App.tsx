/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { LoginView } from './components/auth/LoginView';
import { AccessDeniedView } from './components/auth/AccessDeniedView';
import { Shell } from './components/layout/Shell';
import { Compass, AlertCircle, RefreshCw, LogOut } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentUser, isAllowed, isLoading, refreshProfile, logout } = useAuth();
  const [hasTimedOut, setHasTimedOut] = useState<boolean>(false);

  useEffect(() => {
    if (!isLoading) {
      setHasTimedOut(false);
      return;
    }
    const timer = setTimeout(() => {
      setHasTimedOut(true);
    }, 6000); // 6 seconds timeout threshold

    return () => clearTimeout(timer);
  }, [isLoading]);

  if (isLoading) {
    return (
      <div
        id="app-loading-screen"
        className="min-h-screen w-full bg-[#F8FAFC] flex flex-col items-center justify-center p-6 text-center"
      >
        <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-100 text-blue-600 flex items-center justify-center mb-4 animate-pulse">
          <Compass className="w-8 h-8" />
        </div>
        <h2 className="text-base font-bold text-slate-900 tracking-tight">Bukit Langit</h2>
        
        {!hasTimedOut ? (
          <div className="flex items-center gap-2 mt-2">
            <div className="w-4 h-4 border-2 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
            <span className="text-xs text-slate-500 font-medium">Memverifikasi status akses...</span>
          </div>
        ) : (
          <div className="mt-4 max-w-sm w-full bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2 text-amber-600 text-xs font-semibold justify-center">
              <AlertCircle className="w-4 h-4" />
              <span>Koneksi lambat atau sedang memulihkan sesi</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Pemeriksaan status akses memerlukan waktu lebih lama dari biasanya. Anda dapat mencoba lagi atau keluar untuk masuk kembali.
            </p>
            <div className="flex items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setHasTimedOut(false);
                  refreshProfile();
                }}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Coba Lagi</span>
              </button>
              <button
                type="button"
                onClick={() => logout()}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Keluar</span>
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (!currentUser) {
    return <LoginView />;
  }

  if (!isAllowed) {
    return <AccessDeniedView />;
  }

  return <Shell />;
};

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ToastProvider>
  );
}
