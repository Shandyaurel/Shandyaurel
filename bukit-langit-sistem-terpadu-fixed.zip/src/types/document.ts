export type LeadStatus = 'New Lead' | 'Contacted' | 'Warm Inquiry' | 'Tentative' | 'Confirmed' | 'Checked In' | 'Completed' | 'Lost' | 'Cancelled';
export type CampaignSource = 'Instagram' | 'Facebook' | 'Google' | 'TikTok' | 'WhatsApp' | 'Website' | 'Referral' | 'Walk-in' | 'OTA' | 'Event' | 'Other';
export type BookingType = 'Hotel' | 'ATV' | 'Combined' | 'Event' | 'Meeting' | 'Other';

export interface ActivityLogItem {
  id: string;
  date: string;
  type: 'call' | 'whatsapp' | 'email' | 'meeting' | 'note' | 'status_change' | 'promo_sent';
  summary: string;
  performedBy: string;
  nextFollowUpDate?: string;
}

export interface Lead {
  id: string;
  guestName: string;
  whatsAppNumber: string;
  email?: string;
  groupName?: string;
  groupSize?: number;
  bookingType: BookingType;
  campaignSource: CampaignSource;
  status: LeadStatus;
  priority: 'High' | 'Medium' | 'Low';
  plannedCheckInDate?: string;
  plannedCheckOutDate?: string;
  estimatedBudget?: number;
  notes?: string;
  assignedTo?: string;
  nextFollowUpDate?: string;
  lastContactedDate?: string;
  activityLog?: ActivityLogItem[];
  promoSentAt?: string;
  promoSentBy?: string;
  promoStatus?: 'not_sent' | 'sent' | 'clicked' | 'responded';
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type { BusinessSettings } from './index';
