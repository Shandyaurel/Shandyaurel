export type PaymentStatus = 'Draft' | 'Unpaid' | 'DP Paid' | 'Partially Paid' | 'Paid' | 'Overpaid' | 'Refunded';
export type BookingStatus = 'Pending' | 'Confirmed' | 'Checked In' | 'Checked Out' | 'Cancelled' | 'No Show';
export type ATVBookingStatus = 'Pending' | 'Confirmed' | 'In Progress' | 'Completed' | 'Cancelled' | 'No Show';
export type DiscountType = 'none' | 'percentage' | 'fixed';
export type AgentFeeStatus = 'Pending' | 'Approved' | 'Rejected' | 'Paid';
export type DocumentType = 'invoice' | 'receipt' | 'quotation' | 'contract' | 'proforma' | 'delivery_order' | 'purchase_order';
export type QuotationStatus = 'Draft' | 'Sent' | 'Accepted' | 'Rejected' | 'Expired' | 'Converted';
export type FollowUpStatus = 'Planned' | 'Done' | 'Skipped' | 'Overdue';
export type CalendarDisplayMode = 'embed' | 'interactive' | 'sync_overview';

export type NavigationModuleKey =
  | 'dashboard'
  | 'combined_orders'
  | 'hotel'
  | 'atv'
  | 'breakfast'
  | 'extra_income'
  | 'inventory'
  | 'agent_fee'
  | 'create_document'
  | 'penawaran'
  | 'contracts'
  | 'document_archive'
  | 'leads'
  | 'influencers'
  | 'partners'
  | 'monthly_revenue'
  | 'reports'
  | 'calendar'
  | 'rundown'
  | 'settings'
  | 'users';

export interface NavigationItem {
  id: NavigationModuleKey;
  label: string;
  permissionKey: string;
  iconName: string;
  adminOnly?: boolean;
}

export interface NavigationGroup {
  title: string;
  items: NavigationItem[];
}

export interface PaymentRecord {
  id: string;
  date: string;
  amount: number;
  method: string;
  notes?: string;
  receivedBy?: string;
}

export interface BookingRoomItem {
  roomType: string;
  roomQty: number;
  roomPrice: number;
  nights: number;
}

export interface Booking {
  id: string;
  date: string;
  guestName: string;
  guestPhone: string;
  guestEmail?: string;
  roomType?: string;
  rooms?: BookingRoomItem[];
  checkInDate: string;
  checkOutDate: string;
  nights: number;
  subtotal: number;
  discount: number;
  discountType: DiscountType;
  discountValue: number;
  taxRate: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
  paymentMethod: string;
  paymentRecords?: PaymentRecord[];
  status: BookingStatus;
  bookingSource: string;
  bookingVia: string;
  partnerId?: string;
  partnerName?: string;
  includeBreakfast: boolean;
  breakfastPaxPerNight: number;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  syncedToCalendarAt?: string;
}

export interface ATVTrackItem {
  trackType: string;
  qty: number;
  pricePerUnit: number;
}

export interface ATVBooking {
  id: string;
  date: string;
  guestName: string;
  guestPhone: string;
  guestEmail?: string;
  bookingDate: string;
  bookingTime: string;
  tracks?: ATVTrackItem[];
  subtotal: number;
  discount: number;
  discountType: DiscountType;
  discountValue: number;
  taxRate: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
  paymentMethod: string;
  paymentRecords?: PaymentRecord[];
  status: ATVBookingStatus;
  bookingSource: string;
  bookingVia: string;
  partnerId?: string;
  partnerName?: string;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  syncedToCalendarAt?: string;
}

export interface BreakfastRecord {
  id: string;
  date: string;
  bookingId?: string;
  guestName: string;
  guestPhone?: string;
  roomType?: string;
  paxCount: number;
  pricePerPax: number;
  totalPrice: number;
  menuNotes?: string;
  status: 'Pending' | 'Served' | 'Cancelled';
  servedBy?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface BreakfastBulkRecordChange {
  recordId: string;
  guestName: string;
  field: string;
  oldValue: string | number;
  newValue: string | number;
}

export interface BreakfastBulkEditHistoryItem {
  id: string;
  date: string;
  editedBy: string;
  editedAt: string;
  changes: BreakfastBulkRecordChange[];
  totalRecords: number;
  reason?: string;
}

export interface ExtraIncomeItem {
  id: string;
  date: string;
  guestName: string;
  guestPhone?: string;
  category: string;
  description: string;
  qty: number;
  pricePerUnit: number;
  totalPrice: number;
  paymentMethod: string;
  paymentStatus: PaymentStatus;
  paidAmount: number;
  remainingBalance: number;
  costBreakdown?: CostBreakdownItem[];
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CostBreakdownItem {
  label: string;
  qty: number;
  unitCost: number;
  total: number;
  inventoryItemId?: string;
}

export interface ExtraServiceCatalogItem {
  id: string;
  name: string;
  category: string;
  description?: string;
  defaultPrice: number;
  unit?: string;
  costBreakdown?: CostBreakdownItem[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  unit: string;
  currentStock: number;
  minStock: number;
  costPerUnit: number;
  sellPrice?: number;
  supplier?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InventoryLog {
  id: string;
  itemId: string;
  itemName: string;
  type: 'in' | 'out' | 'adjustment';
  quantity: number;
  reason: string;
  date: string;
  createdBy: string;
  createdAt: string;
}

export interface AgentFee {
  id: string;
  bookingId?: string;
  atvBookingId?: string;
  combinedOrderId?: string;
  transactionType: 'hotel' | 'atv' | 'combined_order';
  guestName: string;
  partnerName: string;
  partnerId: string;
  commissionPercentage: number;
  commissionAmount: number;
  transactionAmount: number;
  status: AgentFeeStatus;
  paymentMethod?: string;
  paidDate?: string;
  notes?: string;
  approvedBy?: string;
  rejectedBy?: string;
  rejectionReason?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankAccount {
  bankName: string;
  accountNumber: string;
  accountName: string;
}

export interface DocumentLineItem {
  description: string;
  qty: number;
  unit?: string;
  pricePerUnit: number;
  amount: number;
  notes?: string;
}

export interface RoomRateItem {
  roomType: string;
  weekdayRate: number;
  weekendRate: number;
  highSeasonRate: number;
  maxOccupancy: number;
  notes?: string;
}

export interface PackageTable {
  packageName: string;
  items: { description: string; qty: number; unit: string; price: number }[];
  totalPerPax: number;
  minPax: number;
  notes?: string;
}

export interface MeetingPackageItem {
  packageName: string;
  pricePerPax: number;
  minPax: number;
  includes: string[];
  notes?: string;
}

export interface KlausulKontrakItem {
  id: string;
  title: string;
  content: string;
  order: number;
}

export interface FinancialDocument {
  id: string;
  documentType: DocumentType;
  documentTitle: string;
  documentNumber: string;
  documentDate: string;
  validUntil?: string;
  guestName: string;
  guestPhone?: string;
  guestEmail?: string;
  guestOrganization?: string;
  guestAddress?: string;
  stayDate?: string;
  checkInDate?: string;
  checkOutDate?: string;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  useTax: boolean;
  paymentStatus: PaymentStatus | string;
  items: DocumentLineItem[];
  notes?: string;
  bankAccount?: BankAccount;
  roomRates?: RoomRateItem[];
  packageTables?: PackageTable[];
  meetingPackages?: MeetingPackageItem[];
  klausulKontrak?: KlausulKontrakItem[];
  contractTerms?: string;
  partnerId?: string;
  partnerName?: string;
  signatory?: { name: string; title: string };
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ClientContact {
  id: string;
  companyName: string;
  contactPerson: string;
  phone: string;
  email?: string;
  address?: string;
  type: 'travel_agent' | 'corporate' | 'government' | 'ota' | 'influencer' | 'other';
  commissionRate?: number;
  notes?: string;
  contractId?: string;
  followUpLogs?: FollowUpLog[];
  meetingAgreements?: MeetingAgreement[];
  status: 'Active' | 'Inactive' | 'Prospect';
  createdAt: string;
  updatedAt: string;
}

export interface FollowUpLog {
  id: string;
  date: string;
  method: 'WhatsApp' | 'Phone' | 'Email' | 'Meeting' | 'Visit' | 'Other';
  summary: string;
  status: FollowUpStatus;
  createdBy: string;
  nextFollowUpDate?: string;
}

export interface MeetingAgreement {
  id: string;
  date: string;
  topic: string;
  attendees: string;
  agreements: string;
  nextSteps?: string;
  createdBy: string;
}

export interface Influencer {
  id: string;
  name: string;
  platform: string;
  handle: string;
  followers: number;
  category: string;
  status: 'Prospect' | 'Contacted' | 'Active' | 'Completed' | 'Declined';
  rating?: number;
  email?: string;
  phone?: string;
  notes?: string;
  campaigns?: { name: string; date: string; result?: string }[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CombinedOrder {
  id: string;
  date: string;
  guestName: string;
  guestPhone: string;
  guestEmail?: string;
  bookingSource: string;
  bookingVia: string;
  partnerId?: string;
  partnerName?: string;
  hotelItems?: BookingRoomItem[];
  checkInDate?: string;
  checkOutDate?: string;
  nights?: number;
  atvItems?: ATVTrackItem[];
  atvDate?: string;
  atvTime?: string;
  extraItems?: CombinedOrderExtraItem[];
  includeBreakfast: boolean;
  breakfastPaxPerNight: number;
  subtotal: number;
  discount: number;
  discountType: DiscountType;
  discountValue: number;
  taxRate: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  remainingBalance: number;
  paymentStatus: PaymentStatus;
  paymentMethod: string;
  paymentRecords?: PaymentRecord[];
  status: BookingStatus;
  notes?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CombinedOrderExtraItem {
  description: string;
  qty: number;
  pricePerUnit: number;
  total: number;
  category?: string;
}

export interface RundownEvent {
  id: string;
  title: string;
  date: string;
  endDate?: string;
  eventType: 'gathering' | 'wedding' | 'corporate' | 'camp' | 'custom';
  guestName?: string;
  guestPhone?: string;
  organizationName?: string;
  totalPax?: number;
  items: RundownItem[];
  totalDurationMin?: number;
  notes?: string;
  status: 'Draft' | 'Confirmed' | 'Ongoing' | 'Completed' | 'Cancelled';
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface RundownItem {
  id: string;
  time: string;
  endTime?: string;
  durationMin?: number;
  activity: string;
  pic?: string;
  location?: string;
  notes?: string;
  day?: number;
}

export interface Quotation {
  id: string;
  quotationNumber: string;
  date: string;
  validUntil: string;
  clientName: string;
  clientPhone?: string;
  clientEmail?: string;
  clientOrganization?: string;
  offerPackageId?: string;
  options: QuotationOption[];
  selectedOptionIndex?: number;
  notes?: string;
  status: QuotationStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface QuotationOption {
  title: string;
  items: DocumentLineItem[];
  subtotal: number;
  discount?: number;
  taxRate?: number;
  taxAmount?: number;
  totalAmount: number;
  notes?: string;
}

export interface OfferPackage {
  id: string;
  name: string;
  description?: string;
  category: string;
  items: DocumentLineItem[];
  minPax?: number;
  maxPax?: number;
  pricePerPax?: number;
  totalBasePrice: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface OperationalCalendar {
  id: string;
  name: string;
  calendarId: string;
  color?: string;
}

export interface GoogleCalendarEvent {
  id: string;
  summary: string;
  description?: string;
  location?: string;
  start: { date?: string; dateTime?: string; timeZone?: string };
  end: { date?: string; dateTime?: string; timeZone?: string };
  status?: string;
  htmlLink?: string;
}

export interface BusinessSettings {
  businessName: string;
  tagline?: string;
  logoUrl?: string;
  address?: string;
  phone?: string;
  email?: string;
  website?: string;
  npwp?: string;
  bankAccounts?: BankAccount[];
  defaultTaxRate?: number;
  breakfastPricePerPax?: number;
  defaultBreakfastIncluded?: boolean;
  calendarId?: string;
  calendarEmbedUrl?: string;
  calendarTimezone?: string;
  calendarDefaultView?: 'MONTH' | 'WEEK' | 'AGENDA';
  operationalCalendars?: OperationalCalendar[];
  googleCalendarAutoSync?: boolean;
  roomTypes?: { name: string; basePrice: number; maxOccupancy: number }[];
  atvTracks?: { name: string; basePrice: number }[];
  leadFollowUpDaysTentative?: number;
  leadFollowUpDaysConfirmed?: number;
  signatory?: { name: string; title: string };
  whatsappTemplates?: Record<string, string>;
  createdAt?: string;
  updatedAt?: string;
}

export interface MonthlyTarget {
  id: string;
  month: string;
  hotelRevenue?: number;
  atvRevenue?: number;
  extraRevenue?: number;
  totalRevenue?: number;
  bookingCount?: number;
  occupancyRate?: number;
  notes?: string;
}

export interface SystemLog {
  id: string;
  action: string;
  module: string;
  details: string;
  performedBy: string;
  timestamp: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin' | 'staff';
  permissions: Record<string, boolean>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  duration?: number;
}
