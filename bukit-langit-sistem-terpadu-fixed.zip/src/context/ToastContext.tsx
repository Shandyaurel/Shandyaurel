import React, { createContext, useContext, useState, useCallback } from 'react';
import { ToastMessage } from '../types';
import { Toast } from '../components/common/Toast';

interface ToastContextType {
  showSuccess: (message: string, title?: string) => void;
  showError: (message: string, title?: string) => void;
  showInfo: (message: string, title?: string) => void;
  showWarning: (message: string, title?: string) => void;
  showToast: (type: ToastMessage['type'], title: string, message: string) => void;
}

const ToastContext = createContext<ToastContextType>({
  showSuccess: () => {},
  showError: () => {},
  showInfo: () => {},
  showWarning: () => {},
  showToast: () => {},
});

export const useToast = () => useContext(ToastContext);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((type: ToastMessage['type'], title: string, message: string, duration = 4000) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev, { id, type, title, message, duration }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, duration);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showSuccess = useCallback((message: string, title?: string) => {
    addToast('success', title || 'Berhasil', message);
  }, [addToast]);

  const showError = useCallback((message: string, title?: string) => {
    addToast('error', title || 'Gagal', message, 6000);
  }, [addToast]);

  const showInfo = useCallback((message: string, title?: string) => {
    addToast('info', title || 'Info', message);
  }, [addToast]);

  const showWarning = useCallback((message: string, title?: string) => {
    addToast('warning', title || 'Peringatan', message, 5000);
  }, [addToast]);

  const showToast = useCallback((type: ToastMessage['type'], title: string, message: string) => {
    addToast(type, title, message);
  }, [addToast]);

  return (
    <ToastContext.Provider value={{ showSuccess, showError, showInfo, showWarning, showToast }}>
      {children}
      <div className="fixed top-4 right-4 z-[9999] space-y-2 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => (
          <Toast key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
};
