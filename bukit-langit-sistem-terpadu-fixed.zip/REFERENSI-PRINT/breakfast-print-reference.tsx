// ============================================================
// REFERENSI KODE PRINT BREAKFAST (dari sistem lama rsvsbl)
// AI Studio: reproduksi LAYOUT/HTML/CSS ini PERSIS untuk 3 print:
//   (1) printBreakfastVouchers  -> Print Voucher (untuk tamu, 8/halaman, dipotong)
//   (2) printBreakfast('guest')  -> Print Guest (daftar A4 untuk resto)
//   (3) printBreakfast('detail') -> Print Detail (harga + ringkasan untuk accounting)
// Adaptasi sumber datanya ke record breakfast + settings app baru. JANGAN ubah tampilannya.
// ============================================================

import { BreakfastRecord, BusinessSettings } from '../src/types';

// Helper formatters
function formatDate(dateStr: string): string {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

function formatIDR(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount || 0);
}

// ---------- (1) VOUCHER ----------
export const printBreakfastVouchers = (
  selectedBreakfasts: BreakfastRecord[],
  printTemplate: {
    namaPerusahaan: string;
    logoUrl?: string;
  },
  onMessage?: (msg: string) => void,
) => {
  if (!selectedBreakfasts || selectedBreakfasts.length === 0) {
    if (onMessage) onMessage('Tidak ada data breakfast untuk dicetak dalam filter/pilihan saat ini.');
    return;
  }

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    if (onMessage) onMessage('Gagal membuka jendela cetak. Pastikan pop-up tidak diblokir browser.');
    return;
  }

  const logoHtml = printTemplate.logoUrl 
    ? `<img src="${printTemplate.logoUrl}" alt="Logo" style="max-height: 45px; object-fit: contain;" />` 
    : `<div style="font-weight: 900; font-size: 20px; color: #1e3a8a;">${printTemplate.namaPerusahaan}</div>`;

  printWindow.document.open();
  printWindow.document.write(`
    <html>
      <head>
        <title>Breakfast Vouchers - ${printTemplate.namaPerusahaan}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&display=swap');
          @page { 
            size: A4; 
            margin: 10mm 10mm; 
          }
          body { 
            margin: 0; 
            padding: 0; 
            font-family: 'Montserrat', sans-serif;
            background: #fff;
            color: #333;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
            box-sizing: border-box;
          }
          .voucher-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0;
            width: 190mm;
            margin: 0 auto;
            border-top: 1px dashed #000;
            border-left: 1px dashed #000;
            box-sizing: border-box;
          }
          .page-container {
            width: 100%;
            height: 275mm;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            box-sizing: border-box;
          }
          .voucher {
            border-right: 1px dashed #000;
            border-bottom: 1px dashed #000;
            padding: 8px 18px;
            border-radius: 0;
            position: relative;
            height: 66mm;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background: #f8fafc !important;
            overflow: hidden;
            box-sizing: border-box;
            break-inside: avoid;
            page-break-inside: avoid;
          }
          .voucher::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: #1e3a8a;
          }
          .voucher-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding-bottom: 5px;
          }
          .voucher-title {
            font-size: 10px;
            font-weight: 800;
            color: #1e3a8a;
            text-transform: uppercase;
            letter-spacing: 1.2px;
          }
          .voucher-body {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 2px 0;
            text-align: center;
          }
          .guest-info {
            margin-bottom: 2px;
          }
          .guest-name {
            font-size: 17px;
            font-weight: 700;
            color: #0f172a;
            margin: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .room-info {
            font-size: 12px;
            color: #64748b;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
          }
          .pax-info {
            font-size: 14px;
            font-weight: 700;
            color: #2563eb;
            margin-top: 2px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
          }
          .validity {
            font-size: 10px;
            color: #475569;
            font-weight: 500;
            margin-top: 4px;
            background: rgba(255,255,255,0.5);
            padding: 3px 10px;
            border-radius: 4px;
            display: inline-block;
          }
          .footer-note {
            font-size: 8px;
            color: #475569;
            line-height: 1.3;
            border-top: 1px solid rgba(0,0,0,0.05);
            padding-top: 4px;
            font-style: italic;
            text-align: right;
          }
          .watermark {
            position: absolute;
            bottom: -10px;
            right: -10px;
            opacity: 0.02;
            transform: rotate(-15deg);
            font-size: 40px;
            font-weight: 900;
            pointer-events: none;
          }
          @media print {
            body { 
              padding: 0; 
              margin: 0; 
              -webkit-print-color-adjust: exact; 
              print-color-adjust: exact;
            }
            .page-break {
              page-break-after: always !important;
              break-after: page !important;
            }
            @media print {
              .page-container {
                height: 270mm;
                overflow: hidden;
              }
            }
            .voucher { 
              break-inside: avoid; 
              page-break-inside: avoid; 
              box-shadow: none; 
              border-color: #000; 
              background-color: #f8fafc !important;
            }
            .voucher::before { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .validity { -webkit-print-color-adjust: exact; print-color-adjust: exact; background: rgba(255,255,255,0.5) !important; }
          }
        </style>
      </head>
      <body>
        ${(() => {
          const chunks = [];
          for (let i = 0; i < selectedBreakfasts.length; i += 8) {
            chunks.push(selectedBreakfasts.slice(i, i + 8));
          }
          return chunks.map((chunk, index) => `
            <div class="page-container ${index < chunks.length - 1 ? 'page-break' : ''}">
              <div class="voucher-container">
                ${chunk.map(b => `
                  <div class="voucher">
                    <div class="watermark">BREAKFAST</div>
                    <div class="voucher-header">
                      <div class="voucher-title">BREAKFAST VOUCHER</div>
                      ${logoHtml}
                    </div>
                    <div class="voucher-body">
                      <div class="guest-info">
                        <p class="guest-name">${b.guestName}</p>
                        <div class="room-info">
                          <span>Room:</span>
                          <span style="color: #1e3a8a;">${b.roomType ? `${b.roomType} - ${b.roomNumber || '...'}` : (b.roomName || '-')}</span>
                        </div>
                      </div>
                      <div class="pax-info">
                        <span>Untuk:</span>
                        <span>${b.qty} Orang</span>
                      </div>
                      <div class="validity">
                        🕒 07.00 – 10.00 WIB
                        <br/>Tanggal: ${formatDate(b.date)}
                      </div>
                    </div>
                    <div class="footer-note">
                      Voucher beserta nomor kamar Anda<br/>
                      wajib ditunjukkan kepada<br/>
                      pramusaji pada saat pemesanan.
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>
          `).join('');
        })()}
        <script>
          window.onload = () => {
            window.print();
          };
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
};


// ---------- (2)+(3) GUEST + DETAIL ----------
export const printBreakfast = (
  mode: 'guest' | 'detail',
  data: BreakfastRecord[],
  printTemplate: {
    namaPerusahaan: string;
    logoUrl?: string;
    breakfastDibuatNama?: string;
    breakfastDibuatJabatan?: string;
    breakfastMengetahuiNama?: string;
    breakfastMengetahuiJabatan?: string;
  },
  breakfastFilterDate?: string,
  breakfastFilterEndDate?: string,
) => {
  const filteredBreakfasts = data;
  
  const groupedByDate: Record<string, BreakfastRecord[]> = {};
  const summaryByDateAndType: Record<string, Record<string, { pax: number, total: number, type: string, price: number }>> = {};

  filteredBreakfasts.forEach(b => {
    // Group for daily details
    if (!groupedByDate[b.date]) groupedByDate[b.date] = [];
    groupedByDate[b.date].push(b);

    // Group for summary page
    if (!summaryByDateAndType[b.date]) summaryByDateAndType[b.date] = {};
    const rType = b.roomType || 'Lainnya';
    const rPrice = b.price || 0;
    const key = `${rType}_${rPrice}`;
    if (!summaryByDateAndType[b.date][key]) summaryByDateAndType[b.date][key] = { pax: 0, total: 0, type: rType, price: rPrice };
    summaryByDateAndType[b.date][key].pax += b.qty;
    summaryByDateAndType[b.date][key].total += (b.qty * rPrice);
  });

  const dates = Object.keys(groupedByDate).sort();

  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const logoHtml = printTemplate.logoUrl 
    ? `<div style="text-align: center; margin-bottom: 10px;"><img src="${printTemplate.logoUrl}" alt="Logo" style="max-height: 60px;" /></div>` 
    : '';

  printWindow.document.write(`
    <html>
      <head>
        <title>Laporan Breakfast</title>
        <style>
          body { font-family: 'Courier New', Courier, monospace; padding: 20px; font-size: 12px; }
          h1 { text-align: center; font-size: 16px; margin-bottom: 5px; text-transform: uppercase; }
          p.subtitle { text-align: center; margin-top: 0; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th, td { border-bottom: 1px dashed #000; padding: 8px; text-align: left; }
          .total-section { border-top: 2px solid #000; padding-top: 10px; font-weight: bold; }
          .flex-between { display: flex; justify-content: space-between; }
          .text-right { text-align: right; }
          .text-center { text-align: center; }
          .page-break { page-break-after: always; }
          .summary-title { font-size: 14px; font-bold: true; margin-top: 30px; border-bottom: 2px solid #000; padding-bottom: 5px; }
        </style>
      </head>
      <body>
        ${dates.map((date, index) => {
          const dayBreakfasts = groupedByDate[date];
          const dayTotalPax = dayBreakfasts.reduce((sum, b) => sum + b.qty, 0);
          const dayTotalPrice = dayBreakfasts.reduce((sum, b) => sum + (b.qty * (b.price || 0)), 0);
          
          // Only add page-break if it's not the last date OR if summary is coming
          const shouldBreak = index < dates.length - 1 || mode === 'detail';
          
          return `
            <div class="${shouldBreak ? 'page-break' : ''}">
              ${logoHtml}
              <h1>${printTemplate.namaPerusahaan}</h1>
              <p class="subtitle">LAPORAN RINCIAN BREAKFAST<br/>${formatDate(date)}</p>
              
              <table>
                <thead>
                  <tr>
                    <th>Tamu</th>
                    <th>Kamar</th>
                    <th class="text-center">Qty</th>
                    ${mode === 'detail' ? '<th class="text-right">Harga</th><th class="text-right">Total</th>' : ''}
                  </tr>
                </thead>
                <tbody>
                  ${dayBreakfasts.map(b => `
                    <tr>
                      <td>${b.guestName}</td>
                      <td>${b.roomType ? `${b.roomType}${b.roomNumber ? ` - ${b.roomNumber}` : ''}` : (b.roomName || '-')}</td>
                      <td class="text-center">${b.qty}</td>
                      ${mode === 'detail' ? `<td class="text-right">${formatIDR(b.price || 0)}</td><td class="text-right">${formatIDR(b.qty * (b.price || 0))}</td>` : ''}
                    </tr>
                  `).join('')}
                </tbody>
              </table>

              <div class="total-section">
                <div class="flex-between">
                  <span>Total Pax:</span>
                  <span>${dayTotalPax} Pax</span>
                </div>
                ${mode === 'detail' ? `
                <div class="flex-between">
                  <span>Total Biaya:</span>
                  <span>${formatIDR(dayTotalPrice)}</span>
                </div>
                ` : ''}
              </div>
              
              <div style="margin-top: 40px; display: flex; justify-content: space-between;">
                <div style="text-align: center; width: 150px;">
                  <p>Dibuat Oleh,</p>
                  <br/><br/><br/>
                  <p><strong>${printTemplate.breakfastDibuatNama || '................'}</strong></p>
                  <p style="font-size: 10px;">${printTemplate.breakfastDibuatJabatan || ''}</p>
                </div>
                <div style="text-align: center; width: 150px;">
                  <p>Mengetahui,</p>
                  <br/><br/><br/>
                  <p><strong>${printTemplate.breakfastMengetahuiNama || '................'}</strong></p>
                  <p style="font-size: 10px;">${printTemplate.breakfastMengetahuiJabatan || ''}</p>
                </div>
              </div>
            </div>
          `;
        }).join('')}

        ${mode === 'detail' ? `
          <!-- Halaman Ringkasan Bulanan -->
          <div class="summary-page" style="page-break-before: always;">
            ${logoHtml}
            <h1>${printTemplate.namaPerusahaan}</h1>
            <p class="subtitle">RINGKASAN LAPORAN BREAKFAST<br/>Periode: ${formatDate(breakfastFilterDate || '')} - ${formatDate(breakfastFilterEndDate || '')}</p>
            
            <div style="margin-bottom: 30px;">
              <h2 style="font-size: 14px; border-bottom: 1px solid #000; padding-bottom: 5px; margin-bottom: 10px;">RINCIAN PER TANGGAL</h2>
              <table>
                <thead>
                  <tr>
                    <th>Tanggal</th>
                    <th>Tipe Kamar</th>
                    <th class="text-center">Total Pax</th>
                    <th class="text-right">Total Biaya</th>
                  </tr>
                </thead>
                <tbody>
                  ${dates.map(date => {
                    const types = summaryByDateAndType[date];
                    return Object.values(types).map((data, idx) => `
                      <tr>
                        <td>${idx === 0 ? formatDate(date) : ''}</td>
                        <td>${data.type} (${formatIDR(data.price)})</td>
                        <td class="text-center">${data.pax} Pax</td>
                        <td class="text-right">${formatIDR(data.total)}</td>
                      </tr>
                    `).join('');
                  }).join('')}
                </tbody>
              </table>
            </div>

            <div style="margin-top: 40px; border: 2px solid #000; padding: 15px;">
              <h2 style="font-size: 14px; text-align: center; margin-bottom: 15px; text-decoration: underline;">REKAPAN TOTAL PER TIPE & HARGA</h2>
              <table style="border: none;">
                <tbody>
                  ${(() => {
                    const grandSummary: Record<string, { type: string, price: number, pax: number }> = {};
                    filteredBreakfasts.forEach(b => {
                      const type = b.roomType || b.roomName || 'Lainnya';
                      const price = b.price || 0;
                      const key = `${type}_${price}`;
                      if (!grandSummary[key]) grandSummary[key] = { type, price, pax: 0 };
                      grandSummary[key].pax += b.qty;
                    });
                    return Object.values(grandSummary)
                      .sort((a, b) => a.type.localeCompare(b.type) || a.price - b.price)
                      .map(data => `
                        <tr>
                          <td style="border: none; font-size: 14px; font-weight: bold;">${data.type} (${formatIDR(data.price)})</td>
                          <td style="border: none; font-size: 14px; font-weight: bold; text-align: right;">: ${data.pax} Pax</td>
                        </tr>
                      `).join('');
                  })()}
                </tbody>
              </table>
              
              <div class="total-section" style="margin-top: 15px; border-top: 1px solid #000; padding-top: 10px;">
                <div class="flex-between" style="font-size: 16px;">
                  <span>GRAND TOTAL SELURUHNYA:</span>
                  <span>${filteredBreakfasts.reduce((sum, b) => sum + b.qty, 0)} Pax</span>
                </div>
                <div class="flex-between" style="font-size: 16px;">
                  <span>TOTAL BIAYA KESELURUHAN:</span>
                  <span>${formatIDR(filteredBreakfasts.reduce((sum, b) => sum + (b.qty * (b.price || 0)), 0))}</span>
                </div>
              </div>
            </div>

            <div style="margin-top: 60px; display: flex; justify-content: space-between;">
              <div style="text-align: center; width: 150px;">
                <p>Admin,</p>
                <br/><br/><br/>
                <p>( ................. )</p>
              </div>
              <div style="text-align: center; width: 150px;">
                <p>Manager,</p>
                <br/><br/><br/>
                <p>( ................. )</p>
              </div>
            </div>
          </div>
        ` : ''}

        <script>
          window.onload = () => { window.print(); window.close(); };
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
};
